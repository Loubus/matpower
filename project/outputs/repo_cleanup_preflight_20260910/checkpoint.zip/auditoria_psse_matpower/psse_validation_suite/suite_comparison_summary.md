# PSS/E Validation Suite Comparison Summary

Generated from validation_matrix.csv, auditoria_all_comparison_latest.csv, and suite_control_comparison.csv.

## Artifact Counts

| artifact | count |
|---|---:|
| RAW | 69 |
| solved RAW | 69 |
| PSS/E logs | 69 |
| IDV | 69 |
| SAV | 69 |

## Category Summary

| category | cases | runpf success | max dVM | max dVA | max dQG | max dBINIT | max tap | max TWODC tap | max FACTS abs-Q |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| integrado_moderado | 8 | 8 | 0.0068241 | 0.871791 | 3.50703 | 1.5608 | 1.11022E-16 | 0 | 6.04552 |
| interaccion_simple | 18 | 18 | 0.000658245 | 0.0426816 | 0.316877 | 0.0025241 | 1.11022E-16 | 0 | 0.0406271 |
| stress_xplore | 5 | 5 | 0.00878505 | 1.0716 | 1.76153 | 1.5608 | 0 | 0 | 0.503436 |
| unitario | 38 | 38 | 0.000239847 | 0.012382 | 0.452215 | 0.0025241 | 3.33333E-06 | 0 | 0.16668 |

## Run Summary

- Suite cases compared: 69
- runpf_psse success: 69/69
- Non-stress runpf_psse success: 64/64
- Outlier/review rows: 4

## Outliers And Review Rows

| status | case | category | reason | dVM | dVA | dQG | dBINIT | tap | TWODC tap | FACTS abs-Q |
|---|---|---|---|---:|---:|---:|---:|---:|---:|---:|
| review | suite_m_integrated_14bus_dctaps0 | integrado_moderado | dVM>0.005 | 0.0068241 | 0.871791 | 3.50703 | 0 | 1.11022E-16 | 0 | 6.03742 |
| review | suite_m_integrated_14bus_flatst1 | integrado_moderado | dVM>0.005 | 0.00679537 | 0.871516 | 3.40897 | 0 | 1.11022E-16 | 0 | 6.04552 |
| review | suite_m_integrated_14bus_nominal | integrado_moderado | dVM>0.005 | 0.00679537 | 0.871516 | 3.40897 | 0 | 1.11022E-16 | 0 | 6.04552 |
| review | suite_m_integrated_14bus_varlim0 | integrado_moderado | dVM>0.005 | 0.00679537 | 0.871516 | 3.40897 | 0 | 1.11022E-16 | 0 | 6.04552 |

## Source Reports

- Full harness CSV: C:\Users\santi\Documents\UNIVERSIDAD\PROYECTO FINAL DE CARRERA - MATPOWER\auditoria_psse_matpower\results\psse_cli_comparison\auditoria_all_comparison_latest.csv
- Full harness Markdown: C:\Users\santi\Documents\UNIVERSIDAD\PROYECTO FINAL DE CARRERA - MATPOWER\auditoria_psse_matpower\results\psse_cli_comparison\auditoria_all_comparison_latest.md
- Suite filtered CSV: C:\Users\santi\Documents\UNIVERSIDAD\PROYECTO FINAL DE CARRERA - MATPOWER\auditoria_psse_matpower\psse_validation_suite\suite_comparison_latest.csv
- Suite control-state CSV: C:\Users\santi\Documents\UNIVERSIDAD\PROYECTO FINAL DE CARRERA - MATPOWER\auditoria_psse_matpower\psse_validation_suite\suite_control_comparison.csv
- Suite outliers CSV: C:\Users\santi\Documents\UNIVERSIDAD\PROYECTO FINAL DE CARRERA - MATPOWER\auditoria_psse_matpower\psse_validation_suite\suite_outliers.csv
