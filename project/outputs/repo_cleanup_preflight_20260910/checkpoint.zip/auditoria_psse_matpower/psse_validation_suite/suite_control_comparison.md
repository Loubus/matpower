# Suite Control-State Comparison

This auxiliary report complements `compare_psse_cli_cases('AUDITORIA_ALL')` for `psse_validation_suite` only. It compares switched-shunt deltas from the main CSV, transformer/two-terminal-DC taps from solved RAW exports, and FACTS reactive magnitudes parsed from PSS/E logs against `runpf_psse` state fields when available.

| case | category | success | tap count | tap count status | tap diff | TWODC tap diff | FACTS | BINIT diff | notes |
|---|---|---:|---:|---|---:|---:|---:|---:|---|
| suite_i_facts_4bus_remote_group | interaccion_simple | 1 | 0/0 | no_taps | NaN | NaN | 0.0347762 | NaN |  |
| suite_i_facts_pqbrak_remote_limit | interaccion_simple | 1 | 0/0 | no_taps | NaN | NaN | 0.0406271 | NaN |  |
| suite_i_genq_flatst1_qmax | interaccion_simple | 1 | 0/NaN |  | NaN | NaN | NaN | NaN | main comparison covers VM/VA/QG/SWSHNT; no extra tap/FACTS/TWODC state |
| suite_i_genq_nondiv1_qmin | interaccion_simple | 1 | 0/NaN |  | NaN | NaN | NaN | NaN | main comparison covers VM/VA/QG/SWSHNT; no extra tap/FACTS/TWODC state |
| suite_i_genq_varlim0_remote_group | interaccion_simple | 1 | 0/NaN |  | NaN | NaN | NaN | NaN | main comparison covers VM/VA/QG/SWSHNT; no extra tap/FACTS/TWODC state |
| suite_i_pqbrak_genq_remote_single | interaccion_simple | 1 | 0/NaN |  | NaN | NaN | NaN | NaN | main comparison covers VM/VA/QG/SWSHNT; no extra tap/FACTS/TWODC state |
| suite_i_solver_all_options_3bus | interaccion_simple | 1 | 0/NaN |  | NaN | NaN | NaN | NaN | main comparison covers VM/VA/QG/SWSHNT; no extra tap/FACTS/TWODC state |
| suite_i_swdev_open_parallel_pqbrak | interaccion_simple | 1 | 0/NaN |  | NaN | NaN | NaN | NaN | main comparison covers VM/VA/QG/SWSHNT; no extra tap/FACTS/TWODC state |
| suite_i_swdev_tight_thrshz_closed | interaccion_simple | 1 | 0/NaN |  | NaN | NaN | NaN | NaN | main comparison covers VM/VA/QG/SWSHNT; no extra tap/FACTS/TWODC state |
| suite_i_swshnt_flatst1_continuous | interaccion_simple | 1 | 0/NaN |  | NaN | NaN | NaN | 0.0025241 | main comparison covers VM/VA/QG/SWSHNT; no extra tap/FACTS/TWODC state |
| suite_i_swshnt_pqbrak_remote_group | interaccion_simple | 1 | 0/NaN |  | NaN | NaN | NaN | 0 | main comparison covers VM/VA/QG/SWSHNT; no extra tap/FACTS/TWODC state |
| suite_i_twodc_dctaps0_active | interaccion_simple | 1 | 0/0 | no_taps | NaN | 0 | NaN | NaN |  |
| suite_i_twodc_varlim1_loss | interaccion_simple | 1 | 0/0 | no_taps | NaN | 0 | NaN | NaN |  |
| suite_i_ultc_10bus_sign_matrix | interaccion_simple | 1 | 7/7 | match | 0 | NaN | NaN | NaN |  |
| suite_i_ultc_multi_2w_shared | interaccion_simple | 1 | 2/2 | match | 0 | NaN | NaN | NaN |  |
| suite_i_ultc_multi_3w_cw2_shared | interaccion_simple | 1 | 6/6 | match | 0 | NaN | NaN | NaN |  |
| suite_i_ultc_nondiv1_local | interaccion_simple | 1 | 1/1 | match | 1.11022e-16 | NaN | NaN | NaN |  |
| suite_i_ultc_varlim1_remote_limit | interaccion_simple | 1 | 1/1 | match | 0 | NaN | NaN | NaN |  |
| suite_m_integrated_14bus_dctaps0 | integrado_moderado | 1 | 1/1 | match | 1.11022e-16 | 0 | 6.03742 | 0 |  |
| suite_m_integrated_14bus_flatst1 | integrado_moderado | 1 | 1/1 | match | 1.11022e-16 | 0 | 6.04552 | 0 |  |
| suite_m_integrated_14bus_nominal | integrado_moderado | 1 | 1/1 | match | 1.11022e-16 | 0 | 6.04552 | 0 |  |
| suite_m_integrated_14bus_varlim0 | integrado_moderado | 1 | 1/1 | match | 1.11022e-16 | 0 | 6.04552 | 0 |  |
| suite_m_integrated_30bus_conservative_adjust | integrado_moderado | 1 | 5/5 | match | 0 | 0 | 0.50414 | 1.5608 |  |
| suite_m_integrated_30bus_flatst1 | integrado_moderado | 1 | 5/5 | match | 0 | 0 | 0.503436 | 1.5608 |  |
| suite_m_integrated_30bus_nominal | integrado_moderado | 1 | 5/5 | match | 0 | 0 | 0.503436 | 1.5608 |  |
| suite_m_integrated_30bus_swsht1 | integrado_moderado | 1 | 5/5 | match | 0 | 0 | 0.503436 | 1.5608 |  |
| suite_s_30bus_nondiv1 | stress_xplore | 1 | 5/5 | match | 0 | 0 | 0.503436 | 1.5608 |  |
| suite_s_30bus_pqbrak_high | stress_xplore | 1 | 5/5 | match | 0 | 0 | 0.503436 | 1.5608 |  |
| suite_s_40bus_dctaps0 | stress_xplore | 0 | 2/2 | match | 0 | 0 | NaN | 0 |  |
| suite_s_40bus_nominal | stress_xplore | 0 | 2/2 | match | 0 | 0 | NaN | 0 |  |
| suite_s_40bus_varlim0 | stress_xplore | 0 | 2/2 | match | 0 | 0 | NaN | 0 |  |
| suite_u_facts_3bus_local | unitario | 1 | 0/0 | no_taps | NaN | NaN | 0.00870989 | NaN |  |
| suite_u_facts_3bus_remote | unitario | 1 | 0/0 | no_taps | NaN | NaN | 0.16668 | NaN |  |
| suite_u_facts_3bus_remote_limit | unitario | 1 | 0/0 | no_taps | NaN | NaN | 0.0121926 | NaN |  |
| suite_u_genq_3bus_local_inband | unitario | 1 | 0/NaN |  | NaN | NaN | NaN | NaN | main comparison covers VM/VA/QG/SWSHNT; no extra tap/FACTS/TWODC state |
| suite_u_genq_3bus_qmax | unitario | 1 | 0/NaN |  | NaN | NaN | NaN | NaN | main comparison covers VM/VA/QG/SWSHNT; no extra tap/FACTS/TWODC state |
| suite_u_genq_3bus_qmin | unitario | 1 | 0/NaN |  | NaN | NaN | NaN | NaN | main comparison covers VM/VA/QG/SWSHNT; no extra tap/FACTS/TWODC state |
| suite_u_genq_3bus_qzero | unitario | 1 | 0/NaN |  | NaN | NaN | NaN | NaN | main comparison covers VM/VA/QG/SWSHNT; no extra tap/FACTS/TWODC state |
| suite_u_genq_3bus_slack_limit | unitario | 1 | 0/NaN |  | NaN | NaN | NaN | NaN | main comparison covers VM/VA/QG/SWSHNT; no extra tap/FACTS/TWODC state |
| suite_u_genq_4bus_remote_single | unitario | 1 | 0/NaN |  | NaN | NaN | NaN | NaN | main comparison covers VM/VA/QG/SWSHNT; no extra tap/FACTS/TWODC state |
| suite_u_genq_5bus_group_all_limited | unitario | 1 | 0/NaN |  | NaN | NaN | NaN | NaN | main comparison covers VM/VA/QG/SWSHNT; no extra tap/FACTS/TWODC state |
| suite_u_genq_5bus_group_one_limited | unitario | 1 | 0/NaN |  | NaN | NaN | NaN | NaN | main comparison covers VM/VA/QG/SWSHNT; no extra tap/FACTS/TWODC state |
| suite_u_genq_5bus_remote_group | unitario | 1 | 0/NaN |  | NaN | NaN | NaN | NaN | main comparison covers VM/VA/QG/SWSHNT; no extra tap/FACTS/TWODC state |
| suite_u_pqbrak_3bus_basic | unitario | 1 | 0/NaN |  | NaN | NaN | NaN | NaN | main comparison covers VM/VA/QG/SWSHNT; no extra tap/FACTS/TWODC state |
| suite_u_swdev_3bus_closed | unitario | 1 | 0/NaN |  | NaN | NaN | NaN | NaN | main comparison covers VM/VA/QG/SWSHNT; no extra tap/FACTS/TWODC state |
| suite_u_swshnt_2bus_continuous_local | unitario | 1 | 0/NaN |  | NaN | NaN | NaN | 0.0025241 | main comparison covers VM/VA/QG/SWSHNT; no extra tap/FACTS/TWODC state |
| suite_u_swshnt_2bus_discrete_local | unitario | 1 | 0/NaN |  | NaN | NaN | NaN | 0 | main comparison covers VM/VA/QG/SWSHNT; no extra tap/FACTS/TWODC state |
| suite_u_swshnt_2bus_discrete_swsht1 | unitario | 1 | 0/NaN |  | NaN | NaN | NaN | 0 | main comparison covers VM/VA/QG/SWSHNT; no extra tap/FACTS/TWODC state |
| suite_u_swshnt_3bus_remote_group | unitario | 1 | 0/NaN |  | NaN | NaN | NaN | 0 | main comparison covers VM/VA/QG/SWSHNT; no extra tap/FACTS/TWODC state |
| suite_u_twodc_4bus_base | unitario | 1 | 0/0 | no_taps | NaN | NaN | NaN | NaN |  |
| suite_u_twodc_5bus_active | unitario | 1 | 0/0 | no_taps | NaN | 0 | NaN | NaN |  |
| suite_u_ultc_2bus_actaps_off | unitario | 1 | 1/1 | match | 0 | NaN | NaN | NaN |  |
| suite_u_ultc_2bus_cod0 | unitario | 1 | 1/1 | match | 0 | NaN | NaN | NaN |  |
| suite_u_ultc_2bus_cod_m1 | unitario | 1 | 1/1 | match | 0 | NaN | NaN | NaN |  |
| suite_u_ultc_2bus_cont0 | unitario | 1 | 1/1 | match | 0 | NaN | NaN | NaN |  |
| suite_u_ultc_2bus_cont_pos | unitario | 1 | 1/1 | match | 1.11022e-16 | NaN | NaN | NaN |  |
| suite_u_ultc_2bus_cw2 | unitario | 1 | 1/1 | match | 0 | NaN | NaN | NaN |  |
| suite_u_ultc_2bus_local | unitario | 1 | 1/1 | match | 1.11022e-16 | NaN | NaN | NaN |  |
| suite_u_ultc_2bus_ntp10_inband | unitario | 1 | 1/1 | match | 1.11111e-06 | NaN | NaN | NaN |  |
| suite_u_ultc_2bus_ntp10_lowv | unitario | 1 | 1/1 | match | 3.33333e-06 | NaN | NaN | NaN |  |
| suite_u_ultc_2bus_tab | unitario | 1 | 1/1 | match | 1.11022e-16 | NaN | NaN | NaN |  |
| suite_u_ultc_3bus_remote | unitario | 1 | 1/1 | match | 0 | NaN | NaN | NaN |  |
| suite_u_ultc_3bus_remote_cont_pos | unitario | 1 | 1/1 | match | 1.11022e-16 | NaN | NaN | NaN |  |
| suite_u_ultc_3bus_remote_limit | unitario | 1 | 1/1 | match | 0 | NaN | NaN | NaN |  |
| suite_u_ultc_3w_tab | unitario | 1 | 3/3 | match | 0 | NaN | NaN | NaN |  |
| suite_u_ultc_3w_tab_cw2 | unitario | 1 | 3/3 | match | 0 | NaN | NaN | NaN |  |
| suite_u_ultc_3w_w2 | unitario | 1 | 3/3 | match | 0 | NaN | NaN | NaN |  |
| suite_u_ultc_3w_w2_cw2 | unitario | 1 | 3/3 | match | 0 | NaN | NaN | NaN |  |
| suite_u_ultc_3w_w3 | unitario | 1 | 3/3 | match | 0 | NaN | NaN | NaN |  |
