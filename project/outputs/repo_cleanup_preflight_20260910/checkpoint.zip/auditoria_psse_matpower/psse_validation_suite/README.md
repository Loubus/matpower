# PSS/E Validation Suite

This folder is a generated validation suite for local PSS/E Xplore vs runpf_psse comparisons.

- All RAW files are <=50 buses.
- Original fixtures under sibling psse_validation_cases_* folders are not modified.
- PSS/E outputs are expected in solved_raw/, logs/, idv/, and optional .sav files beside this suite.
- Use validation_matrix.csv or validation_matrix.md as the source of case purpose, category, options, thresholds, and reference kind.

Suggested PSS/E run from workspace root:

powershell -ExecutionPolicy Bypass -File .\PSSE\Solve-RawPowerFlow.ps1 -RawFile '..\auditoria_psse_matpower\psse_validation_suite\*.raw' -OutputDir '..\auditoria_psse_matpower\psse_validation_suite' -WriteSolvedRaw

