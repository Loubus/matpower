# ULTC Validation Run - 2026-06-24

## Scope

This run validates PSS/E transformer tap-control behavior with cases that stay within the PSS/E Xplore 50-bus limit. It does not retry the full TRANSENER `V26p_Trs_2532.raw` case.

## Generated Suite

- Total suite RAW cases: 69
- PSS/E solved RAW outputs: 69
- PSS/E logs: 69
- IDV files: 69
- SAV files: 69

ULTC-focused coverage added to the generated suite includes:

- 2-winding local regulation, remote regulation, `CONT > 0`, `CONT = 0`, `COD = 0`, `COD = -1`
- `CW = 2` nominal-kV/WINDV behavior
- `NTP = 10` discrete tap behavior for in-band and low-voltage starts
- `TAB`-based 2-winding behavior
- 3-winding W2/W3 control, 3-winding `CW = 2`, and 3-winding `TAB`
- Multi-transformer shared-regulated-bus cases
- A 10-bus ULTC sign matrix
- Existing integrated 14-bus, integrated 30-bus, and stress 40-bus cases

## Validation Outputs

Primary reports:

- `auditoria_psse_matpower/results/psse_cli_comparison/auditoria_all_comparison_latest.csv`
- `auditoria_psse_matpower/results/psse_cli_comparison/auditoria_all_comparison_latest.md`
- `auditoria_psse_matpower/psse_validation_suite/suite_comparison_latest.csv`
- `auditoria_psse_matpower/psse_validation_suite/suite_control_comparison.csv`
- `auditoria_psse_matpower/psse_validation_suite/suite_tap_comparison.csv`
- `auditoria_psse_matpower/psse_validation_suite/suite_comparison_summary.md`

## Current Results

- PSS/E CLI solved all 69 suite cases.
- `runpf_psse` reported success for all 69 suite cases.
- Non-stress `runpf_psse` success is 64/64.
- Outlier/review rows: 10.

The artificial positional mismatch in `suite_i_ultc_multi_3w_cw2_shared` was removed by aligning parsed PSS/E 3-winding tap order with MATPOWER `psse_xfmr_states` order. Its taps now match.

Remaining ULTC-specific mismatch:

- `suite_u_ultc_3w_tab`: PSS/E first tap 0.9, MATPOWER first tap 1.1, abs diff 0.2.
- `suite_u_ultc_3w_tab_cw2`: PSS/E first WINDV 207, MATPOWER first WINDV 253, abs diff 46.

Secondary integrated-case mismatches:

- Integrated 14-bus variants differ by about 0.03032 pu max VM and 0.025 tap.
- Integrated 30-bus variants differ by about 0.00750 pu max VM and about 6.425 MVAr max generator Q.

## Next Fix Order

1. Fix 3-winding `TAB` semantics first. The isolated unit cases show the sharpest, smallest-scope MATPOWER-vs-PSS/E mismatch and are likely to explain the larger TRANSENER-style failure mode better than tuning integrated cases.
2. Re-run the 69-case suite after the 3-winding `TAB` fix and verify `suite_u_ultc_3w_tab*` moves from review to match.
3. Re-check the integrated 14-bus tap delta. If it remains, isolate whether it is two-winding tap-grid rounding, regulated-bus target interpretation, or control iteration settlement.
4. Re-check the integrated 30-bus generator-Q delta. Treat this as secondary unless it is coupled to the transformer fix.
5. Only after the small-suite outliers are resolved, retry reduced/TRANSENER cases with ACTAPS enabled.

## Verification Performed

- Generated validation suite with `auditoria_psse_matpower/tools/generate_psse_validation_suite.ps1`.
- Ran PSS/E CLI with `PSSE/Solve-RawPowerFlow.ps1` and `-WriteSolvedRaw`.
- Ran MATPOWER comparison through `compare_psse_cli_cases('AUDITORIA_ALL')`.
- Ran control/tap comparison through `compare_psse_validation_suite_controls()`.
- Regenerated `suite_comparison_summary.md`.
- Parsed `generate_psse_validation_suite.ps1` with the PowerShell parser successfully.
- MATLAB Code Analyzer reported no issues for `compare_psse_validation_suite_controls.m`.
