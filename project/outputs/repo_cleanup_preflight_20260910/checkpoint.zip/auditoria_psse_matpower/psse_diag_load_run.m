function run = psse_diag_load_run(run_dir, opts)
%PSSE_DIAG_LOAD_RUN Load a PSS/E-aware PF/CPF diagnostic run folder.

if nargin < 2 || isempty(opts)
    opts = struct();
end
run_dir = char(run_dir);
if exist(run_dir, 'dir') ~= 7
    error('psse_diag_load_run:missing_run_dir', ...
        'Result folder not found: %s', run_dir);
end

warnings = strings(0, 1);
[primary_file, candidates, primary_warnings] = choose_primary_mat(run_dir);
warnings = [warnings; primary_warnings(:)];
S = load(primary_file);

[results, result_name] = result_struct(S);
if isempty(results)
    error('psse_diag_load_run:no_results', ...
        'No usable MATPOWER result struct found in %s.', primary_file);
end

[gen_trace, trace_info, trace_file, trace_warnings] = load_gen_trace(run_dir);
warnings = [warnings; trace_warnings(:)];
warnings = [warnings; stale_transpa_warnings(run_dir, primary_file, trace_file)];

run_id = folder_run_id(run_dir, opts);
label = run_id;
if isfield(opts, 'labels') && ~isempty(opts.labels)
    labels = cellstr(string(opts.labels(:)));
    if ~isempty(labels)
        label = matlab.lang.makeValidName(labels{1});
    end
end

run = struct( ...
    'run_id', string(run_id), ...
    'label', string(label), ...
    'source_dir', string(run_dir), ...
    'primary_file', string(primary_file), ...
    'candidate_files', {string(candidates(:))}, ...
    'raw', S, ...
    'results', results, ...
    'result_variable', string(result_name), ...
    'gen_pq_trace', gen_trace, ...
    'gen_pq_trace_info', trace_info, ...
    'gen_pq_trace_file', string(trace_file), ...
    'warnings', warnings_table(warnings) );
end

function [primary, candidates, warnings] = choose_primary_mat(run_dir)
warnings = strings(0, 1);
files = dir(fullfile(run_dir, '*.mat'));
if isempty(files)
    error('psse_diag_load_run:no_mat_files', ...
        'No MAT files found in %s.', run_dir);
end

scores = -Inf(numel(files), 1);
for k = 1:numel(files)
    file = fullfile(files(k).folder, files(k).name);
    if strcmpi(files(k).name, 'gen_pq_trace.mat')
        scores(k) = -Inf;
        continue;
    end
    try
        w = whos('-file', file);
        names = {w.name};
        scores(k) = score_vars(names, files(k).name);
    catch me
        warnings(end+1, 1) = "Could not inspect MAT file " + ...
            string(file) + ": " + string(me.message); %#ok<AGROW>
    end
end
good = find(isfinite(scores) & scores > 0);
if isempty(good)
    error('psse_diag_load_run:no_candidate_mat', ...
        'No MAT file with CPF/PF result variables found in %s.', run_dir);
end
[~, order] = sortrows([-scores(good), -[files(good).datenum]']);
good = good(order);
candidates = fullfile({files(good).folder}', {files(good).name}');
primary = candidates{1};
if numel(candidates) > 1
    warnings(end+1, 1) = sprintf( ...
        'Multiple candidate MAT files found; selected %s.', primary);
end
end

function score = score_vars(names, filename)
score = 0;
if any(strcmp(names, 'cpf_results'))
    score = score + 100;
end
if any(strcmp(names, 'results'))
    score = score + 80;
end
if any(strcmp(names, 'r'))
    score = score + 60;
end
if any(strcmp(names, 'cpf_success')) || any(strcmp(names, 'success'))
    score = score + 10;
end
if any(strcmp(names, 'mpc_base'))
    score = score + 8;
end
if any(strcmp(names, 'summary'))
    score = score + 5;
end
if contains(lower(filename), 'summary')
    score = score - 20;
end
end

function [results, name] = result_struct(S)
results = [];
name = '';
if isfield(S, 'cpf_results') && isstruct(S.cpf_results)
    results = S.cpf_results;
    name = 'cpf_results';
elseif isfield(S, 'results') && isstruct(S.results)
    results = S.results;
    name = 'results';
elseif isfield(S, 'r') && isstruct(S.r)
    results = S.r;
    name = 'r';
end
end

function [trace, info, file, warnings] = load_gen_trace(run_dir)
trace = [];
info = struct();
file = '';
warnings = strings(0, 1);
files = dir(fullfile(run_dir, 'gen_pq_trace.mat'));
if isempty(files)
    warnings(end+1, 1) = "Missing optional gen_pq_trace.mat; " + ...
        "generator traces may be reconstructed from CPF/event history.";
    return;
end
[~, k] = max([files.datenum]);
file = fullfile(files(k).folder, files(k).name);
T = load(file);
if isfield(T, 'gen_pq_trace')
    trace = T.gen_pq_trace;
else
    warnings(end+1, 1) = "Trace sidecar lacks gen_pq_trace: " + string(file);
end
if isfield(T, 'trace_info')
    info = T.trace_info;
end
end

function warnings = stale_transpa_warnings(run_dir, primary_file, trace_file)
warnings = strings(0, 1);
if isempty(trace_file) || ~contains(lower(run_dir), 'transpa')
    return;
end
known_fix = datenum(2026, 6, 24, 1, 0, 0);
files = dir(primary_file);
if ~isempty(files) && files(1).datenum < known_fix
    warnings(end+1, 1) = [ ...
        "TRANSPA folder predates the generator technology remap fix; " + ...
        "do not treat wind/technology redispatch plots as final evidence." ];
end
end

function id = folder_run_id(run_dir, opts)
if isfield(opts, 'run_id') && ~isempty(opts.run_id)
    id = char(opts.run_id);
else
    [~, id] = fileparts(run_dir);
end
id = matlab.lang.makeValidName(id);
end

function T = warnings_table(warnings)
warnings = string(warnings(:));
if isempty(warnings)
    T = table(strings(0, 1), 'VariableNames', {'warning'});
else
    T = table(warnings, 'VariableNames', {'warning'});
end
end
