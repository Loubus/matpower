function results = run_cpf_25bus_genq_ultc_swshunt()
%RUN_CPF_25BUS_GENQ_ULTC_SWSHUNT Run CPF and plot PV curves for a RAW case.
%
% Creates reproducible outputs for psse_cpf_25bus_genq_ultc_swshunt.raw.

define_constants;

root = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(fullfile(root, 'matpower', 'lib'));
addpath(fullfile(root, 'matpower', 'lib', 't'));
addpath(fullfile(root, 'auditoria_psse_matpower'));

raw_file = fullfile(root, 'auditoria_psse_matpower', ...
    'psse_validation_cases_cpf', ...
    'psse_cpf_25bus_genq_ultc_swshunt.raw');
outdir = fullfile(root, 'auditoria_psse_matpower', 'results', ...
    'cpf_25bus_genq_ultc_swshunt');
if ~exist(outdir, 'dir')
    mkdir(outdir);
end

load_scale = 2.20;
mpc_base = psse2mpc(raw_file, 0, 34);
mpc_target = mpc_base;
mpc_target.bus(:, [PD QD]) = load_scale * mpc_base.bus(:, [PD QD]);

mpopt = mpoption( ...
    'verbose', 0, ...
    'out.all', 0, ...
    'cpf.stop_at', 'NOSE', ...
    'cpf.step', 0.02, ...
    'cpf.adapt_step', 1, ...
    'cpf.enforce_q_lims', 0);
mpopt = mp.psse_mpx_options(mpopt);

[base_pf, base_success] = runpf_psse(mpc_base, mpopt);
if ~base_success
    error('run_cpf_25bus:base_pf_failed', ...
        'Base runpf_psse did not converge for %s.', raw_file);
end

[cpf_results, cpf_success] = runcpf_psse(mpc_base, mpc_target, mpopt);
if ~cpf_success
    warning('run_cpf_25bus:cpf_failed', ...
        'CPF did not report success; diagnostic outputs are still written.');
end

trace = compact_trace(cpf_results);
lam = trace.lam(:).';
Vmag = abs(trace.V);
bus_ids = cpf_results.bus(:, BUS_I);
base_kv = cpf_results.bus(:, BASE_KV);

counts = feature_counts(mpc_base);
event_table = event_counts(cpf_results);
curve_sets = build_curve_sets(mpc_base, cpf_results, Vmag);

writematrix(lam(:), fullfile(outdir, 'cpf_lambda.csv'));
writematrix(Vmag, fullfile(outdir, 'cpf_vmag.csv'));
writematrix([bus_ids base_kv cpf_results.bus(:, VM)], ...
    fullfile(outdir, 'cpf_bus_meta.csv'));
writetable(event_table, fullfile(outdir, 'event_counts.csv'));
writetable(curve_set_table(curve_sets, bus_ids, base_kv, Vmag), ...
    fullfile(outdir, 'selected_curve_buses.csv'));

fig_paths = plot_curve_sets(outdir, lam, Vmag, bus_ids, base_kv, curve_sets);
summary = write_summary(outdir, raw_file, load_scale, counts, base_pf, ...
    cpf_results, cpf_success, event_table, fig_paths);

save(fullfile(outdir, 'cpf_25bus_genq_ultc_swshunt_results.mat'), ...
    'raw_file', 'load_scale', 'mpc_base', 'mpc_target', 'base_pf', ...
    'cpf_results', 'cpf_success', 'trace', 'counts', 'curve_sets', ...
    'fig_paths', 'summary', '-v7');

results = struct( ...
    'raw_file', raw_file, ...
    'outdir', outdir, ...
    'success', cpf_success, ...
    'summary', summary, ...
    'fig_paths', {fig_paths});

fprintf('RAW: %s\n', raw_file);
fprintf('Outputs: %s\n', outdir);
fprintf('CPF success=%d, lambda_max=%.12g, points=%d, events=%d\n', ...
    cpf_success, summary.lambda_max, summary.points, summary.events);
end

function trace = compact_trace(cpf_results)
if isfield(cpf_results, 'cpf_psse_compact') && ...
        isfield(cpf_results.cpf_psse_compact, 'lam')
    trace = cpf_results.cpf_psse_compact;
else
    trace = cpf_results.cpf;
end
end

function counts = feature_counts(mpc)
counts = struct();
counts.buses = size(mpc.bus, 1);
counts.generators = size(mpc.gen, 1);
counts.genq_rows = 0;
counts.switched_shunt_rows = 0;
counts.transformer_rows = 0;
counts.ultc_rows = 0;

if isfield(mpc, 'psse') && isfield(mpc.psse, 'genq') && ...
        isfield(mpc.psse.genq, 'num')
    counts.genq_rows = size(mpc.psse.genq.num, 1);
end
if isfield(mpc, 'psse') && isfield(mpc.psse, 'swshunt') && ...
        isfield(mpc.psse.swshunt, 'num')
    counts.switched_shunt_rows = size(mpc.psse.swshunt.num, 1);
end
if isfield(mpc, 'psse') && isfield(mpc.psse, 'xfmr')
    if isfield(mpc.psse.xfmr, 'two')
        counts.transformer_rows = counts.transformer_rows + ...
            size(mpc.psse.xfmr.two.num, 1);
    end
    if isfield(mpc.psse.xfmr, 'three')
        counts.transformer_rows = counts.transformer_rows + ...
            size(mpc.psse.xfmr.three.num, 1);
    end
end
    xf_state = mp.psse_xfmr_states(mpc);
    counts.ultc_rows = nnz(xf_state.controllable);
end

function curve_sets = build_curve_sets(mpc_base, cpf_results, Vmag)
define_constants;
bus_ids = cpf_results.bus(:, BUS_I);
base_kv = cpf_results.bus(:, BASE_KV);
curve_sets = struct('name', {}, 'title', {}, 'bus', {}, 'legend', {});

curve_sets(end+1) = make_set('all_buses', 'Todas las barras', ...
    bus_ids, false);
curve_sets(end+1) = make_set('control_buses', ...
    'Barras de GENQ, ULTC y switched shunts', ...
    unique([genq_buses(mpc_base); genq_regulated_buses(mpc_base); ...
        swshunt_buses(mpc_base); ultc_control_buses(mpc_base)]), true);
curve_sets(end+1) = make_set('high_voltage_buses', ...
    'Barras de 345 kV y 500 kV', bus_ids(base_kv >= 345), true);

drop = Vmag(:, 1) - Vmag(:, end);
[~, ord_drop] = sort(drop, 'descend');
curve_sets(end+1) = make_set('worst_voltage_drop', ...
    'Mayores caidas de tension', bus_ids(ord_drop(1:min(10, numel(ord_drop)))), ...
    true);

final_v = Vmag(:, end);
[~, ord_low] = sort(final_v, 'ascend');
curve_sets(end+1) = make_set('lowest_final_voltage', ...
    'Menores tensiones en el punto final', ...
    bus_ids(ord_low(1:min(10, numel(ord_low)))), true);
end

function s = make_set(name, title_text, buses, legend_flag)
s = struct('name', name, 'title', title_text, ...
    'bus', unique(buses(:), 'stable'), 'legend', legend_flag);
end

function fig_paths = plot_curve_sets(outdir, lam, Vmag, bus_ids, base_kv, curve_sets)
fig_paths = strings(0, 1);
for k = 1:numel(curve_sets)
    idx = bus_indices(bus_ids, curve_sets(k).bus);
    if isempty(idx)
        continue;
    end
    fig_path = fullfile(outdir, sprintf('pv_%s.png', curve_sets(k).name));
    plot_pv(lam, Vmag, bus_ids, base_kv, idx, curve_sets(k).title, ...
        fig_path, curve_sets(k).legend);
    fig_paths(end+1, 1) = string(fig_path); %#ok<AGROW>
end
end

function plot_pv(lam, Vmag, bus_ids, base_kv, idx, title_text, fig_path, ...
        show_legend)
fig = figure('Visible', 'off', 'Color', 'w', 'Position', [80 80 1300 820]);
ax = axes(fig);
set(ax, 'Color', 'w', 'XColor', [0 0 0], 'YColor', [0 0 0], ...
    'GridColor', [0.65 0.65 0.65], 'MinorGridColor', [0.8 0.8 0.8]);
hold(ax, 'on');
plot(ax, lam, Vmag(idx, :)', 'LineWidth', 1.15);
grid(ax, 'on');
box(ax, 'on');
xlabel(ax, '\lambda');
ylabel(ax, 'V [pu]');
title(ax, title_text, 'Interpreter', 'none', 'Color', [0 0 0]);
xlim(ax, [min(lam) max(lam)]);
ymin = max(0.45, min(Vmag(idx, :), [], 'all') - 0.04);
ymax = min(1.25, max(Vmag(idx, :), [], 'all') + 0.04);
ylim(ax, [ymin ymax]);
if show_legend && numel(idx) <= 30
    labels = arrayfun(@(i) sprintf('%g (%.0f kV)', bus_ids(i), base_kv(i)), ...
        idx, 'UniformOutput', false);
    lgd = legend(ax, labels, 'Location', 'eastoutside', 'Interpreter', 'none');
    set(lgd, 'Color', 'w', 'TextColor', [0 0 0], 'EdgeColor', [0.4 0.4 0.4]);
end
print(fig, fig_path, '-dpng', '-r150');
close(fig);
end

function summary = write_summary(outdir, raw_file, load_scale, counts, ...
        base_pf, cpf_results, cpf_success, event_table, fig_paths)
define_constants;
summary = struct();
summary.success = cpf_success;
summary.lambda_max = max(cpf_results.cpf.lam);
summary.points = numel(cpf_results.cpf.lam);
summary.events = numel(cpf_results.cpf.events);
[summary.final_min_v, min_idx] = min(cpf_results.bus(:, VM));
summary.final_min_v_bus = cpf_results.bus(min_idx, BUS_I);
summary.base_min_v = min(base_pf.bus(:, VM));

summary_table = table( ...
    summary.success, summary.lambda_max, summary.points, summary.events, ...
    summary.final_min_v_bus, summary.final_min_v, summary.base_min_v, ...
    load_scale, counts.buses, counts.genq_rows, ...
    counts.switched_shunt_rows, counts.transformer_rows, counts.ultc_rows, ...
    'VariableNames', {'success', 'lambda_max', 'points', 'events', ...
    'final_min_v_bus', 'final_min_v', 'base_min_v', 'target_load_scale', ...
    'buses', 'genq_rows', 'switched_shunt_rows', 'transformer_rows', ...
    'ultc_rows'});
writetable(summary_table, fullfile(outdir, 'summary_metrics.csv'));

md = fullfile(outdir, 'resumen_cpf_25bus_genq_ultc_swshunt.md');
fid = fopen(md, 'w');
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, '# CPF 25 buses con GENQ, ULTC y switched shunts\n\n');
fprintf(fid, 'RAW: `%s`\n\n', raw_file);
fprintf(fid, '## Caso\n\n');
fprintf(fid, '- Barras: `%d`\n', counts.buses);
fprintf(fid, '- Generadores: `%d`\n', counts.generators);
fprintf(fid, '- Filas GENQ preservadas desde GENERATOR DATA: `%d`\n', counts.genq_rows);
fprintf(fid, '- Switched shunts: `%d`\n', counts.switched_shunt_rows);
fprintf(fid, '- Transformadores: `%d`; ULTC activos por `COD`: `%d`\n', ...
    counts.transformer_rows, counts.ultc_rows);
fprintf(fid, '- Target CPF: carga `%.2fx` respecto del caso base.\n\n', load_scale);
fprintf(fid, '## Resultado\n\n');
fprintf(fid, '| Metrica | Valor |\n|---|---:|\n');
fprintf(fid, '| CPF success | %d |\n', summary.success);
fprintf(fid, '| Lambda max | %.12g |\n', summary.lambda_max);
fprintf(fid, '| Puntos CPF | %d |\n', summary.points);
fprintf(fid, '| Eventos CPF | %d |\n', summary.events);
fprintf(fid, '| Min V base | %.12g |\n', summary.base_min_v);
fprintf(fid, '| Bus min V final | %.0f |\n', summary.final_min_v_bus);
fprintf(fid, '| Min V final | %.12g |\n\n', summary.final_min_v);
fprintf(fid, '## Eventos\n\n');
fprintf(fid, '| Evento | Conteo |\n|---|---:|\n');
for k = 1:height(event_table)
    fprintf(fid, '| %s | %d |\n', event_table.event(k), event_table.count(k));
end
fprintf(fid, '\n## Figuras\n\n');
for k = 1:numel(fig_paths)
    fprintf(fid, '- `%s`\n', fig_paths(k));
end
end

function t = event_counts(cpf_results)
t = table(string.empty(0, 1), zeros(0, 1), ...
    'VariableNames', {'event', 'count'});
if ~isfield(cpf_results, 'cpf') || ~isfield(cpf_results.cpf, 'events') || ...
        isempty(cpf_results.cpf.events)
    return;
end
names = string({cpf_results.cpf.events.name})';
[u, ~, ic] = unique(names);
count = accumarray(ic, 1);
t = table(u, count, 'VariableNames', {'event', 'count'});
end

function t = curve_set_table(curve_sets, bus_ids, base_kv, Vmag)
t = table(string.empty(0, 1), zeros(0, 1), zeros(0, 1), ...
    zeros(0, 1), zeros(0, 1), zeros(0, 1), ...
    'VariableNames', {'set_name', 'bus_i', 'base_kv', ...
    'vm_initial', 'vm_final', 'vm_min'});
for k = 1:numel(curve_sets)
    idx = bus_indices(bus_ids, curve_sets(k).bus);
    if isempty(idx)
        continue;
    end
    rows = table( ...
        repmat(string(curve_sets(k).name), numel(idx), 1), ...
        bus_ids(idx), base_kv(idx), Vmag(idx, 1), Vmag(idx, end), ...
        min(Vmag(idx, :), [], 2), ...
        'VariableNames', {'set_name', 'bus_i', 'base_kv', ...
        'vm_initial', 'vm_final', 'vm_min'});
    t = [t; rows]; %#ok<AGROW>
end
end

function idx = bus_indices(bus_ids, buses)
[tf, loc] = ismember(buses(:), bus_ids);
idx = loc(tf);
end

function buses = genq_buses(mpc)
buses = [];
if isfield(mpc.psse, 'genq') && isfield(mpc.psse.genq, 'bus_ext')
    rows = mpc.psse.genq.status ~= 0;
    buses = unique(mpc.psse.genq.bus_ext(rows));
end
end

function buses = genq_regulated_buses(mpc)
buses = [];
if isfield(mpc.psse, 'genq') && isfield(mpc.psse.genq, 'reg_bus_ext')
    rows = mpc.psse.genq.status ~= 0;
    reg = mpc.psse.genq.reg_bus_ext(rows);
    reg(reg == 0 | isnan(reg)) = [];
    buses = unique(reg);
end
end

function buses = swshunt_buses(mpc)
buses = [];
if isfield(mpc.psse, 'swshunt') && isfield(mpc.psse.swshunt, 'num')
    c = psse_col(mpc.psse.swshunt, 'I');
    if c > 0
        buses = unique(mpc.psse.swshunt.num(:, c));
    end
end
end

function buses = ultc_control_buses(mpc)
buses = [];
if ~isfield(mpc, 'psse') || ~isfield(mpc.psse, 'xfmr')
    return;
end
for part_name = {'two', 'three'}
    part = part_name{1};
    if ~isfield(mpc.psse.xfmr, part)
        continue;
    end
    xf = mpc.psse.xfmr.(part);
    if ~isfield(xf, 'num') || isempty(xf.num)
        continue;
    end
    i = psse_col(xf, 'I');
    j = psse_col(xf, 'J');
    cont = psse_col(xf, 'CONT');
    cod = psse_col(xf, 'COD');
    rows = true(size(xf.num, 1), 1);
    if cod > 0
        rows = rows & xf.num(:, cod) ~= 0;
    end
    local_buses = [];
    if i > 0
        local_buses = [local_buses; xf.num(rows, i)]; %#ok<AGROW>
    end
    if j > 0
        local_buses = [local_buses; xf.num(rows, j)]; %#ok<AGROW>
    end
    if cont > 0
        local_buses = [local_buses; xf.num(rows, cont)]; %#ok<AGROW>
    end
    buses = [buses; local_buses]; %#ok<AGROW>
end
buses = unique(buses);
buses(isnan(buses) | buses == 0) = [];
end

function col = psse_col(s, name)
col = 0;
if isfield(s, 'col') && isfield(s.col, lower(name))
    col = s.col.(lower(name));
elseif isfield(s, 'colnames')
    found = find(strcmpi(s.colnames, name), 1);
    if ~isempty(found)
        col = found;
    end
end
end
