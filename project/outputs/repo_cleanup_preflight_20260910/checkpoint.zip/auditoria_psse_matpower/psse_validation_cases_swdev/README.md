# Validacion PSS/E - SYSTEM SWITCHING DEVICE DATA

Estos casos chicos aislan la semantica electrica de `SYSTEM SWITCHING DEVICE DATA`
frente a PSS/E 36.1 y MATPOWER.

## Archivos

| Caso | RAW | Log PSS/E | Objetivo |
| --- | --- | --- | --- |
| Cerrado | `psse_swdev_3bus_closed.raw` | `psse_swdev_3bus_closed.log` | `STAT=1` debe quedar en servicio. |
| Abierto paralelo | `psse_swdev_3bus_open_parallel.raw` | `psse_swdev_3bus_open_parallel.log` | `STAT=0` debe quedar fuera de servicio sin aislar la carga, porque existe una linea paralela. |
| Stuck closed | `psse_swdev_3bus_stuck_closed.raw` | `psse_swdev_3bus_stuck_closed.log` | `STAT=2` debe quedar electricamente cerrado, preservando el estado crudo. |

Todos los casos usan un unico switching device entre los buses 2 y 3 con:

- `X = 0.0001`
- `RATE1..RATE12 = 150, 140, 130, 120, 110, 100, 90, 80, 70, 60, 50, 40`
- `MET = 2`
- `CKT` y `NAME` diferenciados por caso

## Evidencia PSS/E

Los logs de PSS/E muestran que los tres RAW se leen como revision 34, se
convierten internamente a revision 36 y contienen un registro de switching
device.

| Caso | PSS/E FNSL | Estado mostrado por PSS/E | Resultado electrico |
| --- | --- | --- | --- |
| Cerrado | converge en 2 iteraciones | rama `2 -> 3 @1`, `ST = 1` | en servicio, flujo aproximado `+90.0 MW / +30.0 Mvar` por el swdev |
| Abierto paralelo | converge en 3 iteraciones | rama `2 -> 3 @2`, `ST = 0` | fuera de servicio; el flujo lo toma la linea paralela `2 -> 3` |
| Stuck closed | converge en 2 iteraciones | rama `2 -> 3 @3`, `ST = 2` | en servicio, flujo aproximado `+90.0 MW / +30.0 Mvar` por el swdev |

El caso `stuck_closed` da el mismo punto operativo que el caso cerrado. Por
lo tanto, para flujo de carga, PSS/E trata `STAT=2` como electricamente cerrado.
MATPOWER conserva `STAT=2` en `mpc.psse.swdev.status`, pero traduce la fila
`branch` a `BR_STATUS = 1` porque `BR_STATUS` es binario.

## Comparacion MATPOWER

Resultados obtenidos con:

```matlab
[mpc, warn] = psse2mpc(raw_file, 0, 34);
r = runpf(mpc, mpoption('verbose', 0, 'out.all', 0));
```

| Caso | MATPOWER PF | Slack PG/QG | Tensiones principales | Swdev branch |
| --- | --- | --- | --- | --- |
| Cerrado | converge en 4 iteraciones | `90.9869 MW / 39.8788 Mvar` | bus 2 `0.95499 pu, -5.2268 deg`; bus 3 `0.95496 pu, -5.2325 deg` | `branch_idx=2`, `BR_STATUS=1`, `PF/QF=90.0000/30.0099` |
| Abierto paralelo | converge en 4 iteraciones | `92.2543 MW / 52.5433 Mvar` | bus 2 `0.94226 pu, -5.2978 deg`; bus 3 `0.89357 pu, -11.2287 deg` | `branch_idx=3`, `BR_STATUS=0`, `PF/QF=0/0` |
| Stuck closed | converge en 4 iteraciones | `90.9869 MW / 39.8788 Mvar` | bus 2 `0.95499 pu, -5.2268 deg`; bus 3 `0.95496 pu, -5.2325 deg` | `branch_idx=2`, `BR_STATUS=1`, `PF/QF=90.0000/30.0099` |

La comparacion usa los valores redondeados impresos por PSS/E. Las diferencias
observadas estan dentro del redondeo de los reportes: tensiones en torno a
`1e-4 pu`, angulos dentro del decimal mostrado por PSS/E, y potencias dentro
del redondeo de `0.1 MW/Mvar` de los logs.

## Metadata auditada

La conversion MATPOWER preserva la trazabilidad del registro PSS/E en
`mpc.psse.swdev`:

- `branch_idx` enlaza cada switching device con la fila `branch` generada.
- `status` conserva `STAT` crudo: `0`, `1` o `2`.
- `normal_status`, `metered_end`, `stype`, `ckt` y `name` conservan
  `NSTAT`, `MET`, `STYPE`, `CKT` y `NAME`.
- `rates(:,1:12)` conserva `RATE1..RATE12`; `RATE1..RATE3` tambien se mapean
  a `RATE_A`, `RATE_B`, `RATE_C`.
- `x` conserva la reactancia PSS/E y la fila `branch` usa `BR_R = 0`,
  `BR_X = X`.

Estos casos no introducen control iterativo. `NSTAT`, `MET`, `STYPE`, `CKT` y
`NAME` se preservan como metadata PSS/E para auditoria; el estado electrico en
flujo de carga queda definido por `STAT`.
