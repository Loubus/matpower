# Casos chicos PSS/E - TWO-TERMINAL DC DATA

Objetivo: aislar la conversion PSS/E `TWO-TERMINAL DC DATA` a `mpc.dcline`
en redes minimas donde el comportamiento del enlace DC se pueda leer sin
interferencias.

Casos:

| Caso | Descripcion | Resultado esperado MATPOWER |
|---|---|---|
| `psse_twodc_4bus_base.raw` | Red AC base sin DC | No hay `mpc.dcline` |
| `psse_twodc_4bus_mdc0.raw` | Un enlace `MDC=0` | `BR_STATUS=0`, `PF=PT=0`, perdidas cero |
| `psse_twodc_4bus_mdc1_noloss.raw` | Un enlace `MDC=1`, `RDC=0` | `PF=PT=50 MW`, perdidas cero |
| `psse_twodc_4bus_mdc1_loss.raw` | Un enlace `MDC=1`, `RDC=10 ohm` | `PF=50 MW`, `PT=49.9 MW`, `LOSS0=0.1 MW` |
| `psse_twodc_5bus_v26p_active.raw` | Caso reducido de 5 buses con los parametros activos del RAW grande | `runpf`: `PF=825 MW`, `PT=805.205156 MW`, `LOSS0=19.794844 MW`; `runpf_psse`: modo potencia LCC, `PT=804.089934 MW`, `LOSS0=20.910066 MW`, `QACR=379.425136 MVAr`, `QACI=367.541929 MVAr` |

La perdida esperada del caso 4 buses con `RDC=10` es:

```text
Idc = 50 MW / 500 kV = 0.1 kA
P_loss = 10 ohm * (0.1 kA)^2 = 0.1 MW
```

Logs PSS/E recibidos:

| Log | Resultado PSS/E relevante |
|---|---|
| `psse_twodc_4bus_base.log` | Sin enlace DC; converge como red AC base |
| `psse_twodc_4bus_mdc0.log` | `MDC=0` queda bloqueado; `PAC=QAC=VDC=0` |
| `psse_twodc_4bus_mdc1_noloss.log` | `MDC=1` cae a corriente por `VCMODE`; `DCAMPS=100.0`, `VCOMP=290.9`, `PAC(R)=29.1`, `PAC(I)=-29.1` |
| `psse_twodc_4bus_mdc1_loss.log` | Igual, con `RDC=10`; `DCAMPS=100.0`, `VCOMP=291.9`, `PAC(R)=29.2`, `PAC(I)=-29.1`, perdida `0.10 MW` |
| `psse_twodc_5bus_v26p_active.log` | Enlace activo grande aislado queda en modo potencia: `DCAMPS=1413.2`, `VCOMP=583.8`, `PAC(R)=825.0`, `PAC(I)=-804.1`, perdida `20.91 MW` |

En MATPOWER, `runpf` conserva la conversion estatica `dcline`. `runpf_psse`
activa el modelo opt-in PSS/E validado: resuelve el equivalente LCC con
taps discretos, `alpha/gamma`, `Idc`, `Vdcr/Vdci/Vcomp`, solapes, perdida
`RDC*Idc^2` y consumo reactivo equivalente `QACR/QACI` aplicado como
`bus(:, QD)`. Si `Vdci < VCMOD`, cae al modo corriente validado con los casos
chicos.

Caso reducido del enlace activo del RAW grande:

```text
Archivo: psse_twodc_5bus_v26p_active.raw
Buses: 5
Rectificador: bus 85, 500 kV
Inversor: bus 86, 345 kV
MDC=1
SETVL=825 MW
VSCHD=600 kV
VCMOD=558 kV
RDC=10.47 ohm
RCOMP=10.47 ohm
```

Validacion MATPOWER local:

```text
runpf success=1, 4 iteraciones
runpf_psse success=1, 4 iteraciones
dcline: PF=825.000000, PT=804.089934, LOSS0=20.910066, LOSS1=0
runpf_psse: current_limited=0, Idc=1.413202 kA
QACR=379.425136 MVAr, QACI=367.541929 MVAr
```

Validacion PSS/E Xplore recibida:

```text
DCAMPS=1413.2 A
VCOMP=583.8 kV
Rectificador: PAC=825.0 MW, QAC=379.4 MVAr, VDC=583.8 kV, TAP=1.0125, ALPHA=16.75
Inversor:     PAC=-804.1 MW, QAC=367.5 MVAr, VDC=569.0 kV, TAP=0.9660, GAMMA=17.00
Perdida DC:   20.91 MW
```

La comparacion confirma que el enlace grande aislado queda en modo potencia,
no en modo corriente. El contrato de validacion compara potencia, perdida,
corriente y reactiva:
`20.910066 MW` frente a `20.91 MW`, `1.413202 kA` frente a `1.4132 kA`,
`QACR=379.425136` frente a `379.4`, y `QACI=367.541929` frente a `367.5`.

Configuracion sugerida para PSS/E:

- Cargar cada RAW.
- Ejecutar `FNSL` con las opciones declaradas en `SYSTEM-WIDE`.
- Exportar o copiar el reporte de flujo DC/terminales DC y el resumen de
  `PGEN/QGEN`, `VM/VA`.
- Comparar especialmente potencia rectificador, potencia inversor y perdidas.
