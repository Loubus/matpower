# Diagnostico actual - V26p_Trs_2532.raw

Fecha de trabajo: 2026-05-15.

Este documento resume la evidencia recopilada en la sesion actual. No es una auditoria generica PSS/E vs MATPOWER; esta aplicado al contenido real de `PSSE/V26p_Trs_2532.raw`.

## 1. Estado del repositorio

Directorio raiz:

`C:\Users\santi\Documents\UNIVERSIDAD\PROYECTO FINAL DE CARRERA - MATPOWER`

La raiz no es un repositorio git. Los repositorios locales detectados son:

| Carpeta | Branch | Estado | Commit |
|---|---|---|---|
| `matpower/` | `master` | limpio, tracking `origin/master` | `812acbec34c6b0d5f0dbd8d6bf5bd0ad5dff22a1 Improve PSS/E rev 34 RAW import` |
| `matpower-extras/` | `master` | limpio, tracking `origin/master` | `bc21752 Release 8.1.` |

Remotes de `matpower/`:

- `origin`: `https://github.com/Loubus/matpower.git`
- `upstream`: `https://github.com/MATPOWER/matpower.git`

## 2. Importacion y flujo de potencia

Comprobaciones ejecutadas en MATLAB:

- `addpath(genpath('matpower'))`
- `addpath(genpath('matpower-extras'))`
- `psse_read`
- `psse_parse`
- `psse2mpc`
- `runpf`

Resultado:

| Item | Valor |
|---|---:|
| MATPOWER | `8.1.1-dev` |
| RAW | `PSSE/V26p_Trs_2532.raw` |
| PSS/E REV | `34` |
| SBASE | `100 MVA` |
| BASFRQ | `50 Hz` |
| Importacion `psse2mpc` | OK |
| `runpf` success | `1` |
| Iteraciones | `4` |
| Rango `VM` final | `0.697041` a `1.156370` pu |
| Rango `VA` final | `-90.953835` a `46.616672` grados |
| Buses PQ/PV/REF/NONE | `4671 / 685 / 2 / 405` |
| Generadores online/offline | `662 / 299` |
| Ramas online/offline | `6470 / 827` |
| Islas conectadas | `2` grupos: `5356` buses y `2` buses |
| Buses aislados | `405` |

Observacion importante:

MATPOWER contiene `5763` buses luego de la conversion. El RAW tiene `5015` buses; la diferencia corresponde a `748` buses estrella agregados para transformadores de tres devanados.

## 3. Warnings de conversion

Warnings devueltos por `psse2mpc`:

1. `Skipped 18 lines of system-wide data.`
2. `Skipped 12 lines of impedance correction data.`
3. `Skipped 65 lines of zone data.`
4. `Skipped 24 lines of owner data.`
5. `Skipped 1 line of FACTS device data.`
6. `BRANCH DATA` Rev34 no-transformer: la metadata no nativa se preserva ahora en `mpc.psse.branch`.
7. `Converted 508 system switching devices to zero-resistance MATPOWER branches; PSS/E metadata is preserved in mpc.psse.swdev.`
8. `Added buses 1000001-1000748 as star-points for 3-winding transformers.`

## 4. Inventario completo de secciones RAW

Conteos extraidos de `PSSE/V26p_Trs_2532.raw`. Para secciones multilina, se diferencia entre lineas RAW y objetos electricos.

| Orden | Seccion | Lineas no comentario | Objetos/registros electricos | Clasificacion |
|---:|---|---:|---:|---|
| 1 | `ID` | 3 | 1 bloque | convertida |
| 2 | `SYSTEM-WIDE` | 18 | 18 lineas | ignorada con impacto posible |
| 3 | `BUS` | 5015 | 5015 | convertida |
| 4 | `LOAD` | 1691 | 1691 | convertida con metadata preservada |
| 5 | `FIXED SHUNT` | 201 | 201 | convertida |
| 6 | `GENERATOR` | 961 | 961 | convertida con controles aproximados |
| 7 | `BRANCH` | 2802 | 2802 | convertida con metadata preservada |
| 8 | `SYSTEM SWITCHING DEVICE` | 508 | 508 | convertida y validada para PF |
| 9 | `TRANSFORMER` | 10712 | 2491 objetos: 1743 2W, 748 3W | aproximada |
| 10 | `AREA` | 15 | 15 | ignorada sin impacto fuerte en este caso |
| 11 | `TWO-TERMINAL DC` | 24 | 8 | aproximada |
| 12 | `VSC DC LINE` | 0 | 0 | vacia |
| 13 | `IMPEDANCE CORRECTION` | 12 | 12 tablas | ignorada con impacto posible |
| 14 | `MULTI-TERMINAL DC` | 0 | 0 | vacia |
| 15 | `MULTI-SECTION LINE` | 0 | 0 | vacia |
| 16 | `ZONE` | 65 | 65 | ignorada sin impacto electrico directo |
| 17 | `INTER-AREA TRANSFER` | 0 | 0 | vacia |
| 18 | `OWNER` | 24 | 24 | ignorada sin impacto electrico directo |
| 19 | `FACTS DEVICE` | 1 | 1 | ignorada con impacto posible |
| 20 | `SWITCHED SHUNT` | 361 | 361 | aproximada |
| 21 | `GNE` | 0 | 0 | vacia |
| 22 | `INDUCTION MACHINE` | 0 | 0 | vacia |
| 23 | `SUBSTATION` | 0 | 0 | vacia |

Secciones vacias en este caso:

- `VSC DC LINE`
- `MULTI-TERMINAL DC`
- `MULTI-SECTION LINE`
- `INTER-AREA TRANSFER`
- `GNE`
- `INDUCTION MACHINE`
- `SUBSTATION`

## 5. Diagnostico selectivo por seccion no vacia

### SYSTEM-WIDE

Lineas presentes:

- Parametros `GENERAL`, `GAUSS`, `NEWTON`, `ADJUST`, `TYSL`.
- `SOLVER, FNSL, ACTAPS=0, AREAIN=0, PHSHFT=0, DCTAPS=1, SWSHNT=2, FLATST=0, VARLIM=0, NONDIV=0`.
- `RATING` sets 1 a 12.

Impacto:

MATPOWER ignora esta seccion. Esto no impide resolver, pero elimina informacion de solucion PSS/E: tolerancias, aceleraciones y flags de controles automaticos. En este caso son especialmente relevantes `DCTAPS=1` y `SWSHNT=2`.

### BUS

Conteo y datos:

- `5015` buses.
- IDE: `3963` tipo 1, `685` tipo 2, `2` tipo 3, `365` tipo 4.
- `VM` RAW: `0.8318` a `1.15962` pu.
- `VA` RAW: `-89.1033` a `46.3462` grados.

Impacto:

La estructura base se conserva. Las discrepancias no parecen venir de una mala lectura de buses.

### LOAD

Conteo y datos:

- `1691` cargas.
- `1593` online, `98` offline.
- `PL total RAW`: `40950.072 MW`.
- `QL total RAW`: `14726.686 MVAr`.
- `IP/IQ/YP/YQ`: todos cero.
- `DGENP/DGENQ`: todos cero.

Impacto:

La contribucion electrica a MATPOWER sigue agregada en `mpc.bus(:, PD/QD)`, solo para cargas en servicio: `PD = PL + IP*VM + YP*VM^2` y `QD = QL + IQ*VM - YQ*VM^2`. En este caso la conversion es practicamente exacta porque no hay componente ZIP ni generacion distribuida en la seccion LOAD.

La fila RAW queda preservada como metadata auditable en `mpc.psse.load`: `I`, `ID`, `STAT`, `AREA`, `ZONE`, `PL/QL`, `IP/IQ`, `YP/YQ`, `OWNER`, `SCALE`, `INTRPT`, `DGENP/DGENQ/DGENF`, mas el mapeo al bus MATPOWER. Esto permite auditar cada carga por fila, cruzar area/zona/owner, sumar contribuciones por bus y detectar referencias administrativas no definidas en `OWNER DATA`, por ejemplo `OWNER=99` en el RAW grande. No hay cambio de comportamiento en `runpf` estandar.

### FIXED SHUNT

Conteo y datos:

- `201` registros.
- `194` online, `7` offline.
- `GL total`: `48.0 MW`.
- `BL total`: `6775.87 MVAr`.
- `192` registros con `BL` no cero.

Impacto:

La conversion a `bus GS/BS` es directa. Puede haber impacto numerico por acumulacion de shunts grandes, pero no aparece como fuente principal de discrepancia de modelo.

### GENERATOR

Conteo y datos:

- `961` generadores.
- `662` online, `299` offline.
- `PG online total`: `40385.322 MW`.
- `QG online total`: `8929.171 MVAr`.
- `IREG` no cero en todos los generadores.
- `103` generadores regulan un bus distinto al propio.
- `WMOD=1` en `191` registros.
- `24` generadores online ya estan en limite o cerca de limite Q inicial.

Impacto:

MATPOWER conserva `PG/QG/QMAX/QMIN/VG/MBASE/STAT/PMAX/PMIN`, pero no modela de forma equivalente la regulacion remota, reparto `RMPCT`, `WMOD` ni algunos comportamientos PSS/E de limites Q. Esto afecta especialmente buses PV, conversion PV/PQ y reparto de reactiva.

### BRANCH

Conteo y datos:

- `2802` ramas no transformador.
- `2591` online, `211` offline.
- `MET`: `1660` con valor 1, `1142` con valor 2.
- `1974` registros con longitud no cero.
- `258` registros tienen algun rating 4-12 no cero.
- `88` registros tienen shunts terminales `GI/BI/GJ/BJ` no cero.
- `7` ramas online con `|Z| < 1e-4`.

Impacto:

Para flujo AC, MATPOWER conserva en `mpc.branch` R/X/B, status y ratings 1-3. La metadata Rev34 no nativa queda preservada en `mpc.psse.branch`: `CKT`, `NAME`, `RATE1-12`, `MET`, `LEN`, owners `O1/F1` a `O4/F4`, `raw_row_idx` y `branch_idx`. El enlace `branch_idx` apunta desde cada fila RAW de `BRANCH DATA` a la fila equivalente de `mpc.branch`, por lo que se puede cruzar auditoria/reporte sin depender del orden visual del RAW. Los shunts terminales se integran a `bus GS/BS`, por lo que no desaparecen electricamente.

Limitacion real: la solucion electrica no cambia. `makeYbus`, `runpf` y los reportes MATPOWER nativos siguen usando el modelo estandar de rama AC y los ratings `RATE_A/B/C`; `RATE4-12`, `MET`, `LEN`, `NAME` y ownership quedan disponibles para auditoria/exportacion, pero no accionan controles ni limites adicionales.

### SYSTEM SWITCHING DEVICE

Conteo y datos:

- `508` registros.
- `222` online, `286` offline.
- `NSTAT`: `392` con 1, `116` con 0.
- `STYPE`: `4` tipo 1, `500` tipo 2, `4` tipo 3.
- Todos tienen X no cero.

Impacto:

MATPOWER los convierte a ramas con `R=0`, `X` del dispositivo, ratings 1-3 y `BR_STATUS` binario. La metadata PSS/E queda preservada en `mpc.psse.swdev`: `CKT`, `RATE1-12`, `STAT`, `NSTAT`, `MET`, `STYPE`, `NAME` y el enlace `branch_idx`. PSS/E valida que `STAT=0` es abierto, mientras que `STAT=1` y `STAT=2` son electricamente cerrados para PF. Al apagar todos los switching devices online, `runpf` no converge; por lo tanto, sostienen topologia efectiva del caso.

### TRANSFORMER

Conteo y datos:

- `2491` transformadores.
- `1743` de dos devanados.
- `748` de tres devanados.
- Status: `2241` online, `250` offline.
- `4037` devanados con tap distinto de nominal.
- `134` devanados con phase shift no cero.
- `36` devanados referencian tabla `TAB`.
- `12` tablas de impedance correction existen en el RAW.
- `56` objetos tienen magnetizacion no cero.

Impacto:

MATPOWER conserva impedancias, taps y shifts actuales, y modela trafos 3W mediante buses estrella. No conserva controles automaticos, curvas de correccion por tap/angulo, magnetizacion completa ni ratings 4-12. Es una fuente fuerte de discrepancia si la solucion PSS/E aplico controles o factores `TAB`.

### AREA

Conteo y datos:

- `15` areas.
- `ISW` no cero: `0`.
- `PDES` no cero: `0`.
- `PTOL` no cero: `15`.

Impacto:

`psse2mpc` conserva `AREA DATA` en `mpc.psse.area`: IDs, `ISW`, `PDES`, `PTOL`, nombres y mapeo a buses por `bus(:, BUS_AREA)`. En este RAW no activa intercambio de area porque `AREAIN=0`, `ISW=0` y `PDES=0`.

### TWO-TERMINAL DC

Conteo y datos:

- `8` registros HVDC de dos terminales.
- `4` bloqueados (`MDC=0`).
- `4` activos (`MDC=1`), todos de `825 MW`.
- Activos: rectificador bus `85`, inversor bus `86`.
- Bloqueados: buses `20-5010` y `22-5020`.

MATPOWER `dcline` resultante:

- 4 lineas activas con `PF=PT=825 MW`.
- `PMIN=701.25 MW`, `PMAX=948.75 MW`.
- `LOSS0=0`, `LOSS1=0`.
- Limites Q calculados por formula simplificada con angulos.

Impacto:

La conversion no representa perdidas `RDC`, control de taps de convertidor, VCMOD, DCVMIN ni solucion interna HVDC PSS/E. Al apagar las `dcline`, `runpf` no converge.

### IMPEDANCE CORRECTION

Conteo y datos:

- `12` tablas.
- IDs: `1` a `12`.
- `36` devanados de transformador referencian `TAB`.

Impacto:

MATPOWER las ignora. Es una fuente importante de discrepancia cuando PSS/E modifica impedancia efectiva por tap o angulo.

### ZONE

Conteo:

- `65` zonas.

Impacto:

MATPOWER conserva el numero de zona en `bus(:, ZONE)` desde BUS DATA y `psse2mpc` conserva los nombres en `mpc.psse.zone`, con mapeo auditable a filas de `mpc.bus`. Sin impacto electrico directo.

### OWNER

Conteo:

- `24` owners.

Impacto:

`psse2mpc` conserva `OWNER DATA` en `mpc.psse.owner`, incluyendo nombres, owners de buses desde `BUS DATA` y referencias de ownership ya preservadas en metadata como `mpc.psse.branch.owner`. Sin impacto electrico directo en `runpf`; las referencias sin fila `OWNER DATA` quedan visibles para auditoria.

### FACTS DEVICE

Registro presente:

- Nombre: `FACTS 1`.
- Bus `I=40403`.
- Bus `J=0`.
- `MODE=1`.
- `PDES=0`, `QDES=0`.
- `VSET=1.0`.
- `SHMX=100`.
- `TRMX=9999`.
- `FCREG=41002`.
- `NREG=0`.

Impacto:

MATPOWER ignora el FACTS. Una sensibilidad simple agregando/removiendo `100 MVAr` como shunt en bus `40403` mostro impacto fuerte: `+100 MVAr` no converge; `-100 MVAr` converge con `max |dVM|=0.328337 pu` y `max |dVA|=10.351 grados`.

### SWITCHED SHUNT

Conteo y datos:

- `361` registros.
- `348` activos, `13` fuera de servicio.
- `MODSW`: `216` con 0, `141` con 1, `4` con 2.
- `BINIT` no cero en `276` registros.
- `BINIT total`, todos los estados: `3621.7 MVAr`.
- `BINIT` en servicio (`ST=1`): `3756.7 MVAr`.
- `BINIT` fuera de servicio (`ST=0`): `-135.0 MVAr`.
- `503` bloques no cero.
- `39` registros controlan bus remoto (`SWREG` distinto del propio).

Impacto:

Estado original del repo: MATPOWER conservaba solo `BINIT` como susceptancia fija en `bus BS`, no respetaba `ST`, y no dejaba disponibles `MODSW`, `SWREG`, `RMPCT` ni bloques `N/B` en el `mpc`.

Cambio aplicado en el issue `SWITCHED SHUNT DATA`: `psse_parse` parsea la tabla Rev34 completa, `psse_convert` preserva `mpc.psse.swshunt`, y `BINIT` se suma a `bus BS` solo si `ST != 0`. El control automatico, discreto/continuo y remoto sigue pendiente. Al remover todo `BINIT`, `runpf` no converge; al aplicar solamente la correccion de `ST`, `runpf` sigue convergiendo en 4 iteraciones y el mayor cambio frente al comportamiento anterior reconstruido fue `max |dVM| = 0.043779 pu`.

## 6. Comparacion numerica contra estado inicial RAW

No se encontro salida PSS/E local exportada. Por eso la comparacion es:

- Estado inicial del RAW importado en `mpc`.
- Resultado `runpf` de MATPOWER.

### Mayores desviaciones de magnitud de tension

| Bus | Nombre | kV | VM RAW | VM MATPOWER | Delta VM |
|---:|---|---:|---:|---:|---:|
| 46402 | `MES  A    23` | 23.0 | 0.907270 | 0.705070 | -0.202200 |
| 46202 | `MES B1    66` | 66.0 | 0.880290 | 0.697041 | -0.183249 |
| 46401 | `FIL  A    23` | 23.0 | 0.949750 | 0.777984 | -0.171766 |
| 46201 | `FIL B1    66` | 66.0 | 0.934980 | 0.778934 | -0.156046 |
| 46204 | `FER  66` | 66.0 | 0.936250 | 0.780831 | -0.155419 |

### Mayores desviaciones de angulo

| Bus | Nombre | kV | VA RAW | VA MATPOWER | Delta VA |
|---:|---|---:|---:|---:|---:|
| 46402 | `MES  A    23` | 23.0 | -37.890300 | -44.272308 | -6.382008 |
| 46401 | `FIL  A    23` | 23.0 | -33.838000 | -37.942881 | -4.104881 |
| 46202 | `MES B1    66` | 66.0 | -64.074600 | -68.094545 | -4.019945 |
| 3581 | `EDIS13_01` | 13.2 | -36.740100 | -32.764209 | 3.975891 |
| 1000325 | `STR_PT_XF_325` | 1.0 | -36.740100 | -32.764209 | 3.975891 |

### Generadores con mayor cambio de Q

| Gen row | Bus | Nombre | Q inicial | Q final | Delta Q | QMIN | QMAX |
|---:|---:|---|---:|---:|---:|---:|---:|
| 329 | 3607 | `COSTTV07` | 205.733 | 0.000 | -205.733 | -104.000 | 241.000 |
| 227 | 2610 | `ATUCNUCL` | 108.279 | 0.000 | -108.279 | -79.200 | 216.000 |
| 899 | 98179 | `PTB15TV` | 0.000 | 69.283 | 69.283 | 0.000 | 0.000 |
| 898 | 98178 | `PTB15TG2` | 0.000 | 68.124 | 68.124 | 0.000 | 0.000 |
| 897 | 98177 | `PTB15TG1` | 0.000 | 67.316 | 67.316 | 0.000 | 0.000 |

Conteo de limites Q:

- Inicial online bajo QMIN: `0`.
- Inicial online sobre QMAX: `0`.
- Final bajo QMIN: `14`.
- Final sobre QMAX: `5`.
- Final en o mas alla de limite: `23`.

### Tensiones anomalas finales

- Buses conectados con `VM < 0.90`: `36`.
- Buses conectados con `VM > 1.10`: `11`.

Minimos destacados:

- Bus `46202`, `MES B1 66`, `VM=0.697041`.
- Bus `46402`, `MES A 23`, `VM=0.705070`.
- Bus `46401`, `FIL A 23`, `VM=0.777984`.

Maximos destacados:

- Bus `95400`, `RIV_30_L`, `VM=1.156370`.
- Bus `98403`, `PON_13_G`, `VM=1.156370`.
- Bus `98404`, `BIO_13_G`, `VM=1.156370`.

### Ramas con flujos extremos

| Branch row | Clase | From | To | R | X | Smax | RateA |
|---:|---|---:|---:|---:|---:|---:|---:|
| 12 | branch | 86 | 87 | 0 | 0.000101 | 3591.73 | 0 |
| 146 | branch | 1026 | 1028 | 0 | -0.011616 | 1932.57 | 2421 |
| 258 | branch | 2004 | 2006 | 0 | -0.011616 | 1737.31 | 2265 |
| 2452 | branch | 49100 | 49101 | 0.00001 | 0.00022 | 1670.56 | 2078 |
| 2453 | branch | 49100 | 49101 | 0.00001 | 0.00022 | 1670.56 | 2078 |

Sobrecargas por `RATE_A > 0`:

- `81` ramas con loading mayor a 100%.
- `996` ramas con `RATE_A=0`.

## 7. Sensibilidades ejecutadas

Estas pruebas fueron no destructivas y se ejecutaron en variables MATLAB temporales.

| Prueba | Resultado | Interpretacion |
|---|---|---|
| HVDC/dcline status = 0 | no converge | HVDC activo sostiene el balance/topologia efectiva |
| System switching devices off | no converge | los switching devices online son topologicamente relevantes |
| Switched shunts `BINIT` removidos | no converge | los shunts conmutables fijados por `BINIT` son electricamente criticos |
| FACTS aproximado `+100 MVAr` en bus 40403 | no converge | el FACTS ignorado puede tener impacto fuerte |
| FACTS aproximado `-100 MVAr` en bus 40403 | converge, `max |dVM|=0.328337`, `max |dVA|=10.351` | sensibilidad alta alrededor de ese control |
| Taps y phase shifts de transformadores neutralizados | no converge | taps/shifts actuales son esenciales |
| `pf.enforce_q_lims=1` legacy | no converge, `max |dVM|=1.065899` | diferencias de tratamiento de limites Q son importantes |
| `pf.enforce_q_lims=2` legacy | no converge, `max |dVM|=37.675074` | conversion PV/PQ puede desestabilizar el caso |
| Piso baja impedancia `1e-4` | converge, `max |dVM|=0.000061` | baja impedancia no parece causa primaria |

## 8. Ranking preliminar de fuentes de discrepancia

| Rank | Seccion asociada | Cantidad | Mecanismo | Impacto observado/esperado | Severidad |
|---:|---|---:|---|---|---|
| 1 | `SWITCHED SHUNT` | 361 | MATPOWER usa `BINIT` fijo; PSS/E tiene control discreto/remoto y `SWSHNT=2` | remover `BINIT` no converge | alta |
| 2 | `TWO-TERMINAL DC` | 8 | `dcline` simplifica HVDC; no modela perdidas `RDC`, taps, VCMOD ni solucion DC interna | apagar dcline no converge | alta |
| 3 | `TRANSFORMER` + `IMPEDANCE CORRECTION` | 2491 + 12 tablas | taps actuales conservados, pero controles y `TAB` no | neutralizar taps/shifts no converge; 36 devanados con TAB | alta |
| 4 | `SYSTEM SWITCHING DEVICE` | 508 | conversion a rama R=0/X fija; `STAT` validado y metadata preservada en `mpc.psse.swdev` | apagarlos no converge | alta |
| 5 | `FACTS DEVICE` | 1 | ignorado completamente | sensibilidad shunt +/-100 MVAr fuerte | media-alta |
| 6 | `GENERATOR` | 961 | control remoto, reparto RMPCT y limites Q no equivalentes | 19 violaciones finales de Q, grandes cambios Q | media-alta |
| 7 | `BRANCH` | 2802 | metadata Rev34 preservada en `mpc.psse.branch`, sin accion electrica adicional | afecta reportes/sobrecargas si no se consulta la estructura auxiliar | baja |
| 8 | `AREA/ZONE/OWNER` | 15/65/24 | metadata administrativa preservada en `mpc.psse.area/zone/owner`; intercambio de area deshabilitado en este caso | bajo impacto electrico directo | baja |

## 9. Evidencia documental local usada

PSS/E:

- `PSSE/DataFormats.pdf`
  - `1.7 Bus Data`
  - `1.8 Load Data`
  - `1.9 Fixed Shunt Data`
  - `1.11 Generator Data`
  - `1.13 Non-Transformer Branch Data`
  - `1.14 System Switching Device Data`
  - `1.15 Transformer Data`
  - `1.17 Area Interchange Data`
  - `1.18 Two-Terminal DC Transmission Line Data`
  - `1.20 Transformer Impedance Correction Tables`
  - `1.23 Zone Data`
  - `1.25 Owner Data`
  - `1.26 FACTS Device Data`
  - `1.27 Switched Shunt Data`
- `PSSE/PAGV1.pdf`
  - `6.7 Power Flow Solution`
  - Automatic adjustments for transformer taps, phase shifters, area interchange, dc taps and switched shunts
  - FACTS device modeling
  - Two-terminal HVDC converter/tap logic

MATPOWER:

- `Matpower Manuals/MATPOWER-manual-8.1.pdf`
  - `4.1 AC Power Flow`
  - `4.4 runpf`
  - `7.3 DC Line Model`
  - Appendix B MATPOWER case format
- `Matpower Manuals/matpower_ref_manual.pdf`
  - `psse2mpc`
  - `psse_read`
  - `psse_parse`
  - `psse_parse_section`
  - `psse_parse_line`
  - `psse_convert`
  - `psse_convert_xfmr`
  - `psse_convert_hvdc`
  - `runpf`
  - `makeYbus`
  - `makeSbus`
  - `bustypes`
  - `pfsoln`

## 10. Evidencia de codigo local

Archivos clave:

- `matpower/lib/psse2mpc.m`
  - Encadena `psse_read`, `psse_parse`, `psse_convert`.
  - Nota que la conversion RAW es experimental y solo algunas secciones se leen.
- `matpower/lib/psse_read.m`
  - Detecta secciones del RAW mediante records terminadores.
- `matpower/lib/psse_parse.m`
  - Parsea BUS, LOAD, SHUNT, GEN, BRANCH, SYSTEM SWITCHING DEVICE, TRANSFORMER, AREA, TWO-TERMINAL DC, SWITCHED SHUNT, ZONE, OWNER y FACTS.
  - Salta VSC, MULTI-TERMINAL DC, MULTI-SECTION LINE, GNE, INDUCTION MACHINE y SUBSTATION.
- `matpower/lib/psse_convert.m`
  - Agrega cargas y shunts a `bus`.
  - Convierte switching devices a ramas y preserva metadata en `mpc.psse.swdev`.
  - Convierte branch Rev34 conservando el equivalente electrico en `mpc.branch` y metadata no nativa en `mpc.psse.branch`.
  - Conserva metadata administrativa de areas, zonas y owners en `mpc.psse.area`, `mpc.psse.zone` y `mpc.psse.owner`.
  - Llama `psse_convert_xfmr` y `psse_convert_hvdc`.
- `matpower/lib/psse_convert_xfmr.m`
  - Convierte trafos 2W y 3W.
  - Agrega buses estrella para trafos 3W.
  - Conserva taps y phase shifts actuales, no la logica de control.
- `matpower/lib/psse_convert_hvdc.m`
  - Convierte two-terminal DC a `mpc.dcline`.
  - Calcula `PF/PT`, limites Q y status.
  - No modela perdidas `RDC` en `LOSS0/LOSS1`.
- `matpower/lib/runpf.m`
  - Newton AC por defecto.
  - `pf.enforce_q_lims` desactivado por defecto.
- `matpower/lib/makeYbus.m`
  - Usa R/X/B, tap y shift para armar `Ybus`.
- `matpower/lib/makeSbus.m`
  - Arma inyeccion compleja generacion menos demanda.
- `matpower/lib/bustypes.m`
  - Construye REF/PV/PQ segun tipo de bus y generadores online.
- `matpower/lib/pfsoln.m`
  - Actualiza VM/VA, QG y flujos de ramas.
