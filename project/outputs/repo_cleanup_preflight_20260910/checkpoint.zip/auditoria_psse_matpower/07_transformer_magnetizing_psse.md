# Transformer MAG1/MAG2 / magnetizacion PSS/E

## 1. Alcance

Este issue cubre solo la magnetizacion de transformadores PSS/E en `TRANSFORMER
DATA`: campos `CM`, `MAG1` y `MAG2`. No agrega nuevos controles iterativos ni
modifica `runpf`, `makeYbus`, `makeSbus` o la logica ULTC.

## 2. Evidencia RAW

En `PSSE/V26p_Trs_2532.raw` hay:

- `2491` transformadores totales.
- `2241` transformadores activos.
- `56` transformadores activos con `MAG1` o `MAG2` no nulo.
- `35` de dos devanados y `21` de tres devanados.
- `17` activos con `MAG1/MAG2` no nulo y algun `COD=1`.
- Todos los casos con magnetizacion no nula usan `CM=1` o `CM=2`.

## 3. Evidencia documental

Segun `PSSE/DataFormats.pdf`, en `Transformer Data`:

- La admitancia magnetizante se modela conectada a tierra en el bus `I`, es
  decir, la barra del devanado 1.
- `CM=1`: `MAG1` y `MAG2` son conductancia y susceptancia en pu sobre base MVA
  del sistema y base de tension del bus del devanado 1. `MAG2` no nulo se ingresa
  como valor negativo.
- `CM=2`: `MAG1` es la perdida en vacio en W y `MAG2` es la corriente de
  excitacion en pu sobre `SBASE1-2` y `NOMV1`. `MAG2` no nulo se ingresa como
  valor positivo.

## 4. Decision de modelado

La magnetizacion se convierte durante `psse2mpc` como shunt fijo en
`bus(:, GS)` y `bus(:, BS)` del bus `I`.

Para `CM=1`:

```text
GS += MAG1 * baseMVA
BS += MAG2 * baseMVA
```

Para `CM=2`:

```text
g0 = MAG1 / 1e6 / SBASE1-2
b0 = -sqrt(MAG2^2 - g0^2)
scale = SBASE1-2 / baseMVA * (BASEKV_I / NOMV1)^2
GS += g0 * scale * baseMVA
BS += b0 * scale * baseMVA
```

Si `NOMV1=0`, se usa la tension base del bus `I`, coherente con la conversion
existente de transformadores.

## 5. Implementacion

Cambios locales:

- `matpower/lib/psse_parse.m`: parsea `MAG1/MAG2` en transformadores 2W y 3W.
- `matpower/lib/psse_convert_xfmr.m`: convierte la magnetizacion y la suma a
  `bus(:, GS/BS)` en la barra del devanado 1.
- `matpower/lib/t/t_psse.m`: agrega cobertura de parsing y conversion.
- `matpower/lib/t/t_psse_case4.raw`: agrega casos sintenticos `CM=1` y `CM=2`.
- `matpower/lib/t/t_psse_case3.m`: actualiza la referencia historica, porque
  ahora la conversion conserva magnetizacion que antes se ignoraba.

## 6. Validacion PSS/E

Casos chicos:

- `psse_validation_cases_mag/psse_xfmr_mag_2bus_cm1.raw`
- `psse_validation_cases_mag/psse_xfmr_mag_2bus_cm2.raw`
- `psse_validation_cases_mag/psse_xfmr_mag_3w_cm1.raw`
- `psse_validation_cases_mag/psse_xfmr_mag_3w_cm2.raw`

Resultados PSS/E:

- Los 4 casos convergen en 2 iteraciones.
- Mismatch final reportado: `0.00 MW / 0.00 Mvar`.
- `CM=1`: swing `PGEN=1.0 MW`, `QGEN=2.0 Mvar`.
- `CM=2`: swing `PGEN=1.0 MW`, `QGEN=9.9 Mvar` en el reporte PSS/E; el valor
  calculado es `9.949874 Mvar` y PSS/E lo redondea a una cifra decimal.

La evidencia completa esta en
`psse_validation_cases_mag/results_psse_validation.md`.

## 7. Validacion MATPOWER

Pruebas ejecutadas:

- `t_psse(0)`: `176/176` exitosos.
- `t_mpxt_psse(0)`: `48/48` exitosos.
- RAW grande `V26p_Trs_2532.raw`:
  - `psse2mpc` correcto.
  - `runpf`: `success=1`, `iterations=4`.
  - `runpf_psse`: `success=1`, `iterations=5`, `ACTAPS=0`, `adjustments=0`.

Los 4 RAWs chicos en MATPOWER dan:

- `CM=1`: `GS=1.000000`, `BS=-2.000000`, `PG=1.000000`, `QG=2.000000`.
- `CM=2`: `GS=1.000000`, `BS=-9.949874`, `PG=1.000000`, `QG=9.949874`.

## 8. Riesgos / limitaciones

- Solo se implementan `CM=1` y `CM=2`, que son los modos presentes en el RAW.
- `CM` no soportado se reporta y se ignora para no introducir una conversion
  especulativa.
- La validacion PSS/E fue hecha en casos chicos sin carga, para aislar la rama
  magnetizante.

