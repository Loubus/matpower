function summary = compare_psse_cli_cases(group_name, reference_root)
% compare_psse_cli_cases - Compares PSSE CLI solved RAWs with runpf_psse.
% ::
%
%   SUMMARY = COMPARE_PSSE_CLI_CASES()
%   SUMMARY = COMPARE_PSSE_CLI_CASES(GROUP_NAME)
%   SUMMARY = COMPARE_PSSE_CLI_CASES(GROUP_NAME, REFERENCE_ROOT)
%
% Runs each RAW fixture in PSSE/GROUP_NAME through MATPOWER's runpf_psse and
% compares the result against the corresponding PSSE CLI solved RAW and log.
% The default group is SOLVER, which contains the small SYSTEM-WIDE solver
% option fixtures. Use GROUP_NAME = 'AUDITORIA_ALL' to recursively validate
% all auditoria_psse_matpower RAW fixtures that have a matching solved_raw
% export. For AUDITORIA_ALL, REFERENCE_ROOT can point to a mirrored PSSE CLI
% output tree with <fixture-folder>/solved_raw/<case>_solved.raw references.
%
% This tool does not modify the original RAW/SAV/log fixtures. It writes CSV,
% Markdown and MAT summaries under auditoria_psse_matpower/results/.
%
% See also runpf_psse, psse2mpc.

if nargin < 1 || isempty(group_name)
    group_name = 'SOLVER';
end
if nargin < 2
    reference_root = '';
end

audit_dir = fileparts(mfilename('fullpath'));
root_dir = fileparts(audit_dir);
mp_dir = fullfile(root_dir, 'matpower');
if strcmpi(group_name, 'AUDITORIA_ALL')
    psse_dir = audit_dir;
    [cases, skipped_cases] = find_auditoria_cases(audit_dir, reference_root);
else
    psse_dir = fullfile(root_dir, 'PSSE', group_name);
    cases = find_cases(psse_dir);
    skipped_cases = skipped_case_template();
    skipped_cases(1) = [];
end
results_dir = fullfile(audit_dir, 'results', 'psse_cli_comparison');
if ~exist(results_dir, 'dir')
    mkdir(results_dir);
end
addpath(fullfile(mp_dir, 'lib'));

mpopt = mpoption('verbose', 0, 'out.all', 0);
if strcmpi(group_name, 'AUDITORIA_ALL')
    % The full audit set intentionally includes mixed-control cases that
    % validate the coordinated active-set fallback. Keep runpf_psse()
    % default behavior explicit by opting in from this validation harness.
    mpopt.exp.psse_coordinated_active_set = 1;
end

summary = struct();
summary.generated_at = datestr(now, 'yyyy-mm-dd HH:MM:SS');
summary.group = group_name;
summary.root_dir = root_dir;
summary.psse_dir = psse_dir;
summary.reference_root = reference_root;
summary.matpower_dir = mp_dir;
summary.cases = repmat(empty_case_result(), 1, numel(cases));
summary.skipped_cases = skipped_cases;

for k = 1:numel(cases)
    fprintf('Comparing PSSE CLI case %d/%d: %s\n', ...
        k, numel(cases), cases(k).name);
    summary.cases(k) = run_one_case(cases(k), mpopt);
end

stamp = datestr(now, 'yyyymmdd_HHMMSS');
prefix = sprintf('%s_comparison_%s', lower(safe_name(group_name)), stamp);
csv_path = fullfile(results_dir, [prefix '.csv']);
param_csv_path = fullfile(results_dir, [prefix '_parameters.csv']);
md_path = fullfile(results_dir, [prefix '.md']);
mat_path = fullfile(results_dir, [prefix '.mat']);
latest_csv = fullfile(results_dir, [lower(safe_name(group_name)) '_comparison_latest.csv']);
latest_param_csv = fullfile(results_dir, ...
    [lower(safe_name(group_name)) '_comparison_parameters_latest.csv']);
latest_md = fullfile(results_dir, [lower(safe_name(group_name)) '_comparison_latest.md']);

write_case_csv(summary, csv_path);
write_parameter_csv(summary, param_csv_path);
write_report(summary, md_path);
copyfile(csv_path, latest_csv);
copyfile(param_csv_path, latest_param_csv);
copyfile(md_path, latest_md);
save(mat_path, 'summary');

summary.csv_path = csv_path;
summary.parameter_csv_path = param_csv_path;
summary.report_path = md_path;
summary.mat_path = mat_path;
summary.latest_csv_path = latest_csv;
summary.latest_parameter_csv_path = latest_param_csv;
summary.latest_report_path = latest_md;

fprintf('Wrote CSV: %s\n', csv_path);
fprintf('Wrote parameter CSV: %s\n', param_csv_path);
fprintf('Wrote report: %s\n', md_path);
fprintf('Wrote MAT data: %s\n', mat_path);

function cases = find_cases(psse_dir)
if exist(psse_dir, 'dir') ~= 7
    error('compare_psse_cli_cases:missing_dir', ...
        'PSS/E case directory does not exist: %s', psse_dir);
end
raw_files = dir(fullfile(psse_dir, '*.raw'));
cases = struct('name', {}, 'raw', {}, 'solved_raw', {}, 'log', {});
for k = 1:numel(raw_files)
    name = raw_files(k).name(1:end-4);
    solved_raw = fullfile(psse_dir, 'solved_raw', [name '_solved.raw']);
    log_path = fullfile(psse_dir, 'logs', [name '.log']);
    if exist(solved_raw, 'file') ~= 2
        continue;
    end
    cases(end+1) = struct( ... %#ok<AGROW>
        'name', name, ...
        'raw', fullfile(raw_files(k).folder, raw_files(k).name), ...
        'solved_raw', solved_raw, ...
        'log', log_path);
end
if isempty(cases)
    error('compare_psse_cli_cases:no_cases', ...
        'No RAW files with matching solved_raw/*_solved.raw were found in %s.', ...
        psse_dir);
end

function [cases, skipped] = find_auditoria_cases(audit_dir, reference_root)
raw_files = dir(fullfile(audit_dir, '**', '*.raw'));
cases = struct('name', {}, 'raw', {}, 'solved_raw', {}, 'log', {});
skipped = skipped_case_template();
skipped(1) = [];
for k = 1:numel(raw_files)
    raw_path = fullfile(raw_files(k).folder, raw_files(k).name);
    if is_ignored_auditoria_raw(raw_path)
        continue;
    end
    name = raw_files(k).name(1:end-4);
    rel_name = strrep(relative_path(raw_path(1:end-4), audit_dir), filesep, '/');
    [solved_raw, log_path, reason] = find_auditoria_reference( ...
        raw_files(k).folder, name, audit_dir, reference_root);
    if exist(solved_raw, 'file') == 2
        cases(end+1) = struct( ... %#ok<AGROW>
            'name', rel_name, ...
            'raw', raw_path, ...
            'solved_raw', solved_raw, ...
            'log', log_path);
    else
        skipped(end+1) = struct( ... %#ok<AGROW>
            'name', rel_name, ...
            'raw', raw_path, ...
            'log', log_path, ...
            'reason', reason);
    end
end
if isempty(cases)
    error('compare_psse_cli_cases:no_cases', ...
        'No auditoria RAW files with matching solved_raw/*_solved.raw were found in %s.', ...
        audit_dir);
end

function [solved_raw, log_path, reason] = find_auditoria_reference( ...
        case_dir, name, audit_dir, reference_root)
local_solved = fullfile(case_dir, 'solved_raw', [name '_solved.raw']);
local_log = find_log_for_raw(case_dir, name);
rel_dir = relative_path(case_dir, audit_dir);
solved_raw = local_solved;
log_path = local_log;
reason = sprintf('missing solved_raw/%s_solved.raw', name);

if ~isempty(reference_root)
    ext_solved = fullfile(reference_root, rel_dir, 'solved_raw', ...
        [name '_solved.raw']);
    ext_log = find_log_for_raw(fullfile(reference_root, rel_dir), name);
    if exist(ext_solved, 'file') == 2
        solved_raw = ext_solved;
        log_path = ext_log;
        return;
    end
    reason = sprintf(['missing solved_raw/%s_solved.raw locally and under ' ...
        'reference root'], name);
end

if exist(local_solved, 'file') == 2
    return;
end

function tf = is_ignored_auditoria_raw(raw_path)
parts = strsplit(strrep(raw_path, '/', filesep), filesep);
tf = any(strcmpi(parts, 'solved_raw')) || any(strcmpi(parts, 'results'));

function log_path = find_log_for_raw(case_dir, name)
candidates = {
    fullfile(case_dir, 'logs', [name '.log']);
    fullfile(case_dir, [name '.log'])
    };
log_path = '';
for k = 1:numel(candidates)
    if exist(candidates{k}, 'file') == 2
        log_path = candidates{k};
        return;
    end
end

function rel = relative_path(path, root)
rel = path;
root = char(root);
if startsWith(path, [root filesep], 'IgnoreCase', true)
    rel = path(numel(root) + 2:end);
elseif strcmpi(path, root)
    rel = '';
end

function row = skipped_case_template()
row = struct('name', '', 'raw', '', 'log', '', 'reason', '');

function out = empty_case_result()
out = struct( ...
    'name', '', 'raw', '', 'psse_solved_raw', '', 'psse_log', '', ...
    'psse_log_summary', struct(), 'parse_ok', false, 'parse_error', '', ...
    'warning_count', 0, 'warnings', {{}}, 'run_ok', false, ...
    'run_success', false, 'run_error', '', 'run_iterations', NaN, ...
    'solver_options', struct(), 'bus', struct(), 'gen', struct(), ...
    'swshunt', struct(), 'parameters', struct());

function result = run_one_case(tc, mpopt)
result = empty_case_result();
result.name = tc.name;
result.raw = tc.raw;
result.psse_solved_raw = tc.solved_raw;
result.psse_log = tc.log;
result.psse_log_summary = parse_psse_log(tc.log);
reference = parse_reference(tc.solved_raw);

try
    [mpc, warns] = psse2mpc(tc.raw, 0, 34);
    result.parse_ok = true;
    if isempty(warns)
        warns = {};
    end
    result.warnings = warns(:)';
    result.warning_count = numel(warns);
catch err
    result.parse_error = getReport(err, 'basic', 'hyperlinks', 'off');
    return;
end

try
    [r, success] = runpf_psse(mpc, mpopt);
    result.run_ok = true;
    result.run_success = logical(success);
    if isfield(r, 'iterations')
        result.run_iterations = r.iterations;
    end
    result.solver_options = summarize_solver_options(r);
    result.parameters = compare_effective_parameters(tc.raw, tc.log, r);
    result.bus = compare_bus(reference.bus, r);
    result.gen = compare_gen(reference.gen, r);
    result.swshunt = compare_swshunt(reference.swshunt, r);
catch err
    result.run_error = getReport(err, 'basic', 'hyperlinks', 'off');
end

function ref = parse_reference(raw_path)
lines = read_lines(raw_path);
ref = struct();
ref.bus = parse_bus_section(lines);
ref.gen = parse_generator_section(lines);
ref.swshunt = parse_swshunt_section(lines);

function lines = read_lines(path)
txt = fileread(path);
txt = strrep(txt, sprintf('\r\n'), sprintf('\n'));
txt = strrep(txt, sprintf('\r'), sprintf('\n'));
lines = regexp(txt, sprintf('\n'), 'split')';

function section = section_lines(lines, name)
section = {};
target = ['BEGIN ' upper(name) ' DATA'];
start_idx = 0;
for k = 1:numel(lines)
    if contains(upper(lines{k}), target)
        start_idx = k + 1;
        break;
    end
end
if start_idx == 0
    return;
end
for k = start_idx:numel(lines)
    ln = strtrim(lines{k});
    if startsWith(ln, '0 / END')
        break;
    end
    if isempty(ln) || startsWith(ln, '@!')
        continue;
    end
    section{end+1, 1} = lines{k}; %#ok<AGROW>
end

function rows = parse_bus_section(lines)
sec = section_lines(lines, 'BUS');
rows = struct('bus', {}, 'name', {}, 'basekv', {}, 'type', {}, ...
    'vm', {}, 'va', {});
for k = 1:numel(sec)
    t = csv_tokens(sec{k});
    if numel(t) < 9
        continue;
    end
    rows(end+1) = struct( ... %#ok<AGROW>
        'bus', num_token(t, 1), ...
        'name', clean_token(t{2}), ...
        'basekv', num_token(t, 3), ...
        'type', num_token(t, 4), ...
        'vm', num_token(t, 8), ...
        'va', num_token(t, 9));
end

function rows = parse_generator_section(lines)
sec = section_lines(lines, 'GENERATOR');
rows = struct('bus', {}, 'id', {}, 'pg', {}, 'qg', {}, ...
    'qmax', {}, 'qmin', {}, 'vs', {}, 'ireg', {}, 'status', {});
for k = 1:numel(sec)
    t = csv_tokens(sec{k});
    if numel(t) < 16
        continue;
    end
    rows(end+1) = struct( ... %#ok<AGROW>
        'bus', num_token(t, 1), ...
        'id', clean_token(t{2}), ...
        'pg', num_token(t, 3), ...
        'qg', num_token(t, 4), ...
        'qmax', num_token(t, 5), ...
        'qmin', num_token(t, 6), ...
        'vs', num_token(t, 7), ...
        'ireg', num_token(t, 8), ...
        'status', parse_generator_status(t));
end

function status = parse_generator_status(t)
status = NaN;
v16 = num_token(t, 16);
v15 = num_token(t, 15);
if ismember(v16, [0 1])
    status = v16;
elseif ismember(v15, [0 1])
    status = v15;
end

function rows = parse_swshunt_section(lines)
sec = section_lines(lines, 'SWITCHED SHUNT');
rows = struct('bus', {}, 'id', {}, 'modsw', {}, 'stat', {}, ...
    'swreg', {}, 'binit', {});
for k = 1:numel(sec)
    t = csv_tokens(sec{k});
    if numel(t) < 10
        continue;
    end
    has_id = ~isempty(regexp(sec{k}, '^\s*[-+]?\d+\s*,\s*[''"]', 'once'));
    if has_id
        id = clean_token(t{2});
        modsw = num_token(t, 3);
        stat = num_token(t, 5);
        swreg = num_token(t, 8);
        binit = num_token(t, 12);
    else
        id = '';
        modsw = num_token(t, 2);
        stat = num_token(t, 4);
        swreg = num_token(t, 7);
        binit = num_token(t, 10);
    end
    rows(end+1) = struct( ... %#ok<AGROW>
        'bus', num_token(t, 1), 'id', id, 'modsw', modsw, ...
        'stat', stat, 'swreg', swreg, 'binit', binit);
end

function log = parse_psse_log(log_path)
log = struct('available', false, 'iterations', NaN, ...
    'max_mismatch_mva', NaN, 'max_mismatch_bus', NaN, ...
    'total_mismatch_mva', NaN);
if exist(log_path, 'file') ~= 2
    return;
end
log.available = true;
lines = read_lines(log_path);
for k = 1:numel(lines)
    ln = lines{k};
    m = regexp(ln, 'Reached tolerance in\s+(\d+)\s+iterations', ...
        'tokens', 'once');
    if ~isempty(m)
        log.iterations = str2double(m{1});
    end
    m = regexp(ln, ['Largest mismatch:\s+[-+0-9.]+\s+MW\s+' ...
        '[-+0-9.]+\s+Mvar\s+([-+0-9.]+)\s+MVA at bus\s+(\d+)'], ...
        'tokens', 'once');
    if ~isempty(m)
        log.max_mismatch_mva = str2double(m{1});
        log.max_mismatch_bus = str2double(m{2});
    end
    m = regexp(ln, 'System total absolute mismatch:\s+([-+0-9.]+)\s+MVA', ...
        'tokens', 'once');
    if ~isempty(m)
        log.total_mismatch_mva = str2double(m{1});
    end
end

function s = summarize_solver_options(r)
s = struct('available', false, 'applied', NaN, 'ignored', NaN, ...
    'unsupported', NaN, 'fallback', NaN, 'warnings', NaN);
if isfield(r, 'psse') && isfield(r.psse, 'solver_options')
    p = r.psse.solver_options;
    s.available = true;
    s.applied = count_field(p, 'applied');
    s.ignored = count_field(p, 'ignored');
    s.unsupported = count_field(p, 'unsupported');
    s.fallback = count_field(p, 'fallback');
    s.warnings = count_field(p, 'warnings');
end

function n = count_field(s, f)
if isfield(s, f)
    n = numel(s.(f));
else
    n = 0;
end

function params = compare_effective_parameters(raw_path, log_path, r)
psse = psse_effective_parameters(raw_path, log_path);
rows = repmat(parameter_row_template(), 1, numel(psse));
for k = 1:numel(psse)
    rows(k) = psse(k);
    rows(k) = add_matpower_parameter_status(rows(k), r);
end
params = struct();
params.rows = rows;
params.count = numel(rows);
params.gaps = sum(~strcmp({rows.comparison}, 'value_match') & ...
    ~strcmp({rows.comparison}, 'reported_inactive'));

function rows = psse_effective_parameters(raw_path, log_path)
raw_values = parse_raw_system_values(raw_path);
log_values = parse_log_effective_values(log_path);
rows = parameter_row_template();
rows(1) = [];

if ~isempty(log_values.method)
    rows(end+1) = make_parameter_row('SOLVER.METHOD', ... %#ok<AGROW>
        raw_explicit(raw_values, 'SOLVER.METHOD'), log_values.method, ...
        'BAT_FNSL command method', raw_values);
end

solver_names = {'ACTAPS', 'AREAIN', 'PHSHFT', 'DCTAPS', ...
    'SWSHNT', 'FLATST', 'VARLIM', 'NONDIV'};
for k = 1:min(numel(solver_names), numel(log_values.options))
    key = ['SOLVER.' solver_names{k}];
    rows(end+1) = make_parameter_row(key, raw_explicit(raw_values, key), ... %#ok<AGROW>
        log_values.options(k), 'BAT_FNSL option array', raw_values);
end

slot_rows = {
    'GENERAL.PQBRAK', 'realar', 10;
    'GENERAL.THRSHZ', 'realar', 11;
    'NEWTON.ITMXN', 'intgar', 2;
    'NEWTON.ACCN', 'realar', 5;
    'NEWTON.TOLN', 'realar', 6;
    'NEWTON.DVLIM', 'realar', 15;
    'NEWTON.NDVFCT', 'realar', 16;
    'NEWTON.VCTOLQ', 'realar', 17;
    'NEWTON.VCTOLV', 'realar', 18;
    'ADJUST.ADJTHR', 'realar', 12;
    'ADJUST.ACCTAP', 'realar', 13;
    'ADJUST.TAPLIM', 'realar', 14;
    'ADJUST.SWVBND', 'realar', 19;
    'ADJUST.MXTPSS', 'intgar', 4;
    'ADJUST.MXSWIM', 'intgar', 5;
};
for k = 1:size(slot_rows, 1)
    key = slot_rows{k, 1};
    kind = slot_rows{k, 2};
    idx = slot_rows{k, 3};
    [has_value, value] = slot_value(log_values, kind, idx);
    if has_value
        rows(end+1) = make_parameter_row(key, ... %#ok<AGROW>
            raw_explicit(raw_values, key), value, ...
            'BAT_SOLUTION_PARAMETERS_5 effective value', raw_values);
    end
end

for k = 1:numel(raw_values)
    if ~has_parameter_key(rows, raw_values(k).key)
        rows(end+1) = make_parameter_row(raw_values(k).key, true, ... %#ok<AGROW>
            raw_values(k).value, 'RAW explicit value not in parsed PSSE command', ...
            raw_values);
    end
end

function tf = has_parameter_key(rows, key)
tf = false;
for k = 1:numel(rows)
    if strcmpi(rows(k).key, key)
        tf = true;
        return;
    end
end

function [has_value, value] = slot_value(log_values, kind, idx)
has_value = false;
value = NaN;
switch kind
    case 'intgar'
        if numel(log_values.intgar) >= idx
            value = log_values.intgar(idx);
            has_value = true;
        end
    case 'realar'
        if numel(log_values.realar) >= idx
            value = log_values.realar(idx);
            has_value = true;
        end
end

function row = make_parameter_row(key, is_explicit, psse_value, source, raw_values)
row = parameter_row_template();
row.key = upper(key);
row.raw_explicit = logical(is_explicit);
row.raw_value = raw_value_text(raw_values, key);
row.psse_effective_value = value_text(psse_value);
row.psse_source = source;

function row = parameter_row_template()
row = struct( ...
    'key', '', ...
    'raw_explicit', false, ...
    'raw_value', '', ...
    'psse_effective_value', '', ...
    'psse_source', '', ...
    'matpower_status', 'not_evaluated', ...
    'matpower_value', '', ...
    'matpower_target', '', ...
    'comparison', 'not_evaluated', ...
    'note', '');

function values = parse_raw_system_values(raw_path)
values = struct('key', {}, 'value', {});
if exist(raw_path, 'file') ~= 2
    return;
end
lines = read_lines(raw_path);
for k = 1:numel(lines)
    line = strtrim(lines{k});
    if isempty(line)
        continue;
    end
    if ~isempty(regexp(line, '(?i)^0\s*/\s*END OF SYSTEM-WIDE DATA', 'once'))
        break;
    end
    m = regexp(line, '(?i)^(SOLVER|NEWTON|ADJUST|GENERAL)\s*,', ...
        'tokens', 'once');
    if isempty(m)
        continue;
    end
    section = upper(m{1});
    no_comment = regexp(line, '/', 'split');
    no_comment = no_comment{1};
    tokens = csv_tokens(no_comment);
    if strcmp(section, 'SOLVER') && numel(tokens) >= 2
        method = clean_token(tokens{2});
        if ~contains(method, '=')
            values(end+1) = struct('key', 'SOLVER.METHOD', ... %#ok<AGROW>
                'value', method);
        end
    end
    matches = regexp(no_comment, ...
        '(?i)([A-Z][A-Z0-9_]*)\s*=\s*([^,\s]+)', 'tokens');
    for j = 1:numel(matches)
        name = upper(matches{j}{1});
        value = clean_token(matches{j}{2});
        values(end+1) = struct('key', [section '.' name], ... %#ok<AGROW>
            'value', value);
    end
end

function log_values = parse_log_effective_values(log_path)
log_values = struct('method', '', 'options', [], 'intgar', [], 'realar', []);
if exist(log_path, 'file') ~= 2
    return;
end
lines = read_lines(log_path);
for k = 1:numel(lines)
    ln = strtrim(lines{k});
    m = regexp(ln, 'Solver option array values:\s+(.+)$', 'tokens', 'once');
    if ~isempty(m)
        log_values.options = numbers_in_text(m{1});
    end
    m = regexp(ln, 'Solver option array code form:\s+BAT_(FNSL|FDNS)', ...
        'tokens', 'once');
    if ~isempty(m)
        log_values.method = upper(m{1});
    end
    m = regexp(ln, '^BAT_SOLUTION_PARAMETERS_5\s+(.+)$', ...
        'tokens', 'once');
    if ~isempty(m)
        vals = numbers_in_text(m{1});
        if numel(vals) >= 30
            log_values.intgar = vals(1:9);
            log_values.realar = vals(10:30);
        end
    end
    if isempty(log_values.method)
        m = regexp(ln, '^\s*BAT_(FNSL|FDNS)\s+', 'tokens', 'once');
        if ~isempty(m)
            log_values.method = upper(m{1});
        end
    end
end

function row = add_matpower_parameter_status(row, r)
row.matpower_status = 'not_reported';
row.matpower_value = '';
row.matpower_target = '';
row.note = 'No runpf_psse policy or control report exposes this effective PSS/E value.';

if strcmp(row.key, 'GENERAL.PQBRAK')
    row.matpower_target = 'mp.psse_pqbrak_control';
    if isfield(r, 'psse') && isfield(r.psse, 'pqbrak') && ...
            isfield(r.psse.pqbrak, 'pqbrak')
        row.matpower_status = 'applied/control';
        row.matpower_value = value_text(r.psse.pqbrak.pqbrak);
        row.note = 'Applied by the PSS/E low-voltage load scaling helper.';
    else
        row.matpower_status = 'not_active';
        row.note = 'PSS/E PQBRAK control state was not present in runpf_psse results.';
    end
    row.comparison = compare_parameter_row(row);
    return;
end

[found, category, entry] = policy_entry_for_key(r, row.key);
if found
    row.matpower_status = [category '/' entry.status];
    row.matpower_value = value_text(entry.value);
    row.matpower_target = entry.target;
    row.note = entry.reason;
else
    row.matpower_status = 'not_reported';
    if ~row.raw_explicit
        row.note = 'PSS/E uses this effective default, but runpf_psse only reports explicit RAW fields for this parameter.';
    end
end
row.comparison = compare_parameter_row(row);

function [found, category, entry] = policy_entry_for_key(r, key)
found = false;
category = '';
entry = struct();
if ~isfield(r, 'psse') || ~isfield(r.psse, 'solver_options')
    return;
end
p = r.psse.solver_options;
parts = regexp(key, '\.', 'split');
if numel(parts) ~= 2
    return;
end
section = lower(parts{1});
name = upper(parts{2});
categories = {'applied', 'ignored', 'unsupported', 'fallback'};
for c = 1:numel(categories)
    cat = categories{c};
    if ~isfield(p, cat)
        continue;
    end
    entries = p.(cat);
    for k = 1:numel(entries)
        if strcmpi(entries(k).section, section) && ...
                strcmpi(entries(k).name, name)
            found = true;
            category = cat;
            entry = entries(k);
            return;
        end
    end
end

function comparison = compare_parameter_row(row)
if startsWith(row.matpower_status, 'applied')
    if values_equivalent(row.psse_effective_value, row.matpower_value)
        comparison = 'value_match';
    else
        comparison = 'applied_value_diff';
    end
elseif startsWith(row.matpower_status, 'ignored')
    comparison = 'ignored_by_matpower';
elseif startsWith(row.matpower_status, 'unsupported')
    comparison = 'unsupported_by_matpower';
elseif startsWith(row.matpower_status, 'fallback')
    comparison = 'matpower_fallback';
elseif strcmp(row.matpower_status, 'not_active')
    comparison = 'not_active';
else
    comparison = 'not_reported';
end

function tf = values_equivalent(a, b)
an = str2double(a);
bn = str2double(b);
if ~isnan(an) && ~isnan(bn)
    tf = abs(an - bn) <= 1e-9 * max([1 abs(an) abs(bn)]);
else
    tf = strcmpi(strtrim(a), strtrim(b));
end

function tf = raw_explicit(raw_values, key)
tf = false;
for k = 1:numel(raw_values)
    if strcmpi(raw_values(k).key, key)
        tf = true;
        return;
    end
end

function txt = raw_value_text(raw_values, key)
txt = '';
for k = 1:numel(raw_values)
    if strcmpi(raw_values(k).key, key)
        txt = value_text(raw_values(k).value);
        return;
    end
end

function vals = numbers_in_text(txt)
tok = regexp(txt, '[-+]?\d+(?:\.\d*)?(?:[Ee][-+]?\d+)?', 'match');
vals = str2double(tok);

function txt = value_text(value)
if isnumeric(value)
    if isempty(value)
        txt = '';
    elseif isscalar(value)
        txt = sprintf('%.15g', value);
    else
        pieces = arrayfun(@(x) sprintf('%.15g', x), value, ...
            'UniformOutput', false);
        txt = strjoin(pieces, ' ');
    end
elseif ischar(value)
    txt = strtrim(value);
elseif isstring(value) && isscalar(value)
    txt = char(value);
else
    txt = '';
end

function cmp = compare_bus(ref_bus, r)
cmp = struct('available', false, 'count', 0, 'matched', 0, ...
    'max_abs_vm', NaN, 'max_abs_vm_bus', NaN, 'rms_vm', NaN, ...
    'max_abs_va', NaN, 'max_abs_va_bus', NaN, 'rms_va', NaN, ...
    'top', {{}});
if isempty(ref_bus) || isempty(r) || ~isfield(r, 'bus')
    return;
end
[~, ~, ~, ~, BUS_I, ~, ~, ~, ~, ~, ~, VM, VA] = idx_bus;
bus = [ref_bus.bus]';
ref_vm = [ref_bus.vm]';
ref_va = [ref_bus.va]';
[tf, loc] = ismember(bus, r.bus(:, BUS_I));
if ~any(tf)
    return;
end
dvm = r.bus(loc(tf), VM) - ref_vm(tf);
dva = angle_diff_deg(r.bus(loc(tf), VA), ref_va(tf));
bus_ok = bus(tf);
cmp.available = true;
cmp.count = numel(bus);
cmp.matched = nnz(tf);
cmp.rms_vm = sqrt(mean(dvm .^ 2));
cmp.rms_va = sqrt(mean(dva .^ 2));
[cmp.max_abs_vm, i_vm] = max(abs(dvm));
cmp.max_abs_vm_bus = bus_ok(i_vm);
[cmp.max_abs_va, i_va] = max(abs(dva));
cmp.max_abs_va_bus = bus_ok(i_va);
score = abs(dvm) + abs(dva) / 100;
[~, ord] = sort(score, 'descend');
n = min(5, numel(ord));
cmp.top = cell(n, 1);
for k = 1:n
    i = ord(k);
    cmp.top{k} = sprintf('bus %.0f: dVM %+0.6f pu, dVA %+0.6f deg', ...
        bus_ok(i), dvm(i), dva(i));
end

function cmp = compare_gen(ref_gen, r)
cmp = struct('available', false, 'count', 0, 'matched', 0, ...
    'max_abs_qg', NaN, 'max_abs_qg_bus', NaN, 'rms_qg', NaN, ...
    'top', {{}});
if isempty(ref_gen) || isempty(r) || ~isfield(r, 'gen')
    return;
end
[GEN_BUS, ~, QG] = idx_gen;
ref_bus = [ref_gen.bus]';
ref_qg = [ref_gen.qg]';
mp_qg = NaN(size(ref_qg));
for k = 1:numel(ref_bus)
    idx = find(r.gen(:, GEN_BUS) == ref_bus(k), 1);
    if ~isempty(idx)
        mp_qg(k) = r.gen(idx, QG);
    end
end
ok = ~isnan(mp_qg) & ~isnan(ref_qg);
if ~any(ok)
    return;
end
dq = mp_qg(ok) - ref_qg(ok);
bus_ok = ref_bus(ok);
cmp.available = true;
cmp.count = numel(ref_bus);
cmp.matched = nnz(ok);
cmp.rms_qg = sqrt(mean(dq .^ 2));
[cmp.max_abs_qg, i_q] = max(abs(dq));
cmp.max_abs_qg_bus = bus_ok(i_q);
[~, ord] = sort(abs(dq), 'descend');
n = min(5, numel(ord));
cmp.top = cell(n, 1);
for k = 1:n
    i = ord(k);
    cmp.top{k} = sprintf('bus %.0f: dQG %+0.6f MVAr', ...
        bus_ok(i), dq(i));
end

function cmp = compare_swshunt(ref_swshunt, r)
cmp = struct('available', false, 'count', 0, 'matched', 0, ...
    'max_abs_binit', NaN, 'max_abs_binit_bus', NaN, 'rms_binit', NaN, ...
    'top', {{}});
if isempty(ref_swshunt) || isempty(r) || ~isfield(r, 'psse') || ...
        ~isfield(r.psse, 'swshunt') || ...
        ~isfield(r.psse.swshunt, 'control') || ...
        ~isfield(r.psse.swshunt.control, 'final_binit')
    return;
end
final_binit = r.psse.swshunt.control.final_binit(:);
n = min(numel(ref_swshunt), numel(final_binit));
if n == 0
    return;
end
ref_b = [ref_swshunt(1:n).binit]';
diff = final_binit(1:n) - ref_b;
bus = [ref_swshunt(1:n).bus]';
cmp.available = true;
cmp.count = numel(ref_swshunt);
cmp.matched = n;
cmp.rms_binit = sqrt(mean(diff .^ 2));
[cmp.max_abs_binit, i_b] = max(abs(diff));
cmp.max_abs_binit_bus = bus(i_b);
[~, ord] = sort(abs(diff), 'descend');
nshow = min(5, numel(ord));
cmp.top = cell(nshow, 1);
for k = 1:nshow
    i = ord(k);
    cmp.top{k} = sprintf('bus %.0f: dBINIT %+0.6f MVAr', ...
        bus(i), diff(i));
end

function write_case_csv(summary, path)
rows = repmat(csv_row_template(), numel(summary.cases), 1);
for k = 1:numel(summary.cases)
    c = summary.cases(k);
    rows(k).case_name = c.name;
    rows(k).parse_ok = c.parse_ok;
    rows(k).run_ok = c.run_ok;
    rows(k).run_success = c.run_success;
    rows(k).psse_iterations = get_log_value(c, 'iterations');
    rows(k).mp_iterations = c.run_iterations;
    rows(k).psse_max_mismatch_mva = get_log_value(c, 'max_mismatch_mva');
    rows(k).psse_max_mismatch_bus = get_log_value(c, 'max_mismatch_bus');
    rows(k).bus_count = c.bus.count;
    rows(k).bus_matched = c.bus.matched;
    rows(k).max_abs_vm = c.bus.max_abs_vm;
    rows(k).max_abs_vm_bus = c.bus.max_abs_vm_bus;
    rows(k).rms_vm = c.bus.rms_vm;
    rows(k).max_abs_va = c.bus.max_abs_va;
    rows(k).max_abs_va_bus = c.bus.max_abs_va_bus;
    rows(k).rms_va = c.bus.rms_va;
    rows(k).gen_count = c.gen.count;
    rows(k).gen_matched = c.gen.matched;
    rows(k).max_abs_qg = c.gen.max_abs_qg;
    rows(k).max_abs_qg_bus = c.gen.max_abs_qg_bus;
    rows(k).rms_qg = c.gen.rms_qg;
    rows(k).swshunt_count = c.swshunt.count;
    rows(k).swshunt_matched = c.swshunt.matched;
    rows(k).max_abs_binit = c.swshunt.max_abs_binit;
    rows(k).max_abs_binit_bus = c.swshunt.max_abs_binit_bus;
    rows(k).solver_applied = c.solver_options.applied;
    rows(k).solver_ignored = c.solver_options.ignored;
    rows(k).solver_unsupported = c.solver_options.unsupported;
    rows(k).solver_fallback = c.solver_options.fallback;
end
writetable(struct2table(rows), path);

function row = csv_row_template()
row = struct( ...
    'case_name', '', 'parse_ok', false, 'run_ok', false, ...
    'run_success', false, 'psse_iterations', NaN, 'mp_iterations', NaN, ...
    'psse_max_mismatch_mva', NaN, 'psse_max_mismatch_bus', NaN, ...
    'bus_count', NaN, 'bus_matched', NaN, ...
    'max_abs_vm', NaN, 'max_abs_vm_bus', NaN, 'rms_vm', NaN, ...
    'max_abs_va', NaN, 'max_abs_va_bus', NaN, 'rms_va', NaN, ...
    'gen_count', NaN, 'gen_matched', NaN, ...
    'max_abs_qg', NaN, 'max_abs_qg_bus', NaN, 'rms_qg', NaN, ...
    'swshunt_count', NaN, 'swshunt_matched', NaN, ...
    'max_abs_binit', NaN, 'max_abs_binit_bus', NaN, ...
    'solver_applied', NaN, 'solver_ignored', NaN, ...
    'solver_unsupported', NaN, 'solver_fallback', NaN);

function write_parameter_csv(summary, path)
rows = parameter_csv_template();
rows(1) = [];
for k = 1:numel(summary.cases)
    c = summary.cases(k);
    if ~isfield(c, 'parameters') || ~isfield(c.parameters, 'rows')
        continue;
    end
    for j = 1:numel(c.parameters.rows)
        p = c.parameters.rows(j);
        rows(end+1) = struct( ... %#ok<AGROW>
            'case_name', c.name, ...
            'parameter', p.key, ...
            'raw_explicit', p.raw_explicit, ...
            'raw_value', p.raw_value, ...
            'psse_effective_value', p.psse_effective_value, ...
            'psse_source', p.psse_source, ...
            'matpower_status', p.matpower_status, ...
            'matpower_value', p.matpower_value, ...
            'matpower_target', p.matpower_target, ...
            'comparison', p.comparison, ...
            'note', p.note);
    end
end
writetable(struct2table(rows), path);

function row = parameter_csv_template()
row = struct( ...
    'case_name', '', ...
    'parameter', '', ...
    'raw_explicit', false, ...
    'raw_value', '', ...
    'psse_effective_value', '', ...
    'psse_source', '', ...
    'matpower_status', '', ...
    'matpower_value', '', ...
    'matpower_target', '', ...
    'comparison', '', ...
    'note', '');

function v = get_log_value(c, field)
v = NaN;
if isfield(c.psse_log_summary, field)
    v = c.psse_log_summary.(field);
end

function write_report(summary, path)
fid = fopen(path, 'w');
if fid < 0
    error('compare_psse_cli_cases:report_open', ...
        'Could not open report for writing: %s', path);
end
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, '# PSSE CLI vs runpf_psse Comparison\n\n');
fprintf(fid, 'Generated: `%s`\n\n', summary.generated_at);
fprintf(fid, 'Group: `%s`\n\n', summary.group);
fprintf(fid, 'PSS/E case directory: `%s`\n\n', summary.psse_dir);
if isfield(summary, 'reference_root') && ~isempty(summary.reference_root)
    fprintf(fid, 'External PSS/E reference root: `%s`\n\n', summary.reference_root);
end
fprintf(fid, 'This report compares the local PSSE CLI solved RAW exports against `runpf_psse` on the original RAW files. It does not modify the original fixtures.\n\n');
if isfield(summary, 'skipped_cases') && ~isempty(summary.skipped_cases)
    fprintf(fid, 'RAW fixtures without a matching solved RAW are inventoried below as not numerically comparable in this run.\n\n');
end
fprintf(fid, '## Summary\n\n');
fprintf(fid, '| case | PSSE it | MP it | MP success | max abs dVM | max abs dVA | max abs dQG | parameter gaps | applied | ignored | unsupported | fallback |\n');
fprintf(fid, '|---|---:|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|\n');
for k = 1:numel(summary.cases)
    c = summary.cases(k);
    fprintf(fid, '| %s | %.0f | %.0f | %s | %.6g | %.6g | %.6g | %.0f | %.0f | %.0f | %.0f | %.0f |\n', ...
        c.name, get_log_value(c, 'iterations'), c.run_iterations, ...
        yesno(c.run_success), c.bus.max_abs_vm, c.bus.max_abs_va, ...
        c.gen.max_abs_qg, get_parameter_gaps(c), c.solver_options.applied, ...
        c.solver_options.ignored, c.solver_options.unsupported, ...
        c.solver_options.fallback);
end
fprintf(fid, '\n');
write_skipped_cases(fid, summary);
for k = 1:numel(summary.cases)
    write_case_detail(fid, summary.cases(k));
end

function write_skipped_cases(fid, summary)
if ~isfield(summary, 'skipped_cases') || isempty(summary.skipped_cases)
    return;
end
fprintf(fid, '## Not Numerically Compared\n\n');
fprintf(fid, '| case | PSS/E log | reason |\n');
fprintf(fid, '|---|---|---|\n');
for k = 1:numel(summary.skipped_cases)
    c = summary.skipped_cases(k);
    fprintf(fid, '| %s | %s | %s |\n', c.name, ...
        markdown_path_or_dash(c.log), c.reason);
end
fprintf(fid, '\n');

function write_case_detail(fid, c)
fprintf(fid, '## %s\n\n', c.name);
fprintf(fid, '- RAW: `%s`\n', c.raw);
fprintf(fid, '- PSS/E solved RAW: `%s`\n', c.psse_solved_raw);
fprintf(fid, '- PSS/E log: `%s`\n', c.psse_log);
fprintf(fid, '- Parse OK: %s\n', yesno(c.parse_ok));
fprintf(fid, '- runpf_psse OK/success: %s / %s\n', ...
    yesno(c.run_ok), yesno(c.run_success));
if ~c.parse_ok
    fprintf(fid, '- Parse error: `%s`\n\n', oneline(c.parse_error));
    return;
end
if ~c.run_ok
    fprintf(fid, '- Run error: `%s`\n\n', oneline(c.run_error));
    return;
end
fprintf(fid, '- PSS/E iterations: %.0f\n', get_log_value(c, 'iterations'));
fprintf(fid, '- runpf_psse iterations: %.0f\n', c.run_iterations);
fprintf(fid, '- PSS/E largest mismatch: %.6g MVA at bus %.0f\n', ...
    get_log_value(c, 'max_mismatch_mva'), ...
    get_log_value(c, 'max_mismatch_bus'));
fprintf(fid, '- Solver options: applied %.0f, ignored %.0f, unsupported %.0f, fallback %.0f\n', ...
    c.solver_options.applied, c.solver_options.ignored, ...
    c.solver_options.unsupported, c.solver_options.fallback);
fprintf(fid, '- Effective parameter gaps: %.0f\n', get_parameter_gaps(c));
write_parameter_gap_table(fid, c);
fprintf(fid, '- Bus comparison: matched %.0f/%.0f, max |dVM| %.6g pu at bus %.0f, max |dVA| %.6g deg at bus %.0f\n', ...
    c.bus.matched, c.bus.count, c.bus.max_abs_vm, c.bus.max_abs_vm_bus, ...
    c.bus.max_abs_va, c.bus.max_abs_va_bus);
write_bullets(fid, c.bus.top);
if c.gen.available
    fprintf(fid, '- Gen Q comparison: matched %.0f/%.0f, max |dQG| %.6g MVAr at bus %.0f\n', ...
        c.gen.matched, c.gen.count, c.gen.max_abs_qg, c.gen.max_abs_qg_bus);
    write_bullets(fid, c.gen.top);
end
if c.swshunt.available
    fprintf(fid, '- Switched shunt comparison: matched %.0f/%.0f, max |dBINIT| %.6g MVAr at bus %.0f\n', ...
        c.swshunt.matched, c.swshunt.count, ...
        c.swshunt.max_abs_binit, c.swshunt.max_abs_binit_bus);
    write_bullets(fid, c.swshunt.top);
end
fprintf(fid, '\n');

function n = get_parameter_gaps(c)
n = NaN;
if isfield(c, 'parameters') && isfield(c.parameters, 'gaps')
    n = c.parameters.gaps;
end

function write_parameter_gap_table(fid, c)
if ~isfield(c, 'parameters') || ~isfield(c.parameters, 'rows') || ...
        isempty(c.parameters.rows)
    fprintf(fid, '- Effective parameter comparison: unavailable\n');
    return;
end
rows = c.parameters.rows;
is_gap = ~strcmp({rows.comparison}, 'value_match') & ...
    ~strcmp({rows.comparison}, 'reported_inactive');
if ~any(is_gap)
    fprintf(fid, '- Effective parameter comparison: all parsed effective values match applied MATPOWER values.\n');
    return;
end
fprintf(fid, '\nEffective PSS/E parameters not matched as applied MATPOWER values:\n\n');
fprintf(fid, '| parameter | RAW explicit | PSS/E effective | MATPOWER status | MATPOWER value | comparison |\n');
fprintf(fid, '|---|---|---:|---|---:|---|\n');
idx = find(is_gap);
for kk = 1:numel(idx)
    p = rows(idx(kk));
    fprintf(fid, '| %s | %s | %s | %s | %s | %s |\n', ...
        p.key, yesno(p.raw_explicit), p.psse_effective_value, ...
        p.matpower_status, p.matpower_value, p.comparison);
end
fprintf(fid, '\n');

function write_bullets(fid, rows)
if isempty(rows)
    fprintf(fid, '  - none\n');
    return;
end
for k = 1:numel(rows)
    fprintf(fid, '  - %s\n', rows{k});
end

function t = csv_tokens(line)
t = {};
buf = '';
in_quote = false;
quote_char = '';
for k = 1:length(line)
    ch = line(k);
    if ch == '''' || ch == '"'
        if in_quote && ch == quote_char
            in_quote = false;
            quote_char = '';
        elseif ~in_quote
            in_quote = true;
            quote_char = ch;
        else
            buf(end+1) = ch; %#ok<AGROW>
        end
    elseif ch == ',' && ~in_quote
        t{end+1} = strtrim(buf); %#ok<AGROW>
        buf = '';
    else
        buf(end+1) = ch; %#ok<AGROW>
    end
end
t{end+1} = strtrim(buf);

function v = num_token(tokens, idx)
if idx > numel(tokens)
    v = NaN;
else
    v = str2double(clean_token(tokens{idx}));
end

function s = clean_token(s)
s = strtrim(s);
if length(s) >= 2
    if (s(1) == '''' && s(end) == '''') || ...
            (s(1) == '"' && s(end) == '"')
        s = s(2:end-1);
    end
end
s = strtrim(s);

function d = angle_diff_deg(a, b)
d = mod(a - b + 180, 360) - 180;

function s = yesno(v)
if v
    s = 'yes';
else
    s = 'no';
end

function s = oneline(s)
s = strrep(s, sprintf('\n'), ' | ');
s = strrep(s, sprintf('\r'), '');

function out = markdown_path_or_dash(path)
if isempty(path)
    out = '-';
else
    out = sprintf('`%s`', path);
end

function s = safe_name(s)
s = regexprep(s, '[^A-Za-z0-9_]+', '_');
