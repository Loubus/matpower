function data = psse_diag_normalize_run(run, opts) %#ok<INUSD>
%PSSE_DIAG_NORMALIZE_RUN Normalize one loaded PF/CPF run into tables.

define_constants;
results = run.results;
cpf = cpf_struct(results);
lam = cpf_lam(cpf);
warnings = run.warnings;

index_map = build_index_map(run, results);
cpf_points = build_cpf_points(run, cpf, lam);
bus_trace = build_bus_trace(run, cpf, lam);
branch_trace = build_branch_trace(run, cpf, lam);
gen_trace = build_gen_trace(run, results, cpf, lam, warnings);
[capability_audit, cap_warnings] = build_capability_audit(run, results);
warnings = append_warnings(warnings, cap_warnings);
[redispatch_trace, redispatch_technology_trace] = ...
    build_redispatch_trace(run, results);
event_timeline = build_event_timeline(run, cpf, lam);
[vsc_trace, busdc_trace, branchdc_trace] = build_vsc_dc_traces(run, cpf, lam);

manifest = build_run_manifest(run, results, cpf, lam, event_timeline, warnings);

data = struct( ...
    'run_id', run.run_id, ...
    'label', run.label, ...
    'source_dir', run.source_dir, ...
    'primary_file', run.primary_file, ...
    'run_manifest', manifest, ...
    'warnings', warnings, ...
    'index_map', index_map, ...
    'cpf_points', cpf_points, ...
    'bus_trace', bus_trace, ...
    'branch_trace', branch_trace, ...
    'gen_trace', gen_trace, ...
    'vsc_trace', vsc_trace, ...
    'busdc_trace', busdc_trace, ...
    'branchdc_trace', branchdc_trace, ...
    'event_timeline', event_timeline, ...
    'capability_audit', capability_audit, ...
    'redispatch_trace', redispatch_trace, ...
    'redispatch_technology_trace', redispatch_technology_trace, ...
    'raw', run.raw, ...
    'results', results );
end

function cpf = cpf_struct(results)
if isfield(results, 'cpf') && isstruct(results.cpf)
    cpf = results.cpf;
else
    cpf = struct();
end
end

function lam = cpf_lam(cpf)
if isfield(cpf, 'lam') && ~isempty(cpf.lam)
    lam = cpf.lam(:).';
else
    lam = 0;
end
end

function index_map = build_index_map(run, results)
define_constants;
run_id = run.run_id;

bus = empty_table();
if isfield(results, 'bus') && ~isempty(results.bus)
    nb = size(results.bus, 1);
    bus = table(repmat(run_id, nb, 1), (1:nb)', results.bus(:, BUS_I), ...
        results.bus(:, BASE_KV), results.bus(:, BUS_TYPE), ...
        'VariableNames', {'run_id', 'bus_row', 'bus_ext', ...
        'base_kv', 'bus_type'});
end

gen = empty_table();
if ~isempty(run.gen_pq_trace)
    rec = run.gen_pq_trace(1);
    ng = numel(rec.gen_idx);
    tech = generator_technology(run, results, ng);
    gen = table(repmat(run_id, ng, 1), rec.gen_idx(:), rec.gen_idx(:), ...
        rec.bus(:), rec.GEN_STATUS(:), string(tech(:)), ...
        'VariableNames', {'run_id', 'gen_row', 'gen_ext', ...
        'bus_ext', 'status', 'technology'});
elseif isfield(results, 'gen') && ~isempty(results.gen)
    ng = size(results.gen, 1);
    gen_ext = generator_external_indices(results, ng);
    tech = generator_technology(run, results, ng);
    gen = table(repmat(run_id, ng, 1), (1:ng)', gen_ext(:), ...
        results.gen(:, GEN_BUS), results.gen(:, GEN_STATUS), string(tech(:)), ...
        'VariableNames', {'run_id', 'gen_row', 'gen_ext', ...
        'bus_ext', 'status', 'technology'});
end

branch = empty_table();
if isfield(results, 'branch') && ~isempty(results.branch)
    nl = size(results.branch, 1);
    branch = table(repmat(run_id, nl, 1), (1:nl)', ...
        results.branch(:, F_BUS), results.branch(:, T_BUS), ...
        results.branch(:, BR_STATUS), ...
        'VariableNames', {'run_id', 'branch_row', 'from_bus_ext', ...
        'to_bus_ext', 'status'});
end

vsc = empty_table();
busdc = empty_table();
branchdc = empty_table();
if isfield(results, 'vsc') && ~isempty(results.vsc) && exist('idx_vsc', 'file') == 2
    c = idx_vsc;
    nv = size(results.vsc, 1);
    vsc = table(repmat(run_id, nv, 1), (1:nv)', ...
        safe_col(results.vsc, c.VSC_BUS), safe_col(results.vsc, c.BUSDC), ...
        safe_col(results.vsc, c.VSC_STATUS), ...
        'VariableNames', {'run_id', 'vsc_row', 'bus_ext', ...
        'dc_bus_ext', 'status'});
end
if isfield(results, 'busdc') && ~isempty(results.busdc)
    n = size(results.busdc, 1);
    busdc = table(repmat(run_id, n, 1), (1:n)', results.busdc(:, 1), ...
        'VariableNames', {'run_id', 'busdc_row', 'dc_bus_ext'});
end
if isfield(results, 'branchdc') && ~isempty(results.branchdc)
    n = size(results.branchdc, 1);
    branchdc = table(repmat(run_id, n, 1), (1:n)', ...
        results.branchdc(:, 1), results.branchdc(:, 2), ...
        'VariableNames', {'run_id', 'branchdc_row', ...
        'from_dc_bus_ext', 'to_dc_bus_ext'});
end

index_map = struct('bus', bus, 'gen', gen, 'branch', branch, ...
    'vsc', vsc, 'busdc', busdc, 'branchdc', branchdc);
end

function idx = generator_external_indices(results, ng)
idx = (1:ng)';
if ~isfield(results, 'order') || ~isfield(results.order, 'gen')
    return;
end
og = results.order.gen;
if isfield(og, 'status') && isfield(og.status, 'on')
    on = og.status.on(:);
    if isfield(og, 'i2e') && ~isempty(og.i2e)
        i2e = og.i2e(:);
        if length(i2e) == ng && length(on) >= max(i2e)
            idx = on(i2e);
            return;
        end
    end
    if length(on) == ng
        idx = on;
    end
elseif isfield(og, 'i2e') && length(og.i2e) == ng
    idx = og.i2e(:);
end
end

function tech = generator_technology(run, results, ng)
tech = repmat("unknown", ng, 1);
raw = [];
if isfield(results, 'psse') && isfield(results.psse, 'gen_redispatch') && ...
        isfield(results.psse.gen_redispatch, 'technology')
    raw = results.psse.gen_redispatch.technology;
elseif isfield(run.raw, 'mpc_base') && isfield(run.raw.mpc_base, 'cpf_policies') && ...
        isfield(run.raw.mpc_base.cpf_policies, 'gen') && ...
        isfield(run.raw.mpc_base.cpf_policies.gen, 'technology')
    raw = run.raw.mpc_base.cpf_policies.gen.technology;
end
if isempty(raw)
    return;
end
raw = string(raw(:));
raw = internal_generator_values(raw, results, ng);
if length(raw) == ng
    tech = raw(:);
end
end

function values = internal_generator_values(values, mpc, ng)
if length(values) == ng || ~isfield(mpc, 'order') || ...
        ~isfield(mpc.order, 'gen') || ...
        ~isfield(mpc.order.gen, 'status') || ...
        ~isfield(mpc.order.gen.status, 'on')
    return;
end
on = mpc.order.gen.status.on(:);
if isfield(mpc.order.gen, 'i2e') && ~isempty(mpc.order.gen.i2e)
    i2e = mpc.order.gen.i2e(:);
    if length(i2e) == ng && length(on) >= max(i2e)
        on = on(i2e);
    end
end
if length(on) == ng && length(values) >= max(on)
    values = values(on);
end
end

function cpf_points = build_cpf_points(run, cpf, lam)
run_id = run.run_id;
n = numel(lam);
source_index = (1:n)';
is_compact = true(n, 1);
repeat_group = zeros(n, 1);
if isfield(run.results, 'cpf_psse_compact') && ...
        isfield(run.results.cpf_psse_compact, 'source_index')
    src = run.results.cpf_psse_compact.source_index(:);
    is_compact = false(n, 1);
    src = src(src >= 1 & src <= n);
    is_compact(src) = true;
    if isfield(run.results.cpf_psse_compact, 'repeat_groups')
        groups = run.results.cpf_psse_compact.repeat_groups;
        for g = 1:numel(groups)
            repeat_group(groups(g).i1:groups(g).iN) = g;
        end
    end
end
if isfield(cpf, 'steps') && numel(cpf.steps) == n
    steps = cpf.steps(:);
else
    steps = [0; diff(lam(:))];
end
warmstart = false(n, 1);
if ~isempty(run.gen_pq_trace)
    warmstart = map_trace_warmstart(run.gen_pq_trace, lam, warmstart);
end
cpf_points = table(repmat(run_id, n, 1), (1:n)', source_index, lam(:), ...
    steps(:), repeat_group, warmstart, true(n, 1), is_compact, ...
    'VariableNames', {'run_id', 'point_index', 'source_index', ...
    'lambda', 'step', 'repeat_group', 'warmstart', ...
    'accepted', 'compact_member'});
end

function warmstart = map_trace_warmstart(trace, lam, warmstart)
if numel(trace) == numel(lam) - 1
    for k = 1:numel(trace)
        if isfield(trace(k), 'warmstart')
            warmstart(k + 1) = logical(trace(k).warmstart);
        end
    end
else
    for k = 1:numel(trace)
        if ~isfield(trace(k), 'lambda') || ~isfield(trace(k), 'warmstart')
            continue;
        end
        [d, idx] = min(abs(lam(:) - trace(k).lambda));
        if d <= 1e-10
            warmstart(idx) = logical(trace(k).warmstart);
        end
    end
end
end

function T = build_bus_trace(run, cpf, lam)
define_constants;
T = empty_table();
run_id = run.run_id;
if isfield(cpf, 'bus') && ndims(cpf.bus) == 3
    nb = size(cpf.bus, 1);
    np = min(size(cpf.bus, 3), numel(lam));
    rows = cell(np, 1);
    for p = 1:np
        bus = cpf.bus(:, :, p);
        physical = bus_physical_flags(run, bus(:, BUS_I), ...
            bus(:, BUS_TYPE));
        rows{p} = table(repmat(run_id, nb, 1), repmat(p, nb, 1), ...
            repmat(lam(p), nb, 1), (1:nb)', bus(:, BUS_I), ...
            bus(:, VM), bus(:, VA), bus(:, BASE_KV), bus(:, BUS_TYPE), ...
            physical(:), ...
            'VariableNames', {'run_id', 'point_index', 'lambda', ...
            'bus_row', 'bus_ext', 'VM', 'VA', 'base_kv', ...
            'bus_type', 'physical'});
    end
    T = vertcat(rows{:});
elseif isfield(cpf, 'V') && ~isempty(cpf.V) && ...
        isfield(run.results, 'bus') && ~isempty(run.results.bus)
    nb = min(size(cpf.V, 1), size(run.results.bus, 1));
    np = min(size(cpf.V, 2), numel(lam));
    if nb == 0 || np == 0
        return;
    end
    bus = run.results.bus(1:nb, :);
    physical = bus_physical_flags(run, bus(:, BUS_I), bus(:, BUS_TYPE));
    rows = cell(np, 1);
    for p = 1:np
        V = cpf.V(1:nb, p);
        rows{p} = table(repmat(run_id, nb, 1), repmat(p, nb, 1), ...
            repmat(lam(p), nb, 1), (1:nb)', bus(:, BUS_I), ...
            abs(V), angle(V) * 180 / pi, bus(:, BASE_KV), ...
            bus(:, BUS_TYPE), physical(:), ...
            'VariableNames', {'run_id', 'point_index', 'lambda', ...
            'bus_row', 'bus_ext', 'VM', 'VA', 'base_kv', ...
            'bus_type', 'physical'});
    end
    T = vertcat(rows{:});
end
end

function T = build_branch_trace(run, cpf, lam)
define_constants;
T = empty_table();
if ~isfield(cpf, 'branch') || ndims(cpf.branch) ~= 3
    return;
end
run_id = run.run_id;
nl = size(cpf.branch, 1);
np = size(cpf.branch, 3);
rows = cell(np, 1);
for p = 1:np
    br = cpf.branch(:, :, p);
    PFv = safe_col(br, PF);
    QFv = safe_col(br, QF);
    PTv = safe_col(br, PT);
    QTv = safe_col(br, QT);
    rate_a = br(:, RATE_A);
    mva_f = hypot(PFv, QFv);
    mva_t = hypot(PTv, QTv);
    loading_pct = NaN(nl, 1);
    ok = isfinite(rate_a) & rate_a > 0;
    loading_pct(ok) = 100 * max(mva_f(ok), mva_t(ok)) ./ rate_a(ok);
    rows{p} = table(repmat(run_id, nl, 1), repmat(p, nl, 1), ...
        repmat(lam(min(p, numel(lam))), nl, 1), (1:nl)', ...
        br(:, F_BUS), br(:, T_BUS), PFv, QFv, PTv, QTv, ...
        rate_a, mva_f, mva_t, loading_pct, br(:, BR_STATUS), ...
        'VariableNames', {'run_id', 'point_index', 'lambda', ...
        'branch_row', 'from_bus_ext', 'to_bus_ext', 'PF', 'QF', ...
        'PT', 'QT', 'RATE_A', 'MVA_F', 'MVA_T', 'loading_pct', ...
        'status'});
end
T = vertcat(rows{:});
end

function T = build_gen_trace(run, results, cpf, lam, warnings) %#ok<INUSD>
define_constants;
run_id = run.run_id;
T = empty_table();
if ~isempty(run.gen_pq_trace)
    trace = run.gen_pq_trace;
    rows = cell(numel(trace), 1);
    for k = 1:numel(trace)
        rec = trace(k);
        ng = numel(rec.PG);
        point_index = k + 1;
        if isfield(rec, 'k') && isfinite(rec.k)
            point_index = rec.k + 1;
        end
        gen_idx = rec.gen_idx(:);
        rows{k} = table(repmat(run_id, ng, 1), repmat(point_index, ng, 1), ...
            repmat(rec.lambda, ng, 1), repmat("gen_pq_trace", ng, 1), ...
            (1:ng)', gen_idx(:), rec.bus(:), rec.PG(:), rec.QG(:), ...
            rec.QMAX(:), rec.QMIN(:), rec.PMAX(:), rec.PMIN(:), ...
            rec.GEN_STATUS(:), repmat(logical(rec.warmstart), ng, 1), ...
            'VariableNames', {'run_id', 'point_index', 'lambda', ...
            'source', 'trace_row', 'gen_idx', 'bus_ext', 'PG', 'QG', ...
            'QMAX', 'QMIN', 'PMAX', 'PMIN', 'status', 'warmstart'});
    end
    T = vertcat(rows{:});
elseif isfield(cpf, 'gen') && ndims(cpf.gen) == 3
    ng = size(cpf.gen, 1);
    np = size(cpf.gen, 3);
    rows = cell(np, 1);
    for p = 1:np
        gen = cpf.gen(:, :, p);
        rows{p} = table(repmat(run_id, ng, 1), repmat(p, ng, 1), ...
            repmat(lam(min(p, numel(lam))), ng, 1), ...
            repmat("cpf.gen", ng, 1), (1:ng)', (1:ng)', ...
            gen(:, GEN_BUS), gen(:, PG), gen(:, QG), gen(:, QMAX), ...
            gen(:, QMIN), gen(:, PMAX), gen(:, PMIN), gen(:, GEN_STATUS), ...
            false(ng, 1), ...
            'VariableNames', {'run_id', 'point_index', 'lambda', ...
            'source', 'trace_row', 'gen_idx', 'bus_ext', 'PG', 'QG', ...
            'QMAX', 'QMIN', 'PMAX', 'PMIN', 'status', 'warmstart'});
    end
    T = vertcat(rows{:});
elseif isfield(results, 'gen') && ~isempty(results.gen)
    ng = size(results.gen, 1);
    T = table(repmat(run_id, ng, 1), repmat(numel(lam), ng, 1), ...
        repmat(max(lam), ng, 1), repmat("final_only", ng, 1), ...
        (1:ng)', (1:ng)', results.gen(:, GEN_BUS), results.gen(:, PG), ...
        results.gen(:, QG), results.gen(:, QMAX), results.gen(:, QMIN), ...
        results.gen(:, PMAX), results.gen(:, PMIN), ...
        results.gen(:, GEN_STATUS), false(ng, 1), ...
        'VariableNames', {'run_id', 'point_index', 'lambda', ...
        'source', 'trace_row', 'gen_idx', 'bus_ext', 'PG', 'QG', ...
        'QMAX', 'QMIN', 'PMAX', 'PMIN', 'status', 'warmstart'});
end
end

function [T, warnings] = build_capability_audit(run, results)
warnings = strings(0, 1);
T = empty_table();
run_id = run.run_id;
try
    audit = check_gen_capability(results);
catch me
    warnings(end+1, 1) = "check_gen_capability failed: " + string(me.message);
    return;
end
elements = audit.elements(:);
rows = cell(numel(elements), 1);
for k = 1:numel(elements)
    e = elements(k);
    rows{k} = table(run_id, "final", NaN, e.idx, e.bus, ...
        e.P, e.Q, e.S, e.P_saturated, e.Q_saturated, ...
        e.S_saturated, logical(e.sat), string(e.active_limit), ...
        e.margin, string(e.mode), ...
        'VariableNames', {'run_id', 'source', 'lambda', 'gen_idx', ...
        'bus_ext', 'P', 'Q', 'S', 'P_saturated', 'Q_saturated', ...
        'S_saturated', 'sat', 'active_limit', 'margin', 'mode'});
end
if ~isempty(rows)
    T = vertcat(rows{:});
end
events = gen_capability_event_table(run, results);
if ~isempty(events)
    T = [T; events];
end
end

function T = gen_capability_event_table(run, results)
T = empty_table();
if ~isfield(results, 'psse') || ~isfield(results.psse, 'gen_capability') || ...
        ~isfield(results.psse.gen_capability, 'event_history')
    return;
end
hist = results.psse.gen_capability.event_history;
cap_lam = event_lambdas(results, 'PSSE_GEN_CAPABILITY');
rows = {};
for h = 1:numel(hist)
    rep = hist{h};
    if isempty(rep) || ~isfield(rep, 'changed_idx')
        continue;
    end
    lam = NaN;
    if h <= numel(cap_lam)
        lam = cap_lam(h);
    elseif ~isempty(cap_lam)
        lam = cap_lam(end);
    end
    for r = 1:numel(rep.changed_idx)
        rows{end+1, 1} = table(run.run_id, "event_history", lam, ...
            rep.changed_idx(r), rep.bus(r), rep.P(r), rep.Q(r), ...
            abs(rep.P(r) + 1j * rep.Q(r)), rep.P_saturated(r), ...
            rep.Q_saturated(r), abs(rep.P_saturated(r) + ...
            1j * rep.Q_saturated(r)), true, string(rep.active_limit{r}), ...
            NaN, "", ...
            'VariableNames', {'run_id', 'source', 'lambda', 'gen_idx', ...
            'bus_ext', 'P', 'Q', 'S', 'P_saturated', 'Q_saturated', ...
            'S_saturated', 'sat', 'active_limit', 'margin', 'mode'}); %#ok<AGROW>
    end
end
if ~isempty(rows)
    T = vertcat(rows{:});
end
end

function [genT, techT] = build_redispatch_trace(run, results)
genT = empty_table();
techT = empty_table();
if ~isfield(results, 'psse') || ~isfield(results.psse, 'gen_redispatch') || ...
        ~isfield(results.psse.gen_redispatch, 'history') || ...
        isempty(results.psse.gen_redispatch.history)
    return;
end
hist = results.psse.gen_redispatch.history;
grow = {};
trow = {};
cum = containers.Map('KeyType', 'char', 'ValueType', 'double');
for h = 1:numel(hist)
    rep = hist(h);
    for r = 1:numel(rep.gen_idx)
        grow{end+1, 1} = table(run.run_id, h, rep.lambda, ...
            rep.dP_load, rep.scheduled_mw, rep.applied_mw, ...
            rep.unallocated_mw, rep.gen_idx(r), rep.delta_pg(r), ...
            string(rep.technology{r}), rep.reserve(r), ...
            rep.pg_before(rep.gen_idx(r)), rep.pg_after(rep.gen_idx(r)), ...
            'VariableNames', {'run_id', 'redispatch_index', 'lambda', ...
            'dP_load', 'scheduled_mw', 'applied_mw', 'unallocated_mw', ...
            'gen_idx', 'delta_pg', 'technology', 'reserve', ...
            'pg_before', 'pg_after'}); %#ok<AGROW>
    end
    for r = 1:numel(rep.technology_names)
        name = char(rep.technology_names{r});
        if ~isKey(cum, name)
            cum(name) = 0;
        end
        cum(name) = cum(name) + rep.technology_applied_mw(r);
        trow{end+1, 1} = table(run.run_id, h, rep.lambda, string(name), ...
            rep.technology_applied_mw(r), cum(name), ...
            rep.technology_available_mw(r), rep.technology_preference(r), ...
            'VariableNames', {'run_id', 'redispatch_index', 'lambda', ...
            'technology', 'applied_mw', 'cumulative_mw', ...
            'available_mw', 'preference'}); %#ok<AGROW>
    end
end
if ~isempty(grow)
    genT = vertcat(grow{:});
end
if ~isempty(trow)
    techT = vertcat(trow{:});
end
end

function T = build_event_timeline(run, cpf, lam)
T = empty_table();
if ~isfield(cpf, 'events') || isempty(cpf.events)
    return;
end
events = cpf.events(:);
rows = cell(numel(events), 1);
for k = 1:numel(events)
    ev = events(k);
    name = string(field_or(ev, 'name', ''));
    kk = scalar_field(ev, 'k', NaN);
    idx = scalar_field(ev, 'idx', NaN);
    ev_lam = event_lambda_from_event(ev, lam);
    rows{k} = table(run.run_id, k, name, event_family(name), kk, idx, ...
        ev_lam, string(field_or(ev, 'msg', '')), payload_summary(ev), ...
        'VariableNames', {'run_id', 'event_index', 'event_name', ...
        'family', 'k', 'idx', 'lambda', 'message', 'payload'});
end
T = vertcat(rows{:});
end

function [vscT, busdcT, branchdcT] = build_vsc_dc_traces(run, cpf, lam)
vscT = empty_table();
busdcT = empty_table();
branchdcT = empty_table();
if isfield(cpf, 'vsc') && ndims(cpf.vsc) == 3 && exist('idx_vsc', 'file') == 2
    c = idx_vsc;
    nv = size(cpf.vsc, 1);
    np = size(cpf.vsc, 3);
    rows = cell(np, 1);
    for p = 1:np
        v = cpf.vsc(:, :, p);
        rows{p} = table(repmat(run.run_id, nv, 1), repmat(p, nv, 1), ...
            repmat(lam(min(p, numel(lam))), nv, 1), (1:nv)', ...
            safe_col(v, c.VSC_BUS), safe_col(v, c.BUSDC), ...
            safe_col(v, c.PAC), safe_col(v, c.QAC), safe_col(v, c.PDC), ...
            safe_col(v, c.VDC), safe_col(v, c.VAC_PCC), ...
            safe_col(v, c.VAC_INTERNAL), safe_col(v, c.PLOSS), ...
            'VariableNames', {'run_id', 'point_index', 'lambda', ...
            'vsc_row', 'bus_ext', 'dc_bus_ext', 'PAC', 'QAC', ...
            'PDC', 'VDC', 'VAC_PCC', 'VAC_INTERNAL', 'PLOSS'});
    end
    vscT = vertcat(rows{:});
end
if isfield(cpf, 'busdc') && ndims(cpf.busdc) == 3
    n = size(cpf.busdc, 1);
    np = size(cpf.busdc, 3);
    rows = cell(np, 1);
    for p = 1:np
        b = cpf.busdc(:, :, p);
        rows{p} = table(repmat(run.run_id, n, 1), repmat(p, n, 1), ...
            repmat(lam(min(p, numel(lam))), n, 1), (1:n)', b(:, 1), ...
            safe_col(b, 2), safe_col(b, 3), ...
            'VariableNames', {'run_id', 'point_index', 'lambda', ...
            'busdc_row', 'dc_bus_ext', 'VDC', 'PDC'});
    end
    busdcT = vertcat(rows{:});
end
if isfield(cpf, 'branchdc') && ndims(cpf.branchdc) == 3
    n = size(cpf.branchdc, 1);
    np = size(cpf.branchdc, 3);
    rows = cell(np, 1);
    for p = 1:np
        br = cpf.branchdc(:, :, p);
        rows{p} = table(repmat(run.run_id, n, 1), repmat(p, n, 1), ...
            repmat(lam(min(p, numel(lam))), n, 1), (1:n)', ...
            safe_col(br, 1), safe_col(br, 2), safe_col(br, 7), ...
            safe_col(br, 8), ...
            'VariableNames', {'run_id', 'point_index', 'lambda', ...
            'branchdc_row', 'from_dc_bus_ext', 'to_dc_bus_ext', ...
            'PFDC', 'PTDC'});
    end
    branchdcT = vertcat(rows{:});
end
end

function manifest = build_run_manifest(run, results, cpf, lam, events, warnings)
manifest = struct();
manifest.run_id = run.run_id;
manifest.label = run.label;
manifest.source_dir = run.source_dir;
manifest.primary_file = run.primary_file;
manifest.gen_pq_trace_file = run.gen_pq_trace_file;
manifest.result_variable = run.result_variable;
manifest.success = success_flag(run, results);
manifest.solver_type = solver_type(results, cpf);
manifest.point_count = numel(lam);
manifest.max_lambda = max(lam);
manifest.event_count = height(events);
manifest.warning_count = height(warnings);
manifest.has_gen_pq_trace = ~isempty(run.gen_pq_trace);
manifest.has_compact_trace = isfield(results, 'cpf_psse_compact');
manifest.has_bus_trace = (isfield(cpf, 'bus') && ndims(cpf.bus) == 3) || ...
    (isfield(cpf, 'V') && ~isempty(cpf.V));
manifest.has_branch_trace = isfield(cpf, 'branch') && ndims(cpf.branch) == 3;
manifest.has_vsc_trace = isfield(cpf, 'vsc') && ndims(cpf.vsc) == 3;
if isfield(cpf, 'done_msg')
    manifest.done_msg = string(cpf.done_msg);
else
    manifest.done_msg = "";
end
end

function flag = success_flag(run, results)
flag = NaN;
if isfield(run.raw, 'cpf_success')
    flag = double(run.raw.cpf_success);
elseif isfield(run.raw, 'success')
    flag = double(run.raw.success);
elseif isfield(results, 'success')
    flag = double(results.success);
end
end

function typ = solver_type(results, cpf)
typ = "unknown";
if isfield(cpf, 'method')
    typ = string(cpf.method);
elseif isfield(results, 'psse') && isfield(results.psse, 'cpf') && ...
        isfield(results.psse.cpf, 'task_class')
    typ = string(results.psse.cpf.task_class);
elseif isfield(results, 'cpf')
    typ = "cpf";
elseif isfield(results, 'success')
    typ = "pf";
end
end

function lams = event_lambdas(results, name)
lams = [];
if ~isfield(results, 'cpf') || ~isfield(results.cpf, 'events')
    return;
end
events = results.cpf.events;
for k = 1:numel(events)
    if strcmp(string(events(k).name), name)
        lams(end+1, 1) = event_lambda_from_event(events(k), []); %#ok<AGROW>
    end
end
end

function lam = event_lambda_from_event(ev, trace_lam)
lam = scalar_field(ev, 'lambda_event', NaN);
if ~isfinite(lam)
    msg = string(field_or(ev, 'msg', ''));
    tok = regexp(char(msg), 'lambda\s*=\s*([0-9eE+\-.]+)', ...
        'tokens', 'once');
    if ~isempty(tok)
        lam = str2double(tok{1});
    end
end
if ~isfinite(lam) && ~isempty(trace_lam)
    k = scalar_field(ev, 'k', NaN);
    if isfinite(k)
        idx = min(max(round(k) + 1, 1), numel(trace_lam));
        lam = trace_lam(idx);
    end
end
end

function fam = event_family(name)
name = string(name);
if startsWith(name, "PSSE_GEN_REDISPATCH")
    fam = "redispatch";
elseif contains(name, "GEN_CAPABILITY")
    fam = "gen_capability";
elseif contains(name, "VSC_CAPABILITY")
    fam = "vsc_capability";
elseif contains(name, "HVDC_DERATING")
    fam = "hvdc_derating";
elseif startsWith(name, "PSSE_")
    fam = "psse_control";
elseif name == "NOSE" || name == "TARGET_LAM"
    fam = "cpf";
else
    fam = "other";
end
end

function txt = payload_summary(ev)
names = fieldnames(ev);
skip = {'k', 'name', 'idx', 'msg'};
parts = strings(0, 1);
for k = 1:numel(names)
    if any(strcmp(names{k}, skip))
        continue;
    end
    val = ev.(names{k});
    if isnumeric(val) || islogical(val)
        sz = size(val);
        if isscalar(val)
            parts(end+1, 1) = sprintf('%s=%g', names{k}, val); %#ok<AGROW>
        else
            parts(end+1, 1) = sprintf('%s=[%dx%d]', names{k}, ...
                sz(1), sz(2)); %#ok<AGROW>
        end
    elseif ischar(val) || isstring(val)
        parts(end+1, 1) = names{k} + "=" + string(val); %#ok<AGROW>
    elseif iscell(val)
        parts(end+1, 1) = sprintf('%s={%d}', names{k}, numel(val)); %#ok<AGROW>
    end
end
txt = strjoin(parts, '; ');
end

function warnings = append_warnings(warnings, new_warnings)
if isempty(new_warnings)
    return;
end
T = table(string(new_warnings(:)), 'VariableNames', {'warning'});
warnings = [warnings; T];
end

function val = field_or(s, name, default)
if isfield(s, name)
    val = s.(name);
else
    val = default;
end
end

function val = scalar_field(s, name, default)
val = default;
if isfield(s, name) && isnumeric(s.(name)) && ~isempty(s.(name))
    raw = s.(name);
    val = raw(1);
end
end

function x = safe_col(A, col)
if col <= size(A, 2)
    x = A(:, col);
else
    x = NaN(size(A, 1), 1);
end
end

function physical = bus_physical_flags(run, bus_ext, bus_type)
define_constants;
physical = bus_ext(:) < 900000 & bus_type(:) ~= NONE;
meta_file = fullfile(char(run.source_dir), 'cpf_bus_meta.csv');
if exist(meta_file, 'file') ~= 2
    return;
end
try
    meta = readtable(meta_file);
catch
    return;
end
names = string(meta.Properties.VariableNames);
if ~any(names == "bus_i") || ~any(names == "physical")
    return;
end
meta_bus = meta.bus_i(:);
meta_physical = logical(meta.physical(:));
[tf, loc] = ismember(bus_ext(:), meta_bus);
if any(tf)
    physical(tf) = meta_physical(loc(tf));
end
end

function T = empty_table()
T = table();
end
