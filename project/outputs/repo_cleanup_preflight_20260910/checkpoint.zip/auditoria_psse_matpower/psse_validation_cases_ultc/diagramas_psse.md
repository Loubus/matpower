# Diagramas minimos para validar ULTC/TAB en PSS/E

Estos RAW son chicos para abrirlos manualmente en PSS/E, dibujar el one-line
sin el caso grande y correr Newton con ajuste automatico de taps.

## Caso 1 - `psse_ultc_2bus_local.raw`

Objetivo: validar `ACTAPS=1`, `COD=1`, regulacion local y tap discreto.

Diagrama:

```text
[BUS1 230 kV SLACK + GEN] -- [T1 230/115 kV ULTC] -- [BUS2 115 kV LOAD]
```

Elementos a incluir:

- Barra 1 `BUS1`, 230 kV, tipo swing/slack.
- Generador en barra 1.
- Transformador 2 devanados `1-2`, circuito `1`, con tap regulante en W1.
- Barra 2 `BUS2`, 115 kV, tipo load/PQ.
- Carga en barra 2.

Datos clave a revisar:

- `SOLVER ACTAPS=1`.
- `COD1=1`, `CONT1=-2`.
- `RMA1=1.10`, `RMI1=0.90`, `NTP1=5`.
- `VMA1=1.03`, `VMI1=0.97`.
- Esperado local MATPOWER: tap final `0.95`, dentro de banda.

## Caso 2 - `psse_ultc_2bus_actaps_off.raw`

Objetivo: validar gate global `ACTAPS=0`.

Diagrama: igual al caso 1.

Elementos a incluir:

- Barra 1 slack con generador.
- Transformador 2 devanados con `COD1=1`.
- Barra 2 con carga.

Datos clave a revisar:

- `SOLVER ACTAPS=0`.
- Esperado local MATPOWER: tap final `1.00`, sin ajustes.

## Caso 3 - `psse_ultc_3bus_remote.raw`

Objetivo: validar regulacion remota con `CONT=-3`.

Diagrama:

```text
[BUS1 230 kV SLACK + GEN] -- [T1 ULTC] -- [BUS2 115 kV] -- [LINE] -- [BUS3 115 kV LOAD]
                              tap en BUS2       ^
                                                regula BUS3
```

Elementos a incluir:

- Barra 1 slack con generador.
- Transformador 2 devanados `2-1`, circuito `1`, con tap regulante en BUS2.
- Barra 2 intermedia.
- Linea AC `2-3`.
- Barra 3 con carga.

Datos clave a revisar:

- `COD1=1`, `CONT1=-3`.
- `VMA1=0.98`, `VMI1=0.95`.
- Esperado local MATPOWER: tap final `1.05`, bus remoto dentro de banda
  (`VM3 ~= 0.9512`).

## Caso 3b - `psse_ultc_3bus_remote_limit.raw`

Objetivo: conservar la validacion externa PSS/E de regulacion remota que
alcanza limite alto.

Diagrama:

```text
[BUS1 230 kV SLACK + GEN] -- [T1 ULTC] -- [BUS2 115 kV] -- [LINE] -- [BUS3 115 kV LOAD]
                              tap en BUS1       ^
                                                regula BUS3
```

Datos clave a revisar:

- Transformador 2 devanados `1-2`, circuito `1`, con tap regulante en BUS1.
- `COD1=1`, `CONT1=-3`.
- Esperado local MATPOWER y PSS/E externo: tap final `1.10HI`, bus remoto
  fuera de banda.

## Caso 4 - `psse_ultc_2bus_tab.raw`

Objetivo: validar `TAB` en un transformador 2W con tabla no unitaria.

Diagrama: igual al caso 1.

Elementos a incluir:

- Barra 1 slack con generador.
- Transformador 2 devanados `1-2`, circuito `1`, con `TAB1=1`.
- Barra 2 con carga.
- Tabla de impedance correction `1`.

Datos clave a revisar:

- `TAB1=1`.
- Tabla 1:
  - `T=0.90`, `Re(F)=0.90`, `Im(F)=0`.
  - `T=1.10`, `Re(F)=1.10`, `Im(F)=0`.
- Esperado local MATPOWER: tap final `0.95`, `R=0.0095`, `X=0.0950`.

## Caso 5 - `psse_ultc_3w_tab.raw`

Objetivo: validar el modo del RAW grande en pequeno: transformador 3W,
`ZCOD=0`, `TAB` en los tres devanados y control automatico solo en W1.

Diagrama:

```text
                         [BUS2 115 kV LOAD]
                              |
[BUS1 230 kV SLACK + GEN] -- [T1 3W ULTC/TAB] -- [BUS3 13.8 kV LOAD]
```

Elementos a incluir:

- Barra 1 `SOURCE`, 230 kV, tipo swing/slack.
- Generador en barra 1.
- Barra 2 `LOAD`, 115 kV, tipo load/PQ.
- Carga en barra 2.
- Barra 3 `TERTIARY`, 13.8 kV, tipo load/PQ.
- Carga pequena en barra 3.
- Transformador de tres devanados `1-2-3`, circuito `1`.
- Tap regulante en W1.
- Tabla de impedance correction `1`.

Datos clave a revisar:

- En registro 1 del transformador: `ZCOD=0`.
- En W1: `COD1=1`, `CONT1=-2`, `TAB1=1`.
- En W2/W3: `COD=0`, `TAB=1`.
- Tabla 1 igual al caso 4.
- Esperado local MATPOWER: tap W1 final `0.90`, `tab_corrected=3`,
  rama W1 equivalente con `R=0.0090`, `X=0.0900`.

## Caso 6 - `psse_ultc_3w_w2.raw`

Objetivo: validar control 3W en W2 sin mezclar `TAB`.

Diagrama: igual al caso 5.

Elementos a incluir:

- Barra 1 `SOURCE`, 230 kV, tipo swing/slack.
- Generador en barra 1.
- Barra 2 `LOAD`, 115 kV, tipo load/PQ.
- Carga en barra 2.
- Barra 3 `TERTIARY`, 13.8 kV, tipo load/PQ.
- Carga pequena en barra 3.
- Transformador de tres devanados `1-2-3`, circuito `1`.
- Tap regulante en W2.

Datos clave a revisar:

- En W1/W3: `COD=0`, `TAB=0`.
- En W2: `COD2=1`, `CONT2=2`, `VMA2=0.84`, `VMI2=0.82`,
  `RMA2=1.10`, `RMI2=0.90`, `NTP2=5`, `TAB2=0`.
- Esperado local MATPOWER: tap W2 final `1.05`, bus 2 dentro de banda
  (`VM2 ~= 0.8263`), sin cambio de `R/X`.

## Caso 7 - `psse_ultc_3w_w3.raw`

Objetivo: validar control 3W en W3 sin mezclar `TAB`.

Diagrama: igual al caso 5.

Elementos a incluir:

- Barra 1 `SOURCE`, 230 kV, tipo swing/slack.
- Generador en barra 1.
- Barra 2 `LOAD`, 115 kV, tipo load/PQ.
- Carga en barra 2.
- Barra 3 `TERTIARY`, 13.8 kV, tipo load/PQ.
- Carga pequena en barra 3.
- Transformador de tres devanados `1-2-3`, circuito `1`.
- Tap regulante en W3.

Datos clave a revisar:

- En W1/W2: `COD=0`, `TAB=0`.
- En W3: `COD3=1`, `CONT3=3`, `VMA3=0.94`, `VMI3=0.92`,
  `RMA3=1.10`, `RMI3=0.90`, `NTP3=5`, `TAB3=0`.
- Esperado local MATPOWER: tap W3 final `1.05`, bus 3 dentro de banda
  (`VM3 ~= 0.9310`), sin cambio de `R/X`.

## Caso 8 - `psse_ultc_3w_tab_cw2.raw`

Objetivo: validar el modo 3W `TAB` con `CW=2`, que aparece en el RAW grande.

Diagrama: igual al caso 5.

Datos clave a revisar:

- En registro 1 del transformador: `CW=2`, `ZCOD=0`.
- En W1: `WINDV1=230`, `COD1=1`, `CONT1=-2`,
  `RMA1=253`, `RMI1=207`, `TAB1=1`.
- En W2: `WINDV2=115`, `TAB2=1`.
- En W3: `WINDV3=13.8`, `TAB3=1`.
- Tabla 1 igual al caso 4.
- Esperado local MATPOWER: tap W1 final `0.90`, `tab_corrected=3`,
  rama W1 equivalente con `R=0.0090`, `X=0.0900`.

## Caso 9 - `psse_ultc_2bus_cont_pos.raw`

Objetivo: validar el signo positivo de `CONT` en un bus terminal de
transformador 2W.

Diagrama: igual al caso 1.

Datos clave a revisar:

- Transformador 2 devanados `1-2`, circuito `1`, con tap regulante en W1.
- `COD1=1`, `CONT1=+2`.
- `RMA1=1.10`, `RMI1=0.90`, `NTP1=5`.
- `VMA1=1.03`, `VMI1=0.97`.
- Esperado PSS/E y MATPOWER: tap final `0.95`, bus 2 dentro de banda
  (`VM2 ~= 0.9875`). Este caso valida que `CONT=+2` terminal baja el tap
  igual que `CONT=-2`.

## Caso 10 - `psse_ultc_3bus_remote_cont_pos.raw`

Objetivo: validar el signo positivo de `CONT` en un bus remoto de transformador
2W.

Diagrama: igual al caso 3b.

Datos clave a revisar:

- Transformador 2 devanados `1-2`, circuito `1`, con tap regulante en W1.
- Linea AC `2-3`.
- Carga en barra 3.
- `COD1=1`, `CONT1=+3`.
- `RMA1=1.10`, `RMI1=0.90`, `NTP1=5`.
- `VMA1=0.98`, `VMI1=0.95`.
- Esperado PSS/E y MATPOWER: tap final `0.95`, bus 3 dentro de banda
  (`VM3 ~= 0.9607`). Este caso valida que `CONT=+3` remoto invierte la
  direccion respecto del caso `CONT=-3` remoto.

## Caso 11 - `psse_ultc_2bus_cod0.raw`

Objetivo: validar que `COD1=0` deja el tap fijo aunque `ACTAPS=1`.

Diagrama: igual al caso 1.

Datos clave a revisar:

- `SOLVER ACTAPS=1`.
- `COD1=0`, `CONT1=-2`.
- `RMA1=1.10`, `RMI1=0.90`, `NTP1=5`.
- `VMA1=1.03`, `VMI1=0.97`.
- Esperado MATPOWER: tap final `1.00`, sin bloque `TAP RATIOS ADJUSTED`,
  bus 2 fuera de banda (`VM2 ~= 0.9303`).

## Caso 12 - `psse_ultc_2bus_cod_m1.raw`

Objetivo: validar que `COD1=-1` suprime el ajuste automatico aunque
`ACTAPS=1`.

Diagrama: igual al caso 1.

Datos clave a revisar:

- `SOLVER ACTAPS=1`.
- `COD1=-1`, `CONT1=-2`.
- `RMA1=1.10`, `RMI1=0.90`, `NTP1=5`.
- `VMA1=1.03`, `VMI1=0.97`.
- Esperado MATPOWER: tap final `1.00`, sin bloque `TAP RATIOS ADJUSTED`,
  bus 2 fuera de banda (`VM2 ~= 0.9303`).

## Caso 13 - `psse_ultc_2bus_cont0.raw`

Objetivo: validar que `COD1=1` con `CONT1=0` no produce control automatico
por falta de bus regulado.

Diagrama: igual al caso 1.

Datos clave a revisar:

- `SOLVER ACTAPS=1`.
- `COD1=1`, `CONT1=0`.
- `RMA1=1.10`, `RMI1=0.90`, `NTP1=5`.
- `VMA1=1.03`, `VMI1=0.97`.
- Esperado MATPOWER: tap final `1.00`, sin bloque `TAP RATIOS ADJUSTED`,
  bus 2 fuera de banda (`VM2 ~= 0.9303`).

## Caso 14 - `psse_ultc_2bus_cw2.raw`

Objetivo: validar control 2W con `CW=2`, donde `WINDV1`, `WINDV2` y
`RMA/RMI` se ingresan en kV.

Diagrama: igual al caso 1.

Datos clave a revisar:

- `CW=2`.
- `WINDV1=230 kV`, `WINDV2=115 kV`.
- `COD1=1`, `CONT1=-2`.
- `RMA1=253 kV`, `RMI1=207 kV`, `NTP1=5`.
- `VMA1=1.03`, `VMI1=0.97`.
- Esperado MATPOWER: `WINDV1=218.5 kV`, tap final equivalente `0.95`,
  bus 2 dentro de banda (`VM2 ~= 0.9875`).

## Caso 15 - `psse_ultc_3w_w2_cw2.raw`

Objetivo: validar control 3W en W2 con `CW=2`, caso presente en el RAW grande.

Diagrama: igual al caso 6.

Datos clave a revisar:

- En registro 1 del transformador: `CW=2`, `ZCOD=0`.
- En W2: `WINDV2=115 kV`, `COD2=1`, `CONT2=2`.
- `RMA2=126.5 kV`, `RMI2=103.5 kV`, `NTP2=5`.
- `VMA2=0.84`, `VMI2=0.82`.
- `TAB=0` en todos los devanados.
- Esperado MATPOWER: `WINDV2=120.75 kV`, tap W2 equivalente `1.05`,
  bus 2 dentro de banda (`VM2 ~= 0.8263`).

## Salida minima a anotar desde PSS/E

Para cada caso:

- Si Newton converge.
- Numero de iteraciones.
- Tap final `WINDV1`.
- Tension final de las barras reguladas.
- Si aplica `TAB`, tabla usada y valores finales de flujo o impedancia
  equivalente que PSS/E permita reportar.
