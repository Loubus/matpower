# PSS/E transformer tap / ULTC validation results

Estos resultados registran la validacion local con `runpf_psse` y las corridas
manuales PSS/E disponibles.

## runpf_psse local

Comando MATLAB usado desde el workspace:

```matlab
addpath(fullfile(pwd, 'matpower', 'lib'));
mpopt = mpoption('verbose', 0, 'out.all', 0);
files = {'psse_ultc_2bus_local.raw', ...
         'psse_ultc_2bus_actaps_off.raw', ...
         'psse_ultc_3bus_remote.raw', ...
         'psse_ultc_3bus_remote_limit.raw', ...
         'psse_ultc_2bus_tab.raw', ...
         'psse_ultc_3w_tab.raw', ...
         'psse_ultc_3w_w2.raw', ...
         'psse_ultc_3w_w3.raw', ...
         'psse_ultc_3w_tab_cw2.raw', ...
         'psse_ultc_2bus_cont_pos.raw', ...
         'psse_ultc_3bus_remote_cont_pos.raw', ...
         'psse_ultc_2bus_cod0.raw', ...
         'psse_ultc_2bus_cod_m1.raw', ...
         'psse_ultc_2bus_cont0.raw', ...
         'psse_ultc_2bus_cw2.raw', ...
         'psse_ultc_3w_w2_cw2.raw'};
for k = 1:length(files)
    raw = fullfile(pwd, 'auditoria_psse_matpower', ...
        'psse_validation_cases_ultc', files{k});
    mpc = psse2mpc(raw, 0, 34);
    r = runpf_psse(mpc, mpopt);
end
```

Resultados:

Los valores `tap final`, `R final` y `X final` corresponden a la rama
MATPOWER asociada al transformador regulante mediante `mpc.psse.xfmr.*.branch_idx`.

| Caso | success | rama trafo | tap final | R final | X final | enabled | ajustes | dentro de banda | tab_corrected |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| `psse_ultc_2bus_local.raw` | 1 | 1 | 0.950000 | 0.010000 | 0.100000 | 1 | 1 | 1 | 0 |
| `psse_ultc_2bus_actaps_off.raw` | 1 | 1 | 1.000000 | 0.010000 | 0.100000 | 0 | 0 | 0 | 0 |
| `psse_ultc_3bus_remote.raw` | 1 | 2 | 1.050000 | 0.010000 | 0.100000 | 1 | 1 | 1 | 0 |
| `psse_ultc_3bus_remote_limit.raw` | 1 | 2 | 1.100000 | 0.010000 | 0.100000 | 1 | 2 | 0 | 0 |
| `psse_ultc_2bus_tab.raw` | 1 | 1 | 0.950000 | 0.009500 | 0.095000 | 1 | 1 | 1 | 1 |
| `psse_ultc_3w_tab.raw` | 1 | 1 | 0.900000 | 0.009000 | 0.090000 | 1 | 2 | 1 | 3 |
| `psse_ultc_3w_w2.raw` | 1 | 2 | 1.050000 | 0.015000 | 0.120000 | 1 | 1 | 1 | 0 |
| `psse_ultc_3w_w3.raw` | 1 | 3 | 1.050000 | 0.020000 | 0.140000 | 1 | 1 | 1 | 0 |
| `psse_ultc_3w_tab_cw2.raw` | 1 | 1 | 0.900000 | 0.009000 | 0.090000 | 1 | 2 | 1 | 3 |
| `psse_ultc_2bus_cont_pos.raw` | 1 | 1 | 0.950000 | 0.010000 | 0.100000 | 1 | 1 | 1 | 0 |
| `psse_ultc_3bus_remote_cont_pos.raw` | 1 | 2 | 0.950000 | 0.010000 | 0.100000 | 1 | 1 | 1 | 0 |
| `psse_ultc_2bus_cod0.raw` | 1 | 1 | 1.000000 | 0.010000 | 0.100000 | 1 | 0 | 0 | 0 |
| `psse_ultc_2bus_cod_m1.raw` | 1 | 1 | 1.000000 | 0.010000 | 0.100000 | 1 | 0 | 0 | 0 |
| `psse_ultc_2bus_cont0.raw` | 1 | 1 | 1.000000 | 0.010000 | 0.100000 | 1 | 0 | 0 | 0 |
| `psse_ultc_2bus_cw2.raw` | 1 | 1 | 0.950000 | 0.010000 | 0.100000 | 1 | 1 | 1 | 0 |
| `psse_ultc_3w_w2_cw2.raw` | 1 | 2 | 1.050000 | 0.015000 | 0.120000 | 1 | 1 | 1 | 0 |

Interpretacion:

- El caso local mueve el tap un escalon discreto y entra en banda.
- El caso `ACTAPS=0` no mueve tap aunque `COD=1`.
- El caso remoto con `CONT=-3` entra en banda cuando el lado regulante queda
  orientado para que el tap aumente la tension remota.
- El caso remoto `_limit` conserva la corrida PSS/E externa donde el tap llega
  al limite alto y el bus regulado queda fuera de banda.
- El caso `TAB=1` mueve el tap y recalcula `R/X` con el factor interpolado
  de la tabla de impedance correction.
- El caso 3W `TAB=1` reproduce el modo del RAW grande (`ZCOD=0`) en pequeno:
  aplica tabla a los tres devanados y mueve W1 hasta `0.90`.
- Los casos 3W W2/W3 sin `TAB` aislan el control de cada devanado y verifican
  que se actualiza la rama correcta del equivalente estrella.
- El caso 3W `TAB` con `CW=2` reproduce la codificacion de taps en kV presente
  en el RAW grande.
- El caso `CONT=+3` remoto quedo validado contra PSS/E: la direccion correcta
  baja el tap a `0.95` y deja el bus remoto dentro de banda.
- El caso `CONT=+2` terminal quedo validado contra PSS/E: igual que
  `CONT=-2`, baja el tap a `0.95` y deja el bus terminal dentro de banda.
- Los casos `COD=0`, `COD=-1` y `COD=1/CONT=0` quedan como casos chicos para
  validar en PSS/E que los modos preservados/no controlables no ajustan tap.
- Los casos `CW=2` pendientes del RAW grande quedan representados por
  `psse_ultc_2bus_cw2.raw` y `psse_ultc_3w_w2_cw2.raw`.

Estos mismos comportamientos quedan cubiertos por `t_mpxt_psse(0)`.

## PSS/E externo - `psse_ultc_2bus_local.raw`

Corrida manual PSS/E reportada el 2026-05-19:

- metodo: full Newton-Raphson desde flat start;
- PSS/E ajusta 1 tap;
- tap ajustado: `1.00000 -> 0.95000`;
- convergencia: tolerancia alcanzada en 5 iteraciones;
- bus 2: `VM = 0.9875`, `VA = -5.24 deg`;
- swing bus 1: `PGEN = 101.3 MW`, `QGEN = 62.8 MVAr`.

Comparacion contra `runpf_psse` local:

| Magnitud | PSS/E | runpf_psse | Diferencia aproximada |
|---|---:|---:|---:|
| Tap final | 0.95000 | 0.95000 | 0 |
| Bus 2 VM | 0.9875 | 0.987464 | -0.000036 pu |
| Bus 2 VA | -5.24 deg | -5.243907 deg | -0.003907 deg |
| Swing PG | 101.3 MW | 101.281938 MW | -0.018062 MW |
| Swing QG | 62.8 MVAr | 62.819386 MVAr | 0.019386 MVAr |

Interpretacion:

- El movimiento discreto de tap coincide exactamente.
- Las diferencias de `VM/VA/PG/QG` quedan dentro del redondeo del reporte
  mostrado por PSS/E.
- La cantidad de iteraciones no se compara uno a uno porque `runpf_psse`
  registra la ultima corrida PF/data-model, mientras PSS/E reporta la secuencia
  completa con ajuste de tap intermedio.

## PSS/E externo - `psse_ultc_2bus_actaps_off.raw`

Corrida manual PSS/E reportada el 2026-05-19:

- metodo: full Newton-Raphson desde flat start;
- `ACTAPS=0`, sin bloque de taps ajustados;
- tap final: `1.00000`;
- convergencia: tolerancia alcanzada en 3 iteraciones;
- bus 2: `VM = 0.9303`, `VA = -5.86 deg`;
- swing bus 1: `PGEN = 101.4 MW`, `QGEN = 64.4 MVAr`.

Comparacion contra `runpf_psse` local:

| Magnitud | PSS/E | runpf_psse | Diferencia aproximada |
|---|---:|---:|---:|
| Tap final | 1.00000 | 1.00000 | 0 |
| Bus 2 VM | 0.9303 | 0.930275 | -0.000025 pu |
| Bus 2 VA | -5.86 deg | -5.861282 deg | -0.001282 deg |
| Swing PG | 101.4 MW | 101.444399 MW | 0.044399 MW |
| Swing QG | 64.4 MVAr | 64.443995 MVAr | 0.043995 MVAr |

Interpretacion:

- PSS/E y `runpf_psse` coinciden en no mover el tap cuando `ACTAPS=0`.
- Las diferencias numericas quedan dentro del redondeo del reporte mostrado por
  PSS/E.

## PSS/E externo - `psse_ultc_2bus_cont_pos.raw`

Corrida manual PSS/E reportada el 2026-05-19:

- metodo: full Newton-Raphson desde flat start;
- PSS/E ajusta 1 tap;
- tap ajustado: `1.00000 -> 0.95000`;
- convergencia: tolerancia alcanzada en 5 iteraciones;
- bus 2: `VM = 0.9875`, `VA = -5.2 deg`;
- swing bus 1: `PGEN = 101.3 MW`, `QGEN = 62.8 MVAr`.

Comparacion contra `runpf_psse` local:

| Magnitud | PSS/E | runpf_psse | Diferencia aproximada |
|---|---:|---:|---:|
| Tap final | 0.95000 | 0.95000 | 0 |
| Bus 2 VM | 0.9875 | 0.987464 | -0.000036 pu |
| Bus 2 VA | -5.2 deg | -5.243907 deg | -0.043907 deg |
| Swing PG | 101.3 MW | 101.281938 MW | -0.018062 MW |
| Swing QG | 62.8 MVAr | 62.819386 MVAr | 0.019386 MVAr |

Interpretacion:

- PSS/E confirma que `CONT=+2` en el terminal opuesto usa la misma direccion
  efectiva que `CONT=-2` para este caso: el tap baja a `0.95`.
- `runpf_psse` reproduce el tap y la tension regulada dentro del redondeo del
  reporte PSS/E.

## PSS/E externo - `psse_ultc_2bus_cw2.raw`

Corrida manual PSS/E reportada el 2026-05-19:

- metodo: full Newton-Raphson desde flat start;
- `CW=2`, con `WINDV1/RMA/RMI` en kV;
- PSS/E ajusta 1 tap;
- tap ajustado: `1.00000 -> 0.95000`;
- convergencia: tolerancia alcanzada en 5 iteraciones;
- bus 2: `VM = 0.9875`, `VA = -5.2 deg`;
- swing bus 1: `PGEN = 101.3 MW`, `QGEN = 62.8 MVAr`.

Comparacion contra `runpf_psse` local:

| Magnitud | PSS/E | runpf_psse | Diferencia aproximada |
|---|---:|---:|---:|
| Tap final | 0.95000 | 0.95000 | 0 |
| `WINDV1` final | 218.5 kV | 218.5 kV | 0 |
| Bus 2 VM | 0.9875 | 0.987464 | -0.000036 pu |
| Bus 2 VA | -5.2 deg | -5.243907 deg | -0.043907 deg |
| Swing PG | 101.3 MW | 101.281938 MW | -0.018062 MW |
| Swing QG | 62.8 MVAr | 62.819386 MVAr | 0.019386 MVAr |

Interpretacion:

- PSS/E confirma que `CW=2` en 2W usa los mismos pasos fisicos que `CW=1`,
  expresados en kV (`230 kV -> 218.5 kV`).
- `runpf_psse` reproduce el tap equivalente y la solucion dentro del redondeo
  del reporte PSS/E.

## PSS/E externo - `psse_ultc_2bus_cod0.raw`

Corrida manual PSS/E reportada el 2026-05-19:

- metodo: full Newton-Raphson desde flat start;
- `ACTAPS=1`, pero `COD1=0`;
- sin bloque `TAP RATIOS ADJUSTED`;
- tap final reportado: `1.000LK`;
- convergencia: tolerancia alcanzada en 3 iteraciones;
- bus 2: `VM = 0.9303`, `VA = -5.9 deg`;
- swing bus 1: `PGEN = 101.4 MW`, `QGEN = 64.4 MVAr`.

Comparacion contra `runpf_psse` local:

| Magnitud | PSS/E | runpf_psse | Diferencia aproximada |
|---|---:|---:|---:|
| Tap final | 1.00000 | 1.00000 | 0 |
| Bus 2 VM | 0.9303 | 0.930275 | -0.000025 pu |
| Bus 2 VA | -5.9 deg | -5.861282 deg | 0.038718 deg |
| Swing PG | 101.4 MW | 101.444399 MW | 0.044399 MW |
| Swing QG | 64.4 MVAr | 64.443995 MVAr | 0.043995 MVAr |

Interpretacion:

- PSS/E confirma que `COD=0` deja el tap fijo aunque `ACTAPS=1`.
- `runpf_psse` reproduce el caso fijo dentro del redondeo del reporte PSS/E.

## PSS/E externo - `psse_ultc_2bus_cod_m1.raw`

Corrida manual PSS/E reportada el 2026-05-19:

- PSS/E mostro `Record addition rejected` antes de leer el RAW, pero luego
  cargo el caso, convirtio el RAW y resolvio normalmente;
- metodo: full Newton-Raphson desde flat start;
- `ACTAPS=1`, pero `COD1=-1`;
- sin bloque `TAP RATIOS ADJUSTED`;
- tap final reportado: `1.000LK`;
- convergencia: tolerancia alcanzada en 3 iteraciones;
- bus 2: `VM = 0.9303`, `VA = -5.9 deg`;
- swing bus 1: `PGEN = 101.4 MW`, `QGEN = 64.4 MVAr`.

Comparacion contra `runpf_psse` local:

| Magnitud | PSS/E | runpf_psse | Diferencia aproximada |
|---|---:|---:|---:|
| Tap final | 1.00000 | 1.00000 | 0 |
| Bus 2 VM | 0.9303 | 0.930275 | -0.000025 pu |
| Bus 2 VA | -5.9 deg | -5.861282 deg | 0.038718 deg |
| Swing PG | 101.4 MW | 101.444399 MW | 0.044399 MW |
| Swing QG | 64.4 MVAr | 64.443995 MVAr | 0.043995 MVAr |

Interpretacion:

- PSS/E confirma que `COD=-1` suprime el ajuste automatico aunque `ACTAPS=1`.
- `runpf_psse` reproduce el caso fijo y reporta `suppressed_auto=1`.

## PSS/E externo - `psse_ultc_2bus_cont0.raw`

Corrida manual PSS/E reportada el 2026-05-19:

- metodo: full Newton-Raphson desde flat start;
- `ACTAPS=1`, `COD1=1`, pero `CONT1=0`;
- sin bloque `TAP RATIOS ADJUSTED`;
- tap final reportado: `1.000RG`;
- convergencia: tolerancia alcanzada en 3 iteraciones;
- bus 2: `VM = 0.9303`, `VA = -5.9 deg`;
- swing bus 1: `PGEN = 101.4 MW`, `QGEN = 64.4 MVAr`.

Comparacion contra `runpf_psse` local:

| Magnitud | PSS/E | runpf_psse | Diferencia aproximada |
|---|---:|---:|---:|
| Tap final | 1.00000 | 1.00000 | 0 |
| Bus 2 VM | 0.9303 | 0.930275 | -0.000025 pu |
| Bus 2 VA | -5.9 deg | -5.861282 deg | 0.038718 deg |
| Swing PG | 101.4 MW | 101.444399 MW | 0.044399 MW |
| Swing QG | 64.4 MVAr | 64.443995 MVAr | 0.043995 MVAr |

Interpretacion:

- PSS/E conserva el estado regulante (`RG`) por `COD=1`, pero al no tener bus
  controlado (`CONT=0`) no ejecuta ajuste automatico de tap.
- `runpf_psse` reproduce el caso fijo y reporta `cont_missing=1`.

## PSS/E externo - `psse_ultc_3bus_remote.raw`

Corrida manual PSS/E reportada el 2026-05-19:

- metodo: full Newton-Raphson desde flat start;
- PSS/E ajusta 1 tap;
- tap ajustado: `1.00000 -> 1.05000`;
- lado ajustable reportado por PSS/E: bus 2 `[BUS2 115.00]`;
- lado opuesto reportado por PSS/E: bus 1 `[BUS1 230.00]`;
- convergencia: tolerancia alcanzada en 5 iteraciones;
- bus 3: `VM = 0.9512`, `VA = -8.34 deg`;
- swing bus 1: `PGEN = 81.8 MW`, `QGEN = 51.0 MVAr`;
- tension final de bus 2: pendiente de exportar desde PSS/E.

Comparacion contra `runpf_psse` local:

| Magnitud | PSS/E | runpf_psse | Diferencia aproximada |
|---|---:|---:|---:|
| Tap final | 1.05000 | 1.05000 | 0 |
| Bus 2 VM | pendiente | 0.991104 | pendiente |
| Bus 2 VA | pendiente | -4.658954 deg | pendiente |
| Bus 3 VM | 0.9512 | 0.951215 | 0.000015 pu |
| Bus 3 VA | -8.34 deg | -8.338366 deg | 0.001634 deg |
| Swing PG | 81.8 MW | 81.771815 MW | -0.028185 MW |
| Swing QG | 51.0 MVAr | 51.032713 MVAr | 0.032713 MVAr |

Interpretacion:

- El tap discreto coincide exactamente y el swing queda dentro del redondeo del
  reporte PSS/E.
- En `runpf_psse`, el bus remoto regulado es bus 3 y queda dentro de la banda:
  `VM3 = 0.951215` para `VMI/VMA = 0.95/0.98`.
- La tension final PSS/E del bus remoto 3 coincide con `runpf_psse` dentro del
  redondeo reportado, cerrando el criterio principal de este caso.

## PSS/E externo - `psse_ultc_2bus_tab.raw`

Corrida manual PSS/E reportada el 2026-05-19:

- metodo: full Newton-Raphson desde flat start;
- PSS/E ajusta 1 tap;
- tap ajustado: `1.00000 -> 0.95000`;
- mensaje PSS/E de TAB: `Impedance changed from (0.01,0.1) to (0.0095,0.095)`;
- convergencia: tolerancia alcanzada en 5 iteraciones;
- bus 2: `VM = 0.9912`, `VA = -4.96 deg`;
- swing bus 1: `PGEN = 101.2 MW`, `QGEN = 62.1 MVAr`.

Comparacion contra `runpf_psse` local:

| Magnitud | PSS/E | runpf_psse | Diferencia aproximada |
|---|---:|---:|---:|
| Tap final | 0.95000 | 0.95000 | 0 |
| R final | 0.0095 | 0.009500 | 0 |
| X final | 0.095 | 0.095000 | 0 |
| Bus 2 VM | 0.9912 | 0.991179 | -0.000021 pu |
| Bus 2 VA | -4.96 deg | -4.962317 deg | -0.002317 deg |
| Swing PG | 101.2 MW | 101.208731 MW | 0.008731 MW |
| Swing QG | 62.1 MVAr | 62.087307 MVAr | -0.012693 MVAr |

Interpretacion:

- PSS/E confirma que la tabla de impedance correction se aplica cuando el tap
  cambia, recalculando la impedancia nominal `(0.01, 0.1)` con factor `0.95`.
- Las tensiones y potencias coinciden con `runpf_psse` dentro del redondeo del
  reporte PSS/E.

## PSS/E externo - `psse_ultc_3w_tab.raw`

Corrida manual PSS/E reportada el 2026-05-19:

- metodo: full Newton-Raphson desde flat start;
- PSS/E ajusta 2 taps en W1 del transformador de tres devanados;
- taps ajustados: `1.00000 -> 0.95000`, luego `0.95000 -> 0.90000LO`;
- mensajes PSS/E de TAB:
  - `Impedance changed from (0.01,0.1) to (0.0095,0.095)`;
  - `Impedance changed from (0.0095,0.095) to (0.009,0.09)`;
- convergencia: tolerancia alcanzada en 8 iteraciones;
- bus 2: `VM = 0.9517`, `VA = -11.2 deg`;
- bus 3: `VM = 1.0311`, `VA = -5.4 deg`;
- swing bus 1: `PGEN = 113.5 MW`, `QGEN = 84.2 MVAr`.

Comparacion contra `runpf_psse` local:

| Magnitud | PSS/E | runpf_psse | Diferencia aproximada |
|---|---:|---:|---:|
| Tap W1 final | 0.90000LO | 0.90000 | 0 |
| R W1 final | 0.009 | 0.009000 | 0 |
| X W1 final | 0.09 | 0.090000 | 0 |
| Bus 2 VM | 0.9517 | 0.951563 | -0.000137 pu |
| Bus 2 VA | -11.2 deg | -11.254705 deg | -0.054705 deg |
| Bus 3 VM | 1.0311 | 1.031047 | -0.000053 pu |
| Bus 3 VA | -5.4 deg | -5.427176 deg | -0.027176 deg |
| Swing PG | 113.5 MW | 113.549091 MW | 0.049091 MW |
| Swing QG | 84.2 MVAr | 84.287908 MVAr | 0.087908 MVAr |

Interpretacion:

- PSS/E confirma el modo `ZCOD=0` usado en el RAW de referencia: la tabla de
  impedance correction se aplica a la impedancia de W1 cuando cambia el tap.
- El tap final, la impedancia corregida y las tensiones de buses coinciden con
  `runpf_psse` dentro del redondeo del reporte PSS/E.

## PSS/E externo - `psse_ultc_3w_w2.raw`

Corrida manual PSS/E reportada el 2026-05-19:

- metodo: full Newton-Raphson desde flat start;
- PSS/E ajusta 1 tap en W2 del transformador de tres devanados;
- tap ajustado: `1.00000 -> 1.05000`;
- sin mensaje de cambio de impedancia, porque `TAB2=0`;
- convergencia: tolerancia alcanzada en 5 iteraciones;
- bus 2: `VM = 0.8264`, `VA = -16.0 deg`;
- bus 3: `VM = 0.8867`, `VA = -7.7 deg`;
- swing bus 1: `PGEN = 115.4 MW`, `QGEN = 100.9 MVAr`.

Comparacion contra `runpf_psse` local:

| Magnitud | PSS/E | runpf_psse | Diferencia aproximada |
|---|---:|---:|---:|
| Tap W2 final | 1.05000 | 1.05000 | 0 |
| Bus 2 VM | 0.8264 | 0.826305 | -0.000095 pu |
| Bus 2 VA | -16.0 deg | -15.970785 deg | 0.029215 deg |
| Bus 3 VM | 0.8867 | 0.886648 | -0.000052 pu |
| Bus 3 VA | -7.7 deg | -7.735842 deg | -0.035842 deg |
| Swing PG | 115.4 MW | 115.405617 MW | 0.005617 MW |
| Swing QG | 100.9 MVAr | 100.917780 MVAr | 0.017780 MVAr |

Interpretacion:

- PSS/E confirma que el control 3W en W2 actualiza el tap de W2 y no modifica
  impedancias cuando `TAB2=0`.
- El resultado coincide con `runpf_psse` dentro del redondeo del reporte PSS/E.

## PSS/E externo - `psse_ultc_3w_w2_cw2.raw`

Corrida manual PSS/E reportada el 2026-05-19:

- PSS/E mostro `Record addition rejected` antes de leer el RAW, pero luego
  cargo el caso, convirtio el RAW y resolvio normalmente;
- metodo: full Newton-Raphson desde flat start;
- `CW=2`, con `WINDV2/RMA2/RMI2` en kV;
- PSS/E ajusta 1 tap en W2 del transformador de tres devanados;
- tap ajustado: `1.00000 -> 1.05000`;
- sin mensaje de cambio de impedancia, porque `TAB2=0`;
- convergencia: tolerancia alcanzada en 5 iteraciones;
- bus 2: `VM = 0.8264`, `VA = -16.0 deg`;
- bus 3: `VM = 0.8867`, `VA = -7.7 deg`;
- swing bus 1: `PGEN = 115.4 MW`, `QGEN = 100.9 MVAr`.

Comparacion contra `runpf_psse` local:

| Magnitud | PSS/E | runpf_psse | Diferencia aproximada |
|---|---:|---:|---:|
| Tap W2 final | 1.05000 | 1.05000 | 0 |
| `WINDV2` final | 120.75 kV | 120.75 kV | 0 |
| Bus 2 VM | 0.8264 | 0.826305 | -0.000095 pu |
| Bus 2 VA | -16.0 deg | -15.970785 deg | 0.029215 deg |
| Bus 3 VM | 0.8867 | 0.886648 | -0.000052 pu |
| Bus 3 VA | -7.7 deg | -7.735842 deg | -0.035842 deg |
| Swing PG | 115.4 MW | 115.405617 MW | 0.005617 MW |
| Swing QG | 100.9 MVAr | 100.917780 MVAr | 0.017780 MVAr |

Interpretacion:

- PSS/E confirma que `CW=2` en W2 3W usa los mismos pasos fisicos que `CW=1`,
  expresados en kV (`115 kV -> 120.75 kV`).
- `runpf_psse` reproduce el tap equivalente y la solucion dentro del redondeo
  del reporte PSS/E.

## PSS/E externo - `psse_ultc_3w_w3.raw`

Corrida manual PSS/E reportada el 2026-05-19:

- metodo: full Newton-Raphson desde flat start;
- PSS/E ajusta 1 tap en W3 del transformador de tres devanados;
- tap ajustado: `1.00000 -> 1.05000`;
- sin mensaje de cambio de impedancia, porque `TAB3=0`;
- convergencia: tolerancia alcanzada en 5 iteraciones;
- bus 2: `VM = 0.7870`, `VA = -16.0 deg`;
- bus 3: `VM = 0.9310`, `VA = -7.7 deg`;
- swing bus 1: `PGEN = 115.4 MW`, `QGEN = 100.9 MVAr`.

Comparacion contra `runpf_psse` local:

| Magnitud | PSS/E | runpf_psse | Diferencia aproximada |
|---|---:|---:|---:|
| Tap W3 final | 1.05000 | 1.05000 | 0 |
| Bus 2 VM | 0.7870 | 0.786957 | -0.000043 pu |
| Bus 2 VA | -16.0 deg | -15.970785 deg | 0.029215 deg |
| Bus 3 VM | 0.9310 | 0.930980 | -0.000020 pu |
| Bus 3 VA | -7.7 deg | -7.735842 deg | -0.035842 deg |
| Swing PG | 115.4 MW | 115.405617 MW | 0.005617 MW |
| Swing QG | 100.9 MVAr | 100.917780 MVAr | 0.017780 MVAr |

Interpretacion:

- PSS/E confirma que el control 3W en W3 actualiza el tap de W3 y no modifica
  impedancias cuando `TAB3=0`.
- El resultado coincide con `runpf_psse` dentro del redondeo del reporte PSS/E.

## PSS/E externo - `psse_ultc_3w_tab_cw2.raw`

Corrida manual PSS/E reportada el 2026-05-19:

- metodo: full Newton-Raphson desde flat start;
- PSS/E ajusta 2 taps en W1 del transformador de tres devanados con `CW=2`;
- taps ajustados: `1.00000 -> 0.95000`, luego `0.95000 -> 0.90000LO`;
- mensajes PSS/E de TAB:
  - `Impedance changed from (0.01,0.1) to (0.0095,0.095)`;
  - `Impedance changed from (0.0095,0.095) to (0.009,0.09)`;
- convergencia: tolerancia alcanzada en 8 iteraciones;
- bus 2: `VM = 0.9517`, `VA = -11.2 deg`;
- bus 3: `VM = 1.0311`, `VA = -5.4 deg`;
- swing bus 1: `PGEN = 113.5 MW`, `QGEN = 84.2 MVAr`.

Comparacion contra `runpf_psse` local:

| Magnitud | PSS/E | runpf_psse | Diferencia aproximada |
|---|---:|---:|---:|
| Tap W1 final | 0.90000LO | 0.90000 | 0 |
| R W1 final | 0.009 | 0.009000 | 0 |
| X W1 final | 0.09 | 0.090000 | 0 |
| Bus 2 VM | 0.9517 | 0.951563 | -0.000137 pu |
| Bus 2 VA | -11.2 deg | -11.254705 deg | -0.054705 deg |
| Bus 3 VM | 1.0311 | 1.031047 | -0.000053 pu |
| Bus 3 VA | -5.4 deg | -5.427176 deg | -0.027176 deg |
| Swing PG | 113.5 MW | 113.549091 MW | 0.049091 MW |
| Swing QG | 84.2 MVAr | 84.287908 MVAr | 0.087908 MVAr |

Interpretacion:

- PSS/E confirma que el modo 3W `ZCOD=0` con `CW=2` aplica la tabla de
  impedance correction sobre la impedancia de W1 al cambiar el tap.
- El resultado coincide con `runpf_psse` dentro del redondeo del reporte PSS/E.

## PSS/E externo - `psse_ultc_3bus_remote_limit.raw`

Corrida manual PSS/E reportada el 2026-05-19:

- metodo: full Newton-Raphson desde flat start;
- PSS/E ajusta 2 taps;
- taps ajustados: `1.00000 -> 1.05000`, luego `1.05000 -> 1.10000HI`;
- convergencia: tolerancia alcanzada en 7 iteraciones;
- bus 2: `VM = 0.8418`, `VA = -5.76 deg`;
- bus 3: `VM = 0.7929`, `VA = -10.96 deg`;
- swing bus 1: `PGEN = 82.4 MW`, `QGEN = 56.8 MVAr`.

Comparacion contra `runpf_psse` local:

| Magnitud | PSS/E | runpf_psse | Diferencia aproximada |
|---|---:|---:|---:|
| Tap final | 1.10000HI | 1.10000 | 0 |
| Bus 2 VM | 0.8418 | 0.841752 | -0.000048 pu |
| Bus 2 VA | -5.76 deg | -5.755698 deg | 0.004302 deg |
| Bus 3 VM | 0.7929 | 0.792883 | -0.000017 pu |
| Bus 3 VA | -10.96 deg | -10.956628 deg | 0.003372 deg |
| Swing PG | 82.4 MW | 82.425781 MW | 0.025781 MW |
| Swing QG | 56.8 MVAr | 56.832030 MVAr | 0.032030 MVAr |

Interpretacion:

- El resultado PSS/E muestra que este caso remoto no debe seguir la misma
  inversion de direccion usada para el control local del terminal opuesto.
- Con tap fijo en `1.10000`, el modelo convertido en MATPOWER reproduce las
  tensiones y potencias de PSS/E; por lo tanto, la correccion necesaria estaba
  en la direccion automatica de control, no en la representacion electrica.

## PSS/E externo - `psse_ultc_3bus_remote_cont_pos.raw`

Corrida manual PSS/E reportada el 2026-05-19:

- metodo: full Newton-Raphson desde flat start;
- PSS/E ajusta 1 tap;
- tap ajustado: `1.00000 -> 0.95000`;
- convergencia: tolerancia alcanzada en 5 iteraciones;
- bus 2: `VM = 1.0002`, `VA = -4.2 deg`;
- bus 3: `VM = 0.9607`, `VA = -7.8 deg`;
- swing bus 1: `PGEN = 81.6 MW`, `QGEN = 49.8 MVAr`.

Comparacion contra `runpf_psse` local:

| Magnitud | PSS/E | runpf_psse | Diferencia aproximada |
|---|---:|---:|---:|
| Tap final | 0.95000 | 0.95000 | 0 |
| Bus 2 VM | 1.0002 | 1.000152 | -0.000048 pu |
| Bus 2 VA | -4.2 deg | -4.176025 deg | 0.023975 deg |
| Bus 3 VM | 0.9607 | 0.960695 | -0.000005 pu |
| Bus 3 VA | -7.8 deg | -7.786078 deg | 0.013922 deg |
| Swing PG | 81.6 MW | 81.652338 MW | 0.052338 MW |
| Swing QG | 49.8 MVAr | 49.871038 MVAr | 0.071038 MVAr |

Interpretacion:

- PSS/E confirma que `CONT=+3` en un bus remoto no terminal no sigue la misma
  direccion que el caso `CONT=-3`; para tension baja, el tap baja a `0.95`.
- `runpf_psse` reproduce el tap, la tension remota y la potencia de slack
  dentro del redondeo del reporte PSS/E.
