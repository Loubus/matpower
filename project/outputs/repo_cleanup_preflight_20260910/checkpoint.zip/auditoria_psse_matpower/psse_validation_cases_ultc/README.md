# PSS/E transformer tap / ULTC validation cases

Estos casos son artefactos locales de auditoria para comparar el control de
taps PSS/E contra `runpf_psse` sin depender del RAW grande.

Nota de formato PSS/E: los RAW no tienen linea en blanco entre las dos lineas
de encabezado del caso y los registros `SYSTEM-WIDE`. PSS/E interpreta esa
linea vacia como cierre prematuro de la seccion y desplaza la lectura de las
secciones siguientes.

Nota de generador: los casos chicos usan `ZX=1.0` en el registro de generador
para evitar el warning de PSS/E `Invalid ZSORCE reactance`. MATPOWER no usa ese
campo en estas pruebas de flujo AC.

## Casos

- `psse_ultc_2bus_local.raw`: dos barras, un transformador `COD=1`,
  `ACTAPS=1`, cinco posiciones discretas de tap y control de tension del
  lado de carga.
- `psse_ultc_2bus_actaps_off.raw`: mismo caso, pero con `ACTAPS=0`; debe
  converger sin mover el tap.
- `psse_ultc_3bus_remote.raw`: tres barras, un transformador `COD=1` que
  regula una barra remota a traves de `CONT=-3` y entra en banda.
- `psse_ultc_3bus_remote_limit.raw`: tres barras, misma regulacion remota,
  pero con orientacion que lleva el tap al limite alto. Este caso conserva la
  corrida PSS/E externa ya reportada.
- `psse_ultc_2bus_tab.raw`: dos barras, un transformador `COD=1` con
  `TAB=1` y una tabla de impedance correction no unitaria para verificar
  que `R/X` se actualizan cuando cambia el tap.
- `psse_ultc_3w_tab.raw`: tres barras y un transformador de tres devanados
  con `ZCOD=0`, `TAB=1` en los tres devanados y control automatico en W1.
- `psse_ultc_3w_w2.raw`: tres barras y un transformador de tres devanados
  sin `TAB`, con control automatico en W2 para aislar la rama W2-estrella.
- `psse_ultc_3w_w3.raw`: tres barras y un transformador de tres devanados
  sin `TAB`, con control automatico en W3 para aislar la rama W3-estrella.
- `psse_ultc_3w_tab_cw2.raw`: variante 3W con `CW=2` y `TAB=1`,
  representativa de los casos `TAB` del RAW grande.
- `psse_ultc_2bus_cont_pos.raw`: dos barras con `CONT1=+2` para validar el
  signo positivo de `CONT` en un bus terminal.
- `psse_ultc_3bus_remote_cont_pos.raw`: tres barras con `CONT1=+3` para
  validar el signo positivo de `CONT` en un bus remoto.
- `psse_ultc_2bus_cod0.raw`: dos barras con `ACTAPS=1`, pero `COD1=0`;
  debe converger sin mover el tap.
- `psse_ultc_2bus_cod_m1.raw`: dos barras con `ACTAPS=1`, pero `COD1=-1`;
  debe reportarse como ajuste automatico suprimido y converger sin mover tap.
- `psse_ultc_2bus_cont0.raw`: dos barras con `ACTAPS=1`, `COD1=1` y
  `CONT1=0`; debe converger sin mover tap por falta de bus regulado.
- `psse_ultc_2bus_cw2.raw`: dos barras con `CW=2`, para validar que
  `WINDV/RMA/RMI` en kV se convierten al mismo tap fisico que `CW=1`.
- `psse_ultc_3w_w2_cw2.raw`: transformador de tres devanados con control en
  W2 y `CW=2`, representativo de los controles W2 `CW=2` del RAW grande.
- `diagramas_psse.md`: lista de elementos a dibujar en PSS/E y valores
  esperados para cada caso.

## Que exportar desde PSS/E

Para cada caso, correr flujo Newton y exportar:

- buses: `I`, `NAME`, `BASKV`, `TYPE`, `VM`, `VA`;
- transformadores: `I`, `J`, `K`, `CKT`, `STAT`, `CW`, `WINDV1`,
  `WINDV2`, `COD1`, `CONT1`, `RMA1`, `RMI1`, `VMA1`, `VMI1`, `NTP1`,
  `TAB1`, `CR1`, `CX1`;
- impedance correction: tabla referenciada por `TAB`, puntos `T`,
  `Re(F)`, `Im(F)`;
- convergencia, metodo, numero de iteraciones y valor global de `ACTAPS`.

La comparacion principal es `VM/VA` y tap final. El test automatico local
equivalente vive en `matpower/lib/t/t_mpxt_psse.m`.
