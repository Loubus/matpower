function exported = psse_diag_export_run(data, outdir, opts)
%PSSE_DIAG_EXPORT_RUN Write normalized diagnostics tables and manifests.

if nargin < 3 || isempty(opts)
    opts = struct();
end
outdir = char(outdir);
ensure_dir(outdir);

files = strings(0, 1);
files(end+1, 1) = write_table_if_present(data.cpf_points, outdir, ...
    'cpf_points.csv');
files(end+1, 1) = write_table_if_present(data.bus_trace, outdir, ...
    'bus_trace.csv');
files(end+1, 1) = write_table_if_present(data.branch_trace, outdir, ...
    'branch_trace.csv');
files(end+1, 1) = write_table_if_present(data.gen_trace, outdir, ...
    'gen_trace.csv');
files(end+1, 1) = write_table_if_present(data.vsc_trace, outdir, ...
    'vsc_trace.csv');
files(end+1, 1) = write_table_if_present(data.busdc_trace, outdir, ...
    'busdc_trace.csv');
files(end+1, 1) = write_table_if_present(data.branchdc_trace, outdir, ...
    'branchdc_trace.csv');
files(end+1, 1) = write_table_if_present(data.event_timeline, outdir, ...
    'event_timeline.csv');
files(end+1, 1) = write_table_if_present(data.capability_audit, outdir, ...
    'capability_audit.csv');
files(end+1, 1) = write_table_if_present(data.redispatch_trace, outdir, ...
    'redispatch_trace.csv');
files(end+1, 1) = write_table_if_present(data.redispatch_technology_trace, ...
    outdir, 'redispatch_technology_trace.csv');
files(end+1, 1) = write_table_if_present(data.warnings, outdir, ...
    'warnings.csv');

write_index_maps(data.index_map, outdir);
write_json(fullfile(outdir, 'run_manifest.json'), data.run_manifest);
write_plotting_manifest(outdir, data, opts);
readme_file = write_readme(outdir, data);

files = files(strlength(files) > 0);
exported = struct('outdir', string(outdir), 'files', files, ...
    'readme_file', string(readme_file), ...
    'manifest_file', string(fullfile(outdir, 'run_manifest.json')));
end

function ensure_dir(d)
if exist(d, 'dir') ~= 7
    mkdir(d);
end
end

function file = write_table_if_present(T, outdir, name)
file = "";
if isempty(T) || ~istable(T) || width(T) == 0
    return;
end
file = fullfile(outdir, name);
writetable(T, file);
file = string(file);
end

function write_index_maps(index_map, outdir)
names = fieldnames(index_map);
for k = 1:numel(names)
    T = index_map.(names{k});
    write_table_if_present(T, outdir, "index_map_" + names{k} + ".csv");
end
end

function write_plotting_manifest(outdir, data, opts)
manifest = struct();
manifest.created_by = 'psse_diag_export_run';
manifest.run_id = data.run_id;
manifest.selected_modules = option_strings(opts, 'plot_modules', ...
    ["pv"; "gen_pq"; "events"; "redispatch"]);
manifest.bus_groups = option_strings(opts, 'bus_groups', ...
    ["boundary_ports"; "buses_500kv"; "worst_voltage_drop"; ...
    "lowest_final_voltage"]);
manifest.branch_groups = option_strings(opts, 'branch_groups', "top_loading");
manifest.plot_options = plot_option_summary(opts);
manifest.default_curve_trace = 'compact CPF trace when available';
manifest.generator_plot_source = generator_source(data.gen_trace);
manifest.vsc_plotting = 'opt-in plot module; normalized vsc_trace is exported when present';
manifest.assumptions = [ ...
    "PV curves use normalized bus_trace, falling back to results.cpf.V when needed."; ...
    "Branch plots require normalized branch_trace with loading_pct."; ...
    "Plot generation overwrites this manifest with generated file names when make_plots is enabled."];
manifest.output_tables = dir_names(outdir, '*.csv');
write_json(fullfile(outdir, 'plotting_manifest.json'), manifest);
end

function values = option_strings(opts, name, default)
values = default;
if isfield(opts, name) && ~isempty(opts.(name))
    raw = opts.(name);
    values = string(raw(:));
end
values = lower(values);
if any(values == "all")
    values = ["pv"; "gen_pq"; "events"; "redispatch"; "branch"; "vsc"];
end
end

function s = plot_option_summary(opts)
s = struct('page_size', 50, 'gen_per_page', 6, ...
    'event_families', strings(0, 1), 'use_compact_trace', true);
if isfield(opts, 'plot') && isstruct(opts.plot)
    p = opts.plot;
    if isfield(p, 'page_size') && ~isempty(p.page_size)
        s.page_size = p.page_size;
    end
    if isfield(p, 'gen_per_page') && ~isempty(p.gen_per_page)
        s.gen_per_page = p.gen_per_page;
    end
    if isfield(p, 'event_families') && ~isempty(p.event_families)
        s.event_families = string(p.event_families(:));
    end
    if isfield(p, 'use_compact_trace') && ~isempty(p.use_compact_trace)
        s.use_compact_trace = logical(p.use_compact_trace);
    end
end
end

function src = generator_source(T)
src = "";
if istable(T) && width(T) > 0 && any(strcmp(T.Properties.VariableNames, 'source'))
    src = strjoin(unique(string(T.source)), ', ');
end
end

function names = dir_names(outdir, pat)
d = dir(fullfile(outdir, pat));
names = string({d.name});
end

function readme_file = write_readme(outdir, data)
readme_file = fullfile(outdir, 'README.md');
fid = fopen(readme_file, 'w');
if fid < 0
    error('psse_diag_export_run:write_failed', ...
        'Could not write %s.', readme_file);
end
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, '# PSS/E-aware MATPOWER diagnostics\n\n');
fprintf(fid, 'Run id: `%s`\n\n', data.run_id);
fprintf(fid, 'Source folder: `%s`\n\n', data.source_dir);
fprintf(fid, 'Primary MAT file: `%s`\n\n', data.primary_file);
fprintf(fid, '## Summary\n\n');
fprintf(fid, '- solver type: `%s`\n', data.run_manifest.solver_type);
fprintf(fid, '- success: `%g`\n', data.run_manifest.success);
fprintf(fid, '- max lambda: `%.15g`\n', data.run_manifest.max_lambda);
fprintf(fid, '- CPF points: `%d`\n', data.run_manifest.point_count);
fprintf(fid, '- events: `%d`\n', data.run_manifest.event_count);
fprintf(fid, '- generator trace source: `%s`\n', generator_source(data.gen_trace));
fprintf(fid, '- bus trace table: `%d rows`\n', table_height(data.bus_trace));
fprintf(fid, '- branch trace table: `%d rows`\n', table_height(data.branch_trace));
fprintf(fid, '- VSC trace table: `%d rows`\n', table_height(data.vsc_trace));
fprintf(fid, '\n## Warnings\n\n');
if table_height(data.warnings) == 0
    fprintf(fid, '- none\n');
else
    for k = 1:height(data.warnings)
        fprintf(fid, '- %s\n', data.warnings.warning(k));
    end
end
fprintf(fid, '\n## Exports\n\n');
csvs = dir(fullfile(outdir, '*.csv'));
for k = 1:numel(csvs)
    fprintf(fid, '- `%s`\n', csvs(k).name);
end
fprintf(fid, '- `run_manifest.json`\n');
fprintf(fid, '- `plotting_manifest.json`\n');
fprintf(fid, '\n## Assumptions\n\n');
fprintf(fid, ['- Full CPF traces are preserved in exported tables; compact ' ...
    'trace metadata is used for visual curves when available.\n']);
fprintf(fid, ['- Generator technology labels use the same online-generator ' ...
    'remapping convention as the CPF redispatch policy state.\n']);
fprintf(fid, ['- VSC plotting is opt-in through `opts.plot_modules`; ' ...
    'VSC/DC trace CSVs are emitted when present.\n']);
fprintf(fid, ['- Plot summaries are appended here after plotting is ' ...
    'generated.\n']);
end

function n = table_height(T)
if istable(T)
    n = height(T);
else
    n = 0;
end
end

function write_json(file, s)
fid = fopen(file, 'w');
if fid < 0
    error('psse_diag_export_run:write_failed', ...
        'Could not open %s for writing.', file);
end
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, '%s\n', jsonencode(s, 'PrettyPrint', true));
end
