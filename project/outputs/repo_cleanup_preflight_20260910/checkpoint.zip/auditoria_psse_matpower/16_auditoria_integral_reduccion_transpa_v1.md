# Auditoria integral reduccion TRANSPA v1

Fecha: 2026-05-31  
Workspace: `C:\Users\santi\Documents\UNIVERSIDAD\PROYECTO FINAL DE CARRERA - MATPOWER`

## Preflight

Estado git solicitado:

```text
raiz workspace: no es repositorio git
matpower:
 M lib/+mp/psse_genq_states.m
 M lib/+mp/psse_swdev_collapse.m
 M lib/+mp/psse_swdev_expand.m
 M lib/+mp/xt_psse.m
 M lib/runpf_psse.m
?? lib/+mp/psse_cpf_compact_trace.m
?? lib/+mp/psse_mpx_options.m
?? lib/+mp/psse_prepare_case.m
?? lib/+mp/psse_sync_cpf_target.m
?? lib/+mp/task_cpf_psse.m
?? lib/runcpf_psse.m
matpower-extras: limpio
```

Actualizacion posterior a la primera auditoria: se aplico una correccion acotada para preservar `GENQ` y `SWDEV` en el reducido, sin limpiar ni revertir cambios preexistentes. Los artefactos de auditoria quedan bajo:

`auditoria_psse_matpower/results/transpa_reduccion_v1_auditoria_integral/`

## Veredicto actualizado

La reduccion `case_transpa_reduced_v1_explicit.m` es defendible como modelo reducido calibrado para flujo de potencia alrededor del punto base `full_raw_runpf_psse`, con `GENQ` y `SWDEV` ahora preservados como metadata PSS/E del reducido.

Para PF base, el enfoque es razonable: conserva TRANSPA/Rio Negro/Bahia Blanca explicito, reemplaza el SADI externo con un equivalente Thevenin/Norton multipuerto, no pone la slack directamente sobre `1008`, y reproduce tensiones de barras retenidas con error maximo de `0.0115433 pu` y angulo maximo de `0.299208 deg` contra el RAW completo resuelto con `runpf_psse`.

Para CPF, la validacion debe distinguir dos curvas. La CPF estandar `runcpf` sirve como referencia numerica, pero no reajusta taps, switched shunts ni otros controles PSS/E. La ruta operativa para este caso debe ser `runcpf_psse`. En la corrida actual con target de cargas `1.15x`, `runcpf` llego a `lambda=1.5969603073`, mientras `runcpf_psse` llego a `lambda=1.4560035451` con `316` eventos de control. Esa diferencia no es ruido: viene del active-set PSS/E.

Conclusion corta: valido como v1 de equivalente externo AC multipuerto para PF y CPF local, con limitaciones importantes. Ya no queda el bloqueo de metadata `GENQ`/`SWDEV`, pero `GENQ` no realiza ajustes activos en esta v1 porque el caso esta marcado como solved-snapshot y el RAW trae `VARLIM=0`; forzarlo activo descalibra el equivalente base. Siguen pendientes owner metadata completa y validacion externa fina de margen de tension.

## Correccion GENQ/SWDEV aplicada

Evidencia:

- `build_transpa_reduced_case.m` ahora conserva `genq` y `swdev` al filtrar metadata PSS/E del RAW.
- `case_transpa_reduced_v1_explicit.m` carga el sidecar `case_transpa_reduced_v1_psse.mat`, de modo que el caso explicito usa la metadata regenerada.
- `mpc.psse.genq` queda con `133` filas retenidas; `runpf_psse` devuelve `psse.genq.control` con `enabled=0`, `active=48`, `remote=3`, `local=45`, `num_adjustments=0`.
- `mpc.psse.swdev` queda con `20` filas activas internas, `collapse_disabled=1`; `runpf_psse` y `runcpf_psse` no usan `swdev_collapse_fallback`.

Hipotesis resuelta:

- El problema original no era solo que faltara una tabla: `GENQ` habia quedado fuera del sidecar y, al probarlo activo, cambia el punto operativo. Por eso la correccion preserva y reporta GENQ, pero no fuerza ajustes activos contra `VARLIM=0` y el snapshot calibrado.

Recomendacion:

- Usar la v1 corregida para PF/CPF con controles PSS/E actuales. Si se quiere estudiar especificamente limites Q activos, generar un escenario separado con `enable_genq_control=true`, recalibrar el equivalente y no mezclarlo con esta validacion base.

## Evidencia principal

Archivos leidos primero:

- `auditoria_psse_matpower/12_plan_reduccion_transpa_equivalente.md`
- `auditoria_psse_matpower/13_tecnicas_equivalentes_redes_potencia.md`
- `auditoria_psse_matpower/14_plan_runcpf_psse.md`
- `auditoria_psse_matpower/15_resultados_runcpf_psse.md`
- `auditoria_psse_matpower/results/transpa_reduccion_v1/metodologia_y_resultados.md`
- `auditoria_psse_matpower/results/transpa_reduccion_v1/case_transpa_reduced_v1_explicit.m`
- `PSSE/V26p_Trs_2532.raw`
- `PSSE/TRANSPA PICO VERANO 2025_2026.pdf`
- `auditoria_psse_matpower/transpa_reduccion/build_transpa_reduced_case.m`
- scripts/resultados bajo `auditoria_psse_matpower/results/transpa_reduccion_v1/`

El RAW original contiene secciones no vacias relevantes:

```text
SYSTEM-WIDE 21
BUS 5015
LOAD 1691
FIXED SHUNT 201
GENERATOR 961
BRANCH 2802
SYSTEM SWITCHING DEVICE / SWDEV 508
TRANSFORMER 2491
AREA 15
TWO-TERMINAL DC 8
IMPEDANCE CORRECTION 12
ZONE 65
OWNER 24
FACTS DEVICE 1
SWITCHED SHUNT 361
```

El importador MATPOWER genera `5763` buses porque agrega star-points de transformadores de tres devanados. La reduccion queda con `326` buses retenidos mas `6` buses ficticios `SADI_EQ_*`, total `332`.

Resumen cuantitativo generado en:

`auditoria_psse_matpower/results/transpa_reduccion_v1_auditoria_integral/raw_vs_reduced_inventory.csv`

| Item | RAW | Retenido/reducido |
|---|---:|---:|
| BUS section real | 5015 | 326 retenidos + 6 `SADI_EQ` |
| MATPOWER imported buses | 5763 | 332 en reducido |
| GEN rows | 961 | 133 originales retenidos + 6 equivalentes |
| LOAD records | 1691 | 97 en buses retenidos, 60 activos |
| Branches activas internas retenidas | 325 | 325 no equivalentes |
| Cortes activos retenido/externo | 23 | reemplazados por equivalente |
| Ramas equivalentes | n/a | 30 |
| Switched shunts | 361 | 21 preservados |
| Transformadores 2 devanados | 1743 | 91 metadata retenida |
| Transformadores 3 devanados | 748 | 37 metadata retenida |
| FACTS | 1 | 0, externo al retenido |
| Two-terminal DC | 8 | 0, externos al retenido |
| SWDEV | 508 | 20 activos internos preservados como `psse.swdev` |

## Frontera y equivalente

La frontera v1 no es solo `1008` y `2206/2208`. La conectividad actual deja seis puertos electricos:

```text
1008, 1226, 2206, 2208, 2222, 2302
```

Esto es consistente con el propio plan: si aparece otro cruce real, se debe agregarlo como frontera o ampliar la red retenida. En `boundary_cuts.csv` hay `23` cortes activos:

- `1008`: 4 cortes.
- `1226`: 2 cortes.
- `2206`: 7 cortes.
- `2208`: 7 cortes.
- `2222`: 1 corte.
- `2302`: 2 cortes.

El equivalente se clasifica como Thevenin/Norton multipuerto con rasgo Ward operativo:

- Se calcula una matriz externa por Schur/Kron: `Yeq = Ypp - Ype * (Yee \ Yep)`.
- Se calibra una inyeccion Norton al punto base: `Inorton = I_ext0 + Yeq * Vport`.
- Se obtiene `Eth_multi = Yeq \ Inorton`.
- Se realiza en MATPOWER con 6 buses ficticios `SADI_EQ_*`, 6 generadores fuente y 30 ramas equivalentes.

La slack no esta pegada a `1008`. Los puertos fisicos `1008`, `1226`, `2206`, `2208`, `2222`, `2302` son PQ en el caso; los REF son los buses ficticios:

```text
901008, 901226, 902206, 902208, 902222, 902302
```

La realizacion de la matriz multipuerto produce impedancias no fisicas en algunas ramas equivalentes. En el caso hay `11` R negativas y `14` X negativas dentro del bloque equivalente. Esto no debe tratarse como linea real, sino como parametros de una realizacion de admitancia equivalente.

El peor error de intercambio de frontera esta en `1008`, casi todo reactivo:

| Puerto | P corte MW | Q corte MVAr | Eth pu | Eth deg | abs(dS) MVA |
|---:|---:|---:|---:|---:|---:|
| 1008 | 631.5966 | -194.3444 | 1.007151 | 10.6771 | 0.3016 |
| 1226 | -4.7035 | 34.0944 | 0.801787 | 19.7578 | 0.0023 |
| 2206 | 34.9729 | 47.4683 | 1.012322 | 2.6185 | 0.0831 |
| 2208 | -34.9729 | 61.0381 | 1.003693 | 2.9915 | 0.0856 |
| 2222 | -27.9308 | -14.7635 | 1.171045 | 11.2376 | 0.0454 |
| 2302 | -12.4920 | -5.9507 | 1.129507 | 10.5602 | 0.0008 |

Tabla fuente:

`auditoria_psse_matpower/results/transpa_reduccion_v1_auditoria_integral/boundary_ports_audit.csv`

## Controles PSS/E

Tabla generada:

`auditoria_psse_matpower/results/transpa_reduccion_v1_auditoria_integral/control_preservation_audit.csv`

| Familia | RAW | Reducido | Control efectivo |
|---|---|---|---|
| ULTC/taps | 1743 trafos 2D + 748 3D | 91 2D + 37 3D | activo, `ACTAPS=1` efectivo |
| Switched shunts | 361, 348 activos | 21, todos activos | activo, `SWSHNT=1` efectivo |
| Fixed shunts | 201, 194 activos | 14 buses con `GS/BS` | estatico en `Ybus` |
| GENQ/Q limits | 961 filas | 133 generadores retenidos, `psse.genq` preservado | reporte GENQ presente; ajustes activos deshabilitados por solved-snapshot/`VARLIM=0` salvo diagnostico explicito |
| FACTS | 1 STATCON externo | ausente | sin control en reducido |
| Two-terminal DC | 8 registros externos | ausente, `dcline=0` | `DCTAPS=1` no actua sobre nada |
| PQBRAK | `PQBRAK=0.7` | system general retenido | controlable por `runpf_psse/runcpf_psse` |
| SWDEV | 508 registros | 20 activos internos preservados en `psse.swdev` | retenidos como ramas explicitas; `collapse_disabled=1`, sin fallback de colapso |
| Area/zone/owner | 15/65/24 | area/zone numerico en bus, tablas PSS/E ausentes | menor trazabilidad |

Hallazgo importante: el caso explicito conserva el record textual RAW con `ACTAPS=0, DCTAPS=1, SWSHNT=2, VARLIM=0`, pero luego pisa los campos efectivos a `ACTAPS=1` y `SWSHNT=1`. En esta implementacion gobiernan los campos efectivos de `mpc.psse.system.solver`, no el texto original.

## Validacion numerica ejecutada

Setup MATLAB usado:

```matlab
root = 'C:\Users\santi\Documents\UNIVERSIDAD\PROYECTO FINAL DE CARRERA - MATPOWER';
addpath(fullfile(root, 'matpower', 'lib'));
addpath(fullfile(root, 'matpower', 'lib', 't'));
addpath(fullfile(root, 'auditoria_psse_matpower'));
addpath(fullfile(root, 'auditoria_psse_matpower', 'results', 'transpa_reduccion_v1'));
```

PF actual:

```matlab
[mpc_raw, warn_raw] = psse2mpc(fullfile(root, 'PSSE', 'V26p_Trs_2532.raw'), 0, 0, 34);
[mpc_red, mpopt_red] = case_transpa_reduced_v1_explicit();
r_full_std = runpf(mpc_raw, mpopt_full);
r_full_psse = runpf_psse(mpc_raw, mpopt_full);
r_std = runpf(mpc_red, mpopt_red);
r_psse = runpf_psse(mpc_red, mpopt_red);
```

Resultados:

| Validacion | Resultado |
|---|---:|
| RAW completo `runpf` | success=1, 4 iter |
| RAW completo `runpf_psse` | success=1, 4 iter |
| Reducido `runpf` | success=1, 3 iter |
| Reducido `runpf_psse` | success=1, 4 iter |
| RAW `runpf` vs `runpf_psse`, max dVM | 0.238451 pu en bus 46402 |
| RAW `runpf` vs `runpf_psse`, max dVA | 7.53993 deg en bus 46402 |
| Reducido `runpf_psse` vs RAW `runpf_psse`, max dVM | 0.0115433 pu en bus 721 |
| Reducido `runpf_psse` vs RAW `runpf_psse`, max dVA | 0.299208 deg en bus 528 |

La diferencia grande entre `runpf` y `runpf_psse` en el RAW completo confirma que los controles/modelados PSS/E no son cosmeticos. Por eso la reduccion se debe validar contra `runpf_psse`, no contra `runpf` estandar.

CPF actual sin escribir archivos:

```matlab
[pf_psse, pf_success] = runpf_psse(mpcb, mpopt);
[cpf0, cpf0_success] = runcpf_psse(mpcb, mpcb, mpopt);
mpct = mpcb;
mpct.bus(:,3:4) = mpcb.bus(:,3:4) * 1.15;
[cpf_std, std_success] = runcpf(mpcb, mpct, mpopt);
[cpf_psse, psse_success] = runcpf_psse(mpcb, mpct, mpopt);
```

Resultados:

| CPF | success | lambda max | puntos | eventos |
|---|---:|---:|---:|---:|
| Base `runpf_psse` vs `runcpf_psse(mpcb, mpcb)` | 1 | 0 | n/a | n/a |
| Target 1.15 `runcpf` | 1 | 1.5969603073 | 79 | 1 |
| Target 1.15 `runcpf_psse` | 1 | 1.4560035451 | 394 | 316 |

Eventos `runcpf_psse` target 1.15:

```text
PSSE_XFMR 283
PSSE_SWSHUNT 32
NOSE 1
```

Tension minima final `runcpf_psse`: bus `322`, `VM=0.6014935 pu`.

Puertos al final de la CPF target 1.15:

| Puerto | VM runcpf | VM runcpf_psse | Delta |
|---:|---:|---:|---:|
| 1008 | 1.007688 | 1.003062 | -0.004626 |
| 1226 | 1.024707 | 1.020287 | -0.004420 |
| 2206 | 1.025028 | 1.023819 | -0.001209 |
| 2208 | 1.025035 | 1.023825 | -0.001210 |
| 2222 | 0.715531 | 0.723358 | 0.007826 |
| 2302 | 0.871900 | 0.876728 | 0.004828 |

Tablas:

- `auditoria_psse_matpower/results/transpa_reduccion_v1_auditoria_integral/validation_summary_current.csv`
- `auditoria_psse_matpower/results/transpa_reduccion_v1_auditoria_integral/cpf_current_1p15_ports.csv`

## Hallazgos priorizados

### Criticos

No quedan hallazgos criticos abiertos por perdida de metadata `GENQ` o `SWDEV` en la v1 corregida.

1. La CPF guardada originalmente bajo `transpa_reduccion_v1` usa `runcpf` estandar. Es util como curva base, pero no valida comportamiento PSS/E. La corrida actual muestra que `runcpf_psse` cambia el margen por active-set de transformadores y shunts.

### Importantes

2. `GENQ` queda preservado y reportado, pero no hace ajustes activos con la politica actual: `solved_snapshot_policy.active=1`, `gen_vg_source='bus_vm'`, `enable_genq_control=false`, y el RAW trae `VARLIM=0`. Un experimento con GENQ forzado activo produjo 11 ajustes y subio el error base a `0.0556549 pu`; por eso no se aplico como fix operativo.

3. Hay 6 REF ficticios en una misma red equivalente. Esto es coherente con la realizacion multipuerto, pero debe documentarse como red equivalente de fuentes ideales detras de admitancias, no como seis slacks fisicos independientes. Si otra herramienta asume un solo slack por isla, puede reinterpretar el caso.

4. `SWDEV` interno queda preservado como metadata para 20 dispositivos activos y se conserva electricamente como ramas explicitas. La politica `collapse_disabled=1` evita el fallback de colapso que antes podia alterar topologia; esto es trazable, pero no modela maniobras dinamicas de SWDEV.

5. Hay una dualidad entre records textuales RAW y campos efectivos del solver: el texto preserva `ACTAPS=0/SWSHNT=2`, pero la reduccion fuerza `ACTAPS=1/SWSHNT=1`. No es necesariamente incorrecto, pero debe estar marcado como decision de modelado.

### Menores

6. `AREA`, `ZONE` y `OWNER` como tablas PSS/E no se preservan. El bus mantiene area/zone numericas, pero se pierde la tabla nominal y owner general.

7. FACTS y two-terminal DC no quedan en el reducido porque estan fuera de la red retenida. Esto es aceptable para TRANSPA explicito si se documenta que su efecto queda absorbido por el equivalente externo.

8. Las figuras PV de `runcpf_psse` estan fuera de `transpa_reduccion_v1`. Conviene referenciarlas o copiarlas a un paquete de validacion final.

## Recomendaciones

1. Mantener la frontera como seis puertos electricos: `1008`, `1226`, `2206`, `2208`, `2222`, `2302`. No volver a una frontera de dos puertos salvo que se amplie la red retenida para eliminar los cortes extra.

2. No colapsar `2206` y `2208`; el RAW los acopla electricamente y el balance por barra requiere tratarlos separados.

3. Mantener la calibracion actual de frontera: el peor cierre de intercambio bajo la v1 corregida es `1008`, con `|dS| = 0.301632 MVA`. Para estudios de sensibilidad fina, documentar esta tolerancia y revisar si debe bajarse aun mas.

4. Mantener `psse.genq` filtrado a generadores retenidos. Si se quiere estudiar limites Q activos, hacerlo como escenario diagnostico explicito con `enable_genq_control=true` y recalibrar/validar el equivalente, porque el experimento directo descalibra el punto base.

5. Mantener `psse.swdev` filtrado y `collapse_disabled=1` para esta v1; documentar que SWDEV queda como conectividad explicita de estado base, no como dispositivo de maniobra dinamica.

6. Reubicar un resumen minimo de `runcpf_psse` dentro del paquete `transpa_reduccion_v1`: comando, lambda, eventos, buses criticos y rutas de PNG.

7. Antes de modificar el caso, definir tolerancias de aceptacion separadas: base PF, intercambio por frontera, V/Q en puertos, CPF con controles, y trazabilidad de metadata PSS/E.

## Artefactos generados

```text
auditoria_psse_matpower/16_auditoria_integral_reduccion_transpa_v1.md
auditoria_psse_matpower/results/transpa_reduccion_v1_auditoria_integral/raw_vs_reduced_inventory.csv
auditoria_psse_matpower/results/transpa_reduccion_v1_auditoria_integral/boundary_ports_audit.csv
auditoria_psse_matpower/results/transpa_reduccion_v1_auditoria_integral/control_preservation_audit.csv
auditoria_psse_matpower/results/transpa_reduccion_v1_auditoria_integral/validation_summary_current.csv
auditoria_psse_matpower/results/transpa_reduccion_v1_auditoria_integral/cpf_current_1p15_ports.csv
```

Artefactos del reducido regenerados por la correccion:

```text
auditoria_psse_matpower/results/transpa_reduccion_v1/case_transpa_reduced_v1.m
auditoria_psse_matpower/results/transpa_reduccion_v1/case_transpa_reduced_v1_psse.mat
auditoria_psse_matpower/results/transpa_reduccion_v1/transpa_reduction_v1.mat
auditoria_psse_matpower/results/transpa_reduccion_v1/metodologia_y_resultados.md
```

Figuras PV existentes relevantes:

```text
auditoria_psse_matpower/results/runcpf_psse_transpa_control_pv/transpa_pv_3bus_nose_after_iter_reset.png
auditoria_psse_matpower/results/runcpf_psse_transpa_control_pv/transpa_pv_ultc_regulated_complete_to_critical.png
auditoria_psse_matpower/results/runcpf_psse_transpa_control_pv/transpa_pv_swshunt_buses_complete_to_critical.png
auditoria_psse_matpower/results/runcpf_psse_pv_500kv/runcpf_psse_nose_pv_500kv_clean.png
```

## Limitaciones

- No hay referencia CPF nativa de PSS/E en el workspace. La validacion CPF usa coherencia interna `runcpf` vs `runcpf_psse`.
- La carpeta `matpower` esta dirty; los resultados actuales reflejan el codigo local actual, no necesariamente una version commiteada.
- El PDF tiene texto extraible parcial; la auditoria uso el PDF como guia de consistencia, pero la frontera final se resolvio por conectividad RAW/MATPOWER.
- Se aplicaron fixes acotados para `GENQ` y `SWDEV`; el resto del informe conserva evidencia, hipotesis y recomendaciones para decisiones posteriores.
