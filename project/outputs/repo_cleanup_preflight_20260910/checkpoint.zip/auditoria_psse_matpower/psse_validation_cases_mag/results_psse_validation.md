# PSS/E transformer magnetizing validation results

Fecha de ejecucion PSS/E: 2026-05-19.

Todos los casos cargaron y resolvieron en PSS/E sin errores fatales. Los cuatro
alcanzaron tolerancia en 2 iteraciones, con mismatch final `0.00 MW / 0.00 Mvar`
en el reporte de PSS/E.

## Resultados

| Caso | PSS/E swing PGEN | PSS/E swing QGEN | MATPOWER PG | MATPOWER QG | Resultado |
| --- | ---: | ---: | ---: | ---: | --- |
| `psse_xfmr_mag_2bus_cm1.raw` | 1.0 MW | 2.0 Mvar | 1.000000 MW | 2.000000 Mvar | OK |
| `psse_xfmr_mag_2bus_cm2.raw` | 1.0 MW | 9.9 Mvar | 1.000000 MW | 9.949874 Mvar | OK |
| `psse_xfmr_mag_3w_cm1.raw` | 1.0 MW | 2.0 Mvar | 1.000000 MW | 2.000000 Mvar | OK |
| `psse_xfmr_mag_3w_cm2.raw` | 1.0 MW | 9.9 Mvar | 1.000000 MW | 9.949874 Mvar | OK |

Nota: PSS/E imprime `QGEN` con una cifra decimal en el resumen de swing, por eso
los casos `CM=2` aparecen como `9.9 Mvar`. El equivalente calculado y el resultado
MATPOWER son `sqrt(0.1^2 - 0.01^2) * 100 = 9.949874 Mvar`.

## Evidencia PSS/E

- `psse_xfmr_mag_2bus_cm1.log`: `Reached tolerance in 2 iterations`, swing bus
  `PGEN = 1.0`, `QGEN = 2.0`.
- `psse_xfmr_mag_2bus_cm2.log`: `Reached tolerance in 2 iterations`, swing bus
  `PGEN = 1.0`, `QGEN = 9.9`.
- `psse_xfmr_mag_3w_cm1.log`: `Reached tolerance in 2 iterations`, swing bus
  `PGEN = 1.0`, `QGEN = 2.0`.
- `psse_xfmr_mag_3w_cm2.log`: `Reached tolerance in 2 iterations`, swing bus
  `PGEN = 1.0`, `QGEN = 9.9`.

## Decision de modelado

La magnetizacion del transformador se modela como una admitancia shunt en la barra
`I` del devanado 1:

- `CM=1`: `MAG1` y `MAG2` son `G` y `B` en pu sobre base MVA del sistema.
- `CM=2`: `MAG1` es perdida en vacio en W y `MAG2` es corriente de excitacion en
  pu sobre `SBASE1-2` y `NOMV1`; se convierte a `G/B` en pu sobre base del sistema.

La implementacion actual suma esta admitancia a `bus(:, GS)` y `bus(:, BS)` durante
`psse2mpc`, por lo que no requiere logica iterativa ni cambios en `runpf_psse`.

