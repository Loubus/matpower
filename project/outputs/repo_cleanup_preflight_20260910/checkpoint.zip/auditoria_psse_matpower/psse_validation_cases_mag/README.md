# PSS/E transformer magnetizing validation cases

These RAW files isolate PSS/E transformer `MAG1/MAG2` modeling. In all cases the
magnetizing branch is on winding 1 bus `I`, matching `DataFormats.pdf`.

Run each case in PSS/E with full Newton and compare the swing bus `PGEN/QGEN`
against the equivalent shunt contribution at bus 1.

The solved PSS/E outputs are recorded in `results_psse_validation.md`.

| RAW | Purpose | Expected equivalent at bus 1 |
| --- | --- | --- |
| `psse_xfmr_mag_2bus_cm1.raw` | Two-winding, `CM=1`, direct pu admittance | `GS = 1.000 MW`, `BS = -2.000 Mvar` |
| `psse_xfmr_mag_2bus_cm2.raw` | Two-winding, `CM=2`, watts/exciting-current conversion | `GS = 1.000 MW`, `BS = -9.949874 Mvar` |
| `psse_xfmr_mag_3w_cm1.raw` | Three-winding, `CM=1`, direct pu admittance | `GS = 1.000 MW`, `BS = -2.000 Mvar` |
| `psse_xfmr_mag_3w_cm2.raw` | Three-winding, `CM=2`, watts/exciting-current conversion | `GS = 1.000 MW`, `BS = -9.949874 Mvar` |

For `CM=2`, these files use `MAG1 = 1000000 W`, `MAG2 = 0.1 pu`,
`SBASE1-2 = 100 MVA`, and `NOMV1` equal to bus 1 base kV. Therefore:

```text
G = 1 MW
B = -sqrt(0.1^2 - (1/100)^2) * 100 Mvar = -9.949874 Mvar
```
