function comparison = psse_diag_compare_runs(runs, outdir, opts) %#ok<INUSD>
%PSSE_DIAG_COMPARE_RUNS Write simple multi-run comparison artifacts.

outdir = char(outdir);
compare_dir = fullfile(outdir, 'comparison');
if exist(compare_dir, 'dir') ~= 7
    mkdir(compare_dir);
end

n = numel(runs);
run_id = strings(n, 1);
label = strings(n, 1);
max_lambda = NaN(n, 1);
success = NaN(n, 1);
events = NaN(n, 1);
warnings = NaN(n, 1);
gen_final_violations = NaN(n, 1);
redispatch_total_mw = NaN(n, 1);
for k = 1:n
    run_id(k) = runs(k).run_id;
    label(k) = runs(k).label;
    max_lambda(k) = runs(k).run_manifest.max_lambda;
    success(k) = runs(k).run_manifest.success;
    events(k) = runs(k).run_manifest.event_count;
    warnings(k) = runs(k).run_manifest.warning_count;
    final = runs(k).capability_audit;
    if istable(final) && width(final) > 0 && any(strcmp(final.Properties.VariableNames, 'source'))
        gen_final_violations(k) = nnz(final.source == "final" & final.sat);
    end
    rt = runs(k).redispatch_trace;
    if istable(rt) && width(rt) > 0
        redispatch_total_mw(k) = sum(rt.delta_pg, 'omitnan');
    end
end
summary = table(run_id, label, success, max_lambda, events, warnings, ...
    gen_final_violations, redispatch_total_mw);
writetable(summary, fullfile(compare_dir, 'run_comparison.csv'));
plot_files = strings(0, 1);
plot_files(end+1, 1) = plot_run_comparison(summary, compare_dir);
plot_files(end+1, 1) = plot_min_voltage_comparison(runs, compare_dir);
plot_files = plot_files(strlength(plot_files) > 0);

comparison = struct('outdir', string(compare_dir), ...
    'summary_file', string(fullfile(compare_dir, 'run_comparison.csv')), ...
    'plot_files', plot_files, 'summary', summary);
end

function file = plot_run_comparison(summary, compare_dir)
fig = figure('Visible', 'off', 'Color', 'w', 'Position', [50 50 1200 650]);
bar(summary.max_lambda);
grid on;
xticks(1:height(summary));
xticklabels(cellstr(summary.label));
xtickangle(25);
ylabel('max lambda');
title('CPF max lambda by run', 'Interpreter', 'none');
file = fullfile(compare_dir, 'max_lambda_comparison.png');
print(fig, file, '-dpng', '-r150');
close(fig);
file = string(file);
end

function file = plot_min_voltage_comparison(runs, compare_dir)
file = "";
fig = figure('Visible', 'off', 'Color', 'w', 'Position', [50 50 1250 720]);
ax = axes(fig);
hold(ax, 'on');
labels = strings(0, 1);
for k = 1:numel(runs)
    T = runs(k).bus_trace;
    if ~istable(T) || height(T) == 0
        continue;
    end
    if any(strcmp(T.Properties.VariableNames, 'physical'))
        T = T(logical(T.physical), :);
    end
    if height(T) == 0
        continue;
    end
    pts = unique(T.point_index);
    lam = NaN(numel(pts), 1);
    min_vm = NaN(numel(pts), 1);
    for p = 1:numel(pts)
        Tk = T(T.point_index == pts(p), :);
        lam(p) = Tk.lambda(1);
        min_vm(p) = min(Tk.VM, [], 'omitnan');
    end
    plot(ax, lam, min_vm, 'LineWidth', 1.3);
    labels(end+1, 1) = runs(k).label; %#ok<AGROW>
end
if isempty(labels)
    close(fig);
    return;
end
grid(ax, 'on');
xlabel(ax, '\lambda');
ylabel(ax, 'Minimum physical-bus voltage [pu]');
title(ax, 'Minimum voltage comparison', 'Interpreter', 'none');
legend(ax, cellstr(labels), 'Interpreter', 'none', 'Location', 'best');
file = fullfile(compare_dir, 'pv_min_voltage_comparison.png');
print(fig, file, '-dpng', '-r150');
close(fig);
file = string(file);
end
