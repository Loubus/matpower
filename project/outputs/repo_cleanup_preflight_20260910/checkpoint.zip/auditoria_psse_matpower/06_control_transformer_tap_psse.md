# Issue 2 - CONTROL PSS/E DE TRANSFORMADORES REGULANTES / ULTC

Fecha de trabajo: 2026-05-19.

Alcance: solo `PSSE/V26p_Trs_2532.raw`, seccion `TRANSFORMER DATA` y registros `SYSTEM-WIDE` que gobiernan ajuste de taps AC.

Objetivo: preservar la metadata PSS/E de transformadores Rev34 y agregar a `runpf_psse` un control opt-in de taps regulantes compatible con la arquitectura MP-Core ya usada para switched shunts.

## 1. Punto de partida

El issue anterior dejo implementado y validado el control PSS/E de switched shunts en:

- `matpower/lib/runpf_psse.m`
- `matpower/lib/+mp/xt_psse.m`
- `matpower/lib/+mp/task_pf_psse.m`
- `matpower/lib/+mp/psse_swshunt_*`

La regla de arquitectura se mantiene:

- `runpf` estandar no cambia.
- `makeYbus`, `makeSbus` y `runpf` no reciben logica PSS/E.
- `runpf_psse` es la entrada opt-in.
- `mp.task_pf_psse.next_dm` coordina controles iterativos, pero la logica de cada control vive en helpers separados.

## 2. Evidencia RAW

Conteos recalculados desde `PSSE/V26p_Trs_2532.raw` despues de corregir el layout Rev34 de winding records:

| Metrica | Valor |
|---|---:|
| Transformadores totales | 2491 |
| Dos devanados | 1743 |
| Tres devanados | 748 |
| Filas de control por devanado preservadas | 3987 |
| Filas activas por rama/devanado | 3657 |
| Filas inactivas por rama/devanado | 330 |

Distribucion de `COD`:

| Conjunto | `COD=-1` | `COD=0` | `COD=1` | Otros |
|---|---:|---:|---:|---:|
| Todas las filas de control | 282 | 2842 | 863 | 0 |
| Filas activas | 268 | 2560 | 829 | 0 |

Diagnostico de las filas activas con `COD=1`:

| Metrica | Valor |
|---|---:|
| `CONT=0` | 319 |
| `CONT>0` igual al bus del devanado | 54 |
| `CONT>0` apuntando a otro bus | 448 |
| `CONT<0` | 8 |
| `TAB != 0` | 12 |
| `CR/CX != 0` | 0 |

El RAW guarda:

```text
SOLVER, FNSL, ACTAPS=0, AREAIN=0, PHSHFT=0, DCTAPS=1, SWSHNT=2, FLATST=0, VARLIM=0, NONDIV=0
```

Decision aplicada: `ACTAPS=0` deshabilita el movimiento automatico de taps AC en el RAW grande. Por eso `runpf_psse` debe reportar candidatos y estado, pero no debe cambiar taps para este archivo tal como esta guardado.

Si se fuerza `ACTAPS=1` solo como diagnostico, quedan 510 controles implementables con el alcance actual despues de agregar `TAB`. Quedan fuera:

- 319 filas con `CONT=0`.

## 3. Evidencia documental PSS/E

Fuentes locales revisadas:

- `PSSE/DataFormats.pdf`, seccion `Transformer Data`.
- `PSSE/DataFormats.pdf`, secciones `SYSTEM-WIDE`, `SOLVER`, `ADJUST`, `NEWTON`.
- `PSSE/PAGV1.pdf`, apartados de power-flow solution, voltage control y automatically adjusted transformer taps.

Reglas implementables para el RAW:

- `COD=1` identifica control automatico de tap para tension.
- `COD=-1` representa ajuste automatico suprimido; se preserva y reporta, pero no se mueve.
- `COD=0` queda fijo.
- `CONT` identifica el bus regulado; `CONT=0` no se toma como control automatico activo en esta implementacion.
- Para transformadores de dos devanados, la validacion PSS/E distingue entre
  bus terminal opuesto y bus remoto no terminal. En los casos medidos, el bus
  terminal opuesto baja el tap tanto con `CONT=-2` como con `CONT=+2` para
  subir la tension de ese terminal, mientras que el bus remoto no terminal usa
  el signo contrario (`CONT=-3` sube el tap y `CONT=+3` lo baja).
- `RMA/RMI` definen los limites del tap regulante.
- `VMA/VMI` definen la banda de tension del bus regulado.
- `NTP` define la cantidad de posiciones discretas; el paso se calcula como `(RMA - RMI)/(NTP - 1)`.
- `TAB` referencia una impedance correction table. La tabla multiplica la impedancia nominal por un factor complejo interpolado segun tap o angulo.
- Si la tabla tiene un unico punto util, se aplica como factor constante. Si tiene mas de un punto, se interpola linealmente.
- En transformadores de tres devanados, `ZCOD=0` aplica la correccion sobre las impedancias de los brazos equivalentes del modelo en estrella. Este es el unico modo presente en el RAW de referencia para los 12 trafos con `TAB`.
- `ZCOD=1` no aparece en los trafos con `TAB` de este RAW; queda como modo preservado/no aplicado para no corregir sobre la representacion equivocada.
- `CR/CX` son compensacion de caida de carga; en este RAW son cero para `COD=1` activo, por lo que el control se implementa contra `|V_CONT|` sin compensacion.
- `ACTAPS` en `SOLVER` gobierna globalmente el ajuste de taps AC.
- `MXTPSS` en `ADJUST` limita los ciclos de ajuste.
- `VCTOLV` en `NEWTON` se usa como tolerancia de banda.

Modos no presentes en el RAW y por lo tanto no implementados en este issue:

- `COD=2`, `COD=3`, `COD=4`, `COD=5`.
- Control por potencia/reactiva/flujo.
- Compensacion `CR/CX` no nula.
- `ZCOD=1` para tablas aplicadas a impedancias bus-bus de transformadores de tres devanados.

## 4. Evidencia MATPOWER

Fuentes locales revisadas:

- `Matpower Manuals/MATPOWER-manual-8.1.pdf`: formato de caso, matriz `branch`, columna `TAP`, modelo de transformador.
- `Matpower Manuals/matpower_dev_manual.pdf`: MP-Core, task object, data model, extensiones y `next_dm`.
- `matpower/lib/runpf.m`, `runpf_psse.m`, `makeYbus.m`, `psse_parse.m`, `psse_convert.m`, `psse_convert_xfmr.m`.
- Clases bajo `matpower/lib/+mp`.

Punto tecnico:

- MATPOWER representa transformadores como filas de `mpc.branch`; el tap off-nominal esta en `branch(:, TAP)`.
- `psse_convert_xfmr` convierte 3W a tres ramas contra bus estrella.
- Para que un cambio sobreviva el rebuild MP-Core, el tap se actualiza en `dm.source.branch(:, TAP)`, no solamente en la tabla interna del data model.
- La metadata PSS/E se preserva en `mpc.psse.xfmr` con mapping desde filas RAW a filas `branch`.

## 5. Decision de diseno

Implementado en `runpf_psse`:

1. Preservar metadata Rev34 completa de transformadores en `mpc.psse.xfmr`.
2. Normalizar el winding record Rev34 completo:
   `WINDV`, `NOMV`, `ANG`, `RATE1-12`, `COD`, `CONT`, `RMA/RMI`, `VMA/VMI`, `NTP`, `TAB`, `CR/CX`, `CNXA`, `NOD`.
3. Parsear y preservar `IMPEDANCE CORRECTION DATA` en `mpc.psse.impcor`.
4. Aplicar `TAB` en la conversion inicial para que `branch(:, BR_R/BR_X)` represente la impedancia corregida al tap guardado.
5. Reaplicar el factor `TAB` durante cada update de tap en `runpf_psse`, usando siempre la impedancia nominal preservada como base.
6. Agregar helpers separados:
   - `mp.psse_xfmr_states`
   - `mp.psse_xfmr_control`
   - `mp.psse_xfmr_update`
   - `mp.psse_xfmr_report`
   - `mp.psse_xfmr_tab_factor`
7. Ejecutar control de transformadores antes de switched shunts en `mp.task_pf_psse.next_dm`.
8. Si un tap cambia, reconstruir el data model y posponer switched shunts hasta la siguiente solucion.
9. Si no cambia, continuar con switched shunts.

Comportamiento numerico:

- Solo `COD=1`, `ACTAPS!=0`, `CONT!=0`, `NTP>=2`, `CW in {1,2}`, `CR/CX=0`, y `TAB=0` o `TAB` aplicado con `ZCOD=0`.
- Se mueve un paso discreto por ciclo con la direccion de tap PSS/E validada
  para bus local opuesto y bus remoto no terminal, incluyendo `CONT=+2` y
  `CONT=+3`.
- Se respetan limites `RMI/RMA`.
- Se detectan estados repetidos y se restaura el mejor estado visitado si aparece un ciclo.
- `COD=-1`, `COD=0`, `CONT=0`, `ZCOD=1` y modos no soportados quedan reportados.

## 6. Implementacion

Archivos MATPOWER tocados:

- `matpower/lib/psse_parse.m`
  - parsea y normaliza winding records Rev34 completos.
  - parsea `IMPEDANCE CORRECTION DATA`.
- `matpower/lib/psse_convert_xfmr.m`
  - devuelve mapping de filas RAW a ramas MATPOWER.
  - usa indices dinamicos para layout Rev34 completo y layout compacto historico.
  - aplica `TAB` para `ZCOD=0` y preserva la impedancia nominal.
- `matpower/lib/psse_convert.m`
  - preserva `mpc.psse.xfmr` y `mpc.psse.impcor`.
- `matpower/lib/runpf_psse.m`
  - documenta que la entrada opt-in cubre taps de transformador y switched shunts.
- `matpower/lib/+mp/task_pf_psse.m`
  - coordina primero ULTC y luego switched shunts.
- `matpower/lib/+mp/psse_xfmr_states.m`
- `matpower/lib/+mp/psse_xfmr_control.m`
- `matpower/lib/+mp/psse_xfmr_update.m`
- `matpower/lib/+mp/psse_xfmr_report.m`
- `matpower/lib/+mp/psse_xfmr_tab_factor.m`
- `matpower/lib/t/t_mpxt_psse.m`
- `matpower/lib/t/t_psse.m`
- `matpower/lib/t/t_psse_case3.m`
- `matpower/lib/t/t_psse_case4.raw`

## 7. Validacion

Tests MATPOWER ejecutados:

```text
t_mpxt_psse(0)
All tests successful (48 of 48)

t_psse(0)
All tests successful (175 of 175)
```

Code Analyzer sobre archivos nuevos:

```text
mp.psse_xfmr_states  : sin issues
mp.psse_xfmr_control : sin issues
mp.psse_xfmr_update  : sin issues
mp.psse_xfmr_report  : sin issues
mp.psse_xfmr_tab_factor : sin issues
```

RAW grande:

```text
RAW V26p_Trs_2532 runpf success=1 runpf_psse success=1
runpf vs RAW: max|dVM|=0.203490 pu rms dVM=0.017994 max|dVA|=6.431959 deg rms dVA=0.755465
runpf_psse vs RAW: max|dVM|=0.265253 pu rms dVM=0.015440 max|dVA|=11.384263 deg rms dVA=0.482533
runpf_psse vs runpf: max|dVM|=0.078477 pu max|dVA|=4.952304 deg
tap delta count=0 max|dTAP|=0
R delta count=0 max|dR|=0
X delta count=0 max|dX|=0
xfmr report: enabled=0 actaps=0 iterations=0 adjustments=0 changed=0 controllable=0 cod1=863 cod_m1=282 cod0=2842 suppressed=268 cont_missing=319 unsupported_tab=0 tab_corrected=36 lower=0 upper=0
TAB: 12 impedance correction tables, 36 devanados con factor aplicado, `ZCOD=0`, factor real unico `1`, factor imaginario unico `0`
```

Interpretacion:

- Con el RAW tal como esta guardado, `ACTAPS=0`; por eso no hay cambios de tap.
- El cambio de `VM/VA` entre `runpf` y `runpf_psse` sigue viniendo del control de switched shunts ya implementado.
- El nuevo control de transformadores no degrada el RAW grande bajo sus opciones guardadas.
- El reporte ULTC/TAB deja trazabilidad completa para saber que se reconocio, que se aplico y que quedo bloqueado.

## 8. Casos chicos

Los tests nuevos en `t_mpxt_psse(0)` cubren:

- `COD=1` con control de tension y `ACTAPS=1`.
- Actualizacion de `branch(:, TAP)`.
- Actualizacion de `mpc.psse.xfmr.two.num(:, WINDV1)`.
- Control remoto con `CONT<0` no terminal:
  - caso principal en banda con tap final `1.05`;
  - caso `_limit` conservado para la corrida PSS/E externa con limite alto
    `1.10HI`.
- Control remoto con `CONT>0` no terminal:
  - caso `CONT=+3` validado contra PSS/E con tap final `0.95`.
- Control terminal con `CONT>0`:
  - caso `CONT=+2` validado contra PSS/E con tap final `0.95`.
- Gate global `ACTAPS=0`.
- `COD=-1` suprimido.
- Limite inferior de tap alcanzado y reportado.
- `TAB` no unitario en caso de 2 buses: el cambio de tap actualiza tambien `branch(:, BR_R/BR_X)`.

La carpeta local `psse_validation_cases_ultc` documenta estos casos para una futura validacion manual en PSS/E.

## 9. Riesgos y limitaciones

- No hay salida PSS/E local final de taps para comparar identidad numerica en casos grandes.
- Los casos chicos con control local, `ACTAPS=0`, remoto en banda, remoto
  `_limit`, TAB 2W y TAB 3W ya tienen comparacion PSS/E externa para el
  criterio principal.
- Se agregaron casos chicos 3W sin `TAB` para W2 y W3. Su objetivo es aislar
  la actualizacion de cada rama del equivalente estrella. W2 y W3 coinciden
  con PSS/E.
- El caso chico `CW=2 + TAB` en 3W coincide con PSS/E.
- Los casos dirigidos `CONT>0` terminal y remoto ya fueron medidos con PSS/E y
  quedaron incorporados a los tests.
- `TAB` queda implementado para el modo presente en el RAW (`ZCOD=0`). `ZCOD=1` no aparece en el RAW de referencia y queda sin aplicar.
- Las 12 tablas reales del RAW son identidad en el punto guardado (`1 + j0`), por lo que no cambian numericamente `R/X`; la cobertura no unitaria queda en test chico.
- En los RAW chicos de TAB se usa tabla `1`; PSS/E rechazo tabla `7` como
  numero invalido para el tamano base del caso.
- En todos los RAW chicos se ajusto `ZX=1.0` en el registro de generador para
  evitar el warning PSS/E de `Invalid ZSORCE reactance`; ese campo no cambia la
  validacion MATPOWER de flujo AC.
- `CR/CX` no nulo no esta implementado; en este RAW no aparece para `COD=1` activo.
- `COD` distintos de `-1`, `0`, `1` no aparecen en el RAW y no se implementan.
- `CONT=0` queda diagnosticado como no controlable.
- El control se implementa en pasos discretos; no intenta emular posibles heuristicas internas de PSS/E mas alla de las reglas documentadas y observables.

## 10. Issue posterior relacionado

El siguiente issue natural dentro de transformadores era `MAG1/MAG2` /
magnetizacion. Quedo implementado y validado posteriormente en
`07_transformer_magnetizing_psse.md`.
