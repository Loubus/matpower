function summary = run_psse_baseline_validation()
%RUN_PSSE_BASELINE_VALIDATION Build a reproducible PSS/E-vs-MATPOWER baseline.
%   Runs psse2mpc(raw, 0, 34), runpf(), and runpf_psse() for the current
%   reverse-engineering fixtures, then writes a Markdown report and a MAT file
%   under auditoria_psse_matpower/results/.

audit_dir = fileparts(mfilename('fullpath'));
root_dir = fileparts(audit_dir);
mp_dir = fullfile(root_dir, 'matpower');
mp_lib = fullfile(mp_dir, 'lib');
results_dir = fullfile(audit_dir, 'results');
if ~exist(results_dir, 'dir')
    mkdir(results_dir);
end
addpath(mp_lib);

cases = default_cases(root_dir);
mpopt = mpoption('verbose', 0, 'out.all', 0);

summary = struct();
summary.generated_at = datestr(now, 'yyyy-mm-dd HH:MM:SS');
summary.root_dir = root_dir;
summary.matpower_dir = mp_dir;
summary.commands = { ...
    'psse2mpc(raw, 0, 34)', ...
    'runpf(mpc, mpopt)', ...
    'runpf_psse(mpc, mpopt)'};
summary.doc_sources = { ...
    fullfile(root_dir, 'PSSE', 'DataFormats.pdf'), ...
    fullfile(root_dir, 'PSSE', 'PAGV1.pdf'), ...
    fullfile(audit_dir, '01_diagnostico_actual.md'), ...
    fullfile(audit_dir, '05_control_switched_shunt_psse.md'), ...
    fullfile(audit_dir, '08_facts_device_psse.md'), ...
    fullfile(audit_dir, '09_two_terminal_dc_psse.md')};

summary.cases = repmat(empty_case_result(), 1, numel(cases));
for k = 1:numel(cases)
    fprintf('Running baseline case %d/%d: %s\n', k, numel(cases), cases(k).name);
    summary.cases(k) = run_one_case(cases(k), mpopt);
end

stamp = datestr(now, 'yyyymmdd_HHMMSS');
md_path = fullfile(results_dir, ['psse_baseline_validation_' stamp '.md']);
mat_path = fullfile(results_dir, ['psse_baseline_validation_' stamp '.mat']);
latest_md = fullfile(results_dir, 'psse_baseline_validation_latest.md');

write_report(summary, md_path);
copyfile(md_path, latest_md);
save(mat_path, 'summary');

summary.report_path = md_path;
summary.latest_report_path = latest_md;
summary.mat_path = mat_path;

fprintf('Wrote report: %s\n', md_path);
fprintf('Wrote latest report copy: %s\n', latest_md);
fprintf('Wrote MAT data: %s\n', mat_path);

function cases = default_cases(root_dir)
best_dir = fullfile(root_dir, 'auditoria_psse_matpower', ...
    'psse_validation_cases_best_raw');
cases = struct( ...
    'name', {}, 'raw', {}, 'psse_log', {}, 'psse_solved_raw', {}, ...
    'role', {});
cases(end+1) = struct( ...
    'name', 'psse_integrated_controls_14bus', ...
    'raw', fullfile(best_dir, 'psse_integrated_controls_14bus.raw'), ...
    'psse_log', fullfile(best_dir, 'logs', 'psse_integrated_controls_14bus.log'), ...
    'psse_solved_raw', fullfile(best_dir, 'solved_raw', ...
        'psse_integrated_controls_14bus_solved.raw'), ...
    'role', 'compact integrated smoke fixture');
cases(end+1) = struct( ...
    'name', 'psse_integrated_controls_30bus_moderate', ...
    'raw', fullfile(best_dir, 'psse_integrated_controls_30bus_moderate.raw'), ...
    'psse_log', fullfile(best_dir, 'logs', ...
        'psse_integrated_controls_30bus_moderate.log'), ...
    'psse_solved_raw', fullfile(best_dir, 'solved_raw', ...
        'psse_integrated_controls_30bus_moderate_solved.raw'), ...
    'role', 'main moderate integrated fixture');
cases(end+1) = struct( ...
    'name', 'V26p_Trs_2532', ...
    'raw', fullfile(root_dir, 'PSSE', 'V26p_Trs_2532.raw'), ...
    'psse_log', '', ...
    'psse_solved_raw', '', ...
    'role', 'large stress RAW; reference values come from embedded RAW state');

function out = empty_case_result()
out = struct( ...
    'name', '', 'role', '', 'raw', '', 'psse_log', '', ...
    'psse_reference_raw', '', 'reference_source', '', ...
    'parse_ok', false, 'parse_error', '', 'warnings', {{}}, ...
    'warning_count', 0, 'parse_output_tail', {{}}, 'counts', struct(), ...
    'reference', struct(), 'runpf', struct(), 'runpf_psse', struct(), ...
    'comparison', struct(), 'setpoint_conflicts', {{}});

function result = run_one_case(tc, mpopt)
result = empty_case_result();
result.name = tc.name;
result.role = tc.role;
result.raw = tc.raw;
result.psse_log = tc.psse_log;

if exist(tc.psse_solved_raw, 'file')
    result.psse_reference_raw = tc.psse_solved_raw;
    result.reference_source = 'PSS/E solved RAW export plus log';
else
    result.psse_reference_raw = tc.raw;
    result.reference_source = 'original RAW embedded state; no PSS/E log/export found';
end

result.reference = parse_psse_reference(result.psse_reference_raw, tc.psse_log);
result.setpoint_conflicts = detect_setpoint_conflicts(result.reference);

try
    [parse_text, mpc, warns] = capture_psse2mpc(tc.raw);
    result.parse_ok = true;
    result.warnings = warns(:)';
    result.warning_count = numel(warns);
    result.counts = count_case_elements(mpc);
    result.parse_output_tail = tail_text(parse_text, 12);
catch err
    result.parse_ok = false;
    result.parse_error = getReport(err, 'basic', 'hyperlinks', 'off');
    return;
end

[result.runpf, r0] = run_solver('runpf', mpc, mpopt);
[result.runpf_psse, r1] = run_solver('runpf_psse', mpc, mpopt);

result.comparison = compare_against_reference(result.reference, r0, r1);

function [txt, mpc, warns] = capture_psse2mpc(raw)
mpc = [];
warns = {};
txt = evalc('[mpc, warns] = psse2mpc(raw, 0, 34);');
if isempty(warns)
    warns = {};
end

function [info, r] = run_solver(kind, mpc, mpopt)
info = empty_solver_result();
r = [];
success = 0;
try
    switch kind
        case 'runpf'
            txt = evalc('[r, success] = runpf(mpc, mpopt);');
        case 'runpf_psse'
            txt = evalc('[r, success] = runpf_psse(mpc, mpopt);');
        otherwise
            error('unknown solver kind');
    end
    info.ok = true;
    info.success = logical(success);
    info.output_tail = tail_text(txt, 12);
    info = summarize_result(info, r);
catch err
    info.ok = false;
    info.success = false;
    info.error = getReport(err, 'basic', 'hyperlinks', 'off');
end

function info = empty_solver_result()
info = struct( ...
    'ok', false, 'success', false, 'error', '', 'iterations', NaN, ...
    'data_model_iterations', NaN, 'network_model_iterations', NaN, ...
    'math_model_iterations', NaN, 'vm_min', NaN, 'vm_min_bus', NaN, 'vm_max', NaN, ...
    'vm_max_bus', NaN, 'outside_095_110_count', NaN, ...
    'outside_095_110', {{}}, 'control_iterations', struct(), ...
    'output_tail', {{}});

function info = summarize_result(info, r)
[~, ~, ~, ~, ~, ~, ~, ~, ~, ~, ~, VM] = idx_bus;
if isfield(r, 'iterations')
    info.iterations = r.iterations;
end
if isfield(r, 'task') && isobject(r.task)
    if isprop(r.task, 'i_dm'), info.data_model_iterations = r.task.i_dm; end
    if isprop(r.task, 'i_nm'), info.network_model_iterations = r.task.i_nm; end
    if isprop(r.task, 'i_mm'), info.math_model_iterations = r.task.i_mm; end
end
if isfield(r, 'bus') && ~isempty(r.bus)
    [mn, i_mn] = min(r.bus(:, VM));
    [mx, i_mx] = max(r.bus(:, VM));
    info.vm_min = mn;
    info.vm_min_bus = r.bus(i_mn, 1);
    info.vm_max = mx;
    info.vm_max_bus = r.bus(i_mx, 1);
    outside = find(r.bus(:, VM) < 0.95 | r.bus(:, VM) > 1.10);
    info.outside_095_110_count = numel(outside);
    info.outside_095_110 = bus_vm_rows(r.bus, outside);
end
info.control_iterations = summarize_controls(r);

function rows = bus_vm_rows(bus, idx)
[~, ~, ~, ~, ~, ~, ~, ~, ~, ~, ~, VM, VA, BASE_KV] = idx_bus;
rows = cell(numel(idx), 1);
for k = 1:numel(idx)
    ii = idx(k);
    rows{k} = sprintf('bus %.0f: VM %.5f pu, VA %.3f deg, BASKV %.3f', ...
        bus(ii, 1), bus(ii, VM), bus(ii, VA), bus(ii, BASE_KV));
end

function c = summarize_controls(r)
c = struct();
c.genq = control_iter(r, 'genq');
c.xfmr = control_iter(r, 'xfmr');
c.twodc = control_iter(r, 'twodc');
c.swshunt = control_iter(r, 'swshunt');
c.facts = control_iter(r, 'facts');
c.pqbrak = control_iter(r, 'pqbrak');

function s = control_iter(r, family)
s = struct('present', false, 'iterations', NaN, 'num_adjustments', NaN, ...
    'max_iter_reached', NaN);
if isfield(r, 'psse') && isfield(r.psse, family)
    fam = r.psse.(family);
    if isfield(fam, 'control')
        ctrl = fam.control;
    else
        ctrl = fam;
    end
    s.present = true;
    if isfield(ctrl, 'iterations'), s.iterations = ctrl.iterations; end
    if isfield(ctrl, 'num_adjustments'), s.num_adjustments = ctrl.num_adjustments; end
    if isfield(ctrl, 'max_iter_reached'), s.max_iter_reached = ctrl.max_iter_reached; end
end

function counts = count_case_elements(mpc)
counts = struct();
counts.buses = size_or_zero(mpc, 'bus');
counts.gens = size_or_zero(mpc, 'gen');
counts.loads = psse_count(mpc, 'load');
counts.matpower_branches = size_or_zero(mpc, 'branch');
counts.raw_branches = psse_count(mpc, 'branch');
counts.xfmr_two = 0;
counts.xfmr_three = 0;
if isfield(mpc, 'psse') && isfield(mpc.psse, 'xfmr')
    if isfield(mpc.psse.xfmr, 'two') && isfield(mpc.psse.xfmr.two, 'num')
        counts.xfmr_two = size(mpc.psse.xfmr.two.num, 1);
    end
    if isfield(mpc.psse.xfmr, 'three') && isfield(mpc.psse.xfmr.three, 'num')
        counts.xfmr_three = size(mpc.psse.xfmr.three.num, 1);
    end
end
counts.xfmr = counts.xfmr_two + counts.xfmr_three;
counts.swshunt = psse_count(mpc, 'swshunt');
counts.facts = psse_count(mpc, 'facts');
counts.twodc = psse_count(mpc, 'twodc');
counts.swdev = psse_count(mpc, 'swdev');

function n = size_or_zero(s, field)
if isfield(s, field)
    n = size(s.(field), 1);
else
    n = 0;
end

function n = psse_count(mpc, field)
n = 0;
if isfield(mpc, 'psse') && isfield(mpc.psse, field) && ...
        isfield(mpc.psse.(field), 'num')
    n = size(mpc.psse.(field).num, 1);
end

function ref = parse_psse_reference(raw_path, log_path)
ref = struct();
ref.raw_path = raw_path;
ref.log_path = log_path;
ref.has_log = exist(log_path, 'file') == 2;
ref.bus = [];
ref.gen = [];
ref.swshunt = [];
ref.facts = [];
ref.twodc = [];
ref.xfmr = [];
ref.log = struct();
if exist(raw_path, 'file') ~= 2
    ref.error = ['missing reference file: ' raw_path];
    return;
end
lines = read_lines(raw_path);
ref.bus = parse_bus_section(lines);
ref.gen = parse_generator_section(lines);
ref.swshunt = parse_swshunt_section(lines);
ref.facts = parse_facts_section(lines);
ref.twodc = parse_twodc_section(lines);
ref.xfmr = parse_xfmr_section(lines);
if ref.has_log
    ref.log = parse_psse_log(log_path);
else
    ref.log = struct();
end

function lines = read_lines(path)
txt = fileread(path);
txt = strrep(txt, sprintf('\r\n'), sprintf('\n'));
txt = strrep(txt, sprintf('\r'), sprintf('\n'));
lines = regexp(txt, sprintf('\n'), 'split')';

function section = section_lines(lines, name)
section = {};
target = ['BEGIN ' upper(name) ' DATA'];
start_idx = 0;
for k = 1:numel(lines)
    if contains(upper(lines{k}), target)
        start_idx = k + 1;
        break;
    end
end
if start_idx == 0
    return;
end
for k = start_idx:numel(lines)
    ln = strtrim(lines{k});
    if startsWith(ln, '0 / END')
        break;
    end
    if isempty(ln) || startsWith(ln, '@!')
        continue;
    end
    section{end+1, 1} = lines{k}; %#ok<AGROW>
end

function rows = parse_bus_section(lines)
sec = section_lines(lines, 'BUS');
rows = struct('bus', {}, 'name', {}, 'basekv', {}, 'type', {}, 'vm', {}, 'va', {});
for k = 1:numel(sec)
    t = csv_tokens(sec{k});
    if numel(t) < 9, continue; end
    rows(end+1) = struct( ... %#ok<AGROW>
        'bus', num_token(t, 1), ...
        'name', clean_token(t{2}), ...
        'basekv', num_token(t, 3), ...
        'type', num_token(t, 4), ...
        'vm', num_token(t, 8), ...
        'va', num_token(t, 9));
end

function rows = parse_generator_section(lines)
sec = section_lines(lines, 'GENERATOR');
rows = struct('bus', {}, 'id', {}, 'pg', {}, 'qg', {}, 'qmax', {}, ...
    'qmin', {}, 'vs', {}, 'ireg', {}, 'status', {});
for k = 1:numel(sec)
    t = csv_tokens(sec{k});
    if numel(t) < 16, continue; end
    rows(end+1) = struct( ... %#ok<AGROW>
        'bus', num_token(t, 1), ...
        'id', clean_token(t{2}), ...
        'pg', num_token(t, 3), ...
        'qg', num_token(t, 4), ...
        'qmax', num_token(t, 5), ...
        'qmin', num_token(t, 6), ...
        'vs', num_token(t, 7), ...
        'ireg', num_token(t, 8), ...
        'status', parse_generator_status(t));
end

function st = parse_generator_status(t)
st = NaN;
if numel(t) >= 16
    v16 = num_token(t, 16);
    v15 = num_token(t, 15);
    if ismember(v16, [0 1])
        st = v16;
    elseif ismember(v15, [0 1])
        st = v15;
    end
end

function rows = parse_swshunt_section(lines)
sec = section_lines(lines, 'SWITCHED SHUNT');
rows = struct('bus', {}, 'id', {}, 'modsw', {}, 'adjm', {}, 'stat', {}, ...
    'vswhi', {}, 'vswlo', {}, 'swreg', {}, 'rmpct', {}, 'binit', {}, ...
    'bmin', {}, 'bmax', {});
for k = 1:numel(sec)
    t = csv_tokens(sec{k});
    if numel(t) < 10, continue; end
    has_id = ~isempty(regexp(sec{k}, '^\s*[-+]?\d+\s*,\s*[''"]', 'once'));
    if has_id
        id = clean_token(t{2});
        modsw = num_token(t, 3); adjm = num_token(t, 4); stat = num_token(t, 5);
        vswhi = num_token(t, 6); vswlo = num_token(t, 7);
        swreg = num_token(t, 8); rmpct = num_token(t, 10); binit = num_token(t, 12);
        block_start = 14;
    else
        id = '';
        modsw = num_token(t, 2); adjm = num_token(t, 3); stat = num_token(t, 4);
        vswhi = num_token(t, 5); vswlo = num_token(t, 6);
        swreg = num_token(t, 7); rmpct = num_token(t, 8); binit = num_token(t, 10);
        block_start = 11;
    end
    [bmin, bmax] = swshunt_range(t, block_start);
    rows(end+1) = struct( ... %#ok<AGROW>
        'bus', num_token(t, 1), 'id', id, 'modsw', modsw, ...
        'adjm', adjm, 'stat', stat, 'vswhi', vswhi, 'vswlo', vswlo, ...
        'swreg', swreg, 'rmpct', rmpct, 'binit', binit, ...
        'bmin', bmin, 'bmax', bmax);
end

function [bmin, bmax] = swshunt_range(t, block_start)
vals = [];
for kk = block_start:3:numel(t)-2
    st = num_token(t, kk);
    n = num_token(t, kk+1);
    b = num_token(t, kk+2);
    if isnan(st) || isnan(n) || isnan(b) || st == 0 || n == 0
        continue;
    end
    if n > 0
        vals = [vals; (1:n)' * b]; %#ok<AGROW>
    end
end
if isempty(vals)
    bmin = NaN;
    bmax = NaN;
else
    vals = [0; vals];
    bmin = min(vals);
    bmax = max(vals);
end

function rows = parse_facts_section(lines)
sec = section_lines(lines, 'FACTS DEVICE');
rows = struct('name', {}, 'bus', {}, 'j', {}, 'mode', {}, 'vset', {}, ...
    'shmx', {}, 'rmpct', {}, 'fcreg', {});
for k = 1:numel(sec)
    t = csv_tokens(sec{k});
    if numel(t) < 20, continue; end
    rows(end+1) = struct( ... %#ok<AGROW>
        'name', clean_token(t{1}), ...
        'bus', num_token(t, 2), ...
        'j', num_token(t, 3), ...
        'mode', num_token(t, 4), ...
        'vset', num_token(t, 7), ...
        'shmx', num_token(t, 8), ...
        'rmpct', num_token(t, 15), ...
        'fcreg', num_token(t, 20));
end

function rows = parse_twodc_section(lines)
sec = section_lines(lines, 'TWO-TERMINAL DC');
rows = struct('name', {}, 'mdc', {}, 'rdc', {}, 'setvl', {}, ...
    'vschd', {}, 'vcmod', {}, 'rcomp', {}, 'meter', {}, ...
    'rect_bus', {}, 'inv_bus', {}, 'tapr', {}, 'tapi', {}, ...
    'anmnr', {}, 'anmxr', {}, 'anmni', {}, 'anmxi', {});
k = 1;
while k <= numel(sec)
    t1 = csv_tokens(sec{k});
    if numel(t1) < 9 || k + 2 > numel(sec)
        k = k + 1;
        continue;
    end
    tr = csv_tokens(sec{k+1});
    ti = csv_tokens(sec{k+2});
    if numel(tr) < 17 || numel(ti) < 17
        k = k + 3;
        continue;
    end
    rows(end+1) = struct( ... %#ok<AGROW>
        'name', clean_token(t1{1}), ...
        'mdc', num_token(t1, 2), ...
        'rdc', num_token(t1, 3), ...
        'setvl', num_token(t1, 4), ...
        'vschd', num_token(t1, 5), ...
        'vcmod', num_token(t1, 6), ...
        'rcomp', num_token(t1, 7), ...
        'meter', clean_token(t1{9}), ...
        'rect_bus', num_token(tr, 1), ...
        'inv_bus', num_token(ti, 1), ...
        'tapr', num_token(tr, 9), ...
        'tapi', num_token(ti, 9), ...
        'anmnr', num_token(tr, 4), ...
        'anmxr', num_token(tr, 3), ...
        'anmni', num_token(ti, 4), ...
        'anmxi', num_token(ti, 3));
    k = k + 3;
end

function rows = parse_xfmr_section(lines)
sec = section_lines(lines, 'TRANSFORMER');
rows = struct('i', {}, 'j', {}, 'k', {}, 'ckt', {}, 'name', {}, ...
    'stat', {}, 'windv1', {}, 'windv2', {}, 'windv3', {}, ...
    'cod1', {}, 'cont1', {}, 'vma1', {}, 'vmi1', {});
idx = 1;
while idx <= numel(sec)
    t0 = csv_tokens(sec{idx});
    if numel(t0) < 14
        idx = idx + 1;
        continue;
    end
    kbus = num_token(t0, 3);
    n_winding_lines = 2 + double(kbus ~= 0);
    if idx + 1 + n_winding_lines > numel(sec)
        break;
    end
    w1 = csv_tokens(sec{idx+2});
    w2 = csv_tokens(sec{idx+3});
    w3 = {};
    if kbus ~= 0
        w3 = csv_tokens(sec{idx+4});
    end
    rows(end+1) = struct( ... %#ok<AGROW>
        'i', num_token(t0, 1), ...
        'j', num_token(t0, 2), ...
        'k', kbus, ...
        'ckt', clean_token(t0{4}), ...
        'name', clean_token(t0{12}), ...
        'stat', num_token(t0, 13), ...
        'windv1', safe_num_token(w1, 1), ...
        'windv2', safe_num_token(w2, 1), ...
        'windv3', safe_num_token(w3, 1), ...
        'cod1', safe_num_token(w1, 16), ...
        'cont1', safe_num_token(w1, 17), ...
        'vma1', safe_num_token(w1, 20), ...
        'vmi1', safe_num_token(w1, 21));
    idx = idx + 2 + n_winding_lines;
end

function log = parse_psse_log(log_path)
log = struct();
log.path = log_path;
log.converged_iterations = NaN;
log.total_mismatch_mva = NaN;
log.max_mismatch_mva = NaN;
log.max_mismatch_bus = NaN;
log.high_voltage = NaN;
log.high_voltage_bus = NaN;
log.low_voltage = NaN;
log.low_voltage_bus = NaN;
log.facts_flow = [];
log.twodc = [];
if exist(log_path, 'file') ~= 2
    return;
end
lines = read_lines(log_path);
for k = 1:numel(lines)
    ln = lines{k};
    m = regexp(ln, 'Reached tolerance in\s+(\d+)\s+iterations', 'tokens', 'once');
    if ~isempty(m), log.converged_iterations = str2double(m{1}); end
    m = regexp(ln, 'System total absolute mismatch:\s+([-0-9.]+)\s+MVA', 'tokens', 'once');
    if ~isempty(m), log.total_mismatch_mva = str2double(m{1}); end
    m = regexp(ln, 'Largest mismatch:\s+([-0-9.]+)\s+MW\s+([-0-9.]+)\s+Mvar\s+([-0-9.]+)\s+MVA at bus\s+(\d+)', 'tokens', 'once');
    if ~isempty(m)
        log.max_mismatch_mva = str2double(m{3});
        log.max_mismatch_bus = str2double(m{4});
    end
    m = regexp(ln, 'TOTAL MISMATCH =\s+([-0-9.]+)\s+MVA', 'tokens', 'once');
    if ~isempty(m), log.total_mismatch_mva = str2double(m{1}); end
    m = regexp(ln, 'MAX\.\s+MISMATCH =\s+([-0-9.]+)\s+MVA\s+(\d+)', 'tokens', 'once');
    if ~isempty(m)
        log.max_mismatch_mva = str2double(m{1});
        log.max_mismatch_bus = str2double(m{2});
    end
    m = regexp(ln, 'HIGH VOLTAGE =\s+([-0-9.]+)\s+PU\s+(\d+)', 'tokens', 'once');
    if ~isempty(m)
        log.high_voltage = str2double(m{1});
        log.high_voltage_bus = str2double(m{2});
    end
    m = regexp(ln, 'LOW\s+VOLTAGE =\s+([-0-9.]+)\s+PU\s+(\d+)', 'tokens', 'once');
    if ~isempty(m)
        log.low_voltage = str2double(m{1});
        log.low_voltage_bus = str2double(m{2});
    end
    m = regexp(ln, 'TO STATCON SHUNT\s+STA\s+([-0-9.]+)\s+([-0-9.]+)\s+([-0-9.]+).*"([^"]+)"', 'tokens', 'once');
    if ~isempty(m)
        log.facts_flow = [log.facts_flow struct( ... %#ok<AGROW>
            'name', strtrim(m{4}), ...
            'p_mw', str2double(m{1}), ...
            'q_mvar_flow_to_shunt', str2double(m{2}), ...
            'mva', str2double(m{3}))];
    end
end
log.twodc = parse_twodc_from_log(lines);

function rows = parse_twodc_from_log(lines)
rows = struct('name', {}, 'mdc', {}, 'setvl', {}, 'vschd', {}, ...
    'vcmod', {}, 'dcamps', {}, 'vcomp', {}, 'meter', {}, ...
    'rect_bus', {}, 'rect_pac', {}, 'rect_qac', {}, 'rect_vdc', {}, ...
    'rect_alpha', {}, 'rect_tap', {}, 'rect_tap_flag', {}, ...
    'inv_bus', {}, 'inv_pac', {}, 'inv_qac', {}, 'inv_vdc', {}, ...
    'inv_gamma', {}, 'inv_tap', {}, 'inv_tap_flag', {});
for k = 1:numel(lines)
    if isempty(strfind(lines{k}, 'MDC ORG   RDC'))
        continue;
    end
    if k + 12 > numel(lines)
        continue;
    end
    data_line = first_nonempty(lines, k+1, min(k+5, numel(lines)));
    if isempty(data_line)
        continue;
    end
    data_num_part = data_line(min(13, length(data_line)+1):end);
    nums = numbers_in_line(data_num_part);
    if numel(nums) < 10
        continue;
    end
    name = strtrim(data_line(1:min(12, length(data_line))));
    r_line = '';
    i_line = '';
    rtap_line = '';
    itap_line = '';
    for j = k+1:min(k+20, numel(lines))
        s = strtrim(lines{j});
        if startsWith(s, 'R:') && isempty(r_line)
            r_line = s;
        elseif startsWith(s, 'I:') && isempty(i_line)
            i_line = s;
        elseif startsWith(s, 'R:') && ~isempty(r_line)
            rtap_line = s;
        elseif startsWith(s, 'I:') && ~isempty(i_line)
            itap_line = s;
        end
    end
    rn = dc_terminal_numbers(r_line);
    in = dc_terminal_numbers(i_line);
    rtn = numbers_in_line(rtap_line);
    itn = numbers_in_line(itap_line);
    if numel(rn) < 8 || numel(in) < 8
        continue;
    end
    rows(end+1) = struct( ... %#ok<AGROW>
        'name', name, 'mdc', nums(1), 'setvl', nums(5), ...
        'vschd', nums(6), 'vcmod', nums(8), 'dcamps', nums(9), ...
        'vcomp', nums(10), 'meter', parse_meter(data_line), ...
        'rect_bus', rn(1), 'rect_pac', rn(6), 'rect_qac', rn(7), ...
        'rect_vdc', rn(8), 'rect_alpha', rn(3), ...
        'rect_tap', first_or_nan(rtn), ...
        'rect_tap_flag', tap_flag_from_line(rtap_line), ...
        'inv_bus', in(1), 'inv_pac', in(6), 'inv_qac', in(7), ...
        'inv_vdc', in(8), 'inv_gamma', in(3), ...
        'inv_tap', first_or_nan(itn), ...
        'inv_tap_flag', tap_flag_from_line(itap_line));
end

function s = first_nonempty(lines, i1, i2)
s = '';
for i = i1:i2
    if ~isempty(strtrim(lines{i}))
        s = lines{i};
        return;
    end
end

function meter = parse_meter(line)
if contains(line, 'RECT')
    meter = 'RECT';
elseif contains(line, 'INV')
    meter = 'INV';
else
    meter = '';
end

function nums = dc_terminal_numbers(line)
m = regexp(line, '^\s*[RI]:\s+(\d+)\s+(.{12})\s+([-0-9.]+)\s+([-0-9.]+)\s+([-0-9.]+)\s+([-0-9.]+)\s+([-0-9.]+)\s+([-0-9.]+)\s+([-0-9.]+)', 'tokens', 'once');
if isempty(m)
    nums = numbers_in_line(line);
    return;
end
nums = [str2double(m{1}), str2double(m{3}), str2double(m{4}), ...
    str2double(m{5}), str2double(m{6}), str2double(m{7}), ...
    str2double(m{8}), str2double(m{9})];

function flag = tap_flag_from_line(line)
if contains(line, ' HI')
    flag = 'HI';
elseif contains(line, ' LO')
    flag = 'LO';
else
    flag = '';
end

function v = first_or_nan(x)
if isempty(x), v = NaN; else, v = x(1); end

function nums = numbers_in_line(line)
tok = regexp(line, '[-+]?\d+(?:\.\d+)?(?:[Ee][-+]?\d+)?', 'match');
nums = str2double(tok);

function cmp = compare_against_reference(ref, r0, r1)
cmp = struct();
cmp.runpf_vs_psse = compare_solution(ref, r0);
cmp.runpf_psse_vs_psse = compare_solution(ref, r1);
cmp.genq = compare_genq(ref, r1);
cmp.facts = compare_facts(ref, r1);
cmp.swshunt = compare_swshunt(ref, r1);
cmp.xfmr = compare_xfmr(ref, r1);
cmp.twodc = compare_twodc(ref, r1);

function cmp = compare_solution(ref, r)
cmp = struct('available', false, 'max_abs_vm', NaN, 'max_abs_va', NaN, ...
    'max_abs_vm_bus', NaN, 'max_abs_va_bus', NaN, 'top_vm', {{}}, ...
    'top_va', {{}}, 'psse_outside_095_110', {{}});
if isempty(ref.bus) || isempty(r) || ~isfield(r, 'bus')
    return;
end
[~, ~, ~, ~, ~, ~, ~, ~, ~, ~, ~, VM, VA] = idx_bus;
ref_bus = [ref.bus.bus]';
ref_vm = [ref.bus.vm]';
ref_va = [ref.bus.va]';
[tf, loc] = ismember(ref_bus, r.bus(:, 1));
if ~any(tf)
    return;
end
dvm = abs(r.bus(loc(tf), VM) - ref_vm(tf));
dva = abs(angle_diff_deg(r.bus(loc(tf), VA), ref_va(tf)));
[cmp.max_abs_vm, ii] = max(dvm);
ref_ok = ref_bus(tf);
cmp.max_abs_vm_bus = ref_ok(ii);
[cmp.max_abs_va, jj] = max(dva);
cmp.max_abs_va_bus = ref_ok(jj);
cmp.top_vm = top_diff_rows(ref_ok, dvm, 'VM');
cmp.top_va = top_diff_rows(ref_ok, dva, 'VA');
outside = find(ref_vm < 0.95 | ref_vm > 1.10);
cmp.psse_outside_095_110 = cell(numel(outside), 1);
for k = 1:numel(outside)
    i = outside(k);
    cmp.psse_outside_095_110{k} = sprintf('bus %.0f %s: VM %.5f pu', ...
        ref.bus(i).bus, ref.bus(i).name, ref.bus(i).vm);
end
cmp.available = true;

function d = angle_diff_deg(a, b)
d = mod(a - b + 180, 360) - 180;

function rows = top_diff_rows(bus, diff, label)
[~, ord] = sort(diff, 'descend');
n = min(10, numel(ord));
rows = cell(n, 1);
for k = 1:n
    i = ord(k);
    rows{k} = sprintf('bus %.0f: abs %s diff %.6g', bus(i), label, diff(i));
end

function rows = compare_genq(ref, r)
rows = struct('available', false, 'max_abs_q_diff', NaN, ...
    'max_abs_q_diff_bus', NaN, 'top', {{}});
if isempty(ref.gen) || isempty(r) || ~isfield(r, 'gen')
    return;
end
[GEN_BUS, ~, QG] = idx_gen;
ref_bus = [ref.gen.bus]';
ref_q = [ref.gen.qg]';
mp_q = NaN(size(ref_q));
for k = 1:numel(ref_bus)
    idx = find(r.gen(:, GEN_BUS) == ref_bus(k), 1);
    if ~isempty(idx)
        mp_q(k) = r.gen(idx, QG);
    end
end
ok = ~isnan(mp_q) & ~isnan(ref_q);
if ~any(ok)
    return;
end
dq = mp_q(ok) - ref_q(ok);
bus_ok = ref_bus(ok);
[rows.max_abs_q_diff, ii] = max(abs(dq));
rows.max_abs_q_diff_bus = bus_ok(ii);
[~, ord] = sort(abs(dq), 'descend');
n = min(20, numel(ord));
rows.top = cell(n, 1);
for k = 1:n
    i = ord(k);
    rows.top{k} = sprintf('bus %.0f: MATPOWER %.4f MVAr, PSS/E %.4f MVAr, diff %.4f', ...
        bus_ok(i), mp_q(ok_idx(ok, i)), ref_q(ok_idx(ok, i)), dq(i));
end
rows.available = true;

function idx = ok_idx(ok, i)
v = find(ok);
idx = v(i);

function rows = compare_facts(ref, r)
rows = struct('available', false, 'top', {{}});
if isempty(r) || ~isfield(r, 'psse') || ~isfield(r.psse, 'facts') || ...
        ~isfield(r.psse.facts, 'control')
    return;
end
ctrl = r.psse.facts.control;
if ~isfield(ctrl, 'qinj')
    return;
end
items = {};
for k = 1:numel(ctrl.qinj)
    psse_flow = NaN;
    name = sprintf('FACTS_%d', k);
    if isfield(ref.log, 'facts_flow') && ~isempty(ref.log.facts_flow) && ...
            k <= numel(ref.log.facts_flow)
        psse_flow = ref.log.facts_flow(k).q_mvar_flow_to_shunt;
        name = ref.log.facts_flow(k).name;
    elseif ~isempty(ref.facts) && k <= numel(ref.facts)
        name = ref.facts(k).name;
    end
    diff_injection = NaN;
    if ~isnan(psse_flow)
        diff_injection = ctrl.qinj(k) + psse_flow;
    end
    items{end+1, 1} = sprintf('%s: MATPOWER qinj %.4f MVAr, PSS/E flow-to-shunt %.4f MVAr, sign-adjusted diff %.4f', ...
        name, ctrl.qinj(k), psse_flow, diff_injection); %#ok<AGROW>
end
rows.top = items;
rows.available = true;

function rows = compare_swshunt(ref, r)
rows = struct('available', false, 'max_abs_binit_diff', NaN, 'top', {{}});
if isempty(ref.swshunt) || isempty(r) || ~isfield(r, 'psse') || ...
        ~isfield(r.psse, 'swshunt') || ~isfield(r.psse.swshunt, 'control')
    return;
end
ctrl = r.psse.swshunt.control;
if ~isfield(ctrl, 'final_binit')
    return;
end
n = min(numel(ref.swshunt), numel(ctrl.final_binit));
if n == 0
    return;
end
diff = ctrl.final_binit(1:n) - [ref.swshunt(1:n).binit]';
rows.max_abs_binit_diff = max(abs(diff));
[~, ord] = sort(abs(diff), 'descend');
nshow = min(20, n);
rows.top = cell(nshow, 1);
for k = 1:nshow
    i = ord(k);
    rows.top{k} = sprintf('bus %.0f: MATPOWER %.4f MVAr, PSS/E %.4f MVAr, diff %.4f', ...
        ref.swshunt(i).bus, ctrl.final_binit(i), ref.swshunt(i).binit, diff(i));
end
rows.available = true;

function rows = compare_xfmr(ref, r)
rows = struct('available', false, 'max_abs_windv1_diff', NaN, 'top', {{}});
if isempty(ref.xfmr) || isempty(r) || ~isfield(r, 'psse') || ...
        ~isfield(r.psse, 'xfmr') || ~isfield(r.psse.xfmr, 'control')
    return;
end
ctrl = r.psse.xfmr.control;
if ~isfield(ctrl, 'final_windv')
    return;
end
n = min(numel(ref.xfmr), numel(ctrl.final_windv));
if n == 0
    return;
end
ref_w = [ref.xfmr(1:n).windv1]';
diff = ctrl.final_windv(1:n) - ref_w;
rows.max_abs_windv1_diff = max(abs(diff));
[~, ord] = sort(abs(diff), 'descend');
nshow = min(20, n);
rows.top = cell(nshow, 1);
for k = 1:nshow
    i = ord(k);
    rows.top{k} = sprintf('%g-%g %s: MATPOWER WINDV %.5f, PSS/E WINDV1 %.5f, diff %.5f', ...
        ref.xfmr(i).i, ref.xfmr(i).j, ref.xfmr(i).ckt, ...
        ctrl.final_windv(i), ref_w(i), diff(i));
end
rows.available = true;

function rows = compare_twodc(ref, r)
rows = struct('available', false, 'top', {{}});
if isempty(r) || ~isfield(r, 'psse') || ~isfield(r.psse, 'twodc') || ...
        ~isfield(r.psse.twodc, 'control')
    return;
end
ctrl = r.psse.twodc.control;
if ~isfield(ctrl, 'pf')
    return;
end
n = numel(ctrl.pf);
items = cell(n, 1);
for k = 1:n
    psse = struct();
    if isfield(ref.log, 'twodc') && numel(ref.log.twodc) >= k
        psse = ref.log.twodc(k);
    end
    if isfield(psse, 'rect_pac')
        items{k} = sprintf(['link %d: MATPOWER PF %.4f/PT %.4f/QACR %.4f/QACI %.4f/' ...
            'Idc %.4f/taps %.5f %.5f/angles %.3f %.3f; PSS/E PAC %.4f %.4f/' ...
            'QAC %.4f %.4f/DCAMPS %.4f/taps %.5f %.5f/angles %.3f %.3f'], ...
            k, ctrl.pf(k), ctrl.pt(k), ctrl.qacr_mvar(k), ctrl.qaci_mvar(k), ...
            ctrl.idc_ka(k), ctrl.tapr(k), ctrl.tapi(k), ...
            ctrl.alpha_deg(k), ctrl.gamma_deg(k), ...
            psse.rect_pac, psse.inv_pac, psse.rect_qac, psse.inv_qac, ...
            psse.dcamps, psse.rect_tap, psse.inv_tap, ...
            psse.rect_alpha, psse.inv_gamma);
    else
        items{k} = sprintf(['link %d: MATPOWER PF %.4f/PT %.4f/QACR %.4f/QACI %.4f/' ...
            'Idc %.4f/taps %.5f %.5f/angles %.3f %.3f; PSS/E log values unavailable'], ...
            k, ctrl.pf(k), ctrl.pt(k), ctrl.qacr_mvar(k), ctrl.qaci_mvar(k), ...
            ctrl.idc_ka(k), ctrl.tapr(k), ctrl.tapi(k), ...
            ctrl.alpha_deg(k), ctrl.gamma_deg(k));
    end
end
rows.top = items;
rows.available = true;

function conflicts = detect_setpoint_conflicts(ref)
conflicts = {};
if ~isempty(ref.gen) && ~isempty(ref.bus)
    buses = [ref.bus.bus]';
    vms = [ref.bus.vm]';
    for k = 1:numel(ref.gen)
        g = ref.gen(k);
        if g.status == 0, continue; end
        reg = g.ireg;
        if isnan(reg) || reg == 0, reg = g.bus; end
        idx = find(buses == reg, 1);
        if isempty(idx) || isnan(g.vs), continue; end
        at_qmax = abs(g.qg - g.qmax) <= 0.2;
        at_qmin = abs(g.qg - g.qmin) <= 0.2;
        if (at_qmax || at_qmin) && abs(vms(idx) - g.vs) > 1e-3
            side = 'Q limit';
            if at_qmax, side = 'QMAX'; end
            if at_qmin, side = 'QMIN'; end
            conflicts{end+1, 1} = sprintf( ... %#ok<AGROW>
                'GEN bus %.0f at %s (QG %.3f, limits %.3f/%.3f) while regulated bus %.0f VM %.5f differs from VS %.5f', ...
                g.bus, side, g.qg, g.qmin, g.qmax, reg, vms(idx), g.vs);
        end
    end
end
if ~isempty(ref.swshunt) && ~isempty(ref.bus)
    buses = [ref.bus.bus]';
    vms = [ref.bus.vm]';
    for k = 1:numel(ref.swshunt)
        s = ref.swshunt(k);
        if s.stat == 0, continue; end
        reg = s.swreg;
        if isnan(reg) || reg == 0, reg = s.bus; end
        idx = find(buses == reg, 1);
        if isempty(idx), continue; end
        outside = vms(idx) < s.vswlo - 1e-5 || vms(idx) > s.vswhi + 1e-5;
        at_edge = (~isnan(s.bmin) && abs(s.binit - s.bmin) < 1e-5) || ...
            (~isnan(s.bmax) && abs(s.binit - s.bmax) < 1e-5);
        if outside && at_edge
            conflicts{end+1, 1} = sprintf( ... %#ok<AGROW>
                'SWSH bus %.0f at BINIT %.3f edge [%.3f, %.3f] while regulated bus %.0f VM %.5f is outside [%.5f, %.5f]', ...
                s.bus, s.binit, s.bmin, s.bmax, reg, vms(idx), s.vswlo, s.vswhi);
        end
    end
end
if isempty(conflicts)
    conflicts = {'none detected from available PSS/E reference data'};
end

function t = csv_tokens(line)
t = {};
buf = '';
in_quote = false;
quote_char = '';
for k = 1:length(line)
    ch = line(k);
    if (ch == '''' || ch == '"')
        if in_quote && ch == quote_char
            in_quote = false;
            quote_char = '';
        elseif ~in_quote
            in_quote = true;
            quote_char = ch;
        else
            buf(end+1) = ch; %#ok<AGROW>
        end
    elseif ch == ',' && ~in_quote
        t{end+1} = strtrim(buf); %#ok<AGROW>
        buf = '';
    else
        buf(end+1) = ch; %#ok<AGROW>
    end
end
t{end+1} = strtrim(buf);

function v = num_token(tokens, idx)
if idx > numel(tokens)
    v = NaN;
else
    v = str2double(clean_token(tokens{idx}));
end

function v = safe_num_token(tokens, idx)
if isempty(tokens) || idx > numel(tokens)
    v = NaN;
else
    v = num_token(tokens, idx);
end

function s = clean_token(s)
s = strtrim(s);
if length(s) >= 2
    if (s(1) == '''' && s(end) == '''') || (s(1) == '"' && s(end) == '"')
        s = s(2:end-1);
    end
end
s = strtrim(s);

function txt = tail_text(txt, n)
if isempty(txt)
    txt = {};
    return;
end
parts = regexp(strrep(txt, sprintf('\r'), ''), sprintf('\n'), 'split');
parts = parts(~cellfun(@isempty, parts));
if numel(parts) > n
    txt = parts(end-n+1:end);
else
    txt = parts;
end

function write_report(summary, path)
fid = fopen(path, 'w');
if fid < 0
    error('could not open report for writing: %s', path);
end
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, '# PSS/E Baseline Validation Report\n\n');
fprintf(fid, 'Generated: `%s`\n\n', summary.generated_at);
fprintf(fid, 'Workspace: `%s`\n\n', summary.root_dir);
fprintf(fid, 'This baseline does not change MATPOWER logic or original RAW/SAV/log fixtures. It runs `psse2mpc(raw, 0, 34)`, `runpf`, and `runpf_psse` and compares the resulting state against available PSS/E logs/solved RAW exports.\n\n');
fprintf(fid, '## Documentary Trace\n\n');
for k = 1:numel(summary.doc_sources)
    fprintf(fid, '- `%s`\n', summary.doc_sources{k});
end
fprintf(fid, '\n');
for k = 1:numel(summary.cases)
    write_case_report(fid, summary.cases(k));
end

function write_case_report(fid, c)
fprintf(fid, '## %s\n\n', c.name);
fprintf(fid, '- Role: %s\n', c.role);
fprintf(fid, '- RAW: `%s`\n', c.raw);
fprintf(fid, '- PSS/E reference: %s (`%s`)\n', c.reference_source, c.psse_reference_raw);
if ~isempty(c.psse_log)
    fprintf(fid, '- PSS/E log: `%s`\n', c.psse_log);
end
fprintf(fid, '- Parse OK: %s\n', yesno(c.parse_ok));
if ~c.parse_ok
    fprintf(fid, '- Parse error: `%s`\n\n', oneline(c.parse_error));
    return;
end
fprintf(fid, '- Warnings: %d\n', c.warning_count);
for k = 1:numel(c.warnings)
    fprintf(fid, '  - `%s`\n', c.warnings{k});
end
fprintf(fid, '\n');
write_counts(fid, c.counts);
write_solver(fid, 'runpf', c.runpf);
write_solver(fid, 'runpf_psse', c.runpf_psse);
write_reference_summary(fid, c.reference);
write_comparison(fid, c.comparison);
fprintf(fid, '### Setpoint Conflicts From PSS/E Reference\n\n');
write_bullets(fid, c.setpoint_conflicts);
fprintf(fid, '\n');

function write_counts(fid, counts)
fprintf(fid, '### Counts\n\n');
fprintf(fid, '| item | count |\n|---|---:|\n');
fprintf(fid, '| buses | %d |\n', counts.buses);
fprintf(fid, '| generators | %d |\n', counts.gens);
fprintf(fid, '| loads | %d |\n', counts.loads);
fprintf(fid, '| raw AC branches | %d |\n', counts.raw_branches);
fprintf(fid, '| MATPOWER branches | %d |\n', counts.matpower_branches);
fprintf(fid, '| transformers | %d |\n', counts.xfmr);
fprintf(fid, '| switched shunts | %d |\n', counts.swshunt);
fprintf(fid, '| FACTS devices | %d |\n', counts.facts);
fprintf(fid, '| TWO-DC links | %d |\n', counts.twodc);
fprintf(fid, '| system switching devices | %d |\n', counts.swdev);
fprintf(fid, '\n');

function write_solver(fid, name, s)
fprintf(fid, '### %s\n\n', name);
fprintf(fid, '- execution OK: %s\n', yesno(s.ok));
fprintf(fid, '- success: %s\n', yesno(s.success));
if ~s.ok
    fprintf(fid, '- error: `%s`\n\n', oneline(s.error));
    return;
end
fprintf(fid, '- iterations: %.0f\n', s.iterations);
fprintf(fid, '- task model iterations: data %.0f, network %.0f, math %.0f\n', ...
    s.data_model_iterations, s.network_model_iterations, s.math_model_iterations);
fprintf(fid, '- VM min/max: %.5f pu at bus %.0f / %.5f pu at bus %.0f\n', ...
    s.vm_min, s.vm_min_bus, s.vm_max, s.vm_max_bus);
fprintf(fid, '- buses outside 0.95-1.10: %d\n', s.outside_095_110_count);
write_bullets(fid, s.outside_095_110);
fprintf(fid, '- PSS/E control iterations: GENQ %.0f, XFMR %.0f, TWO-DC %.0f, SWSHUNT %.0f, FACTS %.0f\n\n', ...
    get_iter(s, 'genq'), get_iter(s, 'xfmr'), get_iter(s, 'twodc'), ...
    get_iter(s, 'swshunt'), get_iter(s, 'facts'));

function v = get_iter(s, field)
v = NaN;
if isfield(s.control_iterations, field) && ...
        isfield(s.control_iterations.(field), 'iterations')
    v = s.control_iterations.(field).iterations;
end

function write_reference_summary(fid, ref)
fprintf(fid, '### PSS/E Reference Summary\n\n');
if isfield(ref, 'error')
    fprintf(fid, '- `%s`\n\n', ref.error);
    return;
end
if isfield(ref, 'log') && isfield(ref.log, 'converged_iterations')
    fprintf(fid, '- PSS/E iterations: %.0f\n', ref.log.converged_iterations);
    fprintf(fid, '- PSS/E mismatch: total %.4f MVA, max %.4f MVA at bus %.0f\n', ...
        ref.log.total_mismatch_mva, ref.log.max_mismatch_mva, ref.log.max_mismatch_bus);
    fprintf(fid, '- PSS/E VM high/low: %.5f at bus %.0f / %.5f at bus %.0f\n', ...
        ref.log.high_voltage, ref.log.high_voltage_bus, ...
        ref.log.low_voltage, ref.log.low_voltage_bus);
end
if ~isempty(ref.bus)
    vm = [ref.bus.vm]';
    [mn, imn] = min(vm);
    [mx, imx] = max(vm);
    fprintf(fid, '- Reference RAW VM min/max: %.5f at bus %.0f / %.5f at bus %.0f\n', ...
        mn, ref.bus(imn).bus, mx, ref.bus(imx).bus);
    outside = find(vm < 0.95 | vm > 1.10);
    fprintf(fid, '- Reference buses outside 0.95-1.10: %d\n', numel(outside));
    rows = cell(numel(outside), 1);
    for k = 1:numel(outside)
        i = outside(k);
        rows{k} = sprintf('bus %.0f %s VM %.5f', ref.bus(i).bus, ref.bus(i).name, ref.bus(i).vm);
    end
    write_bullets(fid, rows);
end
fprintf(fid, '\n');

function write_comparison(fid, cmp)
fprintf(fid, '### Mismatch Against PSS/E Reference\n\n');
write_solution_cmp(fid, 'runpf vs PSS/E', cmp.runpf_vs_psse);
write_solution_cmp(fid, 'runpf_psse vs PSS/E', cmp.runpf_psse_vs_psse);
fprintf(fid, '### GEN Q vs PSS/E\n\n');
write_cmp_block(fid, cmp.genq, 'top');
fprintf(fid, '### FACTS Q vs PSS/E\n\n');
write_cmp_block(fid, cmp.facts, 'top');
fprintf(fid, '### Switched Shunts Final BINIT vs PSS/E\n\n');
write_cmp_block(fid, cmp.swshunt, 'top');
fprintf(fid, '### Transformer Taps vs PSS/E\n\n');
write_cmp_block(fid, cmp.xfmr, 'top');
fprintf(fid, '### TWO-DC P/Q/Taps/Flags vs PSS/E\n\n');
write_cmp_block(fid, cmp.twodc, 'top');

function write_solution_cmp(fid, title, s)
fprintf(fid, '**%s**\n\n', title);
if ~s.available
    fprintf(fid, '- unavailable\n\n');
    return;
end
fprintf(fid, '- max abs VM diff: %.6g pu at bus %.0f\n', s.max_abs_vm, s.max_abs_vm_bus);
fprintf(fid, '- max abs VA diff: %.6g deg at bus %.0f\n', s.max_abs_va, s.max_abs_va_bus);
fprintf(fid, '- largest VM diffs:\n');
write_bullets(fid, s.top_vm);
fprintf(fid, '\n');

function write_cmp_block(fid, cmp, field)
if ~cmp.available
    fprintf(fid, '- unavailable from current MATPOWER/PSS/E evidence\n\n');
    return;
end
if isfield(cmp, 'max_abs_q_diff') && ~isnan(cmp.max_abs_q_diff)
    fprintf(fid, '- max abs Q diff: %.6g MVAr at bus %.0f\n', ...
        cmp.max_abs_q_diff, cmp.max_abs_q_diff_bus);
end
if isfield(cmp, 'max_abs_binit_diff') && ~isnan(cmp.max_abs_binit_diff)
    fprintf(fid, '- max abs BINIT diff: %.6g MVAr\n', cmp.max_abs_binit_diff);
end
if isfield(cmp, 'max_abs_windv1_diff') && ~isnan(cmp.max_abs_windv1_diff)
    fprintf(fid, '- max abs WINDV1 diff: %.6g\n', cmp.max_abs_windv1_diff);
end
write_bullets(fid, cmp.(field));
fprintf(fid, '\n');

function write_bullets(fid, rows)
if isempty(rows)
    fprintf(fid, '  - none\n');
    return;
end
for k = 1:numel(rows)
    fprintf(fid, '  - %s\n', rows{k});
end

function s = yesno(v)
if v
    s = 'yes';
else
    s = 'no';
end

function s = oneline(s)
s = strrep(s, sprintf('\n'), ' | ');
s = strrep(s, sprintf('\r'), '');
