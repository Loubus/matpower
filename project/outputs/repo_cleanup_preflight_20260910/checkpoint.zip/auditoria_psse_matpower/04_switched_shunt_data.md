# Issue 1 - SWITCHED SHUNT DATA

Fecha de trabajo: 2026-05-15.

Alcance: solo `PSSE/V26p_Trs_2532.raw`, seccion `SWITCHED SHUNT DATA`.

## 1. Evidencia RAW

El RAW local declara la seccion con formato Rev34:

```text
I,MODSW,ADJM,ST,VSWHI,VSWLO,SWREG,RMPCT,RMIDNT,BINIT,N1,B1,...,N8,B8,NREG
```

Conteos del RAW:

| Item | Valor |
|---|---:|
| Registros switched shunt | 361 |
| `ST=1` | 348 |
| `ST=0` | 13 |
| `MODSW=0` | 216 |
| `MODSW=1` | 141 |
| `MODSW=2` | 4 |
| `BINIT` no cero | 276 |
| `BINIT` total previo, todos los estados | 3621.700 MVAr |
| `BINIT` en servicio (`ST=1`) | 3756.700 MVAr |
| `BINIT` fuera de servicio (`ST=0`) | -135.000 MVAr |
| Fuera de servicio con `BINIT` no cero | 5 |
| Control remoto `SWREG != I` | 39 |
| Control remoto en servicio | 33 |
| Bloques no cero | 503 |
| Bloques capacitivos | 407 |
| Bloques reactivos | 96 |
| Rango total disponible capacitivo | 6508.590 MVAr |
| Rango total disponible reactivo | -6998.380 MVAr |

Registros fuera de servicio que antes afectaban `BS`:

| Bus | MODSW | ST | SWREG | BINIT MVAr | kV | Suma bloques MVAr |
|---:|---:|---:|---:|---:|---:|---:|
| 2588 | 0 | 0 | 2588 | 2.500 | 33.0 | 2.500 |
| 2841 | 0 | 0 | 2841 | 2.500 | 33.0 | 2.500 |
| 90480 | 1 | 0 | 90480 | -70.000 | 500.0 | -70.000 |
| 95430 | 0 | 0 | 92430 | -10.000 | 31.5 | -10.000 |
| 98201 | 0 | 0 | 92200 | -60.000 | 13.8 | -60.000 |

Resumen por nivel de tension:

| kV | Registros | Activos | Inactivos | BINIT activos | BINIT inactivos | Rango cap. | Rango reac. | Remotos |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 13.2 | 37 | 36 | 1 | 285.500 | 0.000 | 315.100 | 0.000 | 6 |
| 13.8 | 10 | 9 | 1 | 0.000 | -60.000 | 0.000 | -435.000 | 10 |
| 23.0 | 1 | 1 | 0 | 0.000 | 0.000 | 39.000 | -27.000 | 0 |
| 31.5 | 13 | 8 | 5 | -77.170 | -10.000 | 333.300 | -343.000 | 13 |
| 33.0 | 40 | 35 | 5 | 342.500 | 5.000 | 565.100 | -83.000 | 3 |
| 34.5 | 3 | 3 | 0 | 0.000 | 0.000 | 0.000 | -75.000 | 0 |
| 66.0 | 3 | 3 | 0 | 58.000 | 0.000 | 108.000 | 0.000 | 0 |
| 132.0 | 209 | 209 | 0 | 2854.550 | 0.000 | 3079.350 | -1045.380 | 7 |
| 220.0 | 13 | 13 | 0 | 1028.320 | 0.000 | 1388.740 | -350.000 | 0 |
| 500.0 | 30 | 29 | 1 | -1075.000 | -70.000 | 340.000 | -4640.000 | 0 |
| 525.0 | 2 | 2 | 0 | 340.000 | 0.000 | 340.000 | 0.000 | 0 |

## 2. Evidencia documental PSS/E

`PSSE/DataFormats.pdf`, seccion `1.27 Switched Shunt Data`, define para Rev36 el conjunto completo de campos `I`, `ID`, `MODSW`, `ADJM`, `STAT`, `VSWHI`, `VSWLO`, `SWREG`, `NREG`, `RMPCT`, `RMIDNT`, `BINIT`, `NAME`, y bloques `S/N/B`. La tabla de cambios del mismo manual confirma para PSSE34:

```text
I, MODSW, ADJM, STAT, VSWHI, VSWLO, SWREG, RMPCT, RMIDNT, BINIT,
N1, B1, N2, B2, ..., N8, B8, NREG
```

Puntos relevantes:

- `STAT` es el estado inicial del switched shunt completo: 1 en servicio, 0 fuera de servicio.
- `BINIT` es la admitancia inicial en MVAr a tension unitaria.
- `Ni/Bi` definen hasta ocho bloques; el primer `Ni` o `Bi` cero termina la lista de bloques.
- `MODSW=0` bloquea el equipo; `MODSW=1` lo ajusta discretamente; `MODSW=2` lo ajusta de forma continua.
- `SWREG` puede indicar bus remoto de regulacion para `MODSW=1` o `2`.

`PSSE/PAGV1.pdf`, secciones `6.7 Power Flow Solution`, `Switched Shunt Admittance Adjustment` y `Automatically Switched Shunt Devices`, indica que el ajuste de switched shunts esta normalmente habilitado en las soluciones de flujo, que puede suprimirse globalmente, y que el bloqueo selectivo se realiza con `MODSW=0`. Tambien indica que PSS/E reconoce estos subsistemas como automaticos en buses tipo 1 y tipo 2 de salida fija, y que en buses tipo 2/3 de control de tension quedan fijos en `BINIT`.

## 3. Evidencia documental MATPOWER

`Matpower Manuals/MATPOWER-manual-8.1.pdf`:

- La seccion `3.5 Shunt Elements` modela shunts como admitancia fija a tierra.
- `GS` y `BS` en `mpc.bus` son MW consumidos y MVAr inyectados a `V=1.0 pu`.
- `runpf` resuelve un flujo AC con datos convertidos a formato interno; no hay control automatico nativo de switched shunts PSS/E en el formato estandar.
- El formato `mpc` permite campos adicionales definidos por el usuario.

`Matpower Manuals/matpower_dev_manual.pdf`:

- MP-Core separa capa de datos, red y modelo matematico.
- Una extension formal para control automatico deberia entrar como elemento/modelo, no como logica ad hoc dentro de `makeYbus` o `runpf`.
- Para este issue, preservar metadatos en `mpc` y corregir la conversion fija encaja mejor que introducir un control discreto incompleto.

## 4. Evidencia de codigo antes del cambio

Antes de esta sesion:

- `matpower/lib/psse_parse.m` para `rev >= 32` usaba la plantilla `d........f`; por eso solo quedaban numericos `I` y `BINIT`.
- `matpower/lib/psse_convert.m` sumaba `BINIT` a `bus(:, BS)` para todos los registros, sin mirar `ST`.
- `MODSW`, `ADJM`, `ST`, `VSWHI/VSWLO`, `SWREG`, `RMPCT`, `RMIDNT`, `N/B` y `NREG` no quedaban disponibles en una estructura util del `mpc`.
- `matpower/lib/makeYbus.m` usa `bus(:, GS)` y `bus(:, BS)` como shunt fijo en `Ybus`.

Diagnostico previo al cambio:

```text
current_parse_cols=18
current_parse_numeric_non_nan_cols=[1 10]
```

## 5. Decision de diseno

Se adopto la opcion conservadora:

1. Parsear completamente switched shunts Rev34, y dejar soporte de columnas para Rev35/36.
2. Preservar la tabla parseada en `mpc.psse.swshunt`.
3. Convertir solo `BINIT` de equipos en servicio (`ST != 0`) a `bus(:, BS)`.
4. Mantener `runpf` sin control discreto/continuo automatico por ahora.

No se implemento todavia la opcion avanzada de control automatico, porque requeriria un elemento o extension formal de MP-Core con variables/estados discretos o logica iterativa acoplada al flujo de potencia. Hacerlo ahora sin salida PSS/E final de shunts podria mezclar varias fuentes de discrepancia.

## 6. Implementacion realizada

Archivos modificados:

- `matpower/lib/psse_parse.m`
  - Rev34 parsea `MODSW`, `ADJM`, `STAT`, `VSWHI`, `VSWLO`, `SWREG`, `RMPCT`, `RMIDNT`, `BINIT`, bloques `N/B` y `NREG`.
  - Se agregaron plantillas para Rev35 y Rev36 con `ID`, `NREG`, `NAME` y bloques `S/N/B`.
- `matpower/lib/psse_convert.m`
  - Se agrego metadato local de columnas switched shunt por revision.
  - Se respeta `STAT` al sumar `BINIT` a `bus(:, BS)`.
  - Se preserva `mpc.psse.rev` y `mpc.psse.swshunt`.
- `matpower/lib/t/t_psse_case4.raw`
  - Se agregaron dos switched shunts Rev34 minimos: uno activo y uno fuera de servicio.
- `matpower/lib/t/t_psse.m`
  - Se agregaron tests de parseo completo Rev34, conversion respetando `ST`, y preservacion de `mpc.psse.swshunt`.

## 7. Validacion antes/despues

Resultado sobre `PSSE/V26p_Trs_2532.raw`:

| Variante | success | iter | VM min | VM max | Suma BS |
|---|---:|---:|---:|---:|---:|
| Comportamiento anterior reconstruido | 1 | 4 | 0.697041 | 1.156370 | -79.324 |
| Cambio aplicado (`ST` respetado) | 1 | 4 | 0.695891 | 1.163592 | 55.676 |
| Sin `BINIT` switched shunt | 0 | 10 | - | - | - |
| Solo `MODSW=0` activo como fijo | 0 | 10 | - | - | - |

Diferencia del cambio aplicado contra el comportamiento anterior reconstruido:

| Metrica | Valor |
|---|---:|
| `dBS` | +135.000 MVAr |
| `max |dVM|` | 0.043779 pu |
| `max |dVA|` | 0.259021 grados |

Buses mas afectados en magnitud por respetar `ST`:

| Bus | Nombre | kV | VM anterior | VM nuevo | dVM |
|---:|---|---:|---:|---:|---:|
| 95320 | `GAL_31.5` | 31.5 | 0.928731 | 0.972510 | 0.043779 |
| 98320 | `GAL_15_G` | 15.0 | 0.928731 | 0.972510 | 0.043779 |
| 95322 | `GALARZ_2` | 31.5 | 0.928730 | 0.972510 | 0.043779 |
| 95321 | `GALARZ_1` | 31.5 | 0.928730 | 0.972509 | 0.043779 |
| 95430 | `TYT_30_L` | 31.5 | 0.928725 | 0.972504 | 0.043779 |

Validaciones ejecutadas:

```text
t_psse(0): All tests successful (164 of 164)
psse2mpc + runpf RAW local: success=1, iterations=4
parse_rows=361, parse_cols=27, binit_col=10, status_col=4
mpc_has_psse_swshunt=1
```

## 8. Limitaciones pendientes

- El flujo MATPOWER sigue tratando switched shunts activos como `BINIT` fijo.
- No se replica el control discreto `MODSW=1` ni continuo `MODSW=2`.
- No se usa `SWREG` para control remoto ni `RMPCT` para reparto de MVAr.
- Los bloques `N/B` quedan preservados, pero no se optimizan ni conmutan.
- Falta una salida PSS/E real con estado final de switched shunts para saber si el `BINIT` del RAW coincide con la solucion final PSS/E.

## 9. Continuacion del mismo issue

Este documento cerro la primera parte del issue `SWITCHED SHUNT DATA`: parseo completo Rev34, preservacion de datos y conversion fija respetando `STAT`.

La continuacion inmediata quedo implementada y documentada en `05_control_switched_shunt_psse.md`: control automatico PSS/E por `runpf_psse` con `SWSHNT`, `MODSW=0/1/2`, `ADJM=0`, `SWREG`, `RMPCT`, bandas `VSWLO/VSWHI` y bloques `N/B`, sin abrir `TWO-TERMINAL DC DATA` ni otros controles.
