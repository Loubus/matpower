# Issue 1b - CONTROL PSS/E DE SWITCHED SHUNTS

Fecha de trabajo: 2026-05-15.

Alcance: solo `PSSE/V26p_Trs_2532.raw`, seccion `SWITCHED SHUNT DATA` y registros `SYSTEM-WIDE` que afectan la solucion de flujo.

Objetivo: entender como PSS/E decide ajustar switched shunts en flujo de potencia y que tendria que mimetizar MATPOWER para no tratarlos solamente como `BINIT` fijo.

## 1. Punto de partida

La correccion conservadora ya implementada deja a MATPOWER en este estado:

- `psse_parse` parsea los campos Rev34 completos de switched shunt.
- `psse_convert` preserva `mpc.psse.swshunt`.
- `psse_convert` suma `BINIT` a `bus(:, BS)` solo si `STAT != 0`.
- `runpf` converge, pero no aplica control automatico `MODSW=1` ni `MODSW=2`.

Por lo tanto, este documento no reabre el parseo. Audita el control que falta.

## 2. Variables globales PSS/E que gobiernan el control

El RAW local contiene registros `SYSTEM-WIDE` antes de los datos electricos:

```text
NEWTON, ITMXN=40, ACCN=0.5, TOLN=1.0, VCTOLQ=0.1, VCTOLV=0.00001, DVLIM=0.99, NDVFCT=0.99
ADJUST, ADJTHR=0.005, ACCTAP=1.0, TAPLIM=0.05, SWVBND=100.0, MXTPSS=99, MXSWIM=10
SOLVER, FNSL, ACTAPS=0, AREAIN=0, PHSHFT=0, DCTAPS=1, SWSHNT=2, FLATST=0, VARLIM=0, NONDIV=0
```

Segun `PSSE/DataFormats.pdf`:

| Registro | Campo | Valor RAW | Relevancia para switched shunts |
|---|---:|---:|---|
| `SOLVER` | metodo | `FNSL` | La solucion guardada fue Newton completa, una de las actividades donde PSS/E documenta ajustes automaticos. |
| `SOLVER` | `SWSHNT` | `2` | Codigo global de ajuste de switched shunts. Los manuales locales identifican el campo, pero no enumeran en texto extraido el significado exacto de cada codigo numerico. |
| `SOLVER` | `FLATST` | `0` | La solucion no parte de flat start; usa las tensiones del caso y los `BINIT` iniciales. |
| `SOLVER` | `VARLIM` | `0` | Codigo global de limites Q; interactua con regulacion de tension y conversion PV/PQ, aunque no es un campo de switched shunt. |
| `SOLVER` | `ACTAPS` | `0` | Taps AC deshabilitados en la solucion guardada; reduce acoplamientos con switched shunts. |
| `SOLVER` | `PHSHFT` | `0` | Phase shifters deshabilitados. |
| `SOLVER` | `DCTAPS` | `1` | Taps DC habilitados; puede acoplarse con tensiones, pero pertenece al issue HVDC. |
| `ADJUST` | `ADJTHR` | `0.005` | Tolerancia de ajuste automatico. |
| `ADJUST` | `SWVBND` | `100.0` | Parametro especifico de ajuste de switched shunts con violaciones de tension. |
| `ADJUST` | `MXTPSS` | `99` | Maximo de ciclos de ajuste de taps y/o switched shunts. |
| `NEWTON` | `VCTOLQ` | `0.1` | Tolerancia de mismatch Q en bus controlado. |
| `NEWTON` | `VCTOLV` | `0.00001` | Tolerancia de error de tension en bus controlado. |
| `NEWTON` | `DVLIM` | `0.99` | Limite de cambio de magnitud de tension por iteracion. |

Evidencia de codigo: `matpower/lib/psse_parse.m` salta actualmente `SYSTEM-WIDE`; esos valores no llegan a `mpc` ni a `mpoption`. Para mimetizar PSS/E, MATPOWER necesita al menos preservar estos registros, aunque la primera implementacion use solo una parte.

## 3. Variables locales de cada switched shunt

Para Rev34, el RAW usa:

```text
I, MODSW, ADJM, STAT, VSWHI, VSWLO, SWREG, RMPCT, RMIDNT, BINIT,
N1, B1, N2, B2, ..., N8, B8, NREG
```

Campos que afectan directamente el control:

| Campo | Uso PSS/E para control |
|---|---|
| `STAT` | Estado del switched shunt completo. Si vale 0, no debe inyectar ni controlar. |
| `MODSW=0` | Bloqueado/fijo en la posicion actual. |
| `MODSW=1` | Ajuste discreto para controlar tension local o remota. |
| `MODSW=2` | Ajuste continuo dentro del rango fisico para llevar la tension al punto medio de la banda. |
| `MODSW=3..6` | Otros controles de Q o de equipos remotos. No aparecen en este RAW. |
| `ADJM=0` | Conmutacion en orden de entrada y apagado en orden inverso. Es el unico valor presente en este RAW. |
| `ADJM=1` | Conmutacion al siguiente total de admitancia superior/inferior. No aparece en este RAW, pero debe contemplarse para soporte general. |
| `VSWHI/VSWLO` | Banda de tension para `MODSW=1/2`; banda de Q para modos 3..6. |
| `SWREG` | Bus regulado. Si es 0, controla el propio bus. Si apunta a un bus remoto no tipo 1/2 para `MODSW=1/2`, PSS/E controla el propio bus. |
| `RMPCT` | Porcentaje de MVAr requeridos que aporta este shunt cuando mas de un equipo regula el mismo bus. |
| `BINIT` | Admitancia inicial en MVAr a `V=1 pu`; PSS/E la usa para fijar la posicion inicial y la actualiza al final de la solucion. |
| `Ni/Bi` | Bloques y pasos fisicos disponibles. `Bi > 0` capacitor, `Bi < 0` reactor. |
| `NREG` | Nodo regulado en modelo node-breaker; en este RAW no se usa para subestaciones activas porque no hay `SUBSTATION DATA`. |

## 4. Reglas PSS/E documentadas

De `PSSE/PAGV1.pdf`, secciones `Switched Shunt Admittance Adjustment` y `Automatically Switched Shunt Devices`:

- El ajuste de switched shunts esta normalmente habilitado en las actividades de flujo de potencia y puede suprimirse globalmente.
- El bloqueo selectivo se hace dejando habilitado el ajuste global y poniendo `MODSW=0` en los shunts que se quieren fijos.
- PSS/E reconoce switched shunts automaticos en servicio solo en buses tipo 1 y en buses tipo 2 de generacion fija. En buses tipo 2 que controlan tension y en buses tipo 3 quedan fijos en `BINIT`.
- Al comenzar cada solucion, PSS/E determina la posicion inicial que mas se aproxima a `BINIT`.
- Para `MODSW=1`, conmuta pasos para mantener la tension entre `VSWLO` y `VSWHI`.
- Reactores y capacitores no deben estar simultaneamente conectados; si la tension esta alta, primero se sacan capacitores antes de conectar reactores, y si la tension esta baja ocurre la logica inversa.
- Solo se conmuta dentro de un bloque por vez; un bloque debe quedar todo conectado o todo desconectado antes de pasar a otro.
- Para `MODSW=2`, PSS/E varia la admitancia continuamente dentro del rango total para llevar la tension al punto medio de `VSWLO` y `VSWHI`.
- Al alcanzar solucion, la admitancia final queda escrita en `BINIT`.

De `PSSE/DataFormats.pdf`, seccion `Switched Shunt Data`:

- `ADJM=0` significa orden de entrada / orden inverso.
- `ADJM=1` significa ir al siguiente total de admitancia mayor o menor.
- `RMPCT` solo se usa para `MODSW=1/2`.
- Una banda de admitancia demasiado estrecha para equipos de control de setpoint es desaconsejada; el solver Newton requiere rango Q mayor a `0.002 pu` para equipos de control de setpoint.

## 5. Diagnostico del RAW local

Conteo de modos y estados:

| Metrica | Valor |
|---|---:|
| Registros switched shunt | 361 |
| `STAT=1` | 348 |
| `STAT=0` | 13 |
| `MODSW=0` | 216 |
| `MODSW=1` | 141 |
| `MODSW=2` | 4 |
| `MODSW=3..6` | 0 |
| `ADJM=0` | 361 |
| `ADJM=1` | 0 |

Dispositivos automaticos que PSS/E deberia reconocer en servicio:

| Metrica | Valor |
|---|---:|
| `STAT != 0` y `MODSW in {1,2}` | 136 |
| Reconocibles por tipo de bus 1/2 | 132 |
| No reconocibles por estar en bus tipo 4 | 4 |
| Control local efectivo | 111 |
| Control remoto efectivo | 21 |
| Buses remotos invalidos o faltantes | 0 |

Los 4 no reconocibles por bus tipo 4 son:

| Bus | MODSW | STAT | SWREG | BINIT | Banda |
|---:|---:|---:|---:|---:|---|
| 317 | 1 | 1 | 317 | 0.000 | `[0.950, 1.050]` |
| 2540 | 1 | 1 | 2517 | 2.000 | `[0.960, 1.040]` |
| 8285 | 1 | 1 | 8285 | 10.000 | `[0.970, 1.030]` |
| 728932 | 1 | 1 | 728932 | 20.000 | `[1.000, 1.000]` |

## 6. Estado de bandas luego del runpf MATPOWER actual

Se ejecuto `psse2mpc` + `runpf` con el cambio conservador ya aplicado, es decir, `BINIT` fijo solo para `STAT != 0`.

```text
runpf_success=1
iterations=4
recognized_auto=132
mode1=128
mode2=4
below_band=15
above_band=44
inside_band=73
movable_violations=32
blocked_violations=27
zero_band_auto=23
zero_band_violating=23
```

Interpretacion:

- MATPOWER converge con `BINIT` fijo, pero deja 59 shunts automaticos reconocibles fuera de banda.
- De esos 59, hay 32 con margen fisico para moverse y 27 ya estan en limite del rango en la direccion requerida.
- Hay 23 shunts automaticos con `VSWLO = VSWHI`; PSS/E los trata como setpoint exacto sujeto a tolerancias y pasos disponibles.
- Todos los `MODSW=1` automaticos reconocibles tienen `BINIT` exactamente representable por sus bloques.
- En `MODSW=2`, 2 de 4 tienen `BINIT` no representable por pasos discretos, lo cual es esperable porque el modo continuo puede quedar en un valor intermedio.

Mayores violaciones de banda observadas:

| Bus shunt | MODSW | Bus regulado | Direccion requerida | VM regulado | Banda | BINIT | Rango | Movible |
|---:|---:|---:|---|---:|---|---:|---|---:|
| 4801 | 1 | 4801 | bajar B | 1.088084 | `[0.970, 1.030]` | 14.400 | `[0.000, 24.000]` | 1 |
| 7513 | 1 | 7277 | bajar B | 1.045846 | `[0.980, 1.000]` | 27.000 | `[0.000, 27.000]` | 1 |
| 49921 | 2 | 49921 | subir B | 1.055995 | `[1.100, 1.100]` | 140.000 | `[-120.000, 140.000]` | 0 |
| 6581 | 1 | 6581 | bajar B | 1.043866 | `[1.000, 1.000]` | 24.000 | `[0.000, 24.000]` | 1 |
| 2259 | 1 | 2259 | bajar B | 1.035315 | `[1.000, 1.000]` | 1.500 | `[0.000, 1.500]` | 1 |
| 1250 | 1 | 1250 | subir B | 0.938880 | `[0.970, 1.030]` | 8.550 | `[0.000, 8.550]` | 0 |
| 95440 | 1 | 92440 | subir B | 0.978392 | `[1.000, 1.050]` | 7.650 | `[-5.000, 7.650]` | 0 |

Grupos con mas de un shunt regulando el mismo bus efectivo:

| Bus regulado | Cantidad | Suma RMPCT | Buses shunt |
|---:|---:|---:|---|
| 6000 | 2 | 200.00 | `[6800 6801]` |
| 7000 | 2 | 200.00 | `[7802 7803]` |
| 7110 | 2 | 200.00 | `[7806 7809]` |
| 92170 | 2 | 200.00 | `[95171 95172]` |
| 92300 | 2 | 200.00 | `[95301 95302]` |

Esta evidencia impide suponer "un shunt por bus regulado" o normalizar `RMPCT` sin validar la logica PSS/E.

## 7. Como deberia mimetizarse en MATPOWER

### Nivel minimo correcto

El nivel minimo no cambia el solver:

1. Preservar `SYSTEM-WIDE` en `mpc.psse.system` o estructura equivalente.
2. Mantener `BINIT` fijo cuando `SWSHNT` este deshabilitado o `MODSW=0`.
3. Mantener fuera de control los shunts con `STAT=0` o ubicados en buses donde PSS/E no reconoce control automatico.
4. Exponer diagnosticos que comparen `VM` final contra `VSWLO/VSWHI`.

Esto ya permite reproducibilidad y evita perder configuracion global.

### Control formal mediante extension MP-Core

La implementacion elegida no debe meter logica PSS/E dentro de `runpf` ni crear un lazo externo ad hoc. La ruta alineada con MATPOWER 8.1 es una extension MP-Core:

1. `runpf_psse` activa `mp.xt_psse` mediante `mpopt.exp.mpx`.
2. `mp.xt_psse` reemplaza la clase de tarea PF por `mp.task_pf_psse`.
3. `mp.task_pf_psse` hereda de `mp.task_pf_legacy`.
4. La logica de control se implementa sobreescribiendo `next_dm`, el punto formal donde MATPOWER permite iterar el data model despues de resolver el modelo matematico.
5. Si el control modifica el estado de switched shunts, devuelve un `dm` actualizado y MATPOWER reconstruye red/modelo matematico para una nueva solucion.
6. Si no hay cambios, devuelve `[]` y termina.

El flujo conceptual queda:

```text
runpf_psse
  -> runpf(..., mpopt.exp.mpx = {mp.xt_psse})
       -> mp.task_pf_psse.run()
            -> resolver PF
            -> next_dm()
                 -> controles MATPOWER existentes
                 -> control PSS/E switched shunts
            -> repetir si next_dm devuelve un data model actualizado
```

Dentro de ese hook se deben construir estados fisicos posibles para cada shunt:

   - `ADJM=0`: secuencia por bloques en orden de entrada; reactores y capacitores no simultaneos.
   - `ADJM=1`: lista ordenada de totales de admitancia alcanzables; no se necesita para este RAW, pero se debe disenar.
   - inicializacion desde el estado mas cercano a `BINIT`.
   - actualizacion de `dm.elements.shunt` o del elemento PSS/E dedicado que se defina.

Para cada shunt controlable:

   - si `VM(reg) < VSWLO`, aumentar `B` si hay margen;
   - si `VM(reg) > VSWHI`, disminuir `B` si hay margen;
   - si esta dentro de banda, no mover.

La iteracion termina cuando no hay cambios, se cumple tolerancia, o se alcanza `MXTPSS`. El `BINIT` final debe exportarse al `results` PSS/E.

Esta ruta se puede validar contra el RAW actual porque `ADJM=0` en los 361 registros y no existen modos 3..6.

### Control continuo `MODSW=2`

Para `MODSW=2`, la imitacion correcta no es una conmutacion discreta. PSS/E ajusta una admitancia continua dentro de `[Bmin, Bmax]` para apuntar al punto medio de la banda.

Opciones de implementacion:

- Wrapper iterativo con sensibilidad numerica `dV/dB`: simple para auditar, pero puede requerir multiples `runpf`.
- Variable continua en el modelo matematico: mas fiel y estable, pero requiere extension formal de MP-Core.

El RAW solo tiene 4 shunts `MODSW=2`, pero son electricamente relevantes: los 4 tienen banda de ancho cero y 2 ya muestran `BINIT` intermedio no representable por pasos discretos.

### Extension formal MATPOWER

La arquitectura recomendada por el manual de desarrollo es MP-Core:

- Data model element para `psse_switched_shunt` o un shunt controlable equivalente.
- Network model element que aporte admitancia variable a tierra.
- Math model element PF AC que agregue variable de susceptancia y ecuacion de tension controlada para el modo continuo.
- Para modo discreto, una capa de control iterativa alrededor del PF sigue siendo mas natural que meter variables enteras dentro de `runpf`.

No conviene meter esta logica en `makeYbus` ni en `makeSbus`: esas funciones construyen admitancias e inyecciones para un estado dado; no son el lugar donde decidir conmutaciones.

## 8. Decision de diseno

Para este proyecto, la solucion que mejor encaja con MATPOWER y con el RAW local es:

1. Mantener `runpf` intacto.
2. Usar `runpf_psse` como punto de entrada.
3. Activar una extension `mp.xt_psse`.
4. Implementar el control en `mp.task_pf_psse.next_dm`, no en `runpf_psse`.
5. Acotar la primera version del control a `MODSW=1/2`, `ADJM=0`, `STAT=1`, buses reconocibles tipo 1/2, y `SWSHNT` habilitado segun politica documentada.

Motivo:

- El RAW actual no usa `ADJM=1` ni modos 3..6.
- La mayor brecha observada es operacional: 59 controles automaticos quedan fuera de banda con `BINIT` fijo.
- La extension MP-Core respeta la arquitectura documentada de MATPOWER y mantiene `runpf` para todos los usuarios sin comportamiento PSS/E implicito.
- `next_dm` ya es el mecanismo formal usado por MATPOWER para iterar el data model en PF.

## 9. Validacion planificada

Antes/despues minimo:

| Validacion | Criterio |
|---|---|
| `t_psse(0)` | Sigue pasando completo. |
| `psse2mpc + runpf` baseline fijo | Sigue convergiendo con 4 iteraciones o diferencia justificada. |
| Wrapper switched shunt | Converge sin oscilacion de controles. |
| Bandas de tension | Baja la cantidad de automaticos fuera de banda respecto de 59. |
| `BINIT` final | Queda dentro del rango fisico y respeta estados discretos/continuos. |
| Grupos `RMPCT` | No se rompe en grupos con dos shunts regulando el mismo bus. |
| Comparacion PSS/E | Cuando exista salida PSS/E, comparar primero `VM/VA`; usar `BINIT` final como diagnostico auxiliar. |

Casos unitarios recomendados:

- Un shunt `MODSW=1` local con dos bloques capacitivos.
- Un shunt `MODSW=1` mixto reactor/capacitor, verificando que no queden ambos signos simultaneamente.
- Un shunt remoto con `SWREG` valido.
- Un shunt remoto con `SWREG` invalido, verificando fallback al propio bus.
- Dos shunts sobre el mismo bus regulado con `RMPCT`.
- Un shunt `MODSW=2` continuo con rango simetrico y banda de ancho cero.
- Un caso discreto con banda de ancho cero que repite estados `BINIT`, para validar memoria de ciclos.

## 10. Riesgos identificados antes de implementar

- Los manuales locales no dieron la tabla numerica exacta de `SWSHNT=2`; antes de congelar compatibilidad externa conviene confirmar esa codificacion en PSS/E o con una salida exportada.
- Sin salida PSS/E final, solo se puede validar coherencia interna y reduccion de violaciones, no identidad contra PSS/E.
- Los controles de generadores, limites Q, taps DC y shunts pueden interactuar; este issue debe mantener fijo el resto para no mezclar causas.
- `RMPCT` con suma 200 en varios grupos requiere prueba contra PSS/E o una politica claramente documentada; la implementacion actual preserva la participacion literal y la reporta por grupo.
- Las bandas de ancho cero pueden producir oscilacion si el control discreto no incluye memoria de estados.

## 11. Implementacion realizada

La implementacion quedo como extension opt-in de MP-Core:

```text
runpf_psse
  -> agrega mp.xt_psse a mpopt.exp.mpx
  -> fuerza el camino MP-Core compatible
  -> mp.xt_psse reemplaza mp.task_pf_legacy por mp.task_pf_psse
  -> mp.task_pf_psse.next_dm coordina el control
  -> mp.psse_swshunt_* contiene la logica especifica de switched shunts
```

Archivos agregados:

- `matpower/lib/+mp/xt_psse.m`
- `matpower/lib/+mp/task_pf_psse.m`
- `matpower/lib/+mp/psse_swshunt_control.m`
- `matpower/lib/+mp/psse_swshunt_states.m`
- `matpower/lib/+mp/psse_swshunt_update.m`
- `matpower/lib/+mp/psse_swshunt_report.m`
- `matpower/lib/t/t_mpxt_psse.m`

Archivos modificados:

- `matpower/lib/runpf_psse.m`
  - activa `mp.xt_psse` sin cambiar `runpf`.
  - falla explicitamente si las opciones fuerzan un camino incompatible con MP-Core.
- `matpower/lib/psse_parse.m`
  - preserva `SYSTEM-WIDE` en `data.system`, incluyendo `SOLVER/SWSHNT`, `ADJUST/MXTPSS` y `NEWTON/VCTOLV`.
- `matpower/lib/psse_convert.m`
  - preserva `mpc.psse.system`.
- `matpower/lib/t/t_psse.m`
  - valida preservacion de `SYSTEM-WIDE`.
- `matpower/lib/t/test_matpower.m`
  - registra `t_mpxt_psse` dentro del bloque MP-Core.

La logica implementada para este RAW cubre:

- `MODSW=0`: queda fijo en `BINIT`.
- `MODSW=1`: control discreto por estados fisicos de bloques `N/B` con `ADJM=0`.
- `MODSW=2`: control continuo dentro de `[Bmin, Bmax]`.
- `STAT=0`: no inyecta y no controla.
- `SWREG=0/local/remoto`: mapeo externo-interno, con fallback al bus propio si el remoto no es tipo 1/2.
- `RMPCT`: se aplica por grupo de bus regulado como participacion literal del requerimiento, sin normalizar a 100.
- `SWSHNT`: compuerta global; `SWSHNT=0` deshabilita el control y `SWSHNT=2` del RAW lo habilita.
- `BINIT`: se actualiza en `results.psse.swshunt.num(:, BINIT)` y el resumen queda en `results.psse.swshunt.control`.
- Grupos de control: los switched shunts se agrupan por bus regulado efectivo antes de elegir direccion de ajuste.
- Memoria de ciclos: se guarda la firma global de `BINIT`; si se repite un estado, se termina en el mejor estado visitado segun cantidad y suma de violaciones de banda.

La actualizacion de `BS` se hace reconstruyendo el data model desde `dm.source.bus(:, BS)`, no mutando `Ybus`, `makeYbus`, `makeSbus` ni `runpf`. Esto permite que un switched shunt con `BINIT=0` y bloques disponibles cree la fila de shunt necesaria en la siguiente iteracion formal.

## 12. Validacion antes/despues

Validaciones ejecutadas:

```text
t_mpxt_psse(0): All tests successful (25 of 25)
t_psse(0): All tests successful (168 of 168)
checkcode: limpio para los helpers switched shunt y herramientas nuevas.
```

Resultado sobre `PSSE/V26p_Trs_2532.raw`:

| Variante | success | iter PF final | iter DM | Automaticos | Bajo banda | Sobre banda | Fuera de banda | Suma BS |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| `psse2mpc + runpf` | 1 | 4 | 1 | 132 | 15 | 44 | 59 | 55.676 |
| `psse2mpc + runpf_psse` | 1 | 5 | 10 | 132 | 24 | 12 | 36 | -553.686 |

Diagnostico del control:

| Metrica | Valor |
|---|---:|
| Grupos regulados | 127 |
| Grupos con mas de un shunt | 5 |
| Maxima suma `RMPCT` de grupo | 200.0 |
| `BINIT` modificados | 27 |
| Suma `abs(dBINIT)` | 668.098 MVAr |
| Ajustes acumulados reportados | 103 |
| Ciclo global detectado/resuelto | 1 / 1 |
| `MXTPSS` alcanzado | 0 |

Mayores cambios de `BINIT`:

| Bus shunt | MODSW | Bus regulado | BINIT inicial | BINIT final | VM inicial | VM final | Banda |
|---:|---:|---:|---:|---:|---:|---:|---|
| 8010 | 1 | 8010 | 0.000 | -120.000 | 1.03096 | 0.97401 | `[0.970, 1.030]` |
| 4006 | 1 | 4006 | 0.000 | -80.000 | 1.03916 | 0.98482 | `[0.970, 1.030]` |
| 5002 | 1 | 5002 | 0.000 | -80.000 | 1.04183 | 1.02257 | `[0.970, 1.030]` |
| 5004 | 1 | 5004 | 0.000 | -80.000 | 1.03887 | 0.99685 | `[0.970, 1.030]` |
| 5013 | 1 | 5013 | 0.000 | -80.000 | 1.03887 | 0.99677 | `[0.970, 1.030]` |
| 95101 | 2 | 92100 | -51.820 | -88.000 | 1.03728 | 1.03163 | `[1.027, 1.027]` |
| 7513 | 1 | 7277 | 27.000 | 0.000 | 1.04585 | 1.03957 | `[0.980, 1.000]` |
| 49995 | 2 | 49995 | 159.580 | 185.948 | 1.08220 | 1.08999 | `[1.090, 1.090]` |

Comparacion contra la solucion guardada en el RAW:

El criterio primario de validacion numerica no debe ser `BINIT` final aislado. En este caso aun hay elementos PSS/E no modelados activamente en MATPOWER, por lo que los switched shunts pueden moverse de forma distinta aunque el control local sea razonable. Para medir cercania de solucion se compara primero contra `VM` y `VA` de buses guardados en el RAW, usando `auditoria_psse_matpower/tools/compare_v26p_raw_solution.m`.

| Variante | success | iter | max `abs(dVM)` | RMS `dVM` | max `abs(dVA)` | RMS `dVA` | Suma BS |
|---|---:|---:|---:|---:|---:|---:|---:|
| `runpf` | 1 | 4 | 0.203490 pu | 0.017994 pu | 6.431959 deg | 0.755465 deg | 55.676 |
| `runpf_psse` | 1 | 5 | 0.265253 pu | 0.015440 pu | 11.384248 deg | 0.482533 deg | -553.686 |

Los peores buses siguen siendo practicamente los mismos en ambas variantes (`46402`, `46202`, `46401`, `46201`, `46204`, etc.). El control agrupado mejora el RMS de `VM/VA` frente a la implementacion shunt-por-shunt anterior y reduce las violaciones internas de banda, pero las mayores diferencias contra la solucion RAW guardada permanecen concentradas en la misma zona electrica. Esto confirma que la calibracion fina no debe hacerse solo con `BINIT`; primero hay que clasificar si esas discrepancias dominantes vienen de elementos todavia no representados, diferencias de opciones de solucion o del algoritmo de switched shunts.

## 13. Riesgos y limites

- Los manuales locales no enumeran la tabla completa de codigos `SWSHNT`; se usa `0 = deshabilitado` y cualquier valor no cero como habilitado, preservando el valor exacto en el reporte.
- El criterio de bus reconocible sigue la auditoria local: bus propio tipo 1/2. La distincion documental fina entre bus tipo 2 de generacion fija y bus tipo 2 regulador de tension sigue sin datos adicionales en el conversor.
- Los grupos con suma `RMPCT=200` se tratan sin normalizacion automatica. Falta una salida PSS/E final para validar identidad de reparto, pero esa salida debe evaluarse principalmente por `VM/VA`, no solo por `BINIT`.
- La memoria de ciclos termina en el mejor estado `BINIT` visitado; esto evita oscilaciones indefinidas, pero no garantiza que todas las bandas discretas de ancho cero queden satisfechas.
- No se implementan controles activos `MODSW=3..6` ni `ADJM=1`, porque no aparecen en el RAW de referencia. Se preservan y reportan como no soportados para control activo.

## 14. Proximo issue recomendado

Antes de pasar a otra seccion del RAW, conviene conseguir una salida PSS/E real de solucion final que incluya tensiones, angulos y estado final de switched shunts. La referencia principal debe ser `VM/VA` por bus; `BINIT` queda como diagnostico auxiliar para entender que hizo el control. Con esa referencia se puede calibrar el reparto `RMPCT`, confirmar la codificacion exacta de `SWSHNT=2` y separar las discrepancias restantes entre limite fisico, anti-ciclo, diferencia de algoritmo PSS/E u otros elementos del RAW todavia no modelados.
