# Resultados `runcpf_psse`

## Archivos modificados

- `matpower/lib/runcpf_psse.m`
- `matpower/lib/+mp/task_cpf_psse.m`
- `matpower/lib/+mp/xt_psse.m`
- `matpower/lib/+mp/psse_mpx_options.m`
- `matpower/lib/+mp/psse_prepare_case.m`
- `matpower/lib/+mp/psse_sync_cpf_target.m`
- `matpower/lib/+mp/psse_cpf_compact_trace.m`
- `matpower/lib/runpf_psse.m`

## Diseno implementado

`runcpf_psse` activa MP-Core y `mp.xt_psse`, prepara base y target con la
misma politica `SYSTEM-WIDE` usada por `runpf_psse`, resuelve el punto base
con `runpf_psse`, sincroniza el active-set PSS/E hacia el target y llama al
CPF estandar de MATPOWER.

La formulacion CPF no se reemplaza por un barrido externo de PF. La curva
sigue entrando por `runcpf`, con `mp.task_cpf_psse` y el modelo aumentado:

```text
F(x, lambda) = 0
p(x, lambda) = 0
```

`mp.xt_psse` ahora reemplaza tambien:

```matlab
mp.task_cpf_legacy -> mp.task_cpf_psse
```

ademas del reemplazo PF ya existente:

```matlab
mp.task_pf_legacy -> mp.task_pf_psse
```

## Control PSS/E dentro del CPF

`mp.task_cpf_psse` incorpora un callback PNE interno. En cada punto CPF
aceptado:

1. reconstruye un contexto solucionado desde `nx.x` y `lambda`;
2. evalua los controles PSS/E en el orden de `mp.task_pf_psse`;
3. si un control cambia el active-set, registra un evento `PSSE_*`;
4. suspende el PNE con `s.warmstart`;
5. reconstruye base/target con el nuevo active-set;
6. recorrecta con `lambda` fijo;
7. restaura la tangente CPF con la parametrizacion de continuacion antes de
   seguir la curva.

El ultimo punto es importante para `cpf.stop_at = 'FULL'`: la re-correccion
a `lambda` fijo evita saltos al reconstruir el active-set PSS/E, pero la
tangente posterior debe conservar la orientacion pseudo-arco del CPF. Si se
continuaba con la tangente natural generada por esa re-correccion, el retorno
post-nose podia enganchar una trayectoria de alta tension y deformar la rama
inferior.

Para diagnostico, `results.cpf` conserva todos los puntos internos de
re-correccion. Para graficar curvas PV sin mostrar cada estado intermedio de
una cascada de controles, `runcpf_psse` agrega `results.cpf_psse_compact`.
Esta traza conserva el primer y ultimo punto de cada bloque de `lambda`
repetido y descarta solo los puntos intermedios.

Los eventos `PSSE_XFMR` y `PSSE_SWSHUNT` ahora incluyen el cambio aplicado en
el mensaje del evento: ramas y `TAP old->new` para transformadores, y buses y
`BINIT old->new` para switched shunts. El campo `idx` del evento apunta a las
ramas o buses afectados.

En CPF se corrigio ademas la memoria de ciclos de `PSSE_XFMR` y
`PSSE_SWSHUNT`: `cycle_resolved` y las firmas visitadas son locales al punto
de carga. En `runpf_psse` esa memoria vive solo durante un flujo; en CPF no
debe bloquear todo el resto de la curva despues de resolver un ciclo cerca de
la base.

El orden de control es:

```text
pqbrak -> xfmr -> genq -> twodc -> swshunt -> facts
```

con el orden diferido TWODC cuando corresponde.

Controles incorporados por esta ruta:

- `PQBRAK`
- taps de transformadores
- switched shunts
- GENQ / limites Q / regulacion remota
- two-terminal DC LCC opt-in
- FACTS
- opciones `SYSTEM-WIDE` preservadas y reportadas por `mp.psse_solver_options`

## Limitaciones conocidas

- Los controles PSS/E se disparan en puntos CPF aceptados. Todavia no hay una
  funcion de evento continua que localice con biseccion/secante el `lambda`
  exacto donde empieza a cambiar cada control.
- El two-terminal DC LCC sigue siendo secuencial interno: se calcula desde la
  solucion AC del punto CPF y actualiza el equivalente `dcline`/demandas. No
  hay Jacobiano AC/DC unificado.
- `PQBRAK` y TWODC reutilizan los helpers de `runpf_psse`; por lo tanto su
  fisica es la misma que en PF, ahora ejecutada dentro del lazo CPF.
- No se implemento una herramienta de barrido `lambda + runpf_psse`; no forma
  parte de la solucion principal.

## Validacion ejecutada

Setup comun:

```matlab
root = 'C:\Users\santi\Documents\UNIVERSIDAD\PROYECTO FINAL DE CARRERA - MATPOWER';
addpath(fullfile(root, 'matpower', 'lib'));
addpath(fullfile(root, 'matpower', 'lib', 't'));
addpath(fullfile(root, 'auditoria_psse_matpower'));
addpath(fullfile(root, 'auditoria_psse_matpower', 'results', 'transpa_reduccion_v1'));
```

### Caso sin metadata PSS/E

Comando: `runcpf` vs `runcpf_psse` sobre `t_case9_pfv2`, target con
`PD/QD = 2.5x`, `cpf.stop_at = 'NOSE'`.

```text
success runcpf=1 runcpf_psse=1
max_lam runcpf=0.836437772597 runcpf_psse=0.836437772597 diff=3.33e-16
trace dVM=8.55e-15 dVA=1.95e-14
task=mp.task_cpf_psse
```

### Base TRANSPA contra `runpf_psse`

Comando: `case_transpa_reduced_v1_explicit`, comparando `runpf_psse(mpcb)` con
`runcpf_psse(mpcb, mpcb)`.

```text
runpf_psse success=1 runcpf_psse success=1 max_lam=0
base diffs dVM=4.53e-14 dVA=4e-12 dQG=3.15e-10 dTAP=0
task=mp.task_cpf_psse
```

### TRANSPA explicito con target 2x

Comando: `case_transpa_reduced_v1_explicit`, target con `PD/QD = 2.0x`,
comparando `runcpf` y `runcpf_psse`.

```text
success standard=1 psse=1
max_lam standard=0.239544045986 psse=0.235969823315 diff=-0.00357422
iterations psse=90
done=Reached steady state loading limit in 90 continuation steps, lambda = 0.236.
events psse=20
```

Eventos PSS/E principales:

```text
PSSE_XFMR at lambda = 0.0038186497
PSSE_SWSHUNT at lambda = 0.0038186497
NOSE
```

Con `cpf.stop_at = 'FULL'`:

```text
success=1
max_lam=0.235926965667
points=160
events=21
```

La rama inferior fue validada comparando, para el mismo `lambda`, la tension
de la rama de retorno menos la tension de la rama superior. En barras criticas
la diferencia queda negativa, como corresponde:

```text
lambda   bus1000024  bus1000025  bus332    bus1000121  bus334
0.0200   -0.53065    -0.52997    -0.59238  -0.48118    -0.55443
0.1180   -0.39663    -0.39616    -0.44102  -0.36599    -0.41442
0.2159   -0.16192    -0.16174    -0.17950  -0.15126    -0.16919
```

En las barras de 500 kV la separacion es pequena porque no son las barras
criticas de colapso; aun asi la rama inferior queda levemente por debajo
salvo la barra slack/regulada:

```text
lambda   bus10      bus11      bus12      bus15      bus19      bus1008   bus901008
0.1180   -0.00092   0.00001    -0.00064   -0.00064   -0.00065   -0.00133  0.00000
```

Graficos generados:

```text
auditoria_psse_matpower/results/runcpf_psse_pv_500kv/runcpf_psse_full_pv_500kv_clean_split.png
auditoria_psse_matpower/results/runcpf_psse_pv_500kv/runcpf_psse_full_pv_critical_clean_split.png
auditoria_psse_matpower/results/runcpf_psse_pv_500kv/runcpf_psse_nose_pv_500kv_clean.png
```

Estados de control:

```text
xfmr adjustments=113 changed_last=0 max_iter=99 max_iter_reached=0
swshunt adjustments=2 changed_last=1 max_iter=99 max_iter_reached=0
```

### Trazas compactas para graficacion

Comando: `case_transpa_reduced_v1_explicit`, target con `PD/QD = 2.0x`,
`cpf.stop_at = 'FULL'`, `cpf.step = 0.005`.

```text
TRANSPA FULL success=1 max_lam=0.235960145459 points=103 events=53
compact_points=55 removed=48 groups=4
event_counts XFMR=16 SWSHUNT=2 PQBRAK=34
```

Ejemplo de evento enriquecido:

```text
PSSE_XFMR k=1 lambda=0.0003820805621
Changed TAP: branch 224 0.96->0.97, branch 227 0.96->0.97, branch 230 0.96->0.97, branch 236 1.06->1.07, branch 239 0.98133333->0.97066667, branch 242 1.05->1.06, +5 more.
```

Grafico comparativo de tres barras:

```text
auditoria_psse_matpower/results/runcpf_psse_transpa_control_pv/transpa_pv_3bus_compact_trace.png
```

Comparacion contra la convencion visual del prototipo `contPF`:

- El prototipo del PDF `CURVAS_PV_PROTOTIPO_COMB.pdf` grafica factor de carga
  y rama superior, no la traza cronologica `FULL` con rama de retorno.
- `contPF` guarda un estado final por flujo convergido despues de resolver
  ULTC/shunts; por eso los cambios discretos se ven como saltos verticales
  limpios.
- Para comparar con esa convencion, usar `results.cpf_psse_compact` y cortar
  la curva en `NOSE`.

Despues de hacer local por punto de carga la memoria de ciclos, `iterations`
y `max_iter_reached`, y de no contar los warmstarts PSS/E como nuevos pasos
CPF:

```text
TRANSPA NOSE after iter reset/warmstart guard: success=1 max_lam=0.217209766294 factor=1.21720976629 points=2271 events=2154
done_msg=Reached steady state loading limit in 117 continuation steps, lambda = 0.2172.
PSSE_XFMR count=1967 factors=1.000382081 ... 1.187175200
PSSE_SWSHUNT count=186 factors=1.000382081 ... 1.035319309
PSSE_PQBRAK count=0
XFMR iterations=1 max_iter=99 max_iter_reached=0 changed_last=1 num_adjustments=11414
SWSHUNT iterations=2 max_iter=99 max_iter_reached=0 changed_last=1 num_adjustments=186
```

Grafico comparable con el PDF, incluyendo zoom de los controles iniciales:

```text
auditoria_psse_matpower/results/runcpf_psse_transpa_control_pv/transpa_pv_3bus_nose_after_iter_reset.png
```

Nota: al dejar de contar warmstarts PSS/E como pasos de continuacion,
`event.k` ya no es un indice directo a `cpf.lam` para eventos PSS/E. El
script de validacion usa el `lambda` que queda escrito en el mensaje del
evento.

Comando reproducible:

```powershell
matlab -batch "cd('C:\Users\santi\Documents\UNIVERSIDAD\PROYECTO FINAL DE CARRERA - MATPOWER'); addpath('auditoria_psse_matpower'); run_transpa_iter_reset_validation"
```

Regresiones de compatibilidad despues del ajuste:

```text
case9 runcpf=1 runcpf_psse=1 dlam=0 dV=1.75e-14
transpa base runpf_psse=1 runcpf_psse=1 max_lam=0 dVM=4.53e-14 dVA=4e-12
```

### Sincronizacion SWDEV en CPF

El caso integrado de 14 barras con `SYSTEM SWITCHING DEVICE DATA`, ULTC,
switched shunts, FACTS y two-terminal DC mostro dos problemas de
sincronizacion:

- `psse_swdev_collapse()` no era idempotente cuando el caso ya estaba
  colapsado y podia indexar `branch_idx = 0`.
- La base del CPF se resolvia internamente con SWDEV colapsado, pero el
  resultado de `runpf_psse` se expandia antes de entrar a `runcpf`; el target
  quedaba colapsado.
- En la sincronizacion del target se preservaba `PD/QD` absoluto, borrando
  inyecciones equivalentes PSS/E como la del STATCON/FACTS en la barra 8. Esto
  dejaba distinta cantidad de elementos `load` entre base y target.

Correccion implementada:

- `psse_swdev_collapse()` ahora tolera metadata ya colapsada y filtra
  `branch_idx` validos antes de indexar `branch`.
- `runpf_psse()` acepta la opcion interna
  `mpopt.exp.psse_keep_swdev_collapsed` para llamadas CPF.
- `runcpf_psse()` resuelve el PF base manteniendo la topologia colapsada
  internamente, sincroniza el target con el delta de transferencia
  `target - base_ref`, y expande la salida final a la topologia original,
  incluyendo `cpf.V` y `cpf.V_hat`.

Validacion puntual:

```text
runpf_psse 14bus: success=1 nb=14 nbr=14
runcpf_psse 14bus: success=1 max_lam=2.21652768105 points=84 events=24 nb=14 cpfVrows=14
case9 runcpf vs runcpf_psse: dlam=2.22e-16 dV=5.58e-16
TRANSPA target 1.15x: success=1 max_lam=1.57313216884 points=99 events=19 nb=332
```

Buses clave:

```text
BUS 332  VM std=0.667222 psse=0.659902 VA std=-15.589744 psse=-15.665658
BUS 2222 VM std=0.715534 psse=0.716727 VA std=-3.838594  psse=-3.718731
BUS 1008 VM std=1.007688 psse=1.006570 VA std=12.202827  psse=12.258553
BUS 1226 VM std=1.024707 psse=1.023650 VA std=12.621365  psse=12.680422
BUS 2206 VM std=1.025028 psse=1.024723 VA std=2.221804   psse=2.257616
BUS 2208 VM std=1.025036 psse=1.024731 VA std=2.224086   psse=2.259893
BUS 2302 VM std=0.871902 psse=0.872612 VA std=2.875782   psse=2.943467
```

### Regresiones existentes

```matlab
t_cpf(0);
t_mpxt_psse(0);
```

Resultado:

```text
t_cpf(0): All tests successful (318 passed, 97 skipped of 415)
t_mpxt_psse(0): All tests successful (420 of 420)
```

### Higiene

```text
checkcode: clean en archivos nuevos/modificados
git diff --check: sin errores; solo avisos CRLF esperados en Windows
```
