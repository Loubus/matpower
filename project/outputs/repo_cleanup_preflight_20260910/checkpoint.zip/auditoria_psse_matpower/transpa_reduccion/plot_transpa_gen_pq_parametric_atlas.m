function atlas = plot_transpa_gen_pq_parametric_atlas(run_outdir)
%PLOT_TRANSPA_GEN_PQ_PARAMETRIC_ATLAS Plot true generator P-Q CPF traces.

if nargin < 1 || isempty(run_outdir)
    root = fileparts(fileparts(fileparts(mfilename('fullpath'))));
    run_outdir = fullfile(root, 'auditoria_psse_matpower', 'results', ...
        'runcpf_psse_transpa_no_ultc_no_swshunt_genredispatch_rho040_min1mw_capability_trace');
end

root = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(fullfile(root, 'matpower', 'lib'));

mat_file = fullfile(run_outdir, ...
    'runcpf_psse_transpa_repaired_swshunt_bands.mat');
trace_file = fullfile(run_outdir, 'gen_pq_trace.mat');
if exist(mat_file, 'file') ~= 2
    error('plot_transpa_gen_pq_parametric_atlas:missing_run_mat', ...
        'Run MAT file not found: %s', mat_file);
end
if exist(trace_file, 'file') ~= 2
    error('plot_transpa_gen_pq_parametric_atlas:missing_trace_mat', ...
        'Generator P-Q trace file not found: %s', trace_file);
end

S = load(mat_file, 'cpf_results', 'mpc_base', 'summary');
T = load(trace_file, 'gen_pq_trace');
cpf_results = S.cpf_results;
mpc_base = S.mpc_base;
summary = S.summary;
gen_pq_trace = T.gen_pq_trace;

define_constants;
atlas_dir = fullfile(run_outdir, 'gen_pq_parametric_atlas');
if ~exist(atlas_dir, 'dir')
    mkdir(atlas_dir);
end

audit = check_gen_capability(cpf_results);
elements = audit.elements(:);
[lam, PG_trace, QG_trace] = trace_matrices( ...
    gen_pq_trace, mpc_base, cpf_results, PG, QG);

per_page = 6;
n_pages = ceil(numel(elements) / per_page);
page_paths = strings(n_pages, 1);
for page = 1:n_pages
    idx = (page - 1) * per_page + (1:per_page);
    idx = idx(idx <= numel(elements));
    page_paths(page) = plot_parametric_page(atlas_dir, page, ...
        elements, idx, lam, PG_trace, QG_trace);
end

csv_file = write_trace_points(atlas_dir, elements, lam, PG_trace, QG_trace);
readme_file = write_readme(atlas_dir, run_outdir, trace_file, summary, ...
    audit, lam, page_paths, csv_file);

atlas = struct( ...
    'atlas_dir', atlas_dir, ...
    'page_paths', page_paths, ...
    'csv_file', string(csv_file), ...
    'readme_file', string(readme_file), ...
    'lambda', lam );

fprintf('Generator parametric P-Q atlas written to:\n  %s\n', atlas_dir);
fprintf('pages=%d trace_points=%d lambda=[%.12g, %.12g]\n', ...
    numel(page_paths), numel(lam), min(lam), max(lam));


function [lam, PG_trace, QG_trace] = trace_matrices( ...
        gen_pq_trace, mpc_base, results, PG, QG)
ng = size(mpc_base.gen, 1);
n_trace = numel(gen_pq_trace);
lam = NaN(n_trace + 1, 1);
PG_trace = NaN(ng, n_trace + 1);
QG_trace = NaN(ng, n_trace + 1);

lam(1) = 0;
PG_trace(:, 1) = mpc_base.gen(:, PG);
QG_trace(:, 1) = mpc_base.gen(:, QG);
for k = 1:n_trace
    rec = gen_pq_trace(k);
    lam(k + 1) = rec.lambda;
    g = rec.gen_idx(:);
    good = isfinite(g) & g >= 1 & g <= ng;
    g = g(good);
    PG_trace(g, k + 1) = rec.PG(good);
    QG_trace(g, k + 1) = rec.QG(good);
end

max_lam = max(results.cpf.lam(:));
need_final = isempty(lam) || ~isfinite(lam(end)) || ...
    abs(lam(end) - max_lam) > 1e-10;
if need_final
    lam(end + 1, 1) = max_lam;
    PG_trace(:, end + 1) = results.gen(:, PG);
    QG_trace(:, end + 1) = results.gen(:, QG);
else
    missing = isnan(PG_trace(:, end)) | isnan(QG_trace(:, end));
    PG_trace(missing, end) = results.gen(missing, PG);
    QG_trace(missing, end) = results.gen(missing, QG);
end


function file = plot_parametric_page(atlas_dir, page, elements, idx, ...
        lam, PG_trace, QG_trace)
fig = figure('Visible', 'off', 'Color', 'w', ...
    'Position', [50 50 1700 1050]);
tl = tiledlayout(fig, 2, 3, 'TileSpacing', 'compact', ...
    'Padding', 'compact');
ttl = title(tl, sprintf(['Generator capability boundaries with solved ' ...
    'P-Q(lambda) traces, page %02d'], page), 'Interpreter', 'none');
ttl.Color = 'k';
colormap(fig, turbo(256));
for kk = 1:numel(idx)
    e = elements(idx(kk));
    ax = nexttile(tl);
    style_axes(ax);
    hold(ax, 'on');
    plot_capability_boundary(ax, e.info.curve);
    g = e.idx;
    valid = isfinite(PG_trace(g, :)) & isfinite(QG_trace(g, :)) & ...
        isfinite(lam(:)');
    P = PG_trace(g, valid);
    Q = QG_trace(g, valid);
    L = lam(valid);
    plot(ax, P, Q, '-', 'Color', [0.16 0.16 0.16], ...
        'LineWidth', 0.8);
    scatter(ax, P, Q, 14, L, 'filled', ...
        'MarkerFaceAlpha', 0.85, 'MarkerEdgeColor', 'none');
    plot(ax, P(1), Q(1), 'o', 'MarkerSize', 6, 'LineWidth', 1.2, ...
        'MarkerFaceColor', [0.1 0.45 0.95], ...
        'MarkerEdgeColor', [0.1 0.45 0.95]);
    plot(ax, P(end), Q(end), 's', 'MarkerSize', 6, 'LineWidth', 1.2, ...
        'MarkerFaceColor', [0.02 0.02 0.02], ...
        'MarkerEdgeColor', [0.02 0.02 0.02]);
    grid(ax, 'on');
    axis(ax, 'equal');
    clim(ax, [min(lam) max(lam)]);
    set_axis_limits(ax, e.info.curve, P, Q);
    xlabel(ax, 'P (MW)');
    ylabel(ax, 'Q (MVAr)');
    ax_title = title(ax, sprintf('gen %d bus %g %s | Smax %.1f MVA', ...
        e.idx, e.bus, e.info.gen_type, e.info.Smax), ...
        'Interpreter', 'none');
    ax_title.Color = 'k';
    if kk == numel(idx)
        cb = colorbar(ax);
        cb.Color = 'k';
        ylabel(cb, 'lambda');
    end
end
file = fullfile(atlas_dir, sprintf('gen_pq_parametric_page_%02d.png', page));
print(fig, file, '-dpng', '-r150');
close(fig);
file = string(file);


function plot_capability_boundary(ax, curve)
if isempty(curve) || ~isstruct(curve) || ~isfield(curve, 'PA')
    return;
end
if all(isfield(curve, {'PA', 'QA', 'PB', 'QB', 'PC', 'QC'})) && ...
        ~isfield(curve, 'PD')
    P = [curve.PA curve.PB curve.PC curve.PC curve.PB curve.PA];
    Q = [curve.QA curve.QB curve.QC -curve.QC -curve.QB -curve.QA];
elseif all(isfield(curve, ...
        {'PA', 'QA', 'PB', 'QB', 'PC', 'QC', 'PD', 'QD', 'QE'}))
    q0 = (curve.QA^2 - curve.PB^2 - curve.QB^2) / ...
        (2 * curve.QA - 2 * curve.QB);
    s0 = curve.QA - q0;
    p_arc = linspace(curve.PA, curve.PB, 60);
    q_arc = sqrt(max(0, s0^2 - p_arc.^2)) + q0;
    P = [curve.PA p_arc curve.PB curve.PC curve.PD curve.PA curve.PA];
    Q = [curve.QA q_arc curve.QB curve.QC curve.QD curve.QE curve.QA];
else
    return;
end
patch(ax, P, Q, [0.90 0.94 1.00], 'FaceAlpha', 0.30, ...
    'EdgeColor', 'none');
plot(ax, P, Q, 'k-', 'LineWidth', 1.2);


function style_axes(ax)
set(ax, ...
    'Color', 'w', ...
    'XColor', 'k', ...
    'YColor', 'k', ...
    'GridColor', [0.72 0.72 0.72], ...
    'MinorGridColor', [0.86 0.86 0.86]);


function set_axis_limits(ax, curve, P, Q)
x = P(:);
y = Q(:);
if ~isempty(curve) && isstruct(curve)
    names = fieldnames(curve);
    for k = 1:numel(names)
        if startsWith(names{k}, 'P') && isscalar(curve.(names{k}))
            x(end + 1, 1) = curve.(names{k}); %#ok<AGROW>
        elseif startsWith(names{k}, 'Q') && isscalar(curve.(names{k}))
            y(end + 1, 1) = curve.(names{k}); %#ok<AGROW>
        end
    end
end
x = x(isfinite(x));
y = y(isfinite(y));
if isempty(x) || isempty(y)
    return;
end
px = max(max(x) - min(x), 1) * 0.08;
py = max(max(y) - min(y), 1) * 0.08;
xlim(ax, [min(x) - px, max(x) + px]);
ylim(ax, [min(y) - py, max(y) + py]);


function csv_file = write_trace_points(atlas_dir, elements, lam, ...
        PG_trace, QG_trace)
gen_idx = [];
bus = [];
gen_type = {};
lambda = [];
P = [];
Q = [];
for eidx = 1:numel(elements)
    e = elements(eidx);
    g = e.idx;
    valid = isfinite(PG_trace(g, :)) & isfinite(QG_trace(g, :)) & ...
        isfinite(lam(:)');
    n = nnz(valid);
    gen_idx = [gen_idx; repmat(g, n, 1)]; %#ok<AGROW>
    bus = [bus; repmat(e.bus, n, 1)]; %#ok<AGROW>
    gen_type = [gen_type; repmat({e.info.gen_type}, n, 1)]; %#ok<AGROW>
    lambda = [lambda; lam(valid)]; %#ok<AGROW>
    P = [P; PG_trace(g, valid)']; %#ok<AGROW>
    Q = [Q; QG_trace(g, valid)']; %#ok<AGROW>
end
gen_type = string(gen_type);
T = table(gen_idx, bus, gen_type, lambda, P, Q, ...
    'VariableNames', {'gen_idx', 'bus', 'gen_type', 'lambda', ...
    'P_MW', 'Q_MVAr'});
csv_file = fullfile(atlas_dir, 'gen_pq_parametric_trace_points.csv');
writetable(T, csv_file);


function readme_file = write_readme(atlas_dir, run_outdir, trace_file, ...
        summary, audit, lam, page_paths, csv_file)
readme_file = fullfile(atlas_dir, 'README.md');
fid = fopen(readme_file, 'w');
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, '# Generator P-Q parametric trace atlas\n\n');
fprintf(fid, 'Source run: `%s`\n\n', run_outdir);
fprintf(fid, 'Trace file: `%s`\n\n', trace_file);
fprintf(fid, '- max lambda: `%.15g`\n', summary.max_lambda);
fprintf(fid, '- trace lambda range: `%.15g` to `%.15g`\n', ...
    min(lam), max(lam));
fprintf(fid, '- trace callback points, including base: `%d`\n', numel(lam));
fprintf(fid, '- audited generators: `%d`\n', audit.count);
fprintf(fid, '- final capability violations: `%d`\n', audit.violations);
fprintf(fid, '- plot pages: `%d`\n\n', numel(page_paths));
fprintf(fid, ['Each subplot shows the full generic capability boundary ' ...
    'for that generator and the solved CPF generator setpoint path ' ...
    '`(P(lambda), Q(lambda))` from lambda 0 through the last accepted CPF ' ...
    'value. The blue circle is the base point and the black square is the ' ...
    'last recorded point.\n\n']);
fprintf(fid, '## Files\n\n');
for k = 1:numel(page_paths)
    fprintf(fid, '- `%s`\n', page_paths(k));
end
fprintf(fid, '- `%s`\n', csv_file);
