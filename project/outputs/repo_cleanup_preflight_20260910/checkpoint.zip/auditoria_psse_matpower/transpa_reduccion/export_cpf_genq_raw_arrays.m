function export_cpf_genq_raw_arrays()
%EXPORT_CPF_GENQ_RAW_ARRAYS Export CPF diagnostic MAT data for plotting.

root = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(fullfile(root, 'matpower', 'lib'));
addpath(fullfile(root, 'matpower', 'lib', 't'));
addpath(fullfile(root, 'auditoria_psse_matpower'));
addpath(fullfile(root, 'auditoria_psse_matpower', 'results', ...
    'transpa_reduccion_v1'));
outdir = fullfile(root, 'auditoria_psse_matpower', 'results', ...
    'runcpf_psse_transpa_genq_ultc_swshunt');
raw_file = fullfile(outdir, 'cpf_genq_ultc_swshunt_raw.mat');
load(raw_file, 'cpf_results', 'success', 'load_scale');

define_constants;
lam = cpf_results.cpf.lam(:);
vmag = abs(cpf_results.cpf.V);
bus_meta = cpf_results.bus(:, [BUS_I BASE_KV VM]);
writematrix(lam, fullfile(outdir, 'cpf_lambda.csv'));
writematrix(vmag, fullfile(outdir, 'cpf_vmag.csv'));
writematrix(bus_meta, fullfile(outdir, 'cpf_bus_meta.csv'));

if isfield(cpf_results.cpf, 'events') && ~isempty(cpf_results.cpf.events)
    names = string({cpf_results.cpf.events.name})';
    [u, ~, ic] = unique(names);
    counts = accumarray(ic, 1);
    writetable(table(u, counts, 'VariableNames', {'event', 'count'}), ...
        fullfile(outdir, 'event_counts.csv'));
    write_event_details(fullfile(outdir, 'event_details.csv'), ...
        cpf_results.cpf.events);
else
    writetable(table(string.empty(0, 1), zeros(0, 1), ...
        'VariableNames', {'event', 'count'}), ...
        fullfile(outdir, 'event_counts.csv'));
end

[min_v, min_idx] = min(cpf_results.bus(:, VM));
summary = table(success, max(lam), numel(lam), ...
    numel(cpf_results.cpf.events), cpf_results.bus(min_idx, BUS_I), ...
    min_v, load_scale, ...
    'VariableNames', {'success', 'max_lambda', 'points', 'events', ...
    'final_min_v_bus', 'final_min_v', 'load_scale'});
writetable(summary, fullfile(outdir, 'summary_metrics.csv'));

if isfield(cpf_results, 'psse') && isfield(cpf_results.psse, 'genq') && ...
        isfield(cpf_results.psse.genq, 'control')
    c = cpf_results.psse.genq.control;
    genq = table(c.enabled, c.active, c.local, c.remote, ...
        c.limited_count, c.at_min_count, c.at_max_count, ...
        c.num_adjustments, ...
        'VariableNames', {'enabled', 'active', 'local', 'remote', ...
        'limited_count', 'at_min_count', 'at_max_count', ...
        'num_adjustments'});
    writetable(genq, fullfile(outdir, 'genq_final_control.csv'));
end

[mpcb0, ~] = case_transpa_reduced_v1_explicit();
write_curve_sets(outdir, mpcb0, bus_meta, vmag);

fprintf('Exported CPF arrays to %s\n', outdir);
end

function write_event_details(path, events)
event_no = (1:numel(events))';
name = string({events.name})';
k = arrayfun(@(e) e.k, events(:));
lambda = NaN(numel(events), 1);
msg = strings(numel(events), 1);
for ii = 1:numel(events)
    msg(ii) = string(events(ii).msg);
    tok = regexp(events(ii).msg, 'lambda = ([0-9.Ee+-]+)', ...
        'tokens', 'once');
    if ~isempty(tok)
        lambda(ii) = str2double(tok{1});
    end
end
writetable(table(event_no, name, k, lambda, msg), path);
end

function write_curve_sets(outdir, mpc, bus_meta, vmag)
bus_ids = bus_meta(:, 1);
base_kv = bus_meta(:, 2);
physical = bus_ids < 900000;
sets = table(string.empty(0, 1), zeros(0, 1), ...
    'VariableNames', {'set_name', 'bus_i'});
sets = append_set(sets, 'all_physical', bus_ids(physical));
sets = append_set(sets, 'boundary_ports', [1008; 1226; 2206; 2208; 2222; 2302]);
sets = append_set(sets, 'buses_500kv', bus_ids(physical & base_kv >= 400));
sets = append_set(sets, 'switched_shunt_buses', swshunt_buses(mpc));
sets = append_set(sets, 'genq_generator_buses', genq_buses(mpc));
sets = append_set(sets, 'genq_regulated_buses', genq_regulated_buses(mpc));
sets = append_set(sets, 'ultc_terminal_buses', xfmr_terminal_buses(mpc));

drop = vmag(:, 1) - vmag(:, end);
drop(~physical) = -Inf;
[~, ord_drop] = sort(drop, 'descend');
sets = append_set(sets, 'worst_40_voltage_drop', ...
    bus_ids(ord_drop(1:min(40, nnz(isfinite(drop))))));

final_v = vmag(:, end);
final_v(~physical) = Inf;
[~, ord_low] = sort(final_v, 'ascend');
sets = append_set(sets, 'lowest_40_final_voltage', ...
    bus_ids(ord_low(1:min(40, nnz(isfinite(final_v))))));
writetable(sets, fullfile(outdir, 'curve_sets.csv'));
end

function sets = append_set(sets, name, buses)
buses = unique(buses(:));
buses(isnan(buses) | buses == 0) = [];
if isempty(buses)
    return;
end
sets = [sets; table(repmat(string(name), numel(buses), 1), buses, ...
    'VariableNames', {'set_name', 'bus_i'})];
end

function buses = swshunt_buses(mpc)
buses = [];
if isfield(mpc.psse, 'swshunt') && isfield(mpc.psse.swshunt, 'num')
    c = psse_col(mpc.psse.swshunt.colnames, 'I');
    if c > 0
        buses = unique(mpc.psse.swshunt.num(:, c));
    end
end
end

function buses = genq_buses(mpc)
buses = [];
if isfield(mpc.psse, 'genq') && isfield(mpc.psse.genq, 'bus_ext')
    rows = mpc.psse.genq.status ~= 0;
    buses = unique(mpc.psse.genq.bus_ext(rows));
end
end

function buses = genq_regulated_buses(mpc)
buses = [];
if isfield(mpc.psse, 'genq') && isfield(mpc.psse.genq, 'reg_bus_ext')
    rows = mpc.psse.genq.status ~= 0;
    reg = mpc.psse.genq.reg_bus_ext(rows);
    reg(reg == 0 | isnan(reg)) = [];
    buses = unique(reg);
end
end

function buses = xfmr_terminal_buses(mpc)
buses = [];
if isfield(mpc.psse, 'xfmr') && isfield(mpc.psse.xfmr, 'two')
    x = mpc.psse.xfmr.two;
    i = psse_col(x.colnames, 'I');
    j = psse_col(x.colnames, 'J');
    stat = psse_col(x.colnames, 'STAT');
    rows = true(size(x.num, 1), 1);
    if stat > 0
        rows = x.num(:, stat) ~= 0;
    end
    buses = [buses; x.num(rows, i); x.num(rows, j)];
end
if isfield(mpc.psse, 'xfmr') && isfield(mpc.psse.xfmr, 'three')
    x = mpc.psse.xfmr.three;
    i = psse_col(x.colnames, 'I');
    j = psse_col(x.colnames, 'J');
    k = psse_col(x.colnames, 'K');
    stat = psse_col(x.colnames, 'STAT');
    rows = true(size(x.num, 1), 1);
    if stat > 0
        rows = x.num(:, stat) ~= 0;
    end
    buses = [buses; x.num(rows, i); x.num(rows, j); x.num(rows, k)];
end
buses = unique(buses);
buses(isnan(buses) | buses == 0) = [];
end

function col = psse_col(cols, name)
col = find(strcmpi(cols, name), 1);
if isempty(col)
    col = 0;
end
end
