function results = run_transpa_cpf_psse(opts)
%RUN_TRANSPA_CPF_PSSE Canonical reduced TRANSPA CPF/PSS-E runner.
%
% This thin wrapper exposes the dedicated implementation folder without
% requiring callers to add that subfolder manually.

runner_dir = fullfile(fileparts(mfilename('fullpath')), 'cpf_psse_runner');
if ~contains(path, runner_dir)
    addpath(runner_dir);
end

if nargin < 1
    opts = struct();
end
results = transpa_cpf_run(opts);
end
