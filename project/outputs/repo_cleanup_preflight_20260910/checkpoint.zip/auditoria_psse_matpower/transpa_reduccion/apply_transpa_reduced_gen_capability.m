function [mpc, classification] = apply_transpa_reduced_gen_capability(mpc, outdir)
%APPLY_TRANSPA_REDUCED_GEN_CAPABILITY Add generator capability metadata.
%
% Classifies the reduced TRANSPA generators by retained bus name and assigns
% Smax from GEN(:, MBASE). SADI boundary equivalents are documented but not
% enforced as physical generators.

if nargin < 2
    outdir = '';
end

define_constants;
ng = size(mpc.gen, 1);
bus_names = transpa_bus_names(mpc, GEN_BUS);

Smax = mpc.gen(:, MBASE);
Smax(~isfinite(Smax) | Smax <= 0) = mpc.baseMVA;
gen_type = 2 * ones(ng, 1);
enforce = true(ng, 1);
type_name = repmat({'thermal'}, ng, 1);
rule = repmat({'default_physical_thermal'}, ng, 1);

for g = 1:ng
    name = upper(strtrim(bus_names{g}));
    if startsWith(name, 'SADI_EQ_')
        enforce(g) = false;
        type_name{g} = 'equivalent';
        rule{g} = 'sadi_boundary_equivalent_not_enforced';
    elseif contains(name, 'EO')
        gen_type(g) = 3;
        type_name{g} = 'wind';
        rule{g} = 'bus_name_contains_EO';
    elseif startsWith(name, 'FUTAHI') || startsWith(name, 'AMEGHI')
        gen_type(g) = 1;
        type_name{g} = 'hydraulic';
        rule{g} = 'known_hydro_bus_name';
    else
        gen_type(g) = 2;
        type_name{g} = 'thermal';
        rule{g} = 'default_physical_thermal';
    end
end

mpc.gen_capability.Smax = Smax;
mpc.gen_capability.type = gen_type;
mpc.gen_capability.enforce = enforce;
mpc.gen_capability.classification_rule = rule;

classification = table((1:ng)', mpc.gen(:, GEN_BUS), bus_names(:), ...
    mpc.gen(:, GEN_STATUS), mpc.gen(:, PG), mpc.gen(:, QG), ...
    mpc.gen(:, MBASE), Smax, gen_type, type_name, enforce, rule, ...
    'VariableNames', {'gen_row', 'bus', 'bus_name', 'status', ...
    'PG', 'QG', 'MBASE', 'Smax', 'gen_type_code', 'gen_type', ...
    'enforce', 'classification_rule'});

if ~isempty(outdir)
    if ~exist(outdir, 'dir')
        mkdir(outdir);
    end
    writetable(classification, fullfile(outdir, ...
        'transpa_reduced_gen_capability_classification.csv'));
end

function names = transpa_bus_names(mpc, GEN_BUS)
[~, ~, ~, ~, BUS_I] = idx_bus;
ng = size(mpc.gen, 1);
names = repmat({''}, ng, 1);
has_names = isfield(mpc, 'bus_name') && length(mpc.bus_name) == size(mpc.bus, 1);
for g = 1:ng
    row = find(mpc.bus(:, BUS_I) == mpc.gen(g, GEN_BUS), 1);
    if has_names && ~isempty(row)
        names{g} = char(mpc.bus_name(row));
    elseif ~isempty(row)
        names{g} = sprintf('BUS_%g', mpc.bus(row, BUS_I));
    else
        names{g} = sprintf('BUS_%g', mpc.gen(g, GEN_BUS));
    end
end
