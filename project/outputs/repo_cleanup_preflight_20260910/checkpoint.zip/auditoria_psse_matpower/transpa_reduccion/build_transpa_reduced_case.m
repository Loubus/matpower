function results = build_transpa_reduced_case(varargin)
% build_transpa_reduced_case - Build and validate a reduced TRANSPA case.
%
% This first implementation keeps the TRANSPA/Rio Negro/Bahia Blanca buses
% identified from the RAW/PDF review, replaces every external cut by a
% finite Thevenin source behind an impedance, and writes audit tables.
%
% The full multi-port Norton/Thevenin equivalent is written with equivalent
% source-to-port and port-to-port branches. The exported case is validated
% with runpf_psse(); the standard runpf() result is kept only as a secondary
% smoke check.

define_constants;

root = fileparts(fileparts(fileparts(mfilename('fullpath'))));
raw_file = fullfile(root, 'PSSE', 'V26p_Trs_2532.raw');
out_dir = fullfile(root, 'auditoria_psse_matpower', 'results', 'transpa_reduccion_v1');
if nargin >= 1 && ~isempty(varargin{1})
    raw_file = varargin{1};
end
if nargin >= 2 && ~isempty(varargin{2})
    out_dir = varargin{2};
end
if ~exist(out_dir, 'dir')
    mkdir(out_dir);
end

addpath(genpath(fullfile(root, 'matpower', 'lib')));

mpopt = mpoption('verbose', 0, 'out.all', 0);
mpc_full = psse2mpc(raw_file, 0, 34);
[records, sections] = psse_read(raw_file, 0);
[psse_data, parse_warns] = psse_parse(records, sections, 0, 34);
pf_full = runpf_psse(mpc_full, mpopt);
if pf_full.success
    mpc_ref = operating_point_case(mpc_full, pf_full);
else
    warning('build_transpa_reduced_case:full_pf_failed', ...
        'Full RAW runpf_psse did not converge; falling back to RAW snapshot calibration.');
    mpc_ref = mpc_full;
end

cfg = transpa_reduction_config(psse_data);
[retained, retained_reason] = retained_bus_set(mpc_full, psse_data, cfg);
[cut, internal_branch, physical_ports] = classify_boundaries(mpc_full, retained);

eq = compute_external_equivalent(mpc_ref, retained, physical_ports, cut, internal_branch, cfg);
eq.reference_case_source = ternary_string(pf_full.success, ...
    'full_raw_runpf_psse', 'raw_snapshot');
[mpc_red, eq] = build_vanilla_case(mpc_ref, retained, internal_branch, eq.ports, eq);

pf_psse = runpf_psse(mpc_red, mpopt);
pf_standard = runpf(mpc_red, mpopt);
validation = validate_reduction(mpc_ref, pf_psse, retained, eq.ports, eq, 'runpf_psse');
validation_standard = validate_reduction(mpc_ref, pf_standard, retained, eq.ports, eq, 'runpf');

results = struct();
results.raw_file = raw_file;
results.output_dir = out_dir;
results.config = cfg;
results.parse_warnings = parse_warns;
results.full_runpf_psse = pf_full;
results.reference_case_source = ternary_string(pf_full.success, ...
    'full_raw_runpf_psse', 'raw_snapshot');
results.retained = retained;
results.retained_reason = retained_reason;
results.cut = cut;
results.physical_ports = physical_ports;
results.ports = eq.ports;
results.equivalent = eq;
results.mpc_reduced = mpc_red;
results.runpf_psse = pf_psse;
results.runpf_standard = pf_standard;
results.validation = validation;
results.validation_standard = validation_standard;

save(fullfile(out_dir, 'transpa_reduction_v1.mat'), 'results');
case_file = fullfile(out_dir, 'case_transpa_reduced_v1.m');
psse_sidecar_file = fullfile(out_dir, 'case_transpa_reduced_v1_psse.mat');
savecase(case_file, mpc_red);
write_psse_sidecar_case(case_file, psse_sidecar_file, mpc_red);
write_audit_tables(out_dir, mpc_full, psse_data, retained, retained_reason, cut, eq.ports, eq, validation);

fprintf('Reduced TRANSPA case written to:\n  %s\n', out_dir);
fprintf('Full RAW runpf_psse success: %d\n', pf_full.success);
fprintf('Retained buses: %d, cut branches: %d, equivalent ports: %d\n', ...
    numel(retained), height(cut), numel(eq.ports));
fprintf('runpf_psse success: %d, max |dVM| = %.6g pu, RMS |dVM| = %.6g pu\n', ...
    pf_psse.success, validation.max_abs_dvm, validation.rms_dvm);
fprintf('max |dVA| = %.6g deg, RMS |dVA| = %.6g deg\n', ...
    validation.max_abs_dva, validation.rms_dva);
end

function mpc_ref = operating_point_case(mpc, pf)
define_constants;
[GEN_BUS] = idx_gen;

mpc_ref = mpc;

[tf_bus, loc_bus] = ismember(mpc.bus(:, BUS_I), pf.bus(:, BUS_I));
if all(tf_bus)
    ncol = min(size(mpc.bus, 2), size(pf.bus, 2));
    mpc_ref.bus(:, 2:ncol) = pf.bus(loc_bus, 2:ncol);
    mpc_ref.bus(:, BUS_I) = mpc.bus(:, BUS_I);
end

if size(mpc.branch, 1) == size(pf.branch, 1)
    ncol = min(size(mpc.branch, 2), size(pf.branch, 2));
    if ncol >= BR_R
        mpc_ref.branch(:, BR_R:ncol) = pf.branch(:, BR_R:ncol);
    end
    mpc_ref.branch(:, F_BUS) = mpc.branch(:, F_BUS);
    mpc_ref.branch(:, T_BUS) = mpc.branch(:, T_BUS);
end

if size(mpc.gen, 1) == size(pf.gen, 1)
    ncol = min(size(mpc.gen, 2), size(pf.gen, 2));
    mpc_ref.gen(:, 2:ncol) = pf.gen(:, 2:ncol);
    mpc_ref.gen(:, GEN_BUS) = mpc.gen(:, GEN_BUS);
end

if isfield(mpc, 'dcline') && isfield(pf, 'dcline') && ...
        size(mpc.dcline, 1) == size(pf.dcline, 1)
    ncol = min(size(mpc.dcline, 2), size(pf.dcline, 2));
    if ncol >= 3
        mpc_ref.dcline(:, 3:ncol) = pf.dcline(:, 3:ncol);
        mpc_ref.dcline(:, 1:2) = mpc.dcline(:, 1:2);
    end
end

if isfield(mpc, 'psse')
    mpc_ref.psse = mpc.psse;
end
end

function out = ternary_string(cond, yes_value, no_value)
if cond
    out = yes_value;
else
    out = no_value;
end
end

function cfg = transpa_reduction_config(psse_data)
cfg = struct();

% Bus numbers visible in the one-line PDF, extracted by text/image review.
cfg.pdf_visible_buses = [ ...
    10 11 12 15 19 100 115 117 118 200 220 230 240 243 250 ...
    264 266 271 300 310 311 315 320 322 330 400 401 402 403 ...
    408 410 420 440 441 442 446 448 450 456 457 460 480 495 ...
    504 522 547 720 721 1008 1226 2206 2208 2222 2302 ];

% The PDF aggregates ALUAR and many local low-voltage Patagonia devices; the
% RAW zones/areas are the traceable way to keep those local attachments.
cfg.keep_areas = [16 21];       % ALUAR, PATAGONI
cfg.keep_zones = [51 52 53];    % CHUBUT, STA CRUZ, ALUAR

% Explicit frontiers and local auxiliaries found during the read-only pass.
cfg.explicit_buses = [1008 1226 2206 2208 1804];
cfg.primary_ports = [1008 2206 2208];
cfg.reported_extra_ports = [1226 330 2222 2302];
cfg.external_transformer_block_buses = 2000; % B.BLANCA 500 kV remains external in v1.
cfg.collapse_equivalent_ports = [];
cfg.collapse_equivalent_representative = NaN;

zone_num = psse_data.zone.num(:, 1);
zone_txt = string(strtrim(psse_data.zone.txt(:, 2)));
cfg.zone_names = table(zone_num, zone_txt, 'VariableNames', {'zone', 'name'});
area_num = psse_data.area.num(:, 1);
area_txt = string(strtrim(psse_data.area.txt(:, 5)));
cfg.area_names = table(area_num, area_txt, 'VariableNames', {'area', 'name'});
end

function [retained, reason] = retained_bus_set(mpc, psse_data, cfg)
define_constants;

raw_bus = psse_data.bus.num(:, 1);
raw_area = psse_data.bus.num(:, 5);
raw_zone = psse_data.bus.num(:, 6);

seed = unique([ ...
    raw_bus(ismember(raw_area, cfg.keep_areas)); ...
    raw_bus(ismember(raw_zone, cfg.keep_zones)); ...
    cfg.pdf_visible_buses(:); ...
    cfg.explicit_buses(:) ]);
seed = seed(ismember(seed, mpc.bus(:, BUS_I)));

retained = seed(:);

% Transformer closure for local devices. This keeps secondary/tertiary buses
% attached to visible retained stations, while leaving the Bahia Blanca 500 kV
% transformer path outside the retained system for the SADI equivalent.
changed = true;
while changed
    changed = false;
    before = retained;
    for r = 1:size(psse_data.trans2.num, 1)
        if psse_data.trans2.num(r, 12) == 0
            continue;
        end
        buses = psse_data.trans2.num(r, 1:2).';
        if any(ismember(buses, retained)) && ...
                ~any(ismember(buses, cfg.external_transformer_block_buses))
            retained = unique([retained; buses]);
        end
    end
    for r = 1:size(psse_data.trans3.num, 1)
        if psse_data.trans3.num(r, 12) == 0
            continue;
        end
        buses = psse_data.trans3.num(r, 1:3).';
        if any(ismember(buses, retained)) && ...
                ~any(ismember(buses, cfg.external_transformer_block_buses))
            retained = unique([retained; buses]);
        end
    end
    if numel(retained) ~= numel(before) || any(retained ~= before)
        retained = retained(ismember(retained, mpc.bus(:, BUS_I)));
        changed = true;
    end
end

% Include MATPOWER auxiliary star-point buses for retained 3-winding
% transformers when at least two real retained windings use the same star.
aux = [];
for k = find(mpc.bus(:, BUS_I) >= 1e6).'
    aux_bus = mpc.bus(k, BUS_I);
    incident = find(mpc.branch(:, BR_STATUS) ~= 0 & ...
        (mpc.branch(:, F_BUS) == aux_bus | mpc.branch(:, T_BUS) == aux_bus));
    neighbors = unique([mpc.branch(incident, F_BUS); mpc.branch(incident, T_BUS)]);
    neighbors(neighbors == aux_bus) = [];
    if sum(ismember(neighbors, retained)) >= 2
        aux(end+1, 1) = aux_bus; %#ok<AGROW>
    end
end
retained = unique([retained; aux]);

reason = strings(numel(retained), 1);
for k = 1:numel(retained)
    b = retained(k);
    if ismember(b, cfg.pdf_visible_buses)
        reason(k) = "visible_pdf";
    elseif ismember(b, cfg.explicit_buses)
        reason(k) = "explicit_frontier_or_auxiliary";
    elseif b >= 1e6
        reason(k) = "matpower_3w_star_point";
    else
        idx = find(raw_bus == b, 1);
        if ~isempty(idx) && ismember(raw_area(idx), cfg.keep_areas)
            reason(k) = "raw_area_local";
        elseif ~isempty(idx) && ismember(raw_zone(idx), cfg.keep_zones)
            reason(k) = "raw_zone_local";
        else
            reason(k) = "transformer_winding_closure";
        end
    end
end
end

function [cut, internal_branch, ports] = classify_boundaries(mpc, retained)
define_constants;

active = mpc.branch(:, BR_STATUS) ~= 0;
from_retained = ismember(mpc.branch(:, F_BUS), retained);
to_retained = ismember(mpc.branch(:, T_BUS), retained);

internal_branch = active & from_retained & to_retained;
cut_mask = active & xor(from_retained, to_retained);
cut_idx = find(cut_mask);

port_bus = zeros(numel(cut_idx), 1);
external_bus = zeros(numel(cut_idx), 1);
for k = 1:numel(cut_idx)
    br = cut_idx(k);
    f = mpc.branch(br, F_BUS);
    t = mpc.branch(br, T_BUS);
    if ismember(f, retained)
        port_bus(k) = f;
        external_bus(k) = t;
    else
        port_bus(k) = t;
        external_bus(k) = f;
    end
end

cut = table(cut_idx, port_bus, external_bus, ...
    mpc.branch(cut_idx, F_BUS), mpc.branch(cut_idx, T_BUS), ...
    mpc.branch(cut_idx, BR_R), mpc.branch(cut_idx, BR_X), ...
    mpc.branch(cut_idx, BR_B), ...
    'VariableNames', {'branch_index', 'port_bus', 'external_bus', ...
    'f_bus', 't_bus', 'r_pu', 'x_pu', 'b_pu'});
ports = unique(port_bus(:)).';
end

function eq = compute_external_equivalent(mpc, retained, physical_ports, cut, internal_branch, cfg)
define_constants;

mpci = ext2int(mpc);
i2e = mpci.order.bus.i2e;
baseMVA = mpci.baseMVA;
V0 = mpci.bus(:, VM) .* exp(1j * pi / 180 * mpci.bus(:, VA));

% Full-network flows through every retained/external cut.
[~, Yf, Yt] = makeYbus(baseMVA, mpci.bus, mpci.branch);
S_cut_physical = zeros(numel(physical_ports), 1);
cut_internal_rows = zeros(height(cut), 1);
for r = 1:size(mpci.branch, 1)
    f_ext = i2e(mpci.branch(r, F_BUS));
    t_ext = i2e(mpci.branch(r, T_BUS));
    f_in = ismember(f_ext, retained);
    t_in = ismember(t_ext, retained);
    if ~xor(f_in, t_in)
        continue;
    end
    if f_in
        port_ext = f_ext;
        S = baseMVA * V0(mpci.branch(r, F_BUS)) * conj(Yf(r, :) * V0);
    else
        port_ext = t_ext;
        S = baseMVA * V0(mpci.branch(r, T_BUS)) * conj(Yt(r, :) * V0);
    end
    p = find(physical_ports == port_ext, 1);
    if ~isempty(p)
        S_cut_physical(p) = S_cut_physical(p) + S;
        cut_external_row = find(cut.f_bus == f_ext & cut.t_bus == t_ext, 1);
        if isempty(cut_external_row)
            cut_external_row = find(cut.f_bus == t_ext & cut.t_bus == f_ext, 1);
        end
        if ~isempty(cut_external_row)
            cut_internal_rows(cut_external_row) = r;
        end
    end
end

% Build passive external network: external buses plus retained ports, with
% all wholly retained branches removed and local port shunts zeroed.
port_ext = physical_ports(:);
external_ext = setdiff(mpc.bus(:, BUS_I), retained(:));
y_buses = [port_ext; external_ext(:)];
y_branch = mpc.branch;
y_branch(internal_branch, BR_STATUS) = 0;
keep_branch = ismember(y_branch(:, F_BUS), y_buses) & ismember(y_branch(:, T_BUS), y_buses);
y_branch(~keep_branch, BR_STATUS) = 0;

y_case = mpc;
y_case.bus = mpc.bus(ismember(mpc.bus(:, BUS_I), y_buses), :);
y_case.bus(ismember(y_case.bus(:, BUS_I), port_ext), [GS BS]) = 0;
y_case.branch = y_branch(keep_branch, :);
y_case.gen = zeros(0, size(mpc.gen, 2));
if isfield(y_case, 'dcline')
    y_case = rmfield(y_case, 'dcline');
end
if isfield(y_case, 'userfcn')
    y_case = rmfield(y_case, 'userfcn');
end
y_case = ext2int(y_case);
[Yext, ~, ~] = makeYbus(y_case.baseMVA, y_case.bus, y_case.branch);
ye2i = y_case.order.bus.e2i;
yp = ye2i(port_ext);
all_idx = (1:size(y_case.bus, 1)).';
ye = setdiff(all_idx, yp);

Ypp = Yext(yp, yp);
Ype = Yext(yp, ye);
Yep = Yext(ye, yp);
Yee = Yext(ye, ye);
Yeq_physical = Ypp - Ype * (Yee \ Yep);

Vport = mpc.bus(arrayfun(@(b)find(mpc.bus(:, BUS_I) == b, 1), port_ext), VM) .* ...
    exp(1j * pi / 180 * mpc.bus(arrayfun(@(b)find(mpc.bus(:, BUS_I) == b, 1), port_ext), VA));
[ports, physical_to_equiv, Tcollapse] = collapse_equivalent_ports(port_ext, cfg);
Yeq = Tcollapse.' * Yeq_physical * Tcollapse;
S_cut = Tcollapse.' * S_cut_physical;
Vgroup = zeros(numel(ports), 1);
for k = 1:numel(ports)
    idx = find(port_ext == ports(k), 1);
    Vgroup(k) = Vport(idx);
end
Vport = Vgroup;
S_ext0 = -S_cut;
I_ext0 = conj((S_ext0 / baseMVA) ./ Vport);
Inorton = I_ext0 + Yeq * Vport;

Ydiag = diag(Yeq);
Zdiag = 1 ./ Ydiag;
Eth_diag = Vport + I_ext0 ./ Ydiag;
Zmulti = pinv(full(Yeq));
Eth_multi = full(Yeq) \ Inorton;
Eth_multi_pinv = Vport + Zmulti * I_ext0;

eq = struct();
eq.baseMVA = baseMVA;
eq.physical_ports = port_ext;
eq.physical_to_equiv_port = physical_to_equiv;
eq.ports = ports;
eq.S_cut_physical_from_retained_MVA = S_cut_physical;
eq.Vport = Vport;
eq.S_cut_from_retained_MVA = S_cut;
eq.S_external_injection_MVA = S_ext0;
eq.I_external_injection_pu = I_ext0;
eq.Yeq = Yeq;
eq.Inorton = Inorton;
eq.Zdiag = Zdiag;
eq.Eth_diag = Eth_diag;
eq.Zmulti_pinv = Zmulti;
eq.Eth_multi = Eth_multi;
eq.Eth_multi_pinv = Eth_multi_pinv;
eq.cut_internal_rows = cut_internal_rows;
eq.Yeq_condest = condest(Yeq);
end

function [ports, physical_to_equiv, T] = collapse_equivalent_ports(physical_ports, cfg)
physical_to_equiv = physical_ports(:);
members = cfg.collapse_equivalent_ports(:);
rep = cfg.collapse_equivalent_representative;
if all(ismember(members, physical_ports))
    physical_to_equiv(ismember(physical_to_equiv, members)) = rep;
end
ports = unique(physical_to_equiv, 'stable');
T = zeros(numel(physical_ports), numel(ports));
for k = 1:numel(physical_ports)
    g = find(ports == physical_to_equiv(k), 1);
    T(k, g) = 1;
end
end

function [mpc_red, eq] = build_vanilla_case(mpc, retained, internal_branch, ports, eq)
define_constants;
[GEN_BUS, PG, QG, QMAX, QMIN, VG, MBASE, GEN_STATUS, PMAX, PMIN] = idx_gen;

mpc_red = struct();
mpc_red.version = '2';
mpc_red.baseMVA = mpc.baseMVA;

keep_bus = ismember(mpc.bus(:, BUS_I), retained);
mpc_red.bus = mpc.bus(keep_bus, :);
mpc_red.bus_name = mpc.bus_name(keep_bus);

keep_gen = ismember(mpc.gen(:, GEN_BUS), retained);
mpc_red.gen = mpc.gen(keep_gen, :);
for g = 1:size(mpc_red.gen, 1)
    bidx = find(mpc.bus(:, BUS_I) == mpc_red.gen(g, GEN_BUS), 1);
    if ~isempty(bidx)
        mpc_red.gen(g, VG) = mpc.bus(bidx, VM);
    end
end

mpc_red.branch = mpc.branch(internal_branch, :);

neq = numel(ports);
eq_bus = 900000 + ports(:);
existing = mpc_red.bus(:, BUS_I);
if any(ismember(eq_bus, existing))
    error('Equivalent bus numbering collision.');
end

template_bus = mpc_red.bus(1, :);
eq_rows = repmat(template_bus, neq, 1);
eq_rows(:, :) = 0;
eq_rows(:, BUS_I) = eq_bus;
eq_rows(:, BUS_TYPE) = REF;             % fixed multi-port source angle/magnitude
eq_rows(:, BASE_KV) = port_base_kv(mpc, ports);
eq_rows(:, VM) = abs(eq.Eth_multi);
eq_rows(:, VA) = angle(eq.Eth_multi) * 180 / pi;
eq_rows(:, VMAX) = 1.2;
eq_rows(:, VMIN) = 0.8;
mpc_red.bus = [mpc_red.bus; eq_rows];
mpc_red.bus_name = [mpc_red.bus_name; arrayfun(@(p)sprintf('SADI_EQ_%d', p), ports(:), 'UniformOutput', false)];

gen_cols = size(mpc.gen, 2);
eq_gen = zeros(neq, gen_cols);
for k = 1:neq
    y = full(eq.Yeq(:, k));
    i_src = sum(y .* (eq.Eth_multi(k) - eq.Vport));
    s_src = mpc.baseMVA * eq.Eth_multi(k) * conj(i_src);
    eq_gen(k, GEN_BUS) = eq_bus(k);
    eq_gen(k, PG) = real(s_src);
    eq_gen(k, QG) = imag(s_src);
    eq_gen(k, QMAX) = 99999;
    eq_gen(k, QMIN) = -99999;
    eq_gen(k, VG) = abs(eq.Eth_multi(k));
    eq_gen(k, MBASE) = mpc.baseMVA;
    eq_gen(k, GEN_STATUS) = 1;
    eq_gen(k, PMAX) = 99999;
    eq_gen(k, PMIN) = -99999;
end
mpc_red.gen = [mpc_red.gen; eq_gen];

branch_offset = size(mpc_red.branch, 1);
[eq_branch, eq_branch_info] = build_multipuerto_equivalent_branches(mpc, ports, eq_bus, eq);
eq_branch_info.branch_index = branch_offset + (1:height(eq_branch_info)).';
mpc_red.branch = [mpc_red.branch; eq_branch];
eq.equivalent_branch = eq_branch_info;

if isfield(mpc, 'dcline')
    keep_dcline = retained_dcline_mask(mpc, retained);
    mpc_red.dcline = mpc.dcline(keep_dcline, :);
else
    keep_dcline = false(0, 1);
end

if isfield(mpc, 'psse')
    mpc_red.psse = reduced_reference_psse_metadata(mpc, keep_bus, keep_gen, ...
        find(internal_branch), keep_dcline);
end
end

function psse = reduced_reference_psse_metadata(mpc, keep_bus, keep_gen, internal_branch_idx, keep_dcline)
psse = subset_psse_metadata(mpc, keep_bus, keep_gen, internal_branch_idx, keep_dcline);
if ~isfield(mpc, 'psse')
    return;
end

fields = fieldnames(psse);
keep_fields = ["rev", "system", "swshunt", "xfmr", "genq", "swdev", "impcor"];
for k = 1:numel(fields)
    if ~ismember(string(fields{k}), keep_fields)
        psse = rmfield(psse, fields{k});
    end
end

if ~isfield(psse, 'system')
    psse.system = struct();
end
if ~isfield(psse.system, 'solver')
    psse.system.solver = struct();
end
psse.system.solver.ACTAPS = 1;
psse.system.solver.SWSHNT = 1;
if isfield(psse, 'swdev')
    psse.swdev.collapse_disabled = true;
    psse.swdev.collapse_policy = 'retained_as_explicit_branches';
end
psse.solved_snapshot_policy = struct( ...
    'active', 1, ...
    'gen_vg_source', 'bus_vm', ...
    'enable_genq_control', false, ...
    'note', ['Reduced equivalent calibrated to full RAW runpf_psse solved operating point; ' ...
    'transformer taps, switched shunts, generator Q metadata, and switching devices are retained where internal; ' ...
    'GENQ active adjustments remain disabled by the solved-snapshot/VARLIM policy unless explicitly enabled for diagnostics.']);
psse.reduced_control_policy = struct( ...
    'active_transformer_taps', isfield(psse, 'xfmr'), ...
    'active_switched_shunts', isfield(psse, 'swshunt'), ...
    'preserved_generator_q_metadata', isfield(psse, 'genq'), ...
    'active_generator_q_controls', false, ...
    'active_switching_devices', isfield(psse, 'swdev'), ...
    'collapse_switching_devices', false, ...
    'ACTAPS', psse.system.solver.ACTAPS, ...
    'SWSHNT', psse.system.solver.SWSHNT);
end

function [eq_branch, info] = build_multipuerto_equivalent_branches(mpc, ports, eq_bus, eq)
define_constants;

tol = 1e-10;
Y = full(eq.Yeq);
neq = numel(ports);
br_cols = size(mpc.branch, 2);
rows = {};
types = strings(0, 1);
port_a = zeros(0, 1);
port_b = zeros(0, 1);
source_port = zeros(0, 1);
y_values = zeros(0, 1);

for i = 1:neq
    for j = 1:neq
        y = Y(i, j);
        if abs(y) <= tol
            continue;
        end
        rows{end+1, 1} = equivalent_branch_row(br_cols, eq_bus(j), ports(i), y); %#ok<AGROW>
        types(end+1, 1) = "source_port"; %#ok<AGROW>
        port_a(end+1, 1) = ports(i); %#ok<AGROW>
        port_b(end+1, 1) = NaN; %#ok<AGROW>
        source_port(end+1, 1) = ports(j); %#ok<AGROW>
        y_values(end+1, 1) = y; %#ok<AGROW>
    end
end

for i = 1:neq-1
    for j = i+1:neq
        y = -Y(i, j);
        if abs(y) <= tol
            continue;
        end
        rows{end+1, 1} = equivalent_branch_row(br_cols, ports(i), ports(j), y); %#ok<AGROW>
        types(end+1, 1) = "port_port"; %#ok<AGROW>
        port_a(end+1, 1) = ports(i); %#ok<AGROW>
        port_b(end+1, 1) = ports(j); %#ok<AGROW>
        source_port(end+1, 1) = NaN; %#ok<AGROW>
        y_values(end+1, 1) = y; %#ok<AGROW>
    end
end

if isempty(rows)
    eq_branch = zeros(0, br_cols);
else
    eq_branch = vertcat(rows{:});
end

f_bus = eq_branch(:, F_BUS);
t_bus = eq_branch(:, T_BUS);
z_values = 1 ./ y_values;
branch_index = zeros(numel(y_values), 1);
info = table(branch_index, types, f_bus, t_bus, port_a, port_b, source_port, ...
    real(y_values), imag(y_values), real(z_values), imag(z_values), ...
    'VariableNames', {'branch_index', 'type', 'f_bus', 't_bus', ...
    'port_a', 'port_b', 'source_port', 'G_pu', 'B_pu', 'R_pu', 'X_pu'});
end

function row = equivalent_branch_row(ncols, f_bus, t_bus, y)
define_constants;
z = 1 / y;
row = zeros(1, ncols);
row(F_BUS) = f_bus;
row(T_BUS) = t_bus;
row(BR_R) = real(z);
row(BR_X) = imag(z);
row(BR_B) = 0;
row(RATE_A) = 99999;
row(RATE_B) = 99999;
row(RATE_C) = 99999;
row(TAP) = 0;
row(SHIFT) = 0;
row(BR_STATUS) = 1;
row(ANGMIN) = -360;
row(ANGMAX) = 360;
end

function base_kv = port_base_kv(mpc, ports)
define_constants;
base_kv = zeros(numel(ports), 1);
for k = 1:numel(ports)
    idx = find(mpc.bus(:, BUS_I) == ports(k), 1);
    base_kv(k) = mpc.bus(idx, BASE_KV);
end
end

function keep = retained_dcline_mask(mpc, retained)
if ~isfield(mpc, 'dcline') || isempty(mpc.dcline)
    keep = false(0, 1);
    return;
end
% MATPOWER dcline columns 1 and 2 are from/to buses.
keep = ismember(mpc.dcline(:, 1), retained) & ...
    ismember(mpc.dcline(:, 2), retained);
end

function psse = subset_psse_metadata(mpc, keep_bus, keep_gen, internal_branch_idx, keep_dcline)
define_constants;
src = mpc.psse;
psse = struct();

if isfield(src, 'rev')
    psse.rev = src.rev;
end
if isfield(src, 'system')
    psse.system = src.system;
end

old_bus_to_new = zeros(size(mpc.bus, 1), 1);
old_bus_to_new(find(keep_bus)) = (1:nnz(keep_bus)).';
old_gen_to_new = zeros(size(mpc.gen, 1), 1);
old_gen_to_new(find(keep_gen)) = (1:nnz(keep_gen)).';
old_branch_to_new = zeros(size(mpc.branch, 1), 1);
old_branch_to_new(internal_branch_idx) = (1:numel(internal_branch_idx)).';
old_dcline_to_new = zeros(numel(keep_dcline), 1);
old_dcline_to_new(find(keep_dcline)) = (1:nnz(keep_dcline)).';
retained_bus = mpc.bus(keep_bus, BUS_I);

if isfield(src, 'swshunt') && isfield(src.swshunt, 'num') && ~isempty(src.swshunt.num)
    i_col = psse_col(src.swshunt, 'I');
    keep = i_col > 0 & ismember(src.swshunt.num(:, i_col), retained_bus);
    if any(keep)
        psse.swshunt = subset_rows(src.swshunt, find(keep));
    end
end

if isfield(src, 'branch') && isfield(src.branch, 'branch_idx')
    idx = src.branch.branch_idx(:);
    keep = idx > 0 & idx <= numel(old_branch_to_new) & old_branch_to_new(idx) > 0;
    if any(keep)
        br = subset_rows(src.branch, find(keep));
        br.branch_idx = remap_positive(br.branch_idx, old_branch_to_new);
        br.f_bus_idx = remap_positive(br.f_bus_idx, old_bus_to_new);
        br.t_bus_idx = remap_positive(br.t_bus_idx, old_bus_to_new);
        psse.branch = br;
    end
end

if isfield(src, 'genq') && isfield(src.genq, 'num') && ~isempty(src.genq.num) && ...
        isfield(src.genq, 'gen_idx')
    idx = src.genq.gen_idx(:);
    keep = idx > 0 & idx <= numel(old_gen_to_new) & old_gen_to_new(idx) > 0;
    rows = find(keep);
    if ~isempty(rows)
        [~, ord] = sort(idx(rows));
        gq = subset_rows(src.genq, rows(ord));
        gq.gen_idx = remap_positive(gq.gen_idx, old_gen_to_new);
        if isfield(gq, 'bus_idx')
            gq.bus_idx = remap_positive(gq.bus_idx, old_bus_to_new);
        end
        if isfield(gq, 'reg_bus_idx')
            gq.reg_bus_idx = remap_positive(gq.reg_bus_idx, old_bus_to_new);
        end
        psse.genq = gq;
    end
end

if isfield(src, 'swdev') && isfield(src.swdev, 'num') && ~isempty(src.swdev.num) && ...
        isfield(src.swdev, 'branch_idx')
    br = src.swdev.branch_idx(:);
    fb = src.swdev.f_bus_idx(:);
    tb = src.swdev.t_bus_idx(:);
    keep = br > 0 & br <= numel(old_branch_to_new) & old_branch_to_new(br) > 0 & ...
        fb > 0 & fb <= numel(old_bus_to_new) & old_bus_to_new(fb) > 0 & ...
        tb > 0 & tb <= numel(old_bus_to_new) & old_bus_to_new(tb) > 0;
    if any(keep)
        sw = subset_rows(src.swdev, find(keep));
        sw.branch_idx = remap_positive(sw.branch_idx, old_branch_to_new);
        sw.f_bus_idx = remap_positive(sw.f_bus_idx, old_bus_to_new);
        sw.t_bus_idx = remap_positive(sw.t_bus_idx, old_bus_to_new);
        psse.swdev = sw;
    end
end

if isfield(src, 'xfmr')
    xf = struct();
    if isfield(src.xfmr, 'two')
        xf.two = subset_xfmr_two(src.xfmr.two, old_branch_to_new);
    end
    if isfield(src.xfmr, 'three')
        xf.three = subset_xfmr_three(src.xfmr.three, old_branch_to_new);
    end
    if isfield(xf, 'two') || isfield(xf, 'three')
        if ~isfield(xf, 'two')
            xf.two = empty_xfmr_part(src.xfmr.three);
        end
        if ~isfield(xf, 'three')
            xf.three = empty_xfmr_part(src.xfmr.two);
        end
        psse.xfmr = xf;
    end
end

if isfield(src, 'impcor')
    psse.impcor = src.impcor;
end

if isfield(src, 'twodc') && isfield(src.twodc, 'num') && ~isempty(src.twodc.num) && ...
        isfield(src.twodc, 'dcline_idx') && ~isempty(keep_dcline)
    idx = src.twodc.dcline_idx(:);
    keep = idx > 0 & idx <= numel(old_dcline_to_new) & old_dcline_to_new(idx) > 0;
    if any(keep)
        tw = subset_rows(src.twodc, find(keep));
        tw.dcline_idx = remap_positive(tw.dcline_idx, old_dcline_to_new);
        if isfield(tw, 'rect_bus_idx')
            tw.rect_bus_idx = remap_positive(tw.rect_bus_idx, old_bus_to_new);
        end
        if isfield(tw, 'inv_bus_idx')
            tw.inv_bus_idx = remap_positive(tw.inv_bus_idx, old_bus_to_new);
        end
        psse.twodc = tw;
    end
end

if isfield(src, 'facts') && isfield(src.facts, 'num') && ~isempty(src.facts.num)
    if isfield(src.facts, 'bus_idx')
        idx = src.facts.bus_idx(:);
        keep = idx > 0 & idx <= numel(old_bus_to_new) & old_bus_to_new(idx) > 0;
    else
        i_col = psse_col(src.facts, 'I');
        keep = i_col > 0 & ismember(src.facts.num(:, i_col), retained_bus);
    end
    if any(keep)
        fx = subset_rows(src.facts, find(keep));
        if isfield(fx, 'bus_idx')
            fx.bus_idx = remap_positive(fx.bus_idx, old_bus_to_new);
        end
        if isfield(fx, 'reg_bus_idx')
            fx.reg_bus_idx = remap_positive(fx.reg_bus_idx, old_bus_to_new);
        end
        psse.facts = fx;
    end
end
end

function out = subset_xfmr_two(src, old_branch_to_new)
out = subset_rows(src, []);
if ~isfield(src, 'branch_idx') || isempty(src.branch_idx)
    return;
end
idx = src.branch_idx(:);
keep = idx > 0 & idx <= numel(old_branch_to_new) & old_branch_to_new(idx) > 0;
if any(keep)
    out = subset_rows(src, find(keep));
    out.branch_idx = remap_positive(out.branch_idx, old_branch_to_new);
end
end

function out = subset_xfmr_three(src, old_branch_to_new)
out = subset_rows(src, []);
if ~isfield(src, 'branch_idx') || isempty(src.branch_idx)
    return;
end
remapped = remap_positive(src.branch_idx, old_branch_to_new);
keep = any(remapped > 0, 2);
if any(keep)
    out = subset_rows(src, find(keep));
    out.branch_idx = remapped(keep, :);
end
end

function out = empty_xfmr_part(src)
out = subset_rows(src, []);
if isfield(out, 'branch_idx')
    out.branch_idx = zeros(0, size(src.branch_idx, 2));
end
end

function out = subset_rows(src, rows)
out = src;
fields = fieldnames(src);
if isfield(src, 'num')
    n = size(src.num, 1);
elseif isfield(src, 'branch_idx')
    n = size(src.branch_idx, 1);
else
    n = 0;
end
for k = 1:numel(fields)
    name = fields{k};
    val = src.(name);
    if (isnumeric(val) || islogical(val) || iscell(val) || isstring(val)) && ...
            ~isempty(val) && size(val, 1) == n
        idx = repmat({':'}, 1, ndims(val));
        idx{1} = rows;
        out.(name) = val(idx{:});
    end
end
end

function col = psse_col(s, name)
col = 0;
if isfield(s, 'col') && isfield(s.col, lower(name))
    col = s.col.(lower(name));
elseif isfield(s, 'colnames')
    found = find(strcmpi(s.colnames, name), 1);
    if ~isempty(found)
        col = found;
    end
end
end

function out = remap_positive(val, map)
out = zeros(size(val));
valid = val > 0 & val <= numel(map);
out(valid) = map(val(valid));
end

function write_psse_sidecar_case(case_file, psse_sidecar_file, mpc)
if ~isfield(mpc, 'psse')
    return;
end
psse = mpc.psse;
save(psse_sidecar_file, 'psse');

[~, sidecar_name, sidecar_ext] = fileparts(psse_sidecar_file);
sidecar_file = [sidecar_name sidecar_ext];
fid = fopen(case_file, 'a');
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, '\n%%%% PSS/E metadata sidecar for runpf_psse\n');
fprintf(fid, 'psse_sidecar = fullfile(fileparts(mfilename(''fullpath'')), ''%s'');\n', sidecar_file);
fprintf(fid, 'if exist(psse_sidecar, ''file'')\n');
fprintf(fid, '    psse_data = load(psse_sidecar, ''psse'');\n');
fprintf(fid, '    mpc.psse = psse_data.psse;\n');
fprintf(fid, 'end\n');
end

function validation = validate_reduction(mpc_full, pf, retained, ports, eq, solver_name)
define_constants;
if nargin < 6 || isempty(solver_name)
    solver_name = 'runpf_psse';
end

validation = struct();
validation.solver = solver_name;
validation.success = pf.success;
if isfield(pf, 'psse')
    validation.psse_fields = string(fieldnames(pf.psse)).';
else
    validation.psse_fields = strings(1, 0);
end

[common, ~, ib] = intersect(retained(:), mpc_full.bus(:, BUS_I));
[~, ir] = intersect(pf.bus(:, BUS_I), common);
full_rows = ib;
red_rows = ir;

dvm = pf.bus(red_rows, VM) - mpc_full.bus(full_rows, VM);
dva = angle_diff_deg(pf.bus(red_rows, VA), mpc_full.bus(full_rows, VA));
validation.bus = table(common, mpc_full.bus(full_rows, VM), pf.bus(red_rows, VM), ...
    dvm, mpc_full.bus(full_rows, VA), pf.bus(red_rows, VA), dva, ...
    'VariableNames', {'bus', 'vm_full', 'vm_reduced', 'dvm', 'va_full_deg', ...
    'va_reduced_deg', 'dva_deg'});
validation.max_abs_dvm = max(abs(dvm));
validation.rms_dvm = sqrt(mean(dvm.^2));
validation.max_abs_dva = max(abs(dva));
validation.rms_dva = sqrt(mean(dva.^2));

port_flow = zeros(numel(ports), 1);
if isfield(eq, 'equivalent_branch') && ~isempty(eq.equivalent_branch)
    for r = 1:height(eq.equivalent_branch)
        br = eq.equivalent_branch.branch_index(r);
        if br <= 0 || br > size(pf.branch, 1)
            continue;
        end
        if eq.equivalent_branch.type(r) == "source_port"
            kt = find(ports == eq.equivalent_branch.port_a(r), 1);
            if ~isempty(kt)
                port_flow(kt) = port_flow(kt) + pf.branch(br, PT) + 1j * pf.branch(br, QT);
            end
        elseif eq.equivalent_branch.type(r) == "port_port"
            kf = find(ports == eq.equivalent_branch.port_a(r), 1);
            if ~isempty(kf)
                port_flow(kf) = port_flow(kf) + pf.branch(br, PF) + 1j * pf.branch(br, QF);
            end
            kt = find(ports == eq.equivalent_branch.port_b(r), 1);
            if ~isempty(kt)
                port_flow(kt) = port_flow(kt) + pf.branch(br, PT) + 1j * pf.branch(br, QT);
            end
        end
    end
else
    eq_bus = 900000 + ports(:);
    for k = 1:numel(ports)
        br = find(pf.branch(:, F_BUS) == eq_bus(k) & pf.branch(:, T_BUS) == ports(k), 1);
        if isempty(br)
            port_flow(k) = NaN;
        else
            % Flow from retained port into equivalent is the receiving-end flow.
            port_flow(k) = pf.branch(br, PT) + 1j * pf.branch(br, QT);
        end
    end
end
validation.boundary = table(ports(:), eq.S_cut_from_retained_MVA, port_flow, ...
    port_flow - eq.S_cut_from_retained_MVA, ...
    'VariableNames', {'port_bus', 'S_cut_full_MVA', 'S_cut_reduced_MVA', 'dS_MVA'});

validation.total_load_MW = sum(pf.bus(:, PD));
validation.total_load_MVAr = sum(pf.bus(:, QD));
validation.total_gen_MW = sum(pf.gen(pf.gen(:, GEN_STATUS) > 0, PG));
validation.total_gen_MVAr = sum(pf.gen(pf.gen(:, GEN_STATUS) > 0, QG));
end

function d = angle_diff_deg(a, b)
d = mod((a - b) + 180, 360) - 180;
end

function write_audit_tables(out_dir, mpc, psse_data, retained, reason, cut, ports, eq, validation)
define_constants;

bus_meta = bus_table(mpc, psse_data, retained, reason);
writetable(bus_meta, fullfile(out_dir, 'retained_buses.csv'));

deleted = setdiff(mpc.bus(:, BUS_I), retained(:));
deleted_meta = bus_table(mpc, psse_data, deleted, strings(numel(deleted), 1) + "external_eliminated");
writetable(deleted_meta, fullfile(out_dir, 'external_buses.csv'));

cut2 = decorate_cut_table(cut, mpc, psse_data);
writetable(cut2, fullfile(out_dir, 'boundary_cuts.csv'));

eq_tbl = table(ports(:), real(eq.S_cut_from_retained_MVA), imag(eq.S_cut_from_retained_MVA), ...
    real(eq.Inorton), imag(eq.Inorton), abs(eq.Eth_multi), angle(eq.Eth_multi) * 180 / pi, ...
    real(eq.Zdiag), imag(eq.Zdiag), abs(eq.Eth_diag), angle(eq.Eth_diag) * 180 / pi, ...
    'VariableNames', {'port_bus', 'P_cut_from_retained_MW', 'Q_cut_from_retained_MVAr', ...
    'Inorton_real_pu', 'Inorton_imag_pu', 'Eth_multi_pu', 'Eth_multi_deg', ...
    'Rth_diag_reference_pu', 'Xth_diag_reference_pu', ...
    'Eth_diag_reference_pu', 'Eth_diag_reference_deg'});
writetable(eq_tbl, fullfile(out_dir, 'thevenin_parameters.csv'));
writetable(eq_tbl, fullfile(out_dir, 'equivalent_sources.csv'));

if isfield(eq, 'equivalent_branch') && ~isempty(eq.equivalent_branch)
    writetable(eq.equivalent_branch, fullfile(out_dir, 'equivalent_branches.csv'));
end

if isfield(eq, 'physical_ports')
    mapping_tbl = table(eq.physical_ports(:), eq.physical_to_equiv_port(:), ...
        'VariableNames', {'physical_cut_port', 'equivalent_port'});
    writetable(mapping_tbl, fullfile(out_dir, 'equivalent_port_mapping.csv'));
end

writetable(validation.bus, fullfile(out_dir, 'validation_bus_voltage.csv'));
writetable(validation.boundary, fullfile(out_dir, 'validation_boundary_exchange.csv'));

md = fullfile(out_dir, 'metodologia_y_resultados.md');
fid = fopen(md, 'w');
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, '# Reduccion TRANSPA v1\n\n');
fprintf(fid, 'Fuente RAW: `%s`\n\n', strrep(fullfile('PSSE', 'V26p_Trs_2532.raw'), '\', '/'));
fprintf(fid, 'Fuente visual: `%s`\n\n', strrep(fullfile('PSSE', 'TRANSPA PICO VERANO 2025_2026.pdf'), '\', '/'));
fprintf(fid, '## Criterio\n\n');
fprintf(fid, '- Se retienen barras visibles del unifilar, area `PATAGONI`, area/zona `ALUAR`, y cierres auxiliares de transformadores de tres devanados.\n');
fprintf(fid, '- Se reportan como fronteras todas las ramas activas que cruzan entre barras retenidas y externas.\n');
fprintf(fid, '- `2206` y `2208` quedan como barras fisicas explicitas y como dos puertos electricos separados de la misma frontera geografica B.BCA; colapsarlas en un unico puerto rompia el balance nodal por barra.\n');
fprintf(fid, '- La version runnable usa barras ficticias `SADI_EQ_*` y ramas equivalentes fuente-puerto/puerto-puerto para realizar la matriz multipuerto `Yeq` completa. No hay slack ideal pegada directamente a barras fisicas.\n');
fprintf(fid, '- La validacion principal se ejecuta con `%s`; `runpf` estandar queda solo como chequeo secundario guardado en `results.validation_standard`.\n', validation.solver);
if isfield(eq, 'reference_case_source')
    fprintf(fid, '- La calibracion del equivalente usa como punto operativo de referencia: `%s`.\n', eq.reference_case_source);
end
fprintf(fid, '- El caso exportado carga `case_transpa_reduced_v1_psse.mat` como sidecar. Por decision de modelado se preservan y activan taps de transformadores (`ACTAPS=1`) y bancos de capacitores/reactores conmutables (`SWSHNT=1`) dentro de la red retenida.\n');
fprintf(fid, '- Tambien se guarda el equivalente Norton/Thevenin multipuerto completo en `transpa_reduction_v1.mat` (`results.equivalent.Yeq`, `Inorton`, `Eth_multi`).\n\n');
fprintf(fid, '## Resumen numerico\n\n');
fprintf(fid, '- Barras retenidas: %d\n', numel(retained));
fprintf(fid, '- Barras externas eliminadas: %d\n', size(mpc.bus, 1) - numel(retained));
fprintf(fid, '- Elementos de corte activos: %d\n', height(cut));
fprintf(fid, '- Puertos fisicos de corte: %s\n', strjoin(string(unique(cut.port_bus).'), ', '));
fprintf(fid, '- Puertos electricos equivalentes finales: %s; `2206` y `2208` se reportan como la frontera geografica B.BCA pero se modelan electricamente separados.\n', strjoin(string(ports), ', '));
fprintf(fid, '- Condest de `Yeq`: %.6g\n', eq.Yeq_condest);
if isfield(eq, 'equivalent_branch')
    fprintf(fid, '- Ramas equivalentes multipuerto agregadas: %d\n', height(eq.equivalent_branch));
end
if isfield(validation, 'psse_fields')
    fprintf(fid, '- Metadatos PSS/E activos en el reducido: %s\n', strjoin(validation.psse_fields, ', '));
end
fprintf(fid, '- El caso reducido MATPOWER converge con `%s`: %d\n', validation.solver, validation.success);
[max_dvm, kdvm] = max(abs(validation.bus.dvm));
[max_dva, kdva] = max(abs(validation.bus.dva_deg));
fprintf(fid, '- Desvios de tension frente al caso completo: max |dVM| = %.6g pu en barra `%d`; RMS |dVM| = %.6g pu.\n', ...
    max_dvm, validation.bus.bus(kdvm), validation.rms_dvm);
fprintf(fid, '- Desvios angulares frente al caso completo: max |dVA| = %.6g deg en barra `%d`; RMS |dVA| = %.6g deg.\n\n', ...
    max_dva, validation.bus.bus(kdva), validation.rms_dva);
if height(validation.boundary)
    [max_ds, kds] = max(abs(validation.boundary.dS_MVA));
    fprintf(fid, '## Limitaciones de esta v1\n\n');
    fprintf(fid, '- La frontera con mayor desvio de intercambio en el caso MATPOWER runnable es `%d`: |dS| = %.6g MVA.\n', ...
        validation.boundary.port_bus(kds), max_ds);
    for k = 1:height(validation.boundary)
        fprintf(fid, '  - `%d`: |dS| = %.6g MVA.\n', ...
            validation.boundary.port_bus(k), abs(validation.boundary.dS_MVA(k)));
    end
    fprintf(fid, '- Esta v1 realiza `Yeq` mediante ramas equivalentes. Algunas impedancias pueden ser no fisicas porque representan un Ward/Thevenin multipuerto calibrado al punto operativo, no lineas reales.\n');
    fprintf(fid, '- Por evidencia RAW, las fronteras no son solo `1008` y `2206/2208`: tambien quedan `1226`, `2222` y `2302` como puertos externos en esta retencion. `330` dejo de ser puerto luego de retener sus devanados locales.\n\n');
end
fprintf(fid, '## Archivos generados\n\n');
fprintf(fid, '- `case_transpa_reduced_v1.m`\n');
fprintf(fid, '- `case_transpa_reduced_v1_psse.mat`\n');
fprintf(fid, '- `transpa_reduction_v1.mat`\n');
fprintf(fid, '- `retained_buses.csv`\n');
fprintf(fid, '- `external_buses.csv`\n');
fprintf(fid, '- `boundary_cuts.csv`\n');
fprintf(fid, '- `equivalent_port_mapping.csv`\n');
fprintf(fid, '- `equivalent_sources.csv`\n');
fprintf(fid, '- `equivalent_branches.csv`\n');
fprintf(fid, '- `thevenin_parameters.csv`\n');
fprintf(fid, '- `validation_bus_voltage.csv`\n');
fprintf(fid, '- `validation_boundary_exchange.csv`\n');
end

function tbl = bus_table(mpc, psse_data, buses, reason)
define_constants;

bus = buses(:);
name = strings(numel(bus), 1);
base_kv = NaN(numel(bus), 1);
type = NaN(numel(bus), 1);
area = NaN(numel(bus), 1);
zone = NaN(numel(bus), 1);
vm = NaN(numel(bus), 1);
va = NaN(numel(bus), 1);

for k = 1:numel(bus)
    idx = find(mpc.bus(:, BUS_I) == bus(k), 1);
    if ~isempty(idx)
        base_kv(k) = mpc.bus(idx, BASE_KV);
        type(k) = mpc.bus(idx, BUS_TYPE);
        area(k) = mpc.bus(idx, BUS_AREA);
        zone(k) = mpc.bus(idx, ZONE);
        vm(k) = mpc.bus(idx, VM);
        va(k) = mpc.bus(idx, VA);
        if idx <= numel(mpc.bus_name)
            name(k) = string(strtrim(mpc.bus_name{idx}));
        end
    end
    ridx = find(psse_data.bus.num(:, 1) == bus(k), 1);
    if ~isempty(ridx)
        name(k) = string(strtrim(psse_data.bus.txt{ridx, 2}));
    elseif bus(k) >= 1e6
        name(k) = "MATPOWER_3W_STAR";
    end
end

tbl = table(bus, name, base_kv, type, area, zone, vm, va, reason(:), ...
    'VariableNames', {'bus', 'name', 'base_kv', 'type', 'area', 'zone', ...
    'vm_raw', 'va_raw_deg', 'reason'});
end

function tbl = decorate_cut_table(cut, mpc, psse_data)
define_constants;

tbl = cut;
tbl.port_name = bus_name(psse_data, mpc, tbl.port_bus);
tbl.external_name = bus_name(psse_data, mpc, tbl.external_bus);
tbl.port_kv = bus_value(mpc, tbl.port_bus, BASE_KV);
tbl.external_kv = bus_value(mpc, tbl.external_bus, BASE_KV);
end

function names = bus_name(psse_data, mpc, buses)
define_constants;
names = strings(numel(buses), 1);
for k = 1:numel(buses)
    idx = find(psse_data.bus.num(:, 1) == buses(k), 1);
    if ~isempty(idx)
        names(k) = string(strtrim(psse_data.bus.txt{idx, 2}));
    else
        midx = find(mpc.bus(:, BUS_I) == buses(k), 1);
        if ~isempty(midx) && midx <= numel(mpc.bus_name)
            names(k) = string(strtrim(mpc.bus_name{midx}));
        else
            names(k) = "MATPOWER_3W_STAR";
        end
    end
end
end

function values = bus_value(mpc, buses, col)
define_constants;
values = NaN(numel(buses), 1);
for k = 1:numel(buses)
    idx = find(mpc.bus(:, BUS_I) == buses(k), 1);
    if ~isempty(idx)
        values(k) = mpc.bus(idx, col);
    end
end
end
