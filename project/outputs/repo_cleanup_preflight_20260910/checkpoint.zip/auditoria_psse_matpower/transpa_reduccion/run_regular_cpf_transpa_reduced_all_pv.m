function results = run_regular_cpf_transpa_reduced_all_pv()
%RUN_REGULAR_CPF_TRANSPA_REDUCED_ALL_PV Compatibility wrapper.
%
% Historical entrypoint for the regular MATPOWER CPF TRANSPA baseline. The
% implementation now lives in cpf_psse_runner/transpa_cpf_run.m.

opts = struct();
opts.mode = 'regular';
opts.run_id = 'regular_cpf_transpa_reduced_all_pv';
opts.outdir_name = 'regular_cpf_transpa_reduced_all_pv';
opts.load_scale = 2.0;
opts.plots = true;
opts.swshunt_repair = false;
opts.gen_capability = false;
opts.gen_redispatch = false;
opts.gen_pq_trace = false;
opts.cpf = struct( ...
    'stop_at', 'NOSE', ...
    'step', 0.005, ...
    'step_max', 0.005, ...
    'adapt_step', 1, ...
    'enforce_q_lims', 0, ...
    'plot_level', 0);

results = run_transpa_cpf_psse(opts);
end
