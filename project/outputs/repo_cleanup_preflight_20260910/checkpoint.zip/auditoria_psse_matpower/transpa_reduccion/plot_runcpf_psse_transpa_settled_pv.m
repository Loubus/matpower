function results = plot_runcpf_psse_transpa_settled_pv()
%PLOT_RUNCPF_PSSE_TRANSPA_SETTLED_PV Settled PV plots from raw runcpf_psse.
%
% Keeps only the final stored state for each repeated lambda value, removing
% intermediate PSS/E tap/shunt correction points from the displayed curves.

root = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(fullfile(root, 'matpower', 'lib'));

source_dir = fullfile(root, 'auditoria_psse_matpower', 'results', ...
    'runcpf_psse_transpa_selected_controls_no_genq_pqbrak');
outdir = fullfile(root, 'auditoria_psse_matpower', 'results', ...
    'runcpf_psse_transpa_selected_controls_no_genq_pqbrak_settled_pv');
if ~exist(outdir, 'dir')
    mkdir(outdir);
end

data_file = fullfile(source_dir, ...
    'runcpf_psse_transpa_selected_controls_no_genq_pqbrak.mat');
S = load(data_file, 'cpf_results', 'cpf_success', 'summary');
cpf_results = S.cpf_results;
summary_raw = S.summary;

define_constants;
ports = [1008; 1226; 2206; 2208; 2222; 2302];

lam_raw = cpf_results.cpf.lam(:)';
Vmag_raw = abs(cpf_results.cpf.V);
[lam, keep_idx] = settled_trace(lam_raw);
Vmag = Vmag_raw(:, keep_idx);

bus_ids = cpf_results.bus(:, BUS_I);
base_kv = cpf_results.bus(:, BASE_KV);
bus_type = cpf_results.bus(:, BUS_TYPE);
physical = bus_ids < 900000 & bus_type ~= NONE;
active = bus_type ~= NONE;

sets = build_curve_sets(bus_ids, base_kv, physical, active, ports, Vmag);
fig_paths = plot_curve_sets(outdir, lam, Vmag, bus_ids, base_kv, sets);
fig_paths = [fig_paths; plot_physical_pages(outdir, lam, Vmag, bus_ids, ...
    base_kv, find(physical))];

summary = build_summary(summary_raw, cpf_results, S.cpf_success, ...
    lam_raw, lam, keep_idx, Vmag, bus_ids, physical, fig_paths);
write_outputs(outdir, summary, lam, Vmag, bus_ids, base_kv, bus_type, ...
    physical, sets, keep_idx);

save(fullfile(outdir, 'runcpf_psse_transpa_settled_pv.mat'), ...
    'summary', 'lam', 'Vmag', 'bus_ids', 'base_kv', 'bus_type', ...
    'physical', 'sets', 'fig_paths', 'keep_idx', '-v7.3');

results = struct('outdir', outdir, 'summary', summary, ...
    'fig_paths', {fig_paths});
fprintf('Settled runcpf_psse PV outputs written to:\n  %s\n', outdir);
fprintf(['raw_points=%d, settled_points=%d, max_lambda=%.12g, ' ...
    'load_factor=%.12g\n'], summary.raw_points, summary.settled_points, ...
    summary.max_lambda, summary.load_factor_at_nose);
end

function [lam, keep_idx] = settled_trace(lam_raw)
if isempty(lam_raw)
    lam = lam_raw;
    keep_idx = [];
    return;
end
lam_col = lam_raw(:);
run_start = [1; find(diff(lam_col) ~= 0) + 1];
keep_idx = [run_start(2:end) - 1; numel(lam_col)];
lam = lam_col(keep_idx)';
end

function sets = build_curve_sets(bus_ids, base_kv, physical, active, ports, Vmag)
sets = struct('name', {}, 'title', {}, 'idx', {}, 'with_legend', {});
sets(end+1) = make_set('all_active_buses', ...
    'settled runcpf_psse - all active buses', find(active), false);
sets(end+1) = make_set('all_physical_buses', ...
    'settled runcpf_psse - all physical retained buses', find(physical), false);
sets(end+1) = make_set('boundary_ports', ...
    'settled runcpf_psse - TRANSPA/SADI boundary ports', ...
    find(ismember(bus_ids, ports)), true);
sets(end+1) = make_set('buses_500kv', ...
    'settled runcpf_psse - buses >= 400 kV', find(physical & base_kv >= 400), true);

drop = Vmag(:, 1) - Vmag(:, end);
drop(~physical) = -Inf;
[~, ord_drop] = sort(drop, 'descend');
sets(end+1) = make_set('worst_40_voltage_drop', ...
    'settled runcpf_psse - worst 40 voltage drops', ...
    ord_drop(1:min(40, nnz(isfinite(drop)))), true);

final_v = Vmag(:, end);
final_v(~physical) = Inf;
[~, ord_low] = sort(final_v, 'ascend');
sets(end+1) = make_set('lowest_40_final_voltage', ...
    'settled runcpf_psse - lowest 40 final voltages', ...
    ord_low(1:min(40, nnz(isfinite(final_v)))), true);
end

function s = make_set(name, title_text, idx, with_legend)
s = struct('name', name, 'title', title_text, ...
    'idx', idx(:), 'with_legend', with_legend);
end

function fig_paths = plot_curve_sets(outdir, lam, Vmag, bus_ids, base_kv, sets)
fig_paths = strings(0, 1);
for k = 1:numel(sets)
    idx = sets(k).idx;
    idx = idx(idx > 0 & idx <= size(Vmag, 1));
    if isempty(idx)
        continue;
    end
    file_name = sprintf('pv_settled_%s.png', sets(k).name);
    fig_paths(end+1, 1) = plot_curves(outdir, file_name, lam, Vmag, ...
        bus_ids, base_kv, idx, sets(k).title, sets(k).with_legend); %#ok<AGROW>
end
end

function page_paths = plot_physical_pages(outdir, lam, Vmag, bus_ids, ...
        base_kv, idx_all)
page_size = 50;
page_paths = strings(0, 1);
for p = 1:ceil(numel(idx_all) / page_size)
    lo = (p - 1) * page_size + 1;
    hi = min(p * page_size, numel(idx_all));
    idx = idx_all(lo:hi);
    file_name = sprintf('pv_settled_all_physical_buses_page_%02d.png', p);
    title_text = sprintf( ...
        'settled runcpf_psse - physical retained buses page %02d', p);
    page_paths(end+1, 1) = plot_curves(outdir, file_name, lam, Vmag, ...
        bus_ids, base_kv, idx, title_text, true); %#ok<AGROW>
end
end

function file = plot_curves(outdir, file_name, lam, Vmag, bus_ids, base_kv, ...
        idx, title_text, with_legend)
file = string(fullfile(outdir, file_name));
fig = figure('Visible', 'off', 'Color', 'w', 'InvertHardcopy', 'off', ...
    'Position', [80 80 1500 900]);
ax = axes(fig);
set(ax, ...
    'Color', 'w', ...
    'XColor', 'k', ...
    'YColor', 'k', ...
    'GridColor', [0.75 0.75 0.75], ...
    'MinorGridColor', [0.88 0.88 0.88]);
hold(ax, 'on');
if numel(idx) > 80
    plot(ax, lam, Vmag(idx, :)', 'LineWidth', 0.45, ...
        'Color', [0.18 0.28 0.42]);
elseif numel(idx) > 45
    plot(ax, lam, Vmag(idx, :)', 'LineWidth', 0.8);
else
    plot(ax, lam, Vmag(idx, :)', 'LineWidth', 1.15);
end
grid(ax, 'on');
box(ax, 'on');
xlabel(ax, '\lambda');
ylabel(ax, 'Voltage magnitude [pu]');
title_handle = title(ax, title_text, 'Interpreter', 'none');
set(title_handle, 'Color', 'k');
xlim(ax, [min(lam), max(lam)]);
ymin = max(0.35, min(Vmag(idx, :), [], 'all') - 0.035);
ymax = min(1.25, max(Vmag(idx, :), [], 'all') + 0.035);
ylim(ax, [ymin ymax]);
if with_legend && numel(idx) <= 50
    labels = cell(numel(idx), 1);
    for ii = 1:numel(idx)
        labels{ii} = sprintf('%g (%.0f kV)', bus_ids(idx(ii)), ...
            base_kv(idx(ii)));
    end
    legend_handle = legend(ax, labels, 'Location', 'eastoutside', ...
        'Interpreter', 'none');
    set(legend_handle, 'Color', 'w', 'TextColor', 'k', ...
        'EdgeColor', [0.25 0.25 0.25]);
end
print(fig, char(file), '-dpng', '-r140');
close(fig);
end

function summary = build_summary(summary_raw, cpf_results, cpf_success, ...
        lam_raw, lam, keep_idx, Vmag, bus_ids, physical, fig_paths)
summary = struct();
summary.success = cpf_success;
summary.entrypoint = 'runcpf_psse';
summary.source_trace = 'selected_controls_no_genq_pqbrak';
summary.selection = 'last stored state for each repeated lambda';
summary.raw_points = numel(lam_raw);
summary.settled_points = numel(lam);
summary.removed_points = numel(lam_raw) - numel(lam);
summary.unique_lambda_ratio = numel(lam) / max(numel(lam_raw), 1);
summary.max_repeated_points_per_lambda = max(run_lengths(lam_raw));
summary.keep_idx = keep_idx;
summary.target_load_scale = summary_raw.target_load_scale;
summary.max_lambda = max(lam);
summary.load_factor_at_nose = 1 + ...
    (summary.target_load_scale - 1) * summary.max_lambda;
summary.raw_event_counts = summary_raw.event_counts;
summary.raw_events = numel(cpf_results.cpf.events);
[min_v, min_idx] = min(Vmag(:, end));
vm_physical = Vmag(:, end);
vm_physical(~physical) = Inf;
[min_v_physical, min_idx_physical] = min(vm_physical);
summary.final_min_v_bus = bus_ids(min_idx);
summary.final_min_v = min_v;
summary.final_min_physical_v_bus = bus_ids(min_idx_physical);
summary.final_min_physical_v = min_v_physical;
summary.physical_buses = nnz(physical);
summary.fig_paths = fig_paths;
end

function counts = run_lengths(lam_raw)
if isempty(lam_raw)
    counts = 0;
    return;
end
lam_col = lam_raw(:);
run_start = [1; find(diff(lam_col) ~= 0) + 1];
run_end = [run_start(2:end) - 1; numel(lam_col)];
counts = run_end - run_start + 1;
end

function write_outputs(outdir, summary, lam, Vmag, bus_ids, base_kv, ...
        bus_type, physical, sets, keep_idx)
writematrix(lam(:), fullfile(outdir, 'cpf_settled_lambda.csv'));
writematrix(Vmag, fullfile(outdir, 'cpf_settled_vmag.csv'));
writematrix(keep_idx(:), fullfile(outdir, 'settled_keep_indices.csv'));
writetable(table(bus_ids, base_kv, bus_type, physical, ...
    'VariableNames', {'bus_i', 'base_kv', 'bus_type', 'physical'}), ...
    fullfile(outdir, 'cpf_bus_meta.csv'));
writetable(summary.raw_event_counts, fullfile(outdir, 'raw_event_counts.csv'));

min_v = min(Vmag, [], 1)';
max_v = max(Vmag, [], 1)';
load_factor = 1 + (summary.target_load_scale - 1) * lam(:);
writetable(table((1:numel(lam))', keep_idx(:), lam(:), load_factor, ...
    min_v, max_v, 'VariableNames', {'settled_step_index', ...
    'raw_step_index', 'lambda', 'load_multiplier', 'min_VM_pu', ...
    'max_VM_pu'}), fullfile(outdir, 'cpf_settled_trace.csv'));

set_names = strings(0, 1);
set_buses = zeros(0, 1);
for k = 1:numel(sets)
    idx = sets(k).idx(:);
    set_names = [set_names; repmat(string(sets(k).name), numel(idx), 1)]; %#ok<AGROW>
    set_buses = [set_buses; bus_ids(idx)]; %#ok<AGROW>
end
writetable(table(set_names, set_buses, ...
    'VariableNames', {'set_name', 'bus_i'}), ...
    fullfile(outdir, 'curve_sets.csv'));

write_summary_md(outdir, summary);
end

function write_summary_md(outdir, summary)
md = fullfile(outdir, 'summary.md');
fid = fopen(md, 'w');
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, '# Settled runcpf_psse TRANSPA PV curves\n\n');
fprintf(fid, 'Source trace: `%s`.\n\n', summary.source_trace);
fprintf(fid, 'Selection: %s.\n\n', summary.selection);
fprintf(fid, 'Controls inherited from source run: `ACTAPS=1`, `SWSHNT=1`, ');
fprintf(fid, '`VARLIM=0`, `GENERAL.PQBRAK=0`, `DCTAPS=0`, `FACTS=0`.\n\n');
fprintf(fid, '## Results\n\n');
fprintf(fid, '- success: `%d`\n', summary.success);
fprintf(fid, '- raw CPF points: `%d`\n', summary.raw_points);
fprintf(fid, '- settled CPF points: `%d`\n', summary.settled_points);
fprintf(fid, '- removed repeated-control points: `%d`\n', ...
    summary.removed_points);
fprintf(fid, '- max repeated points for one lambda: `%d`\n', ...
    summary.max_repeated_points_per_lambda);
fprintf(fid, '- raw CPF events: `%d`\n', summary.raw_events);
fprintf(fid, '- max lambda: `%.12g`\n', summary.max_lambda);
fprintf(fid, '- load factor at nose: `%.12g`\n', ...
    summary.load_factor_at_nose);
fprintf(fid, '- physical buses plotted: `%d`\n', summary.physical_buses);
fprintf(fid, '- final minimum physical-bus voltage bus: `%g`\n', ...
    summary.final_min_physical_v_bus);
fprintf(fid, '- final minimum physical-bus voltage: `%.12g pu`\n', ...
    summary.final_min_physical_v);
fprintf(fid, '- final minimum voltage bus: `%g`\n', summary.final_min_v_bus);
fprintf(fid, '- final minimum voltage: `%.12g pu`\n\n', summary.final_min_v);
fprintf(fid, '## Raw Event Counts\n\n');
for k = 1:height(summary.raw_event_counts)
    fprintf(fid, '- `%s`: `%d`\n', summary.raw_event_counts.event(k), ...
        summary.raw_event_counts.count(k));
end
fprintf(fid, '\n## Figures\n\n');
for k = 1:numel(summary.fig_paths)
    fprintf(fid, '- `%s`\n', summary.fig_paths(k));
end
end
