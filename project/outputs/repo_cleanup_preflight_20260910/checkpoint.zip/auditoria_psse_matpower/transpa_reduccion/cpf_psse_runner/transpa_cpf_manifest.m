function manifest = transpa_cpf_manifest(root, outdir, opts, summary, ...
        gen_pq_trace_file)
%TRANSPA_CPF_MANIFEST Machine-readable run manifest.

manifest = struct();
manifest.schema = 'transpa_cpf_psse_runner/v1';
manifest.created_at = char(datetime('now', 'Format', 'yyyy-MM-dd HH:mm:ss'));
manifest.root = root;
manifest.outdir = outdir;
manifest.run_id = opts.run_id;
manifest.case_function = opts.case_function;
manifest.mode = opts.mode;
manifest.options = opts;
manifest.summary = rmfield_if_present(summary, ...
    {'event_counts', 'fig_paths', 'swshunt_band_repair'});
manifest.gen_pq_trace_file = gen_pq_trace_file;
manifest.warning = '';
if opts.controls.GENQ ~= 0 && strcmp(opts.mode, 'psse')
    manifest.warning = ['GENQ enabled with direct runcpf_psse; ' ...
        'genq_synced is the safer historical flow.'];
end
end

function s = rmfield_if_present(s, names)
for k = 1:numel(names)
    if isfield(s, names{k})
        s = rmfield(s, names{k});
    end
end
end
