function sets = transpa_cpf_curve_sets(bus_ids, base_kv, physical, active, ...
        ports, Vmag, opts)
%TRANSPA_CPF_CURVE_SETS Build standard TRANSPA CPF plot groups.

prefix = mode_title(opts);
sets = struct('name', {}, 'title', {}, 'idx', {}, 'with_legend', {});
sets(end+1) = make_set('all_active_buses', ...
    [prefix ' - all active buses'], find(active), false);
sets(end+1) = make_set('all_physical_buses', ...
    [prefix ' - all physical retained buses'], find(physical), false);
sets(end+1) = make_set('boundary_ports', ...
    [prefix ' - TRANSPA/SADI boundary ports'], ...
    find(ismember(bus_ids, ports)), true);
sets(end+1) = make_set('buses_500kv', ...
    [prefix ' - buses >= 400 kV'], find(physical & base_kv >= 400), true);

drop = Vmag(:, 1) - Vmag(:, end);
drop(~physical) = -Inf;
[~, ord_drop] = sort(drop, 'descend');
sets(end+1) = make_set('worst_40_voltage_drop', ...
    [prefix ' - worst 40 voltage drops'], ...
    ord_drop(1:min(40, nnz(isfinite(drop)))), true);

final_v = Vmag(:, end);
final_v(~physical) = Inf;
[~, ord_low] = sort(final_v, 'ascend');
sets(end+1) = make_set('lowest_40_final_voltage', ...
    [prefix ' - lowest 40 final voltages'], ...
    ord_low(1:min(40, nnz(isfinite(final_v)))), true);
end

function s = make_set(name, title_text, idx, with_legend)
s = struct('name', name, 'title', title_text, ...
    'idx', idx(:), 'with_legend', with_legend);
end

function title_text = mode_title(opts)
switch lower(opts.mode)
    case 'regular'
        title_text = 'regular CPF';
    case 'genq_synced'
        title_text = 'GENQ synced CPF-PSS/E';
    otherwise
        title_text = 'runcpf_psse';
end
end
