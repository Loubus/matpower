function mpc = transpa_cpf_apply_options(mpc, opts)
%TRANSPA_CPF_APPLY_OPTIONS Apply PSS/E control options to the case struct.

if ~isfield(mpc, 'psse')
    error('transpa_cpf_apply_options:missing_psse', ...
        'The reduced TRANSPA case must include mpc.psse metadata.');
end

if isfield(mpc.psse, 'solved_snapshot_policy')
    mpc.psse.solved_snapshot_policy.enable_genq_control = ...
        opts.controls.GENQ ~= 0;
end
if ~isfield(mpc.psse, 'system')
    mpc.psse.system = struct();
end
if ~isfield(mpc.psse.system, 'solver')
    mpc.psse.system.solver = struct();
end
if ~isfield(mpc.psse.system, 'general')
    mpc.psse.system.general = struct();
end

mpc.psse.system.solver.ACTAPS = opts.controls.ACTAPS;
mpc.psse.system.solver.SWSHNT = opts.controls.SWSHNT;
mpc.psse.system.solver.VARLIM = opts.controls.VARLIM;
mpc.psse.system.solver.DCTAPS = opts.controls.DCTAPS;
mpc.psse.system.solver.FACTS = opts.controls.FACTS;
mpc.psse.system.general.PQBRAK = opts.controls.PQBRAK;

if opts.swshunt_repair
    mpc = repair_swshunt_voltage_bands(mpc);
end

if isfield(mpc.psse, 'reduced_control_policy')
    mpc.psse.reduced_control_policy.active_transformer_taps = ...
        opts.controls.ACTAPS ~= 0;
    mpc.psse.reduced_control_policy.active_switched_shunts = ...
        opts.controls.SWSHNT ~= 0;
    mpc.psse.reduced_control_policy.active_generator_q_controls = ...
        opts.controls.GENQ ~= 0;
end
if isfield(mpc.psse, 'swdev')
    mpc.psse.swdev.collapse_disabled = opts.swdev_collapse_disabled;
    mpc.psse.swdev.collapse_policy = opts.swdev_collapse_policy;
end
end

function mpc = repair_swshunt_voltage_bands(mpc)
if ~isfield(mpc.psse, 'swshunt') || ~isfield(mpc.psse.swshunt, 'num') || ...
        isempty(mpc.psse.swshunt.num)
    return;
end

[~, ~, ~, ~, BUS_I, ~, ~, ~, ~, ~, BUS_AREA, ~, ~, BASE_KV, ZONE] = idx_bus;
sw = mpc.psse.swshunt;
num = sw.num;
cols = sw.colnames;
i_col = psse_col(cols, 'I');
modsw_col = psse_col(cols, 'MODSW');
vswhi_col = psse_col(cols, 'VSWHI');
vswlo_col = psse_col(cols, 'VSWLO');
binit_col = sw.binit_col;
b1_col = psse_col(cols, 'B1');
if any([i_col modsw_col vswhi_col vswlo_col binit_col b1_col] == 0)
    return;
end

lo = num(:, vswlo_col);
hi = num(:, vswhi_col);
zero_band = isfinite(lo) & isfinite(hi) & abs(hi - lo) < 1e-9;
donor_ok = isfinite(lo) & isfinite(hi) & hi > lo + 1e-9;
repair_rows = find(zero_band);
if isempty(repair_rows)
    return;
end

bus = num(:, i_col);
modsw = num(:, modsw_col);
binit = num(:, binit_col);
b1 = num(:, b1_col);
[base_kv, area, zone] = swshunt_bus_meta(mpc.bus, bus, BUS_I, ...
    BASE_KV, BUS_AREA, ZONE);

target_bus = zeros(numel(repair_rows), 1);
target_old_lo = zeros(numel(repair_rows), 1);
target_old_hi = zeros(numel(repair_rows), 1);
donor_bus = zeros(numel(repair_rows), 1);
donor_lo = zeros(numel(repair_rows), 1);
donor_hi = zeros(numel(repair_rows), 1);
donor_row = zeros(numel(repair_rows), 1);
for rr = 1:numel(repair_rows)
    k = repair_rows(rr);
    candidates = find(donor_ok);
    score = abs(base_kv(candidates) - base_kv(k)) * 10 + ...
        abs(area(candidates) - area(k)) + ...
        0.5 * abs(zone(candidates) - zone(k)) + ...
        5 * (modsw(candidates) ~= modsw(k)) + ...
        25 * (sign(b1(candidates)) ~= sign(b1(k))) + ...
        0.2 * abs(abs(b1(candidates)) - abs(b1(k))) + ...
        0.05 * abs(binit(candidates) - binit(k));
    score(~isfinite(score)) = Inf;
    [~, best] = min(score);
    d = candidates(best);
    num(k, vswlo_col) = lo(d);
    num(k, vswhi_col) = hi(d);
    target_bus(rr) = bus(k);
    target_old_lo(rr) = lo(k);
    target_old_hi(rr) = hi(k);
    donor_bus(rr) = bus(d);
    donor_lo(rr) = lo(d);
    donor_hi(rr) = hi(d);
    donor_row(rr) = d;
end

mpc.psse.swshunt.num = num;
mpc.psse.swshunt_band_repair = table(target_bus, target_old_lo, ...
    target_old_hi, donor_bus, donor_row, donor_lo, donor_hi, ...
    'VariableNames', {'bus_i', 'old_vswlo', 'old_vswhi', ...
    'donor_bus_i', 'donor_row', 'new_vswlo', 'new_vswhi'});
end

function [base_kv, area, zone] = swshunt_bus_meta(bus_mat, bus_ext, ...
        BUS_I, BASE_KV, BUS_AREA, ZONE)
base_kv = NaN(size(bus_ext));
area = NaN(size(bus_ext));
zone = NaN(size(bus_ext));
for kk = 1:numel(bus_ext)
    row = find(bus_mat(:, BUS_I) == bus_ext(kk), 1);
    if ~isempty(row)
        base_kv(kk) = bus_mat(row, BASE_KV);
        area(kk) = bus_mat(row, BUS_AREA);
        zone(kk) = bus_mat(row, ZONE);
    end
end
end

function col = psse_col(cols, name)
col = find(strcmpi(cols, name), 1);
if isempty(col)
    col = 0;
end
end
