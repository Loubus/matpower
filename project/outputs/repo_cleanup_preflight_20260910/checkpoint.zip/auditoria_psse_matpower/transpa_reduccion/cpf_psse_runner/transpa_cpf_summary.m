function summary = transpa_cpf_summary(cpf_results, cpf_success, opts, ...
        physical, fig_paths, cpf_elapsed_seconds, plot_elapsed_seconds, ...
        total_elapsed_seconds, mpc_base, run_info)
%TRANSPA_CPF_SUMMARY Build a stable scalar summary for exports.

define_constants;
[min_v, min_idx] = min(cpf_results.bus(:, VM));
vm_physical = cpf_results.bus(:, VM);
vm_physical(~physical) = Inf;
[min_v_physical, min_idx_physical] = min(vm_physical);
lam = cpf_results.cpf.lam(:);

summary = struct();
summary.success = cpf_success;
summary.mode = opts.mode;
summary.entrypoint = run_info.entrypoint;
summary.run_id = opts.run_id;
summary.target_load_scale = opts.load_scale;
summary.cpf_initial_step = opts.cpf.step;
summary.cpf_max_step = opts.cpf.step_max;
summary.cpf_stop_at = opts.cpf.stop_at;
summary.max_lambda = max(lam);
summary.load_factor_at_nose = 1 + (opts.load_scale - 1) * ...
    summary.max_lambda;
summary.points = numel(lam);
summary.events = numel(cpf_results.cpf.events);
summary.event_counts = event_counts(cpf_results);
summary.final_min_v_bus = cpf_results.bus(min_idx, BUS_I);
summary.final_min_v = min_v;
summary.final_min_physical_v_bus = cpf_results.bus(min_idx_physical, BUS_I);
summary.final_min_physical_v = min_v_physical;
summary.physical_buses = nnz(physical);
summary.cpf_elapsed_seconds = cpf_elapsed_seconds;
summary.plot_elapsed_seconds = plot_elapsed_seconds;
summary.total_elapsed_seconds = total_elapsed_seconds;
summary.fig_paths = fig_paths;
summary.ACTAPS = psse_summary_value(mpc_base, 'solver', 'ACTAPS', NaN);
summary.SWSHNT = psse_summary_value(mpc_base, 'solver', 'SWSHNT', NaN);
summary.VARLIM = psse_summary_value(mpc_base, 'solver', 'VARLIM', NaN);
summary.DCTAPS = psse_summary_value(mpc_base, 'solver', 'DCTAPS', NaN);
summary.FACTS = psse_summary_value(mpc_base, 'solver', 'FACTS', NaN);
summary.PQBRAK = psse_summary_value(mpc_base, 'general', 'PQBRAK', NaN);
summary.GENQ = opts.controls.GENQ;
summary.gen_capability = opts.gen_capability;
summary.gen_capability_enforce = opts.gen_capability_enforce;
summary.gen_redispatch = opts.gen_redispatch;
summary.gen_pq_trace = opts.gen_pq_trace;
summary.swshunt_band_repair = table();
if isfield(mpc_base, 'psse') && isfield(mpc_base.psse, 'swshunt_band_repair')
    summary.swshunt_band_repair = mpc_base.psse.swshunt_band_repair;
end
end

function val = psse_summary_value(mpc, group, name, default)
val = default;
if isfield(mpc, 'psse') && isfield(mpc.psse, 'system') && ...
        isfield(mpc.psse.system, group) && ...
        isfield(mpc.psse.system.(group), name)
    val = mpc.psse.system.(group).(name);
end
end

function counts = event_counts(cpf_results)
counts = table(string.empty(0, 1), zeros(0, 1), ...
    'VariableNames', {'event', 'count'});
if ~isfield(cpf_results, 'cpf') || ~isfield(cpf_results.cpf, 'events') || ...
        isempty(cpf_results.cpf.events)
    return;
end
names = string({cpf_results.cpf.events.name})';
[u, ~, ic] = unique(names);
counts = table(u, accumarray(ic, 1), 'VariableNames', {'event', 'count'});
end
