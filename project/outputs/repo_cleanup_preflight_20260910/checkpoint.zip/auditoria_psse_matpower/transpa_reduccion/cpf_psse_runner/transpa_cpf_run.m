function results = transpa_cpf_run(user_opts)
%TRANSPA_CPF_RUN Canonical configurable CPF runner for reduced TRANSPA.
%
% RESULTS = TRANSPA_CPF_RUN(OPTS) runs the explicit reduced TRANSPA case with
% either regular MATPOWER CPF, direct runcpf_psse, or the GENQ synchronized
% CPF path. It centralizes the options previously spread across several
% one-off scripts.

if nargin < 1
    user_opts = struct();
end
if isfield(user_opts, 'vsc_capability_gen_enforce') && ...
        ~isfield(user_opts, 'gen_capability_enforce')
    user_opts.gen_capability_enforce = user_opts.vsc_capability_gen_enforce;
end
opts = transpa_cpf_merge_opts(transpa_cpf_default_opts(), user_opts);
opts = normalize_opts(opts);

total_tic = tic;
root = transpa_project_root();
configure_paths(root);
outdir = resolve_outdir(root, opts);
if ~exist(outdir, 'dir')
    mkdir(outdir);
end

define_constants;
[mpc_base, mpopt_case] = feval(opts.case_function);
mpc_base = transpa_cpf_apply_options(mpc_base, opts);

gen_capability_classification = table();
if opts.gen_capability
    [mpc_base, gen_capability_classification] = ...
        apply_transpa_reduced_gen_capability(mpc_base, outdir);
end

gen_redispatch_classification = table();
if opts.gen_redispatch
    [mpc_base, gen_redispatch_classification] = ...
        apply_transpa_reduced_gen_redispatch_policy(mpc_base, ...
        opts.redispatch_rho, outdir, opts.redispatch_min_mw);
end

mpc_target = transpa_cpf_build_target(mpc_base, opts.load_scale);
mpopt_cpf = build_mpopt(mpopt_case, opts);
gen_pq_trace_file = '';
if opts.gen_pq_trace
    gen_pq_trace_file = fullfile(outdir, 'gen_pq_trace.mat');
    if ~isfield(mpopt_cpf, 'exp') || isempty(mpopt_cpf.exp)
        mpopt_cpf.exp = struct();
    end
    mpopt_cpf.exp.psse_gen_pq_trace_file = gen_pq_trace_file;
end

cpf_tic = tic;
[cpf_results, cpf_success, run_info] = run_selected_mode( ...
    mpc_base, mpc_target, mpopt_cpf, opts);
cpf_elapsed_seconds = toc(cpf_tic);

lam = cpf_results.cpf.lam(:)';
Vmag = abs(cpf_results.cpf.V);
bus_ids = cpf_results.bus(:, BUS_I);
base_kv = cpf_results.bus(:, BASE_KV);
bus_type = cpf_results.bus(:, BUS_TYPE);
physical = bus_ids < 900000 & bus_type ~= NONE;
active = bus_type ~= NONE;

plot_tic = tic;
sets = transpa_cpf_curve_sets(bus_ids, base_kv, physical, active, ...
    opts.ports, Vmag, opts);
fig_paths = strings(0, 1);
if opts.plots
    fig_paths = transpa_cpf_plot_curve_sets(outdir, lam, Vmag, bus_ids, ...
        base_kv, sets);
    fig_paths = [fig_paths; transpa_cpf_plot_physical_pages(outdir, lam, ...
        Vmag, bus_ids, base_kv, find(physical), opts)];
end
plot_elapsed_seconds = toc(plot_tic);
total_elapsed_seconds = toc(total_tic);

summary = transpa_cpf_summary(cpf_results, cpf_success, opts, physical, ...
    fig_paths, cpf_elapsed_seconds, plot_elapsed_seconds, ...
    total_elapsed_seconds, mpc_base, run_info);
manifest = transpa_cpf_manifest(root, outdir, opts, summary, ...
    gen_pq_trace_file);

transpa_cpf_write_outputs(outdir, summary, manifest, lam, Vmag, bus_ids, ...
    base_kv, bus_type, physical, sets);

mat_file = fullfile(outdir, sprintf('%s.mat', opts.run_id));
if opts.save_mat
    save(mat_file, 'cpf_results', 'cpf_success', 'run_info', ...
        'mpc_base', 'mpc_target', 'mpopt_cpf', 'opts', 'sets', ...
        'fig_paths', 'summary', 'manifest', ...
        'gen_capability_classification', ...
        'gen_redispatch_classification', 'gen_pq_trace_file', ...
        opts.save_version);
end

results = struct( ...
    'success', cpf_success, ...
    'outdir', outdir, ...
    'mat_file', mat_file, ...
    'summary', summary, ...
    'manifest', manifest, ...
    'fig_paths', {fig_paths}, ...
    'gen_pq_trace_file', gen_pq_trace_file, ...
    'opts', opts, ...
    'run_info', run_info);

fprintf('TRANSPA CPF outputs written to:\n  %s\n', outdir);
fprintf(['mode=%s, success=%d, max_lambda=%.12g, load_factor=%.12g, ' ...
    'points=%d, events=%d, total_seconds=%.3f\n'], ...
    opts.mode, cpf_success, summary.max_lambda, ...
    summary.load_factor_at_nose, summary.points, summary.events, ...
    total_elapsed_seconds);
end

function opts = normalize_opts(opts)
opts.mode = lower(char(opts.mode));
valid_modes = {'psse', 'regular', 'genq_synced'};
if ~ismember(opts.mode, valid_modes)
    error('transpa_cpf_run:invalid_mode', ...
        'opts.mode must be one of: psse, regular, genq_synced.');
end
if opts.controls.GENQ ~= 0 && strcmp(opts.mode, 'psse')
    warning('transpa_cpf_run:genq_direct_psse', ...
        ['GENQ is enabled with direct runcpf_psse. For the historical ' ...
        'synced active-set flow, set opts.mode = ''genq_synced''.']);
end
if isempty(opts.run_id)
    opts.run_id = transpa_cpf_run_id(opts);
end
if isempty(opts.outdir_name)
    opts.outdir_name = opts.run_id;
end
end

function root = transpa_project_root()
runner_dir = fileparts(mfilename('fullpath'));
root = fileparts(fileparts(fileparts(runner_dir)));
end

function configure_paths(root)
paths = {
    fullfile(root, 'matpower', 'lib')
    fullfile(root, 'matpower', 'lib', 't')
    fullfile(root, 'auditoria_psse_matpower')
    fullfile(root, 'auditoria_psse_matpower', 'transpa_reduccion')
    fullfile(root, 'auditoria_psse_matpower', 'transpa_reduccion', ...
        'cpf_psse_runner')
    fullfile(root, 'auditoria_psse_matpower', 'results', ...
        'transpa_reduccion_v1')
    };
for k = 1:numel(paths)
    if ~contains(path, paths{k})
        addpath(paths{k});
    end
end
end

function outdir = resolve_outdir(root, opts)
if ~isempty(opts.outdir)
    outdir = opts.outdir;
else
    outdir = fullfile(root, 'auditoria_psse_matpower', 'results', ...
        opts.outdir_name);
end
end

function mpopt_cpf = build_mpopt(mpopt_case, opts)
mpopt_cpf = mpoption(mpopt_case, ...
    'verbose', 0, ...
    'out.all', 0, ...
    'cpf.stop_at', opts.cpf.stop_at, ...
    'cpf.step', opts.cpf.step, ...
    'cpf.step_max', opts.cpf.step_max, ...
    'cpf.adapt_step', opts.cpf.adapt_step, ...
    'cpf.enforce_q_lims', opts.cpf.enforce_q_lims, ...
    'cpf.plot.level', opts.cpf.plot_level, ...
    'vsc_mtdc.capability_gen_enforce', ...
    double(opts.gen_capability_enforce));
if strcmp(opts.mode, 'genq_synced')
    mpopt_cpf = mp.psse_mpx_options(mpopt_cpf);
end
end

function [cpf_results, cpf_success, run_info] = run_selected_mode( ...
        mpc_base, mpc_target, mpopt_cpf, opts)
run_info = struct();
run_info.entrypoint = opts.mode;
switch opts.mode
    case 'regular'
        [cpf_results, cpf_success] = runcpf(mpc_base, mpc_target, ...
            mpopt_cpf);
        run_info.entrypoint = 'runcpf';
    case 'psse'
        [cpf_results, cpf_success] = runcpf_psse(mpc_base, mpc_target, ...
            mpopt_cpf);
        run_info.entrypoint = 'runcpf_psse';
    case 'genq_synced'
        [cpf_results, cpf_success, run_info] = run_genq_synced( ...
            mpc_base, mpc_target, mpopt_cpf);
end
end

function [cpf_results, success, info] = run_genq_synced(mpcb0, mpct0, mpopt)
% GENQ can change base BUS_TYPE before CPF target synchronization.
[mpcb, prep_base, mpopt] = mp.psse_prepare_case(mpcb0, mpopt, 'cpf_base');
[mpct, prep_target] = mp.psse_prepare_case(mpct0, mpopt, 'cpf_target');
mpcb_ref = mpcb;

mpopt_pf = mpoption(mpopt, ...
    'verbose', 0, ...
    'out.all', 0, ...
    'pf.enforce_q_lims', mpopt.cpf.enforce_q_lims);
mpopt_pf.exp.psse_keep_swdev_collapsed = 1;

[rb1, success_pf1] = runpf_psse(mpcb, mpopt_pf);
if ~success_pf1
    error('transpa_cpf_run:initial_pf_failed', ...
        'Initial runpf_psse did not converge.');
end
mpct1 = mp.psse_sync_cpf_target(rb1, mpct, mpcb_ref);

[rb2, success_pf2] = runpf(rb1, mpopt_pf);
if ~success_pf2
    error('transpa_cpf_run:synced_pf_failed', ...
        'Synced active-set runpf did not converge.');
end
mpct2 = mp.psse_sync_cpf_target(rb2, mpct1, rb1);

[cpf_results, success] = runcpf(rb2, mpct2, mpopt);

info = struct();
info.prep_base = prep_base;
info.prep_target = prep_target;
info.success_pf1 = success_pf1;
info.success_pf2 = success_pf2;
info.entrypoint = 'runpf_psse + synced active-set + runcpf with mp.xt_psse';
end
