function opts = transpa_cpf_preset(name)
%TRANSPA_CPF_PRESET Named presets for common reduced TRANSPA CPF studies.

opts = transpa_cpf_default_opts();
name = lower(char(name));
switch name
    case {'psse', 'tap_shunt', 'tap_shunt_capability'}
        opts.mode = 'psse';
        opts.outdir_name = 'transpa_cpf_psse_tap_shunt_capability';
        opts.run_id = opts.outdir_name;

    case {'no_controls', 'psse_no_controls'}
        opts.mode = 'psse';
        opts.controls.ACTAPS = 0;
        opts.controls.SWSHNT = 0;
        opts.outdir_name = 'transpa_cpf_psse_no_controls';
        opts.run_id = opts.outdir_name;

    case {'all_disabled', 'psse_all_disabled', ...
            'all_disabled_pv_only', 'psse_all_disabled_pv_only'}
        opts.mode = 'psse';
        opts.controls.ACTAPS = 0;
        opts.controls.SWSHNT = 0;
        opts.controls.GENQ = 0;
        opts.controls.VARLIM = 0;
        opts.controls.PQBRAK = 0;
        opts.controls.DCTAPS = 0;
        opts.controls.FACTS = 0;
        opts.swshunt_repair = false;
        opts.swdev_collapse_disabled = false;
        opts.gen_capability = false;
        opts.gen_capability_enforce = false;
        opts.gen_redispatch = false;
        opts.gen_pq_trace = false;
        opts.plots = false;
        opts.outdir_name = 'transpa_cpf_psse_all_disabled_pv_only';
        opts.run_id = opts.outdir_name;

    case {'regular', 'regular_baseline'}
        opts.mode = 'regular';
        opts.swshunt_repair = false;
        opts.gen_capability = false;
        opts.outdir_name = 'regular_cpf_transpa_reduced_all_pv';
        opts.run_id = opts.outdir_name;
        opts.cpf.step = 0.005;
        opts.cpf.step_max = 0.005;

    case {'redispatch_trace', 'capability_redispatch_trace'}
        opts.mode = 'psse';
        opts.controls.ACTAPS = 0;
        opts.controls.SWSHNT = 0;
        opts.gen_capability = true;
        opts.gen_redispatch = true;
        opts.redispatch_rho = 0.40;
        opts.redispatch_min_mw = 1.0;
        opts.gen_pq_trace = true;
        opts.outdir_name = ['runcpf_psse_transpa_no_ultc_no_swshunt_' ...
            'genredispatch_rho040_min1mw_capability_pqtrace_nowindfix'];
        opts.run_id = 'runcpf_psse_transpa_repaired_swshunt_bands';

    case {'genq', 'genq_synced'}
        opts.mode = 'genq_synced';
        opts.controls.GENQ = 1;
        opts.controls.VARLIM = 99;
        opts.load_scale = 2.0;
        opts.outdir_name = 'runcpf_psse_transpa_genq_ultc_swshunt';
        opts.run_id = 'cpf_genq_ultc_swshunt';

    otherwise
        error('transpa_cpf_preset:unknown_preset', ...
            'Unknown TRANSPA CPF preset: %s.', name);
end
end
