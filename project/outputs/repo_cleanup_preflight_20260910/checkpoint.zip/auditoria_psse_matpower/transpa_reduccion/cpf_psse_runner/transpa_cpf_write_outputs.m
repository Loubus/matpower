function transpa_cpf_write_outputs(outdir, summary, manifest, lam, Vmag, ...
        bus_ids, base_kv, bus_type, physical, sets)
%TRANSPA_CPF_WRITE_OUTPUTS Write CSV, JSON, and README outputs.

writematrix(lam(:), fullfile(outdir, 'cpf_lambda.csv'));
writematrix(Vmag, fullfile(outdir, 'cpf_vmag.csv'));
writetable(table(bus_ids, base_kv, bus_type, physical, ...
    'VariableNames', {'bus_i', 'base_kv', 'bus_type', 'physical'}), ...
    fullfile(outdir, 'cpf_bus_meta.csv'));
writetable(summary.event_counts, fullfile(outdir, 'event_counts.csv'));
if ~isempty(summary.swshunt_band_repair)
    writetable(summary.swshunt_band_repair, ...
        fullfile(outdir, 'swshunt_band_repair.csv'));
end

min_v = min(Vmag, [], 1)';
max_v = max(Vmag, [], 1)';
load_factor = 1 + (summary.target_load_scale - 1) * lam(:);
writetable(table((1:numel(lam))', lam(:), load_factor, min_v, max_v, ...
    'VariableNames', {'step_index', 'lambda', 'load_multiplier', ...
    'min_VM_pu', 'max_VM_pu'}), fullfile(outdir, 'cpf_trace.csv'));

set_names = strings(0, 1);
set_buses = zeros(0, 1);
for k = 1:numel(sets)
    idx = sets(k).idx(:);
    set_names = [set_names; repmat(string(sets(k).name), numel(idx), 1)]; %#ok<AGROW>
    set_buses = [set_buses; bus_ids(idx)]; %#ok<AGROW>
end
writetable(table(set_names, set_buses, ...
    'VariableNames', {'set_name', 'bus_i'}), ...
    fullfile(outdir, 'curve_sets.csv'));

write_manifest_json(outdir, manifest);
write_summary_md(outdir, summary, manifest);
end

function write_manifest_json(outdir, manifest)
json_file = fullfile(outdir, 'manifest.json');
fid = fopen(json_file, 'w');
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, '%s\n', jsonencode(manifest, 'PrettyPrint', true));
end

function write_summary_md(outdir, summary, manifest)
md = fullfile(outdir, 'README.md');
fid = fopen(md, 'w');
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, '# TRANSPA CPF/PSS-E run\n\n');
fprintf(fid, 'Run id: `%s`.\n\n', summary.run_id);
fprintf(fid, 'Case: `%s`.\n\n', manifest.case_function);
fprintf(fid, 'Mode: `%s`.\n\n', summary.mode);
fprintf(fid, 'Entry point: `%s`.\n\n', summary.entrypoint);
fprintf(fid, ['Control values: `ACTAPS=%g`, `SWSHNT=%g`, `GENQ=%g`, ' ...
    '`VARLIM=%g`, `GENERAL.PQBRAK=%g`, `DCTAPS=%g`, `FACTS=%g`.\n\n'], ...
    summary.ACTAPS, summary.SWSHNT, summary.GENQ, summary.VARLIM, ...
    summary.PQBRAK, summary.DCTAPS, summary.FACTS);
fprintf(fid, ['Options: `swshunt_repair=%d`, `gen_capability=%d`, ' ...
    '`gen_capability_enforce=%d`, `gen_redispatch=%d`, ' ...
    '`gen_pq_trace=%d`.\n\n'], ...
    manifest.options.swshunt_repair, summary.gen_capability, ...
    summary.gen_capability_enforce, summary.gen_redispatch, ...
    summary.gen_pq_trace);
if ~isempty(manifest.warning)
    fprintf(fid, 'Warning: %s\n\n', manifest.warning);
end
if ~isempty(summary.swshunt_band_repair)
    fprintf(fid, 'Switched-shunt zero-width voltage bands repaired from similar retained records:\n\n');
    for k = 1:height(summary.swshunt_band_repair)
        r = summary.swshunt_band_repair(k, :);
        fprintf(fid, ['- bus `%g`: `%.6g-%.6g` copied from bus `%g` ' ...
            '(row `%d`), replacing `%.6g-%.6g`\n'], ...
            r.bus_i, r.new_vswlo, r.new_vswhi, r.donor_bus_i, ...
            r.donor_row, r.old_vswlo, r.old_vswhi);
    end
    fprintf(fid, '\n');
end
fprintf(fid, 'Target: uniform `PD/QD = %.3gx` for nonzero-load buses.\n\n', ...
    summary.target_load_scale);
fprintf(fid, 'Stop condition: `cpf.stop_at = %s`.\n\n', summary.cpf_stop_at);
fprintf(fid, 'CPF step settings: `cpf.step = %.6g`, `cpf.step_max = %.6g`, `cpf.adapt_step = 1`.\n\n', ...
    summary.cpf_initial_step, summary.cpf_max_step);
fprintf(fid, '## Results\n\n');
fprintf(fid, '- success: `%d`\n', summary.success);
fprintf(fid, '- max lambda: `%.12g`\n', summary.max_lambda);
fprintf(fid, '- load factor at nose: `%.12g`\n', ...
    summary.load_factor_at_nose);
fprintf(fid, '- CPF points: `%d`\n', summary.points);
fprintf(fid, '- CPF events: `%d`\n', summary.events);
fprintf(fid, '- physical buses plotted: `%d`\n', summary.physical_buses);
fprintf(fid, '- final minimum physical-bus voltage bus: `%g`\n', ...
    summary.final_min_physical_v_bus);
fprintf(fid, '- final minimum physical-bus voltage: `%.12g pu`\n', ...
    summary.final_min_physical_v);
fprintf(fid, '- final minimum voltage bus: `%g`\n', summary.final_min_v_bus);
fprintf(fid, '- final minimum voltage: `%.12g pu`\n\n', summary.final_min_v);
fprintf(fid, '## Timing\n\n');
fprintf(fid, '- CPF solve seconds: `%.3f`\n', summary.cpf_elapsed_seconds);
fprintf(fid, '- plot/write seconds after CPF: `%.3f`\n', ...
    summary.plot_elapsed_seconds);
fprintf(fid, '- total script seconds: `%.3f`\n\n', ...
    summary.total_elapsed_seconds);
fprintf(fid, '## Event Counts\n\n');
for k = 1:height(summary.event_counts)
    fprintf(fid, '- `%s`: `%d`\n', summary.event_counts.event(k), ...
        summary.event_counts.count(k));
end
fprintf(fid, '\n## Figures\n\n');
for k = 1:numel(summary.fig_paths)
    fprintf(fid, '- `%s`\n', summary.fig_paths(k));
end
end
