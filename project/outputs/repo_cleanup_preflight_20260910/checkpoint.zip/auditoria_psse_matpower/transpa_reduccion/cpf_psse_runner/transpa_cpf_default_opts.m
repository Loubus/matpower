function opts = transpa_cpf_default_opts()
%TRANSPA_CPF_DEFAULT_OPTS Default options for the reduced TRANSPA CPF runner.

opts = struct();
opts.mode = 'psse';              % 'psse', 'regular', or 'genq_synced'
opts.case_function = 'case_transpa_reduced_v1_explicit';
opts.load_scale = 2.0;
opts.outdir = '';
opts.outdir_name = '';
opts.run_id = '';
opts.plots = true;
opts.diagnostics = true;
opts.save_mat = true;
opts.save_version = '-v7.3';

opts.cpf = struct();
opts.cpf.stop_at = 'NOSE';
opts.cpf.step = 0.001;
opts.cpf.step_max = 0.005;
opts.cpf.adapt_step = 1;
opts.cpf.enforce_q_lims = 0;
opts.cpf.plot_level = 0;

opts.controls = struct();
opts.controls.ACTAPS = 1;
opts.controls.SWSHNT = 1;
opts.controls.GENQ = 0;
opts.controls.VARLIM = 0;
opts.controls.PQBRAK = 0;
opts.controls.DCTAPS = 0;
opts.controls.FACTS = 0;

opts.swshunt_repair = true;
opts.swdev_collapse_disabled = true;
opts.swdev_collapse_policy = 'retained_as_explicit_branches';

opts.gen_capability = true;
opts.gen_redispatch = false;
opts.redispatch_rho = 0.40;
opts.redispatch_min_mw = 1.0;
opts.gen_pq_trace = false;
opts.gen_capability_enforce = true;

opts.ports = [1008; 1226; 2206; 2208; 2222; 2302];
opts.plot_page_size = 50;
opts.plot_prefix = 'pv';
end
