function page_paths = transpa_cpf_plot_physical_pages(outdir, lam, Vmag, ...
        bus_ids, base_kv, idx_all, opts)
%TRANSPA_CPF_PLOT_PHYSICAL_PAGES Plot paged physical-bus PV curves.

page_size = opts.plot_page_size;
page_paths = strings(0, 1);
for p = 1:ceil(numel(idx_all) / page_size)
    lo = (p - 1) * page_size + 1;
    hi = min(p * page_size, numel(idx_all));
    idx = idx_all(lo:hi);
    file_name = sprintf('%s_all_physical_buses_page_%02d.png', ...
        opts.plot_prefix, p);
    title_text = sprintf('%s - physical retained buses page %02d', ...
        opts.mode, p);
    page_paths(end+1, 1) = transpa_cpf_plot_one(outdir, file_name, lam, ...
        Vmag, bus_ids, base_kv, idx, title_text, true); %#ok<AGROW>
end
end

function file = transpa_cpf_plot_one(outdir, file_name, lam, Vmag, bus_ids, ...
        base_kv, idx, title_text, with_legend)
file = string(fullfile(outdir, file_name));
fig = figure('Visible', 'off', 'Color', 'w', 'InvertHardcopy', 'off', ...
    'Position', [80 80 1500 900]);
ax = axes(fig);
set(ax, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', ...
    'GridColor', [0.75 0.75 0.75], ...
    'MinorGridColor', [0.88 0.88 0.88]);
hold(ax, 'on');
plot(ax, lam, Vmag(idx, :)', 'LineWidth', 1.0);
grid(ax, 'on');
box(ax, 'on');
xlabel(ax, '\lambda');
ylabel(ax, 'Voltage magnitude [pu]');
title(ax, title_text, 'Interpreter', 'none');
xlim(ax, [min(lam), max(lam)]);
ymin = max(0.35, min(Vmag(idx, :), [], 'all') - 0.035);
ymax = min(1.25, max(Vmag(idx, :), [], 'all') + 0.035);
ylim(ax, [ymin ymax]);
if with_legend && numel(idx) <= 50
    labels = cell(numel(idx), 1);
    for ii = 1:numel(idx)
        labels{ii} = sprintf('%g (%.0f kV)', bus_ids(idx(ii)), ...
            base_kv(idx(ii)));
    end
    legend(ax, labels, 'Location', 'eastoutside', 'Interpreter', 'none');
end
print(fig, char(file), '-dpng', '-r140');
close(fig);
end
