# TRANSPA CPF/PSS-E runner

This folder contains the canonical configurable runner for reduced TRANSPA
CPF/PSS-E studies. Prefer this entrypoint for new runs:

```matlab
addpath('auditoria_psse_matpower/transpa_reduccion');
addpath('auditoria_psse_matpower/transpa_reduccion/cpf_psse_runner');
opts = transpa_cpf_default_opts();
opts.controls.ACTAPS = 1;
opts.controls.SWSHNT = 1;
opts.gen_capability = true;
opts.gen_redispatch = false;
opts.gen_pq_trace = true;
results = run_transpa_cpf_psse(opts);
```

The public wrapper is:

```matlab
results = run_transpa_cpf_psse(opts)
```

The implementation lives in:

```matlab
transpa_cpf_run(opts)
```

For the all-disabled baseline with diagnostics restricted to PV plots:

```matlab
addpath('auditoria_psse_matpower/transpa_reduccion');
out = run_transpa_cpf_psse_all_disabled_pv_only();
```

To inspect that configuration without running CPF:

```matlab
cfg = run_transpa_cpf_psse_all_disabled_pv_only(false);
```

## Modes

- `opts.mode = 'psse'`: direct `runcpf_psse` path.
- `opts.mode = 'regular'`: regular MATPOWER `runcpf` path.
- `opts.mode = 'genq_synced'`: historical GENQ-safe path using
  `runpf_psse`, target active-set synchronization, then `runcpf`.

## Main options

- `opts.load_scale`: uniform scale applied to nonzero `PD/QD` buses;
  default is `2.0`, so `lambda = 0.20` means a 20% load increase.
- `opts.controls.ACTAPS`: PSS/E transformer tap control.
- `opts.controls.SWSHNT`: PSS/E switched-shunt control.
- `opts.controls.GENQ`: generator Q-control metadata.
- `opts.controls.VARLIM`: PSS/E VAR limit mode.
- `opts.controls.PQBRAK`: low-voltage load modifier.
- `opts.controls.DCTAPS`: two-terminal DC tap controls.
- `opts.controls.FACTS`: FACTS controls.
- `opts.swshunt_repair`: repair zero-width switched-shunt voltage bands.
- `opts.gen_capability`: apply TRANSPA generator capability metadata.
- `opts.gen_capability_enforce`: enable CPF/PSS-E generator capability
  active-set enforcement. This is passed internally through MATPOWER's
  `mpopt.vsc_mtdc.capability_gen_enforce` field, but it applies to
  conventional generators too.
- `opts.gen_redispatch`: apply TRANSPA generator redispatch policy.
- `opts.redispatch_rho`: redispatch reserve fraction.
- `opts.redispatch_min_mw`: redispatch minimum available reserve.
- `opts.gen_pq_trace`: write `gen_pq_trace.mat` through
  `mpopt.exp.psse_gen_pq_trace_file`.
- `opts.plots`: write PV curve plots.
- `opts.outdir_name` or `opts.outdir`: output location control.

The named preset `transpa_cpf_preset('all_disabled_pv_only')` disables all
PSS/E control families (`ACTAPS`, `SWSHNT`, `GENQ`, `VARLIM`, `PQBRAK`,
`DCTAPS`, `FACTS`) plus switched-shunt repair, switched-device collapse
retention, generator capability metadata/enforcement, redispatch,
generator P-Q tracing, and the runner's legacy PV plots. Use
`transpa_cpf_pv_only_diagnostics_opts()` for the matching
`psse_study_diagnostics` options (`plot_modules = {'pv'}`).

Each run writes CSV exports, `manifest.json`, `README.md`, and optionally a
MAT file and figures under `auditoria_psse_matpower/results/<outdir_name>`.

The older TRANSPA runner scripts in the parent folder are now compatibility
wrappers around this implementation.
