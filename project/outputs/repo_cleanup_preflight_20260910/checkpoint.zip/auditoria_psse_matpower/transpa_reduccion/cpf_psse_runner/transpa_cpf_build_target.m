function mpc_target = transpa_cpf_build_target(mpc_base, load_scale)
%TRANSPA_CPF_BUILD_TARGET Uniformly scale nonzero TRANSPA loads.

define_constants;
mpc_target = mpc_base;
load_mask = mpc_base.bus(:, PD) ~= 0 | mpc_base.bus(:, QD) ~= 0;
mpc_target.bus(load_mask, [PD QD]) = ...
    load_scale * mpc_base.bus(load_mask, [PD QD]);
end
