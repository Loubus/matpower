function fig_paths = transpa_cpf_plot_curve_sets(outdir, lam, Vmag, bus_ids, ...
        base_kv, sets)
%TRANSPA_CPF_PLOT_CURVE_SETS Plot all configured voltage-lambda groups.

fig_paths = strings(0, 1);
for k = 1:numel(sets)
    idx = sets(k).idx;
    idx = idx(idx > 0 & idx <= size(Vmag, 1));
    if isempty(idx)
        continue;
    end
    file_name = sprintf('pv_%s.png', sets(k).name);
    fig_paths(end+1, 1) = plot_curves(outdir, file_name, lam, Vmag, ...
        bus_ids, base_kv, idx, sets(k).title, sets(k).with_legend); %#ok<AGROW>
end
end

function file = plot_curves(outdir, file_name, lam, Vmag, bus_ids, base_kv, ...
        idx, title_text, with_legend)
file = string(fullfile(outdir, file_name));
fig = figure('Visible', 'off', 'Color', 'w', 'InvertHardcopy', 'off', ...
    'Position', [80 80 1500 900]);
ax = axes(fig);
set(ax, ...
    'Color', 'w', ...
    'XColor', 'k', ...
    'YColor', 'k', ...
    'GridColor', [0.75 0.75 0.75], ...
    'MinorGridColor', [0.88 0.88 0.88]);
hold(ax, 'on');
if numel(idx) > 80
    plot(ax, lam, Vmag(idx, :)', 'LineWidth', 0.45, ...
        'Color', [0.18 0.28 0.42]);
elseif numel(idx) > 45
    plot(ax, lam, Vmag(idx, :)', 'LineWidth', 0.8);
else
    plot(ax, lam, Vmag(idx, :)', 'LineWidth', 1.15);
end
grid(ax, 'on');
box(ax, 'on');
xlabel(ax, '\lambda');
ylabel(ax, 'Voltage magnitude [pu]');
title_handle = title(ax, title_text, 'Interpreter', 'none');
set(title_handle, 'Color', 'k');
xlim(ax, [min(lam), max(lam)]);
ymin = max(0.35, min(Vmag(idx, :), [], 'all') - 0.035);
ymax = min(1.25, max(Vmag(idx, :), [], 'all') + 0.035);
ylim(ax, [ymin ymax]);
if with_legend && numel(idx) <= 50
    labels = cell(numel(idx), 1);
    for ii = 1:numel(idx)
        labels{ii} = sprintf('%g (%.0f kV)', bus_ids(idx(ii)), ...
            base_kv(idx(ii)));
    end
    legend_handle = legend(ax, labels, 'Location', 'eastoutside', ...
        'Interpreter', 'none');
    set(legend_handle, 'Color', 'w', 'TextColor', 'k', ...
        'EdgeColor', [0.25 0.25 0.25]);
end
print(fig, char(file), '-dpng', '-r140');
close(fig);
end
