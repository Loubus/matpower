function run_id = transpa_cpf_run_id(opts)
%TRANSPA_CPF_RUN_ID Build a deterministic result folder name from options.

parts = ["transpa_cpf", string(opts.mode)];
parts(end+1) = sprintf('load%03d', round(100 * opts.load_scale));
parts(end+1) = sprintf('actaps%d', opts.controls.ACTAPS ~= 0);
parts(end+1) = sprintf('swshnt%d', opts.controls.SWSHNT ~= 0);
parts(end+1) = sprintf('genq%d', opts.controls.GENQ ~= 0);
parts(end+1) = sprintf('pqbrak%d', opts.controls.PQBRAK ~= 0);
if opts.swshunt_repair
    parts(end+1) = "swrepair";
end
if opts.gen_capability
    parts(end+1) = "gencap";
end
if opts.gen_redispatch
    parts(end+1) = sprintf('redispatch_rho%03d_min%gmw', ...
        round(100 * opts.redispatch_rho), opts.redispatch_min_mw);
end
if opts.gen_pq_trace
    parts(end+1) = "pqtrace";
end
run_id = char(strjoin(parts, '_'));
run_id = regexprep(run_id, '[^\w.-]', '_');
end
