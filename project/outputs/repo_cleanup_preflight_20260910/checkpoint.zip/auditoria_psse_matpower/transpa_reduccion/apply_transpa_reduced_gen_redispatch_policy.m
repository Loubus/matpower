function [mpc, classification] = apply_transpa_reduced_gen_redispatch_policy( ...
        mpc, rho, outdir, min_change_mw)
%APPLY_TRANSPA_REDUCED_GEN_REDISPATCH_POLICY Add CPF redispatch metadata.
%
% Builds a TRANSPA-specific technology classification for the generic
% accepted-point CPF generator redispatch policy. Wind rows are classified and
% reported, but receive zero scheduled active-power redispatch by policy.

if nargin < 2 || isempty(rho)
    rho = 0.40;
end
if nargin < 3
    outdir = '';
end
if nargin < 4 || isempty(min_change_mw)
    min_change_mw = 0;
end

define_constants;
ng = size(mpc.gen, 1);
bus_names = transpa_bus_names(mpc, GEN_BUS);
technology = repmat({'thermal'}, ng, 1);
rule = repmat({'default_thermal'}, ng, 1);

for g = 1:ng
    name = upper(strtrim(bus_names{g}));
    if startsWith(name, 'SADI_EQ_')
        technology{g} = 'excluded_equivalent';
        rule{g} = 'sadi_boundary_equivalent';
    elseif contains(name, 'EO')
        technology{g} = 'wind';
        rule{g} = 'bus_name_contains_EO';
    elseif startsWith(name, 'FUTAHI') || startsWith(name, 'AMEGHI')
        technology{g} = 'hydraulic';
        rule{g} = 'known_hydro_bus_name';
    elseif contains(name, 'CC')
        technology{g} = 'combined_cycle';
        rule{g} = 'bus_name_contains_CC';
    elseif contains(name, 'TG') || contains(name, 'DI') || ...
            contains(name, 'FIAT') || startsWith(name, 'RESCHI')
        technology{g} = 'gas_small';
        rule{g} = 'gas_turbine_diesel_or_small_unit';
    elseif contains(name, 'TV')
        technology{g} = 'thermal';
        rule{g} = 'steam_turbine_bus_name';
    end
end

if ~isfield(mpc, 'cpf_policies') || isempty(mpc.cpf_policies)
    mpc.cpf_policies = struct();
end
mpc.cpf_policies.gen = struct( ...
    'policy', 'technology_dynamic_participation', ...
    'rho', rho, ...
    'min_change_mw', min_change_mw, ...
    'technology', {technology}, ...
    'technology_weights', struct( ...
        'hydraulic', 0.40, ...
        'combined_cycle', 0.35, ...
        'thermal', 0.15, ...
        'gas_small', 0.10, ...
        'wind', 0, ...
        'excluded_equivalent', 0), ...
    'exclude_technologies', {{'wind', 'excluded_equivalent'}});

[~, ~, ~, NONE, BUS_I, BUS_TYPE] = idx_bus;
bus_type = NaN(ng, 1);
for g = 1:ng
    row = find(mpc.bus(:, BUS_I) == mpc.gen(g, GEN_BUS), 1);
    if ~isempty(row)
        bus_type(g) = mpc.bus(row, BUS_TYPE);
    end
end
eligible = mpc.gen(:, GEN_STATUS) > 0 & ~isload(mpc.gen) & ...
    bus_type ~= NONE & ...
    ~ismember(technology, {'wind', 'excluded_equivalent'});

classification = table((1:ng)', mpc.gen(:, GEN_BUS), bus_names(:), ...
    bus_type, mpc.gen(:, GEN_STATUS), mpc.gen(:, PG), mpc.gen(:, PMAX), ...
    technology, eligible, rule, ...
    'VariableNames', {'gen_row', 'bus', 'bus_name', 'bus_type', ...
    'status', 'PG', 'PMAX', 'technology', 'eligible', ...
    'classification_rule'});

if ~isempty(outdir)
    if ~exist(outdir, 'dir')
        mkdir(outdir);
    end
    writetable(classification, fullfile(outdir, ...
        'transpa_reduced_gen_redispatch_classification.csv'));
end

function names = transpa_bus_names(mpc, GEN_BUS)
[~, ~, ~, ~, BUS_I] = idx_bus;
ng = size(mpc.gen, 1);
names = repmat({''}, ng, 1);
has_names = isfield(mpc, 'bus_name') && length(mpc.bus_name) == size(mpc.bus, 1);
for g = 1:ng
    row = find(mpc.bus(:, BUS_I) == mpc.gen(g, GEN_BUS), 1);
    if has_names && ~isempty(row)
        names{g} = char(mpc.bus_name(row));
    elseif ~isempty(row)
        names{g} = sprintf('BUS_%g', mpc.bus(row, BUS_I));
    else
        names{g} = sprintf('BUS_%g', mpc.gen(g, GEN_BUS));
    end
end
