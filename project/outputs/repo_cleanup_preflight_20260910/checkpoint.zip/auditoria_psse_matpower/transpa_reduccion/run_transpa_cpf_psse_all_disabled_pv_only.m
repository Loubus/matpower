function out = run_transpa_cpf_psse_all_disabled_pv_only(run_cpf)
%RUN_TRANSPA_CPF_PSSE_ALL_DISABLED_PV_ONLY All-disabled CPF + PV diagnostics.
%
% OUT = RUN_TRANSPA_CPF_PSSE_ALL_DISABLED_PV_ONLY() runs the reduced TRANSPA
% direct runcpf_psse case with PSS/E controls and optional runner features
% disabled, then writes only PV plots through psse_study_diagnostics.
%
% OUT = RUN_TRANSPA_CPF_PSSE_ALL_DISABLED_PV_ONLY(false) returns the CPF and
% diagnostics option structs without running the CPF.

if nargin < 1
    run_cpf = true;
end

runner_dir = fullfile(fileparts(mfilename('fullpath')), 'cpf_psse_runner');
addpath(runner_dir);
diag_dir = fileparts(fileparts(mfilename('fullpath')));
addpath(diag_dir);

cpf_opts = transpa_cpf_preset('all_disabled_pv_only');
diag_opts = transpa_cpf_pv_only_diagnostics_opts();

out = struct('cpf_opts', cpf_opts, 'diagnostics_opts', diag_opts);
if ~run_cpf
    return;
end

cpf_results = run_transpa_cpf_psse(cpf_opts);
diag_outdir = fullfile(cpf_results.outdir, 'diagnostics_pv_only');
diagnostics = psse_study_diagnostics(cpf_results.outdir, diag_outdir, ...
    diag_opts);

out.cpf_results = cpf_results;
out.diagnostics = diagnostics;
out.diagnostics_outdir = diag_outdir;
end
