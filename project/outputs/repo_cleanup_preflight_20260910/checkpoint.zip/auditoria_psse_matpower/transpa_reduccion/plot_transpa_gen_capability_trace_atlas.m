function atlas = plot_transpa_gen_capability_trace_atlas(run_outdir)
%PLOT_TRANSPA_GEN_CAPABILITY_TRACE_ATLAS Plot generator P-Q capability atlas.

if nargin < 1 || isempty(run_outdir)
    root = fileparts(fileparts(fileparts(mfilename('fullpath'))));
    run_outdir = fullfile(root, 'auditoria_psse_matpower', 'results', ...
        'runcpf_psse_transpa_no_ultc_no_swshunt_genredispatch_rho040_min1mw_capability_fix2_plots');
end

root = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(fullfile(root, 'matpower', 'lib'));

mat_file = fullfile(run_outdir, 'runcpf_psse_transpa_repaired_swshunt_bands.mat');
S = load(mat_file, 'cpf_results', 'mpc_base', 'summary');
cpf_results = S.cpf_results;
mpc_base = S.mpc_base;
summary = S.summary;

define_constants;
atlas_dir = fullfile(run_outdir, 'gen_capability_trace_atlas');
if ~exist(atlas_dir, 'dir')
    mkdir(atlas_dir);
end

audit = check_gen_capability(cpf_results);
elements = audit.elements(:);
ng = numel(elements);
max_lam = summary.max_lambda;
cap_lam = capability_event_lambdas(cpf_results);
[hist_by_idx, event_table] = capability_history_by_idx(cpf_results, cap_lam);

per_page = 6;
n_pages = ceil(ng / per_page);
curve_pages = strings(n_pages, 1);
trace_pages = strings(n_pages, 1);
for page = 1:n_pages
    idx = (page - 1) * per_page + (1:per_page);
    idx = idx(idx <= ng);
    curve_pages(page) = plot_curve_page(atlas_dir, page, elements, idx, ...
        mpc_base, cpf_results, hist_by_idx, max_lam, PG, QG);
    trace_pages(page) = plot_trace_page(atlas_dir, page, elements, idx, ...
        mpc_base, cpf_results, hist_by_idx, max_lam, PG, QG);
end

technology_page = plot_technology_redispatch(atlas_dir, cpf_results);
write_readme(atlas_dir, run_outdir, summary, audit, curve_pages, ...
    trace_pages, technology_page);
writetable(event_table, fullfile(atlas_dir, ...
    'generator_capability_event_points.csv'));

atlas = struct( ...
    'atlas_dir', atlas_dir, ...
    'curve_pages', curve_pages, ...
    'trace_pages', trace_pages, ...
    'technology_page', technology_page, ...
    'event_table', event_table);

fprintf('Generator capability/trace atlas written to:\n  %s\n', atlas_dir);
fprintf('curve_pages=%d trace_pages=%d technology_page=%s\n', ...
    numel(curve_pages), numel(trace_pages), technology_page);

function lams = capability_event_lambdas(results)
events = results.cpf.events;
names = {events.name};
rows = find(strcmp(names, 'PSSE_GEN_CAPABILITY'));
lams = NaN(numel(rows), 1);
for k = 1:numel(rows)
    tok = regexp(events(rows(k)).msg, ...
        'lambda\s*=\s*([0-9eE+\-.]+)', 'tokens', 'once');
    if ~isempty(tok)
        lams(k) = str2double(tok{1});
    end
end

function [by_idx, T] = capability_history_by_idx(results, cap_lam)
by_idx = containers.Map('KeyType', 'double', 'ValueType', 'any');
T = table();
if ~isfield(results, 'psse') || ~isfield(results.psse, 'gen_capability') || ...
        ~isfield(results.psse.gen_capability, 'event_history')
    return;
end
hist = results.psse.gen_capability.event_history;
for h = 1:numel(hist)
    rep = hist{h};
    if isempty(rep) || ~isfield(rep, 'changed_idx')
        continue;
    end
    lam = NaN;
    if h <= numel(cap_lam)
        lam = cap_lam(h);
    elseif ~isempty(cap_lam)
        lam = cap_lam(end);
    end
    for r = 1:numel(rep.changed_idx)
        rec = struct( ...
            'history_index', h, ...
            'lambda', lam, ...
            'gen_idx', rep.changed_idx(r), ...
            'bus', rep.bus(r), ...
            'P_before', rep.P(r), ...
            'Q_before', rep.Q(r), ...
            'P_after', rep.P_saturated(r), ...
            'Q_after', rep.Q_saturated(r), ...
            'active_limit', string(rep.active_limit{r}));
        if isKey(by_idx, rec.gen_idx)
            rows = by_idx(rec.gen_idx);
            rows(end+1) = rec; %#ok<AGROW>
        else
            rows = rec;
        end
        by_idx(rec.gen_idx) = rows;
        T = [T; struct2table(rec)]; %#ok<AGROW>
    end
end

function file = plot_curve_page(atlas_dir, page, elements, idx, ...
        mpc_base, results, hist_by_idx, max_lam, PG, QG)
fig = figure('Visible', 'off', 'Color', 'w', ...
    'Position', [50 50 1600 1050]);
tl = tiledlayout(fig, 2, 3, 'TileSpacing', 'compact', 'Padding', 'compact');
title(tl, sprintf('Generator capability curves with P-Q setpoint events, page %02d', page));
for kk = 1:numel(idx)
    e = elements(idx(kk));
    ax = nexttile(tl);
    hold(ax, 'on');
    plot_capability_boundary(ax, e.info.curve, e.info.gen_type);
    plot(ax, mpc_base.gen(e.idx, PG), mpc_base.gen(e.idx, QG), ...
        'o', 'MarkerSize', 5, 'LineWidth', 1.2, ...
        'MarkerFaceColor', [0.15 0.45 0.95], ...
        'MarkerEdgeColor', [0.15 0.45 0.95]);
    if isKey(hist_by_idx, e.idx)
        recs = hist_by_idx(e.idx);
        plot(ax, [recs.P_before], [recs.Q_before], 'x', ...
            'Color', [0.8 0.2 0.15], 'LineWidth', 1.1);
        plot(ax, [recs.P_after], [recs.Q_after], '.', ...
            'Color', [0.15 0.55 0.25], 'MarkerSize', 14);
        plot(ax, [mpc_base.gen(e.idx, PG), [recs.P_after], ...
            results.gen(e.idx, PG)], ...
            [mpc_base.gen(e.idx, QG), [recs.Q_after], ...
            results.gen(e.idx, QG)], '-', ...
            'Color', [0.35 0.35 0.35], 'LineWidth', 0.8);
    end
    plot(ax, results.gen(e.idx, PG), results.gen(e.idx, QG), ...
        's', 'MarkerSize', 5, 'LineWidth', 1.2, ...
        'MarkerFaceColor', [0.05 0.05 0.05], ...
        'MarkerEdgeColor', [0.05 0.05 0.05]);
    grid(ax, 'on');
    axis(ax, 'equal');
    xlabel(ax, 'P (MW)');
    ylabel(ax, 'Q (MVAr)');
    title(ax, sprintf('gen %d bus %g %s | lambda %.4f', ...
        e.idx, e.bus, e.info.gen_type, max_lam), 'Interpreter', 'none');
end
file = fullfile(atlas_dir, sprintf('capability_curves_page_%02d.png', page));
print(fig, file, '-dpng', '-r150');
close(fig);
file = string(file);

function file = plot_trace_page(atlas_dir, page, elements, idx, ...
        mpc_base, results, hist_by_idx, max_lam, PG, QG)
fig = figure('Visible', 'off', 'Color', 'w', ...
    'Position', [50 50 1600 1050]);
tl = tiledlayout(fig, 2, 3, 'TileSpacing', 'compact', 'Padding', 'compact');
title(tl, sprintf('Generator P/Q setpoint event traces vs lambda, page %02d', page));
for kk = 1:numel(idx)
    e = elements(idx(kk));
    ax = nexttile(tl);
    [lam, P, Q] = setpoint_trace(e.idx, mpc_base, results, ...
        hist_by_idx, max_lam, PG, QG);
    yyaxis(ax, 'left');
    stairs(ax, lam, P, '-o', 'LineWidth', 1.0, 'MarkerSize', 3);
    ylabel(ax, 'P (MW)');
    yyaxis(ax, 'right');
    stairs(ax, lam, Q, '-s', 'LineWidth', 1.0, 'MarkerSize', 3);
    ylabel(ax, 'Q (MVAr)');
    grid(ax, 'on');
    xlabel(ax, 'lambda');
    xlim(ax, [0 max_lam]);
    title(ax, sprintf('gen %d bus %g %s', ...
        e.idx, e.bus, e.info.gen_type), 'Interpreter', 'none');
end
file = fullfile(atlas_dir, sprintf('pq_setpoint_traces_page_%02d.png', page));
print(fig, file, '-dpng', '-r150');
close(fig);
file = string(file);

function [lam, P, Q] = setpoint_trace(g, mpc_base, results, ...
        hist_by_idx, max_lam, PG, QG)
lam = 0;
P = mpc_base.gen(g, PG);
Q = mpc_base.gen(g, QG);
if isKey(hist_by_idx, g)
    recs = hist_by_idx(g);
    for r = 1:numel(recs)
        if isfinite(recs(r).lambda)
            lam(end+1, 1) = recs(r).lambda; %#ok<AGROW>
            P(end+1, 1) = recs(r).P_after; %#ok<AGROW>
            Q(end+1, 1) = recs(r).Q_after; %#ok<AGROW>
        end
    end
end
lam(end+1, 1) = max_lam;
P(end+1, 1) = results.gen(g, PG);
Q(end+1, 1) = results.gen(g, QG);
[lam, order] = sort(lam);
P = P(order);
Q = Q(order);

function file = plot_technology_redispatch(atlas_dir, results)
file = "";
if ~isfield(results, 'psse') || ~isfield(results.psse, 'gen_redispatch') || ...
        ~isfield(results.psse.gen_redispatch, 'history') || ...
        isempty(results.psse.gen_redispatch.history)
    return;
end
hist = results.psse.gen_redispatch.history;
names = {};
for h = 1:numel(hist)
    names = union(names, hist(h).technology_names(:)');
end
names = names(:);
lam = arrayfun(@(x)x.lambda, hist(:));
Y = zeros(numel(hist), numel(names));
cum = zeros(1, numel(names));
for h = 1:numel(hist)
    for j = 1:numel(hist(h).technology_names)
        k = find(strcmp(names, hist(h).technology_names{j}), 1);
        cum(k) = cum(k) + hist(h).technology_applied_mw(j);
    end
    Y(h, :) = cum;
end
fig = figure('Visible', 'off', 'Color', 'w', ...
    'Position', [50 50 1300 750]);
plot(lam, Y, 'LineWidth', 1.4);
grid on;
xlabel('lambda');
ylabel('Cumulative redispatch applied (MW)');
title('Dynamic redispatch applied by technology');
legend(names, 'Interpreter', 'none', 'Location', 'best');
file = fullfile(atlas_dir, 'technology_redispatch_cumulative.png');
print(fig, file, '-dpng', '-r150');
close(fig);
file = string(file);

function plot_capability_boundary(ax, curve, type_name) %#ok<INUSD>
if ~isfield(curve, 'QA') && isfield(curve, 'QB')
    P = [curve.PA curve.PB curve.PC curve.PC curve.PB curve.PA];
    Q = [0 curve.QB curve.QB -curve.QC -curve.QB 0];
elseif all(isfield(curve, {'QA', 'PB', 'QB', 'PC', 'QC', 'PD', 'QD', 'QE'}))
    q0 = (curve.QA^2 - curve.PB^2 - curve.QB^2) / ...
        (2 * curve.QA - 2 * curve.QB);
    s0 = curve.QA - q0;
    p_arc = linspace(curve.PA, curve.PB, 40);
    q_arc = sqrt(max(0, s0^2 - p_arc.^2)) + q0;
    P = [curve.PA p_arc curve.PB curve.PC curve.PD curve.PA curve.PA];
    Q = [curve.QA q_arc curve.QB curve.QC curve.QD curve.QE curve.QA];
else
    return;
end
plot(ax, P, Q, 'k-', 'LineWidth', 1.2);
patch(ax, P, Q, [0.92 0.95 1.0], 'FaceAlpha', 0.25, ...
    'EdgeColor', 'none');
plot(ax, P, Q, 'k-', 'LineWidth', 1.2);

function write_readme(atlas_dir, run_outdir, summary, audit, curve_pages, ...
        trace_pages, technology_page)
fid = fopen(fullfile(atlas_dir, 'README.md'), 'w');
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, '# Generator capability and P-Q trace atlas\n\n');
fprintf(fid, 'Source run: `%s`\n\n', run_outdir);
fprintf(fid, '- max lambda: `%.15g`\n', summary.max_lambda);
fprintf(fid, '- final capability violations: `%d`\n', audit.violations);
fprintf(fid, '- generator capability pages: `%d`\n', numel(curve_pages));
fprintf(fid, '- P/Q setpoint trace pages: `%d`\n\n', numel(trace_pages));
fprintf(fid, ['The P-Q curve pages show the generic capability boundary, ' ...
    'base operating point, final operating point, and exact capability ' ...
    'projection events saved in the run history. The lambda trace pages ' ...
    'show the saved setpoint-event stair trace; the standard CPF MAT file ' ...
    'does not store every generator P/Q table at every CPF point.\n\n']);
fprintf(fid, '## Files\n\n');
for k = 1:numel(curve_pages)
    fprintf(fid, '- `%s`\n', curve_pages(k));
end
for k = 1:numel(trace_pages)
    fprintf(fid, '- `%s`\n', trace_pages(k));
end
if strlength(technology_page) > 0
    fprintf(fid, '- `%s`\n', technology_page);
end
