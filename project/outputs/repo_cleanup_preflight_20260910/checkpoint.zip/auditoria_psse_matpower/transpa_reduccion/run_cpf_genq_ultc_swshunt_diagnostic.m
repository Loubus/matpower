function results = run_cpf_genq_ultc_swshunt_diagnostic()
%RUN_CPF_GENQ_ULTC_SWSHUNT_DIAGNOSTIC CPF with active GENQ, ULTC and shunts.
%
% This diagnostic intentionally enables PSS/E generator Q control metadata
% for the reduced TRANSPA equivalent, while keeping ULTC and switched shunts
% active. It writes figures and CSV/MD summaries under results/.

root = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(fullfile(root, 'matpower', 'lib'));
addpath(fullfile(root, 'matpower', 'lib', 't'));
addpath(fullfile(root, 'auditoria_psse_matpower'));
addpath(fullfile(root, 'auditoria_psse_matpower', 'results', ...
    'transpa_reduccion_v1'));

outdir = fullfile(root, 'auditoria_psse_matpower', 'results', ...
    'runcpf_psse_transpa_genq_ultc_swshunt');
if ~exist(outdir, 'dir')
    mkdir(outdir);
end

define_constants;
load_scale = 1.15;
ports = [1008; 1226; 2206; 2208; 2222; 2302];

[mpcb0, mpopt] = case_transpa_reduced_v1_explicit();
mpcb0 = activate_psse_controls(mpcb0);

mpct0 = mpcb0;
mpct0.bus(:, [PD QD]) = mpcb0.bus(:, [PD QD]) * load_scale;

mpopt = mpoption(mpopt, ...
    'verbose', 0, ...
    'out.all', 0, ...
    'cpf.stop_at', 'NOSE', ...
    'cpf.enforce_q_lims', 0);
mpopt = mp.psse_mpx_options(mpopt);

[cpf_results, success, run_info] = run_cpf_with_synced_active_set( ...
    mpcb0, mpct0, mpopt);
save(fullfile(outdir, 'cpf_genq_ultc_swshunt_raw.mat'), ...
    'cpf_results', 'success', 'run_info', 'load_scale', 'ports', '-v7');

lam = cpf_results.cpf.lam(:)';
Vmag = abs(cpf_results.cpf.V);
bus_ids = cpf_results.bus(:, BUS_I);
base_kv = cpf_results.bus(:, BASE_KV);
physical = bus_ids < 900000;

sets = build_curve_sets(cpf_results, mpcb0, ports, physical, Vmag);
fig_paths = plot_curve_sets(outdir, lam, Vmag, bus_ids, base_kv, sets);
page_paths = plot_all_bus_pages(outdir, lam, Vmag, bus_ids, physical);
fig_paths = [fig_paths(:); page_paths(:)];

summary = build_summary(cpf_results, success, run_info, mpcb0, sets, fig_paths);
write_summary(outdir, summary);
write_tables(outdir, cpf_results, sets, bus_ids, base_kv, Vmag);

save(fullfile(outdir, 'cpf_genq_ultc_swshunt_results.mat'), ...
    'cpf_results', 'success', 'run_info', 'sets', 'fig_paths', ...
    'load_scale', 'ports', '-v7');

results = struct( ...
    'success', success, ...
    'outdir', outdir, ...
    'summary', summary, ...
    'fig_paths', {fig_paths}, ...
    'run_info', run_info);

fprintf('CPF GENQ/ULTC/SWSHNT diagnostic written to:\n  %s\n', outdir);
fprintf('success=%d, max lambda=%.12g, points=%d, events=%d\n', ...
    success, max(cpf_results.cpf.lam), numel(cpf_results.cpf.lam), ...
    numel(cpf_results.cpf.events));
end

function mpc = activate_psse_controls(mpc)
if ~isfield(mpc, 'psse')
    error('Diagnostic requires mpc.psse metadata.');
end
if isfield(mpc.psse, 'solved_snapshot_policy')
    mpc.psse.solved_snapshot_policy.enable_genq_control = true;
end
if ~isfield(mpc.psse, 'system')
    mpc.psse.system = struct();
end
if ~isfield(mpc.psse.system, 'solver')
    mpc.psse.system.solver = struct();
end
mpc.psse.system.solver.ACTAPS = 1;
mpc.psse.system.solver.SWSHNT = 1;
mpc.psse.system.solver.VARLIM = 99;
if isfield(mpc.psse, 'reduced_control_policy')
    mpc.psse.reduced_control_policy.active_transformer_taps = true;
    mpc.psse.reduced_control_policy.active_switched_shunts = true;
    mpc.psse.reduced_control_policy.active_generator_q_controls = true;
end
if isfield(mpc.psse, 'swdev')
    mpc.psse.swdev.collapse_disabled = true;
    mpc.psse.swdev.collapse_policy = 'retained_as_explicit_branches';
end
end

function [cpf_results, success, info] = run_cpf_with_synced_active_set( ...
        mpcb0, mpct0, mpopt)
% GENQ can change base BUS_TYPE during the initial PSS/E PF. Sync the target
% after that active-set is known, then run CPF with the PSS/E CPF extension.
[mpcb, prep_base, mpopt] = mp.psse_prepare_case(mpcb0, mpopt, 'cpf_base');
[mpct, prep_target] = mp.psse_prepare_case(mpct0, mpopt, 'cpf_target');
mpcb_ref = mpcb;

mpopt_pf = mpoption(mpopt, ...
    'verbose', 0, ...
    'out.all', 0, ...
    'pf.enforce_q_lims', mpopt.cpf.enforce_q_lims);
mpopt_pf.exp.psse_keep_swdev_collapsed = 1;

[rb1, success_pf1] = runpf_psse(mpcb, mpopt_pf);
if ~success_pf1
    error('Initial runpf_psse did not converge.');
end
mpct1 = mp.psse_sync_cpf_target(rb1, mpct, mpcb_ref);

[rb2, success_pf2] = runpf(rb1, mpopt_pf);
if ~success_pf2
    error('Synced active-set runpf did not converge.');
end
mpct2 = mp.psse_sync_cpf_target(rb2, mpct1, rb1);

[cpf_results, success] = runcpf(rb2, mpct2, mpopt);

info = struct();
info.prep_base = prep_base;
info.prep_target = prep_target;
info.success_pf1 = success_pf1;
info.success_pf2 = success_pf2;
info.entrypoint = 'runpf_psse + synced active-set + runcpf with mp.xt_psse';
info.note = ['Direct runcpf_psse can fail this diagnostic because GENQ ' ...
    'changes BUS_TYPE in the base before CPF target synchronization.'];
end

function sets = build_curve_sets(cpf_results, mpcb0, ports, physical, Vmag)
define_constants;
bus_ids = cpf_results.bus(:, BUS_I);
base_kv = cpf_results.bus(:, BASE_KV);
sets = struct('name', {}, 'title', {}, 'idx', {}, 'with_legend', {});

sets(end+1) = make_set('boundary_ports', ...
    'Frontera equivalente - puertos TRANSPA/SADI', ...
    find(ismember(bus_ids, ports)), true);
sets(end+1) = make_set('buses_500kv', ...
    'Barras >= 400 kV', ...
    find(physical & base_kv >= 400), true);
sets(end+1) = make_set('switched_shunt_buses', ...
    'Barras con switched shunts preservados', ...
    find(ismember(bus_ids, swshunt_buses(mpcb0))), true);
sets(end+1) = make_set('genq_generator_buses', ...
    'Barras con generadores GENQ retenidos', ...
    find(ismember(bus_ids, genq_buses(mpcb0))), false);
sets(end+1) = make_set('genq_regulated_buses', ...
    'Barras reguladas por GENQ', ...
    find(ismember(bus_ids, genq_regulated_buses(mpcb0))), true);
sets(end+1) = make_set('ultc_terminal_buses', ...
    'Barras terminales de transformadores retenidos', ...
    find(ismember(bus_ids, xfmr_terminal_buses(mpcb0))), false);

drop = Vmag(:, 1) - Vmag(:, end);
drop(~physical) = -Inf;
[~, ord_drop] = sort(drop, 'descend');
sets(end+1) = make_set('worst_40_voltage_drop', ...
    'Mayores caidas de tension hasta el punto final', ...
    ord_drop(1:min(40, nnz(isfinite(drop)))), true);

final_v = Vmag(:, end);
final_v(~physical) = Inf;
[~, ord_low] = sort(final_v, 'ascend');
sets(end+1) = make_set('lowest_40_final_voltage', ...
    'Barras con menor tension final', ...
    ord_low(1:min(40, nnz(isfinite(final_v)))), true);
end

function s = make_set(name, title_text, idx, with_legend)
s = struct('name', name, 'title', title_text, ...
    'idx', idx(:), 'with_legend', with_legend);
end

function buses = swshunt_buses(mpc)
buses = [];
if isfield(mpc.psse, 'swshunt') && isfield(mpc.psse.swshunt, 'num')
    c = psse_col(mpc.psse.swshunt.colnames, 'I');
    if c > 0
        buses = unique(mpc.psse.swshunt.num(:, c));
    end
end
end

function buses = genq_buses(mpc)
buses = [];
if isfield(mpc.psse, 'genq') && isfield(mpc.psse.genq, 'bus_ext')
    rows = mpc.psse.genq.status ~= 0;
    buses = unique(mpc.psse.genq.bus_ext(rows));
end
end

function buses = genq_regulated_buses(mpc)
buses = [];
if isfield(mpc.psse, 'genq') && isfield(mpc.psse.genq, 'reg_bus_ext')
    rows = mpc.psse.genq.status ~= 0;
    reg = mpc.psse.genq.reg_bus_ext(rows);
    reg(reg == 0 | isnan(reg)) = [];
    buses = unique(reg);
end
end

function buses = xfmr_terminal_buses(mpc)
buses = [];
if isfield(mpc.psse, 'xfmr') && isfield(mpc.psse.xfmr, 'two')
    x = mpc.psse.xfmr.two;
    i = psse_col(x.colnames, 'I');
    j = psse_col(x.colnames, 'J');
    stat = psse_col(x.colnames, 'STAT');
    rows = true(size(x.num, 1), 1);
    if stat > 0
        rows = x.num(:, stat) ~= 0;
    end
    buses = [buses; x.num(rows, i); x.num(rows, j)];
end
if isfield(mpc.psse, 'xfmr') && isfield(mpc.psse.xfmr, 'three')
    x = mpc.psse.xfmr.three;
    i = psse_col(x.colnames, 'I');
    j = psse_col(x.colnames, 'J');
    k = psse_col(x.colnames, 'K');
    stat = psse_col(x.colnames, 'STAT');
    rows = true(size(x.num, 1), 1);
    if stat > 0
        rows = x.num(:, stat) ~= 0;
    end
    buses = [buses; x.num(rows, i); x.num(rows, j); x.num(rows, k)];
end
buses = unique(buses);
buses(isnan(buses) | buses == 0) = [];
end

function fig_paths = plot_curve_sets(outdir, lam, Vmag, bus_ids, base_kv, sets)
fig_paths = strings(0, 1);
for k = 1:numel(sets)
    idx = sets(k).idx;
    idx = idx(idx > 0 & idx <= size(Vmag, 1));
    if isempty(idx)
        continue;
    end
    file = fullfile(outdir, sprintf('pv_%s.png', sets(k).name));
    plot_curves(lam, Vmag, bus_ids, base_kv, idx, sets(k).title, ...
        file, sets(k).with_legend);
    fig_paths(end+1, 1) = string(file); %#ok<AGROW>
end
end

function page_paths = plot_all_bus_pages(outdir, lam, Vmag, bus_ids, physical)
idx_all = find(physical);
page_size = 60;
page_paths = strings(0, 1);
for p = 1:ceil(numel(idx_all) / page_size)
    lo = (p - 1) * page_size + 1;
    hi = min(p * page_size, numel(idx_all));
    idx = idx_all(lo:hi);
    file = fullfile(outdir, sprintf('pv_all_physical_page_%02d.png', p));
    title_text = sprintf('Todas las barras fisicas retenidas - pagina %02d', p);
    plot_curves(lam, Vmag, bus_ids, nan(size(bus_ids)), idx, ...
        title_text, file, false);
    page_paths(end+1, 1) = string(file); %#ok<AGROW>
end
end

function plot_curves(lam, Vmag, bus_ids, base_kv, idx, title_text, file, ...
        with_legend)
fig = figure('Visible', 'off', 'Color', 'w', 'Position', [80 80 1450 880]);
ax = axes(fig);
hold(ax, 'on');
if numel(idx) > 45
    plot(ax, lam, Vmag(idx, :)', 'LineWidth', 0.55, ...
        'Color', [0.28 0.34 0.50]);
else
    plot(ax, lam, Vmag(idx, :)', 'LineWidth', 1.2);
end
grid(ax, 'on');
box(ax, 'on');
xlabel(ax, '\lambda');
ylabel(ax, 'V [pu]');
title(ax, title_text, 'Interpreter', 'none');
ylim(ax, [max(0.45, min(Vmag(idx, :), [], 'all') - 0.04), ...
    min(1.25, max(Vmag(idx, :), [], 'all') + 0.04)]);
xlim(ax, [min(lam), max(lam)]);
if with_legend && numel(idx) <= 45
    labels = cell(numel(idx), 1);
    for ii = 1:numel(idx)
        if all(isnan(base_kv))
            labels{ii} = sprintf('%g', bus_ids(idx(ii)));
        else
            labels{ii} = sprintf('%g (%.0f kV)', bus_ids(idx(ii)), ...
                base_kv(idx(ii)));
        end
    end
    legend(ax, labels, 'Location', 'eastoutside', 'Interpreter', 'none');
end
print(fig, file, '-dpng', '-r130');
close(fig);
end

function summary = build_summary(cpf_results, success, run_info, mpcb0, sets, fig_paths)
define_constants;
events = event_counts(cpf_results);
[min_v, min_idx] = min(cpf_results.bus(:, VM));
genq = struct();
if isfield(cpf_results, 'psse') && isfield(cpf_results.psse, 'genq') && ...
        isfield(cpf_results.psse.genq, 'control')
    genq = cpf_results.psse.genq.control;
end
summary = struct();
summary.success = success;
summary.max_lambda = max(cpf_results.cpf.lam);
summary.points = numel(cpf_results.cpf.lam);
summary.events = numel(cpf_results.cpf.events);
summary.event_counts = events;
summary.final_min_v_bus = cpf_results.bus(min_idx, BUS_I);
summary.final_min_v = min_v;
summary.genq = genq;
summary.genq_rows = size(mpcb0.psse.genq.num, 1);
summary.swdev_rows = size(mpcb0.psse.swdev.num, 1);
summary.swdev_collapse_disabled = any(mpcb0.psse.swdev.collapse_disabled(:));
summary.run_info = run_info;
summary.sets = sets;
summary.fig_paths = fig_paths;
end

function counts = event_counts(cpf_results)
counts = table(string.empty(0, 1), zeros(0, 1), ...
    'VariableNames', {'event', 'count'});
if ~isfield(cpf_results, 'cpf') || ~isfield(cpf_results.cpf, 'events') || ...
        isempty(cpf_results.cpf.events)
    return;
end
names = string({cpf_results.cpf.events.name})';
[u, ~, ic] = unique(names);
count = accumarray(ic, 1);
counts = table(u, count, 'VariableNames', {'event', 'count'});
end

function write_summary(outdir, summary)
md = fullfile(outdir, 'resumen_cpf_genq_ultc_swshunt.md');
fid = fopen(md, 'w');
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, '# CPF TRANSPA con GENQ, ULTC y switched shunts activos\n\n');
fprintf(fid, 'Escenario diagnostico sobre `case_transpa_reduced_v1_explicit`.\n\n');
fprintf(fid, '## Configuracion\n\n');
fprintf(fid, '- `solved_snapshot_policy.enable_genq_control = true`\n');
fprintf(fid, '- `psse.system.solver.VARLIM = 99`\n');
fprintf(fid, '- `psse.system.solver.ACTAPS = 1`\n');
fprintf(fid, '- `psse.system.solver.SWSHNT = 1`\n');
fprintf(fid, '- `cpf.enforce_q_lims = 0`; se usa GENQ PSS/E, no el limite Q generico de MATPOWER.\n');
fprintf(fid, '- Target de carga: `1.15x`.\n');
fprintf(fid, '- Entrada: `%s`.\n\n', summary.run_info.entrypoint);
fprintf(fid, '## Resultado\n\n');
fprintf(fid, '| Metrica | Valor |\n|---|---:|\n');
fprintf(fid, '| CPF success | %d |\n', summary.success);
fprintf(fid, '| Lambda max | %.12g |\n', summary.max_lambda);
fprintf(fid, '| Puntos CPF | %d |\n', summary.points);
fprintf(fid, '| Eventos CPF | %d |\n', summary.events);
fprintf(fid, '| Bus minimo final | %.0f |\n', summary.final_min_v_bus);
fprintf(fid, '| V minimo final | %.12g |\n', summary.final_min_v);
fprintf(fid, '| GENQ filas preservadas | %d |\n', summary.genq_rows);
fprintf(fid, '| SWDEV filas preservadas | %d |\n', summary.swdev_rows);
fprintf(fid, '| SWDEV collapse disabled | %d |\n\n', summary.swdev_collapse_disabled);
if ~isempty(fieldnames(summary.genq))
    fprintf(fid, '## GENQ final\n\n');
    fprintf(fid, '| Campo | Valor |\n|---|---:|\n');
    fprintf(fid, '| enabled | %d |\n', summary.genq.enabled);
    fprintf(fid, '| active | %d |\n', summary.genq.active);
    fprintf(fid, '| local | %d |\n', summary.genq.local);
    fprintf(fid, '| remote | %d |\n', summary.genq.remote);
    fprintf(fid, '| limited_count | %d |\n', summary.genq.limited_count);
    fprintf(fid, '| at_min_count | %d |\n', summary.genq.at_min_count);
    fprintf(fid, '| at_max_count | %d |\n', summary.genq.at_max_count);
    fprintf(fid, '| num_adjustments | %d |\n\n', summary.genq.num_adjustments);
end
fprintf(fid, '## Eventos\n\n');
fprintf(fid, '| Evento | Conteo |\n|---|---:|\n');
for k = 1:height(summary.event_counts)
    fprintf(fid, '| %s | %d |\n', summary.event_counts.event(k), ...
        summary.event_counts.count(k));
end
fprintf(fid, '\n## Figuras\n\n');
for k = 1:numel(summary.fig_paths)
    fprintf(fid, '- `%s`\n', summary.fig_paths(k));
end
end

function write_tables(outdir, cpf_results, sets, bus_ids, base_kv, Vmag)
event_table = event_counts(cpf_results);
writetable(event_table, fullfile(outdir, 'event_counts.csv'));

rows = table();
for k = 1:numel(sets)
    idx = sets(k).idx;
    idx = idx(idx > 0 & idx <= numel(bus_ids));
    if isempty(idx)
        continue;
    end
    t = table( ...
        repmat(string(sets(k).name), numel(idx), 1), ...
        bus_ids(idx), ...
        base_kv(idx), ...
        Vmag(idx, 1), ...
        Vmag(idx, end), ...
        min(Vmag(idx, :), [], 2), ...
        'VariableNames', {'set_name', 'bus_i', 'base_kv', ...
        'vm_initial', 'vm_final', 'vm_min'});
    rows = [rows; t]; %#ok<AGROW>
end
writetable(rows, fullfile(outdir, 'selected_curve_buses.csv'));
end

function col = psse_col(cols, name)
col = find(strcmpi(cols, name), 1);
if isempty(col)
    col = 0;
end
end
