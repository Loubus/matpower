function results = run_runcpf_psse_transpa_repaired_swshunt_bands(do_plots, controls)
%RUN_RUNCPF_PSSE_TRANSPA_REPAIRED_SWSHUNT_BANDS Compatibility wrapper.
%
% Historical flexible TRANSPA CPF entrypoint. New code should call
% run_transpa_cpf_psse(opts) directly.

if nargin < 1 || isempty(do_plots)
    do_plots = true;
end
if nargin < 2 || isempty(controls)
    controls = struct();
end

opts = struct();
opts.mode = 'psse';
opts.run_id = 'runcpf_psse_transpa_repaired_swshunt_bands';
opts.outdir_name = control_value(controls, 'outdir_name', ...
    'runcpf_psse_transpa_repaired_swshunt_bands');
opts.load_scale = 2.0;
opts.plots = do_plots;
opts.swshunt_repair = true;
opts.gen_capability = true;
opts.gen_redispatch = control_value(controls, 'GEN_REDISPATCH', 0) ~= 0;
opts.redispatch_rho = control_value(controls, 'GEN_REDISPATCH_RHO', 0.40);
opts.redispatch_min_mw = control_value(controls, ...
    'GEN_REDISPATCH_MIN_MW', 1.0);
opts.gen_pq_trace = control_value(controls, 'GEN_PQ_TRACE', 0) ~= 0;
opts.controls = struct( ...
    'ACTAPS', control_value(controls, 'ACTAPS', 1), ...
    'SWSHNT', control_value(controls, 'SWSHNT', 1), ...
    'GENQ', control_value(controls, 'GENQ', 0), ...
    'VARLIM', control_value(controls, 'VARLIM', 0), ...
    'PQBRAK', control_value(controls, 'PQBRAK', 0), ...
    'DCTAPS', control_value(controls, 'DCTAPS', 0), ...
    'FACTS', control_value(controls, 'FACTS', 0));
opts.cpf = struct( ...
    'stop_at', 'NOSE', ...
    'step', 0.001, ...
    'step_max', 0.005, ...
    'adapt_step', 1, ...
    'enforce_q_lims', 0, ...
    'plot_level', 0);

if opts.controls.GENQ ~= 0
    opts.mode = 'genq_synced';
end

results = run_transpa_cpf_psse(opts);
end

function val = control_value(controls, name, default)
val = default;
if isfield(controls, name) && ~isempty(controls.(name))
    val = controls.(name);
end
end
