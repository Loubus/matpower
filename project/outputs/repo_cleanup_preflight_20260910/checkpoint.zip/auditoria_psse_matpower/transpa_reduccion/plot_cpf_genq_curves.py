from __future__ import annotations

import csv
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[2]
OUTDIR = ROOT / "auditoria_psse_matpower" / "results" / "runcpf_psse_transpa_genq_ultc_swshunt"


def read_table(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates = [
        Path("C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf"),
        Path("C:/Windows/Fonts/segoeuib.ttf" if bold else "C:/Windows/Fonts/segoeui.ttf"),
    ]
    for p in candidates:
        if p.exists():
            return ImageFont.truetype(str(p), size)
    return ImageFont.load_default()


FONT_TITLE = font(26, True)
FONT_AXIS = font(18)
FONT_TICK = font(14)
FONT_SMALL = font(13)


def load_data():
    lam = np.loadtxt(OUTDIR / "cpf_lambda.csv", delimiter=",")
    vmag = np.loadtxt(OUTDIR / "cpf_vmag.csv", delimiter=",")
    bus_meta = np.loadtxt(OUTDIR / "cpf_bus_meta.csv", delimiter=",")
    if vmag.ndim == 1:
        vmag = vmag.reshape(1, -1)
    bus_ids = bus_meta[:, 0].astype(int)
    base_kv = bus_meta[:, 1]
    sets: dict[str, list[int]] = {}
    for row in read_table(OUTDIR / "curve_sets.csv"):
        sets.setdefault(row["set_name"], []).append(int(float(row["bus_i"])))
    return lam, vmag, bus_ids, base_kv, sets


def compact_repeated_lambda(lam: np.ndarray, vmag: np.ndarray, tol: float = 1e-11):
    """Keep the final post-control point for each repeated lambda block."""
    keep: list[int] = []
    starts: list[int] = []
    start = 0
    for i in range(1, len(lam)):
        if abs(float(lam[i]) - float(lam[start])) > tol:
            starts.append(start)
            keep.append(i - 1)
            start = i
    starts.append(start)
    keep.append(len(lam) - 1)
    keep_arr = np.array(keep, dtype=int)
    start_arr = np.array(starts, dtype=int)
    return lam[keep_arr], vmag[:, keep_arr], keep_arr, start_arr


def accepted_control_jump_mask(
    vmag_raw: np.ndarray,
    starts: np.ndarray,
    keep: np.ndarray,
    threshold: float = 0.03,
) -> np.ndarray:
    """Mark accepted points reached through a same-lambda control jump."""
    pre = vmag_raw[:, starts]
    post = vmag_raw[:, keep]
    mask = np.abs(post - pre) > threshold
    if mask.shape[1]:
        mask[:, 0] = False
    return mask


def nice_ticks(lo: float, hi: float, n: int = 6) -> list[float]:
    if hi <= lo:
        return [lo]
    raw = (hi - lo) / max(1, n - 1)
    mag = 10 ** np.floor(np.log10(raw))
    step = min([1, 2, 5, 10], key=lambda x: abs(raw - x * mag)) * mag
    start = np.ceil(lo / step) * step
    ticks = []
    x = start
    while x <= hi + 1e-12:
        ticks.append(float(x))
        x += step
    return ticks


def palette(n: int) -> list[tuple[int, int, int, int]]:
    base = [
        (31, 119, 180, 255),
        (214, 39, 40, 255),
        (44, 160, 44, 255),
        (148, 103, 189, 255),
        (255, 127, 14, 255),
        (23, 190, 207, 255),
        (140, 86, 75, 255),
        (227, 119, 194, 255),
        (127, 127, 127, 255),
        (188, 189, 34, 255),
    ]
    if n <= len(base):
        return base[:n]
    colors = []
    for i in range(n):
        r = int(80 + 130 * ((i * 37) % 101) / 100)
        g = int(70 + 140 * ((i * 61) % 101) / 100)
        b = int(90 + 130 * ((i * 83) % 101) / 100)
        colors.append((r, g, b, 185 if n > 45 else 255))
    return colors


def dashed_line(
    draw: ImageDraw.ImageDraw,
    p0: tuple[float, float],
    p1: tuple[float, float],
    fill: tuple[int, int, int, int],
    width: int = 1,
    dash: float = 8,
    gap: float = 5,
):
    x0, y0 = p0
    x1, y1 = p1
    length = float(((x1 - x0) ** 2 + (y1 - y0) ** 2) ** 0.5)
    if length <= 1e-9:
        return
    ux = (x1 - x0) / length
    uy = (y1 - y0) / length
    pos = 0.0
    while pos < length:
        end = min(pos + dash, length)
        draw.line(
            [(x0 + ux * pos, y0 + uy * pos), (x0 + ux * end, y0 + uy * end)],
            fill=fill,
            width=width,
        )
        pos += dash + gap


def plot_curves(
    lam: np.ndarray,
    vmag: np.ndarray,
    bus_ids: np.ndarray,
    base_kv: np.ndarray,
    idx: list[int],
    title: str,
    path: Path,
    legend: bool,
    break_pu: float | None = None,
    break_before: np.ndarray | None = None,
    markers_only: bool = False,
):
    idx = [i for i in idx if np.any(np.isfinite(vmag[i, :]))]
    if not idx:
        return
    width, height = 1650, 980
    left, right = 105, 390 if legend and len(idx) <= 45 else 70
    top, bottom = 85, 95
    plot_w = width - left - right
    plot_h = height - top - bottom
    img = Image.new("RGB", (width, height), "white")
    d = ImageDraw.Draw(img, "RGBA")

    ydata = vmag[idx, :]
    ymin = max(0.45, float(np.nanmin(ydata)) - 0.035)
    ymax = min(1.25, float(np.nanmax(ydata)) + 0.035)
    xmin, xmax = float(np.nanmin(lam)), float(np.nanmax(lam))

    def xmap(x):
        return left + (float(x) - xmin) / (xmax - xmin) * plot_w

    def ymap(y):
        return top + (ymax - float(y)) / (ymax - ymin) * plot_h

    for tick in nice_ticks(xmin, xmax, 7):
        x = xmap(tick)
        d.line([(x, top), (x, top + plot_h)], fill=(225, 229, 236, 255), width=1)
        d.text((x - 18, top + plot_h + 14), f"{tick:.2f}", fill=(40, 44, 52), font=FONT_TICK)
    for tick in nice_ticks(ymin, ymax, 7):
        y = ymap(tick)
        d.line([(left, y), (left + plot_w, y)], fill=(225, 229, 236, 255), width=1)
        d.text((22, y - 9), f"{tick:.2f}", fill=(40, 44, 52), font=FONT_TICK)

    d.rectangle([left, top, left + plot_w, top + plot_h], outline=(45, 52, 66, 255), width=2)
    colors = palette(len(idx))
    xs = [xmap(x) for x in lam]
    for c, row in zip(colors, idx):
        finite = np.isfinite(vmag[row, :])
        if np.sum(finite) < 2:
            continue
        if markers_only:
            for j in np.where(finite)[0]:
                x, y = xs[j], ymap(vmag[row, j])
                r = 2.7 if len(idx) <= 45 else 1.6
                d.ellipse([x - r, y - r, x + r, y + r], fill=c)
            continue
        start = None
        last = None
        for j in range(len(lam)):
            if not finite[j]:
                if start is not None and last is not None and last - start >= 1:
                    pts = [(xs[k], ymap(vmag[row, k])) for k in range(start, last + 1)]
                    d.line(pts, fill=c, width=2 if len(idx) <= 45 else 1)
                start = None
                last = None
                continue
            if start is None:
                start = j
                last = j
                continue
            if break_before is not None and bool(break_before[row, j]):
                if last - start >= 1:
                    pts = [(xs[k], ymap(vmag[row, k])) for k in range(start, last + 1)]
                    d.line(pts, fill=c, width=2 if len(idx) <= 45 else 1)
                start = j
                last = j
                continue
            if (
                break_pu is not None
                and abs(float(vmag[row, j]) - float(vmag[row, last])) > break_pu
            ):
                if last - start >= 1:
                    pts = [(xs[k], ymap(vmag[row, k])) for k in range(start, last + 1)]
                    d.line(pts, fill=c, width=2 if len(idx) <= 45 else 1)
                start = j
                last = j
            else:
                last = j
        if start is not None and last is not None and last - start >= 1:
            pts = [(xs[k], ymap(vmag[row, k])) for k in range(start, last + 1)]
            d.line(pts, fill=c, width=2 if len(idx) <= 45 else 1)

    d.text((left, 28), title, fill=(24, 31, 42), font=FONT_TITLE)
    d.text((left + plot_w / 2 - 35, height - 45), "lambda", fill=(24, 31, 42), font=FONT_AXIS)
    d.text((20, 35), "V [pu]", fill=(24, 31, 42), font=FONT_AXIS)
    if markers_only:
        mode_text = "puntos aceptados, sin unir"
    elif break_before is not None:
        mode_text = "puntos aceptados segmentados por recorrecciones PSS/E"
    elif break_pu is None:
        mode_text = "puntos aceptados conectados"
    else:
        mode_text = f"cortes si dV > {break_pu:.3f} pu"
    d.text((left, height - 72), f"{len(idx)} curvas | lambda max = {xmax:.6g} | {mode_text}", fill=(78, 86, 100), font=FONT_SMALL)

    if legend and len(idx) <= 45:
        lx = left + plot_w + 22
        ly = top
        for k, row in enumerate(idx):
            if ly > height - 40:
                break
            d.line([(lx, ly + 8), (lx + 24, ly + 8)], fill=colors[k], width=3)
            label = bus_label(int(bus_ids[row]), float(base_kv[row]))
            d.text((lx + 34, ly), label, fill=(35, 40, 50), font=FONT_SMALL)
            ly += 20

    img.save(path)


def plot_curves_with_event_bridges(
    lam: np.ndarray,
    vpost: np.ndarray,
    vpre: np.ndarray,
    break_before: np.ndarray,
    bus_ids: np.ndarray,
    base_kv: np.ndarray,
    idx: list[int],
    title: str,
    path: Path,
    legend: bool,
):
    idx = [i for i in idx if np.any(np.isfinite(vpost[i, :]))]
    if not idx:
        return
    width, height = 1650, 980
    left, right = 105, 390 if legend and len(idx) <= 45 else 70
    top, bottom = 85, 95
    plot_w = width - left - right
    plot_h = height - top - bottom
    img = Image.new("RGB", (width, height), "white")
    d = ImageDraw.Draw(img, "RGBA")

    ydata = np.vstack([vpost[idx, :], vpre[idx, :]])
    ymin = max(0.45, float(np.nanmin(ydata)) - 0.035)
    ymax = min(1.25, float(np.nanmax(ydata)) + 0.035)
    xmin, xmax = float(np.nanmin(lam)), float(np.nanmax(lam))

    def xmap(x):
        return left + (float(x) - xmin) / (xmax - xmin) * plot_w

    def ymap(y):
        return top + (ymax - float(y)) / (ymax - ymin) * plot_h

    for tick in nice_ticks(xmin, xmax, 7):
        x = xmap(tick)
        d.line([(x, top), (x, top + plot_h)], fill=(225, 229, 236, 255), width=1)
        d.text((x - 18, top + plot_h + 14), f"{tick:.2f}", fill=(40, 44, 52), font=FONT_TICK)
    for tick in nice_ticks(ymin, ymax, 7):
        y = ymap(tick)
        d.line([(left, y), (left + plot_w, y)], fill=(225, 229, 236, 255), width=1)
        d.text((22, y - 9), f"{tick:.2f}", fill=(40, 44, 52), font=FONT_TICK)

    d.rectangle([left, top, left + plot_w, top + plot_h], outline=(45, 52, 66, 255), width=2)
    colors = palette(len(idx))
    xs = [xmap(x) for x in lam]

    for c, row in zip(colors, idx):
        finite = np.isfinite(vpost[row, :])
        start = None
        last = None
        for j in range(len(lam)):
            if not finite[j]:
                if start is not None and last is not None and last - start >= 1:
                    pts = [(xs[k], ymap(vpost[row, k])) for k in range(start, last + 1)]
                    d.line(pts, fill=c, width=2 if len(idx) <= 45 else 1)
                start = None
                last = None
                continue
            if start is None:
                start = j
                last = j
                continue
            if bool(break_before[row, j]):
                if last - start >= 1:
                    pts = [(xs[k], ymap(vpost[row, k])) for k in range(start, last + 1)]
                    d.line(pts, fill=c, width=2 if len(idx) <= 45 else 1)
                if np.isfinite(vpre[row, j]) and np.isfinite(vpost[row, last]):
                    bridge_color = (c[0], c[1], c[2], 105)
                    dashed_line(
                        d,
                        (xs[last], ymap(vpost[row, last])),
                        (xs[j], ymap(vpre[row, j])),
                        bridge_color,
                        width=1,
                    )
                    jump_color = (35, 40, 50, 110)
                    dashed_line(
                        d,
                        (xs[j], ymap(vpre[row, j])),
                        (xs[j], ymap(vpost[row, j])),
                        jump_color,
                        width=1,
                        dash=5,
                        gap=4,
                    )
                start = j
                last = j
            else:
                last = j
        if start is not None and last is not None and last - start >= 1:
            pts = [(xs[k], ymap(vpost[row, k])) for k in range(start, last + 1)]
            d.line(pts, fill=c, width=2 if len(idx) <= 45 else 1)

    d.text((left, 28), title, fill=(24, 31, 42), font=FONT_TITLE)
    d.text((left + plot_w / 2 - 35, height - 45), "lambda", fill=(24, 31, 42), font=FONT_AXIS)
    d.text((20, 35), "V [pu]", fill=(24, 31, 42), font=FONT_AXIS)
    d.text(
        (left, height - 72),
        f"{len(idx)} curvas | lambda max = {xmax:.6g} | solido: aceptado, punteado: evento PSS/E",
        fill=(78, 86, 100),
        font=FONT_SMALL,
    )

    if legend and len(idx) <= 45:
        lx = left + plot_w + 22
        ly = top
        for k, row in enumerate(idx):
            if ly > height - 40:
                break
            d.line([(lx, ly + 8), (lx + 24, ly + 8)], fill=colors[k], width=3)
            label = bus_label(int(bus_ids[row]), float(base_kv[row]))
            d.text((lx + 34, ly), label, fill=(35, 40, 50), font=FONT_SMALL)
            ly += 20

    img.save(path)


def set_indices(bus_ids: np.ndarray, buses: list[int]) -> list[int]:
    pos = {int(b): i for i, b in enumerate(bus_ids)}
    return [pos[b] for b in buses if b in pos]


def complete_curve_indices(vmag: np.ndarray, idx: list[int]) -> list[int]:
    return [i for i in idx if np.all(np.isfinite(vmag[i, :]))]


def bus_label(bus_id: int, kv: float) -> str:
    if not np.isfinite(kv):
        return f"{bus_id}"
    if kv < 10:
        return f"{bus_id} ({kv:.1f} kV)"
    return f"{bus_id} ({kv:.0f} kV)"


def write_selected_table(path: Path, sets: dict[str, list[int]], bus_ids, base_kv, vmag):
    pos = {int(b): i for i, b in enumerate(bus_ids)}
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["set_name", "bus_i", "base_kv", "vm_initial", "vm_final", "vm_min"])
        for name, buses in sets.items():
            for b in buses:
                if b not in pos:
                    continue
                i = pos[b]
                if np.any(np.isfinite(vmag[i, :])):
                    vm_min = np.nanmin(vmag[i, :])
                else:
                    vm_min = np.nan
                w.writerow([name, int(bus_ids[i]), f"{base_kv[i]:.8g}", f"{vmag[i,0]:.12g}", f"{vmag[i,-1]:.12g}", f"{vm_min:.12g}"])


def write_plot_breaks(path: Path, lam: np.ndarray, vmag: np.ndarray, bus_ids: np.ndarray, base_kv: np.ndarray, threshold: float = 0.025):
    rows = []
    for i, b in enumerate(bus_ids):
        if b >= 900000 or not np.any(np.isfinite(vmag[i, :])):
            continue
        dv = np.abs(np.diff(vmag[i, :]))
        for j in np.where(dv > threshold)[0]:
            rows.append((int(b), float(base_kv[i]), float(lam[j]), float(lam[j + 1]), float(vmag[i, j]), float(vmag[i, j + 1]), float(vmag[i, j + 1] - vmag[i, j])))
    rows.sort(key=lambda r: abs(r[-1]), reverse=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["bus_i", "base_kv", "lambda_from", "lambda_to", "vm_from", "vm_to", "delta_vm"])
        w.writerows(rows)


def write_control_jumps(
    path: Path,
    lam: np.ndarray,
    vmag_raw: np.ndarray,
    bus_ids: np.ndarray,
    base_kv: np.ndarray,
    starts: np.ndarray,
    keep: np.ndarray,
    threshold: float = 0.03,
):
    rows = []
    for i, b in enumerate(bus_ids):
        if b >= 900000:
            continue
        for j in range(1, len(keep)):
            pre = float(vmag_raw[i, starts[j]])
            post = float(vmag_raw[i, keep[j]])
            if not np.isfinite(pre) or not np.isfinite(post):
                continue
            dv = post - pre
            if abs(dv) > threshold:
                rows.append((
                    int(b), float(base_kv[i]), float(lam[j]),
                    int(starts[j]), int(keep[j]), pre, post, dv,
                ))
    rows.sort(key=lambda r: abs(r[-1]), reverse=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["bus_i", "base_kv", "lambda", "raw_start", "raw_end", "vm_pre_control", "vm_post_control", "delta_vm"])
        w.writerows(rows)


def write_summary(path: Path, figures: list[Path]):
    metrics = read_table(OUTDIR / "summary_metrics.csv")[0]
    events = read_table(OUTDIR / "event_counts.csv")
    genq_rows = read_table(OUTDIR / "genq_final_control.csv")
    genq = genq_rows[0] if genq_rows else {}
    with path.open("w", encoding="utf-8") as f:
        f.write("# CPF TRANSPA con GENQ, ULTC y switched shunts activos\n\n")
        f.write("Escenario diagnostico sobre `case_transpa_reduced_v1_explicit`.\n\n")
        f.write("## Configuracion\n\n")
        f.write("- `solved_snapshot_policy.enable_genq_control = true`\n")
        f.write("- `psse.system.solver.VARLIM = 99`\n")
        f.write("- `psse.system.solver.ACTAPS = 1`\n")
        f.write("- `psse.system.solver.SWSHNT = 1`\n")
        f.write("- `cpf.enforce_q_lims = 0`; se usa GENQ PSS/E, no el limite Q generico de MATPOWER.\n")
        f.write("- Target de carga: `1.15x`.\n")
        f.write("- Entrada efectiva: `runpf_psse + active-set sync + runcpf` con `mp.xt_psse`.\n\n")
        f.write("Nota de graficacion: las curvas PNG unen puntos aceptados antes de calcular el nuevo tangente. Las `*_accepted_curve_v5.png` conectan todos los puntos finales; las `*_accepted_segmented_v6.png` cortan la curva cuando una re-correccion PSS/E produce un salto discreto; las `*_accepted_event_bridges_v7.png` evitan huecos largos mostrando esos saltos con trazo punteado diagnostico.\n\n")
        f.write("## Resultado\n\n")
        f.write("| Metrica | Valor |\n|---|---:|\n")
        for k in ["success", "max_lambda", "points", "events", "final_min_v_bus", "final_min_v", "load_scale"]:
            f.write(f"| {k} | {metrics[k]} |\n")
        if genq:
            f.write("\n## GENQ final\n\n")
            f.write("| Campo | Valor |\n|---|---:|\n")
            for k, v in genq.items():
                f.write(f"| {k} | {v} |\n")
        f.write("\n## Eventos\n\n")
        f.write("| Evento | Conteo |\n|---|---:|\n")
        for row in events:
            f.write(f"| {row['event']} | {row['count']} |\n")
        f.write("\n## Figuras\n\n")
        for p in figures:
            f.write(f"- `{p}`\n")


def main():
    lam, vmag, bus_ids, base_kv, sets = load_data()
    lam_raw = lam
    vmag_raw = vmag
    raw_points = len(lam)
    lam, vmag, keep, starts = compact_repeated_lambda(lam_raw, vmag_raw)
    vmag_pre = vmag_raw[:, starts]
    control_jump_mask = accepted_control_jump_mask(vmag_raw, starts, keep)
    (OUTDIR / "plot_compaction_note.txt").write_text(
        f"Raw CPF points: {raw_points}\n"
        f"Accepted plotted points: {len(lam)}\n"
        f"Kept raw indices: {','.join(str(int(i)) for i in keep)}\n",
        encoding="utf-8",
    )
    with (OUTDIR / "accepted_point_indices.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["accepted_point_no", "raw_index", "lambda"])
        for n, (raw_i, lam_i) in enumerate(zip(keep, lam), start=1):
            w.writerow([n, int(raw_i), f"{float(lam_i):.15g}"])
    figures: list[Path] = []
    titles = {
        "all_physical": "Todas las barras fisicas retenidas",
        "boundary_ports": "Frontera equivalente - puertos TRANSPA/SADI",
        "buses_500kv": "Barras >= 400 kV",
        "switched_shunt_buses": "Barras con switched shunts preservados",
        "genq_generator_buses": "Barras con generadores GENQ retenidos",
        "genq_regulated_buses": "Barras reguladas por GENQ",
        "ultc_terminal_buses": "Barras terminales de transformadores retenidos",
        "worst_40_voltage_drop": "Mayores caidas de tension hasta el punto final",
        "lowest_40_final_voltage": "Barras con menor tension final",
    }
    legend_sets = {"boundary_ports", "buses_500kv", "switched_shunt_buses", "genq_regulated_buses", "worst_40_voltage_drop", "lowest_40_final_voltage"}
    order = ["all_physical", "boundary_ports", "buses_500kv", "switched_shunt_buses", "genq_generator_buses", "genq_regulated_buses", "ultc_terminal_buses", "worst_40_voltage_drop", "lowest_40_final_voltage"]
    for name in order:
        idx = set_indices(bus_ids, sets.get(name, []))
        if not idx:
            continue
        p = OUTDIR / f"pv_{name}.png"
        plot_curves(lam, vmag, bus_ids, base_kv, idx, titles[name], p, name in legend_sets)
        figures.append(p)
        p_curve = OUTDIR / f"pv_{name}_curve_only_v2.png"
        plot_curves(
            lam, vmag, bus_ids, base_kv, idx,
            titles[name] + " - curva aceptada", p_curve,
            name in legend_sets, markers_only=False,
        )
        figures.append(p_curve)
        p_curve_v5 = OUTDIR / f"pv_{name}_accepted_curve_v5.png"
        plot_curves(
            lam, vmag, bus_ids, base_kv, idx,
            titles[name] + " - curva aceptada", p_curve_v5,
            name in legend_sets, markers_only=False,
        )
        figures.append(p_curve_v5)
        p_curve_v6 = OUTDIR / f"pv_{name}_accepted_segmented_v6.png"
        plot_curves(
            lam, vmag, bus_ids, base_kv, idx,
            titles[name] + " - curva aceptada segmentada", p_curve_v6,
            name in legend_sets, break_before=control_jump_mask,
            markers_only=False,
        )
        figures.append(p_curve_v6)
        p_curve_v7 = OUTDIR / f"pv_{name}_accepted_event_bridges_v7.png"
        plot_curves_with_event_bridges(
            lam, vmag, vmag_pre, control_jump_mask, bus_ids, base_kv, idx,
            titles[name] + " - curva aceptada con eventos", p_curve_v7,
            name in legend_sets,
        )
        figures.append(p_curve_v7)
        idx_complete = complete_curve_indices(vmag, idx)
        if idx_complete:
            p_complete = OUTDIR / f"pv_{name}_complete_curve_v3.png"
            plot_curves(
                lam, vmag, bus_ids, base_kv, idx_complete,
                titles[name] + " - curvas completas", p_complete,
                name in legend_sets, markers_only=False,
            )
            figures.append(p_complete)
            p_complete_v5 = OUTDIR / f"pv_{name}_complete_curve_v5.png"
            plot_curves(
                lam, vmag, bus_ids, base_kv, idx_complete,
                titles[name] + " - curvas completas", p_complete_v5,
                name in legend_sets, markers_only=False,
            )
            figures.append(p_complete_v5)
        p2 = OUTDIR / f"pv_{name}_accepted_points.png"
        plot_curves(lam, vmag, bus_ids, base_kv, idx, titles[name] + " - puntos aceptados", p2, name in legend_sets, markers_only=True)
        figures.append(p2)

    all_idx = set_indices(bus_ids, sets.get("all_physical", []))
    page_size = 60
    for page, start in enumerate(range(0, len(all_idx), page_size), start=1):
        idx = all_idx[start : start + page_size]
        p = OUTDIR / f"pv_all_physical_page_{page:02d}.png"
        plot_curves(lam, vmag, bus_ids, base_kv, idx, f"Todas las barras fisicas retenidas - pagina {page:02d}", p, False)
        figures.append(p)

    write_selected_table(OUTDIR / "selected_curve_buses.csv", sets, bus_ids, base_kv, vmag)
    write_plot_breaks(OUTDIR / "plot_breaks_gt_0p025pu.csv", lam, vmag, bus_ids, base_kv)
    write_control_jumps(OUTDIR / "accepted_control_jumps_gt_0p03pu.csv", lam, vmag_raw, bus_ids, base_kv, starts, keep)
    write_summary(OUTDIR / "resumen_cpf_genq_ultc_swshunt.md", figures)
    print(f"Wrote {len(figures)} figures to {OUTDIR}")


if __name__ == "__main__":
    main()
