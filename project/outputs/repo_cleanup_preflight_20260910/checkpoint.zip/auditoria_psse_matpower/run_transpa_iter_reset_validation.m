function run_transpa_iter_reset_validation()
% RUN_TRANSPA_ITER_RESET_VALIDATION Validate CPF-PSS/E iteration reset behavior.

root = fileparts(fileparts(mfilename('fullpath')));
addpath(fullfile(root, 'matpower', 'lib'));
addpath(fullfile(root, 'matpower', 'data'));
addpath(fullfile(root, 'matpower', 'mips', 'lib'));
addpath(fullfile(root, 'matpower', 'mp-opt-model', 'lib'));
addpath(fullfile(root, 'matpower', 'mptest', 'lib'));
addpath(fullfile(root, 'auditoria_psse_matpower', ...
    'results', 'transpa_reduccion_v1'));

define_constants;
[mpcb, mpopt_case] = case_transpa_reduced_v1_explicit();
mpct = mpcb;
mpct.bus(:, PD) = 2.0 * mpcb.bus(:, PD);
mpct.bus(:, QD) = 2.0 * mpcb.bus(:, QD);
mpopt = mpoption(mpopt_case, 'verbose', 0, 'out.all', 0, ...
    'cpf.stop_at', 'NOSE', 'cpf.step', 0.005, ...
    'cpf.adapt_step', 1, 'cpf.enforce_q_lims', 0);

[rn, sn] = runcpf_psse(mpcb, mpct, mpopt);
lam = rn.cpf.lam(:).';
ev = rn.cpf.events;
if isempty(ev)
    names = {};
else
    names = {ev.name};
end

outdir = fullfile(root, 'auditoria_psse_matpower', ...
    'results', 'runcpf_psse_transpa_control_pv');
if ~exist(outdir, 'dir')
    mkdir(outdir);
end

summary_lines = build_summary(rn, sn, lam, ev, names);
sumfile = fullfile(outdir, 'transpa_iter_reset_summary.txt');
fid = fopen(sumfile, 'w');
for k = 1:numel(summary_lines)
    fprintf('%s\n', summary_lines{k});
    fprintf(fid, '%s\n', summary_lines{k});
end
fclose(fid);

plotfile = fullfile(outdir, ...
    'transpa_pv_3bus_nose_after_iter_reset.png');
plot_three_bus_trace(rn, lam, ev, names, plotfile);
save(fullfile(outdir, 'transpa_nose_after_iter_reset.mat'), ...
    'rn', 'sn', '-v7.3');

fprintf('summary_file=%s\n', sumfile);
fprintf('plot_file=%s\n', plotfile);
fprintf('mat_file=%s\n', fullfile(outdir, ...
    'transpa_nose_after_iter_reset.mat'));
end

function summary_lines = build_summary(rn, sn, lam, ev, names)
summary_lines = cell(1, 8);
n = 1;
summary_lines{n} = sprintf(['TRANSPA NOSE after iter reset/' ...
    'warmstart guard: success=%d max_lam=%.12g factor=%.12g ' ...
    'points=%d events=%d'], ...
    sn, max(lam), 1 + max(lam), numel(lam), numel(ev));
if isfield(rn.cpf, 'done_msg')
    n = n + 1;
    summary_lines{n} = sprintf('done_msg=%s', rn.cpf.done_msg);
end

for name = {'PSSE_XFMR', 'PSSE_SWSHUNT', 'PSSE_PQBRAK'}
    mask = strcmp(names, name{1});
    cnt = sum(mask);
    n = n + 1;
    if cnt
        ff = psse_event_factors(ev(mask), lam);
        summary_lines{n} = sprintf('%s count=%d factors=%.9f ... %.9f', ...
            name{1}, cnt, min(ff), max(ff));
    else
        summary_lines{n} = sprintf('%s count=0', name{1});
    end
end

if isfield(rn, 'psse') && isfield(rn.psse, 'xfmr') && ...
        isfield(rn.psse.xfmr, 'control')
    c = rn.psse.xfmr.control;
    n = n + 1;
    summary_lines{n} = sprintf(['XFMR iterations=%d max_iter=%d ' ...
        'max_iter_reached=%d changed_last=%d num_adjustments=%d'], ...
        c.iterations, c.max_iter, c.max_iter_reached, ...
        c.changed_last, c.num_adjustments);
end
if isfield(rn, 'psse') && isfield(rn.psse, 'swshunt') && ...
        isfield(rn.psse.swshunt, 'control')
    c = rn.psse.swshunt.control;
    n = n + 1;
    summary_lines{n} = sprintf(['SWSHUNT iterations=%d max_iter=%d ' ...
        'max_iter_reached=%d changed_last=%d num_adjustments=%d'], ...
        c.iterations, c.max_iter, c.max_iter_reached, ...
        c.changed_last, c.num_adjustments);
end
summary_lines = summary_lines(1:n);
end

function ff = psse_event_factors(ev, lam)
% Return loading factors for PSS/E events.

ff = NaN(1, numel(ev));
for k = 1:numel(ev)
    tok = regexp(ev(k).msg, 'lambda = ([0-9eE+\-.]+)', ...
        'tokens', 'once');
    if ~isempty(tok)
        ff(k) = 1 + str2double(tok{1});
    else
        kk = max(1, min(numel(lam), ev(k).k + 1));
        ff(k) = 1 + lam(kk);
    end
end
end

function plot_three_bus_trace(rn, lam, ev, names, plotfile)
define_constants;
cpfc = rn.cpf_psse_compact;
factor = 1 + cpfc.lam(:).';
bus_sel = [322 230201 557];
[tf, bus_idx] = ismember(bus_sel, rn.bus(:, BUS_I));
bus_sel = bus_sel(tf);
bus_idx = bus_idx(tf);
Vm = abs(cpfc.V(bus_idx, :));

last_control_factor = 1.0;
if ~isempty(ev)
    ctrlmask = startsWith(names, 'PSSE_');
    if any(ctrlmask)
        last_control_factor = max(psse_event_factors(ev(ctrlmask), lam));
    end
end
zoom_max = min(max(factor), max(1.02, min(1.08, ...
    last_control_factor + 0.005)));

fig = figure('Visible', 'off', 'Color', 'w', ...
    'Position', [100 100 1400 560]);
tl = tiledlayout(fig, 1, 2, 'TileSpacing', 'compact', ...
    'Padding', 'compact');
colors = lines(numel(bus_sel));

ax1 = nexttile(tl);
plot_panel(ax1, factor, Vm, bus_sel, colors, false);
title(ax1, 'TRANSPA CPF-PSS/E - rama superior');
legend(ax1, compose('Bus %d', bus_sel), 'Location', 'southwest');

ax2 = nexttile(tl);
plot_panel(ax2, factor, Vm, bus_sel, colors, true);
title(ax2, 'Zoom sobre controles discretos');
xlim(ax2, [1 zoom_max]);
legend(ax2, compose('Bus %d', bus_sel), 'Location', 'best');

exportgraphics(fig, plotfile, 'Resolution', 160);
close(fig);
end

function plot_panel(ax, factor, Vm, bus_sel, colors, with_markers)
hold(ax, 'on');
grid(ax, 'on');
box(ax, 'on');
set(ax, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', ...
    'GridColor', [0.7 0.7 0.7]);
for k = 1:numel(bus_sel)
    if with_markers
        plot(ax, factor, Vm(k, :), '.-', 'LineWidth', 1.3, ...
            'MarkerSize', 9, 'Color', colors(k, :));
    else
        plot(ax, factor, Vm(k, :), 'LineWidth', 1.7, ...
            'Color', colors(k, :));
    end
end
xlabel(ax, 'Factor de carga');
ylabel(ax, 'V [p.u.]');
end
