# Plan de ataque - discrepancias PSS/E vs MATPOWER

Este plan parte del estado actual: el RAW Rev34 ya importa y `runpf` converge. El siguiente objetivo no es "hacer que corra", sino explicar y reducir diferencias respecto de PSS/E con cambios incrementales y verificables.

## Principios de trabajo

1. Mantener la auditoria anclada a `PSSE/V26p_Trs_2532.raw`.
2. No dedicar implementacion a secciones vacias del RAW.
3. Separar siempre:
   - parsing/importacion,
   - modelo electrico,
   - solver/algoritmo,
   - datos preservados sin accionar,
   - controles no equivalentes.
4. Cada mejora debe tener un diagnostico antes/despues.
5. Evitar cambios grandes simultaneos: una fuente de discrepancia por vez.
6. Preservar compatibilidad con RAW antiguos y tests MATPOWER existentes.

## Fase 0 - Congelar baseline reproducible

Objetivo:

Dejar una forma repetible de obtener los numeros base, sin depender de memoria de chat.

Tareas:

- Crear un comando o script temporal de diagnostico que reporte:
  - commit,
  - revision RAW,
  - conteos por seccion,
  - warnings,
  - `runpf success`,
  - iteraciones,
  - rangos VM/VA,
  - buses PV/PQ/REF/NONE,
  - gen/branch online/offline,
  - islas,
  - top desviaciones VM/VA/QG.
- Decidir si este diagnostico queda como script permanente en `auditoria_psse_matpower/tools` o como test MATPOWER.
- Guardar salidas baseline en Markdown o CSV para comparar cambios futuros.

Criterio de salida:

Se puede regenerar el baseline completo en una corrida limpia.

## Fase 1 - Obtener referencia PSS/E real

Objetivo:

Comparar contra una solucion PSS/E exportada, no solo contra el estado inicial del RAW.

Datos necesarios:

- Bus: `I`, `NAME`, `BASKV`, `VM`, `VA`, tipo.
- Generadores: bus/id, `PG`, `QG`, status, limites.
- Branch/transformer: `I`, `J`, `CKT`, `P/Q` en extremos, status, tap, phase shift.
- HVDC: potencia, estado, buses, variables de control si estan disponibles.
- Switched shunts: `BINIT`/estado final o pasos finales, como diagnostico auxiliar.
- FACTS: estado final y variables de control.

Opciones:

- Exportar desde PSS/E reportes `.out/.rep/.csv`.
- Si solo hay `.sav`, abrirlo en PSS/E y exportar tablas.
- Alinear angulos por isla antes de comparar.

Criterio de salida:

Existe una tabla PSS/E local verificable para comparar primero `VM` y `VA` por bus, y luego `QG`, flujos y controles. El estado final de switched shunts no debe usarse como unica referencia porque otros elementos del RAW tambien pueden desplazar los puntos finales de control.

## Fase 2 - Clasificar diferencias sin tocar modelo

Objetivo:

Saber cuanto de la discrepancia viene de datos ignorados vs solver.

Pruebas:

- Ejecutar MATPOWER con:
  - `pf.enforce_q_lims=0` baseline.
  - `pf.enforce_q_lims=1` y `2`.
  - legacy core si el core nuevo falla con Q limits.
  - tolerancias alineadas lo mas posible con PSS/E.
- Comparar con PSS/E:
  - `VM/VA` por nivel de tension.
  - `QG` por generador y planta/bus.
  - flows por branch/trafo.
  - estado final de shunts/taps/HVDC.

Criterio de salida:

Ranking cuantitativo validado contra PSS/E real.

## Fase cerrada - `BRANCH DATA` Rev34

- La metadata no-transformer que no cabe en `mpc.branch` queda preservada en `mpc.psse.branch`: `CKT`, `NAME`, `RATE1-12`, `MET`, `LEN`, owners `O1/F1` a `O4/F4`, `raw_row_idx` y `branch_idx`.
- `branch_idx` enlaza cada fila RAW de `BRANCH DATA` con la fila equivalente de `mpc.branch`, para reportes y trazabilidad de auditoria.
- El equivalente electrico no cambia: `runpf` sigue usando R/X/B, status, `RATE_A/B/C` y shunts terminales agregados a `bus GS/BS`.
- Limitacion: `RATE4-12`, `MET`, `LEN`, `NAME` y ownership quedan preservados, pero no se usan automaticamente en `makeYbus`, `runpf` ni en limites nativos.

## Fase cerrada - `AREA/ZONE/OWNER DATA`

- `AREA DATA`, `ZONE DATA` y `OWNER DATA` quedan preservadas en `mpc.psse.area`, `mpc.psse.zone` y `mpc.psse.owner`.
- `AREA` y `ZONE` se enlazan con `mpc.bus` por `bus(:, BUS_AREA)` y `bus(:, ZONE)`; `ISW` se enlaza a la fila de bus cuando el RAW define un bus valido.
- `OWNER DATA` conserva nombres y cruza owners de buses y ownership ya preservado, por ejemplo `mpc.psse.branch.owner`; las referencias sin fila de owner se mantienen visibles para auditoria.
- El equivalente electrico no cambia: estas estructuras son metadata administrativa y `runpf` no las consulta.

## Fase cerrada - `LOAD DATA`

- `LOAD DATA` queda preservada en `mpc.psse.load` como metadata auditable por fila: `I`, `ID`, `STAT`, `AREA`, `ZONE`, `PL/QL`, `IP/IQ`, `YP/YQ`, `OWNER`, `SCALE`, `INTRPT`, `DGENP/DGENQ/DGENF`.
- La contribucion electrica sigue siendo el agregado existente en `mpc.bus(:, PD/QD)`, solo para cargas en servicio: `PL + IP*VM + YP*VM^2` y `QL + IQ*VM - YQ*VM^2`.
- La auditoria debe poder cruzar fila de carga, bus MATPOWER, area/zona/owner, sumas de contribucion por bus y referencias de owner no definidas, por ejemplo `OWNER=99` en el RAW grande.
- No hay cambio de comportamiento en `runpf` estandar.

## Fase 3 - Switched shunts

Motivo:

Es la primera fuente de discrepancia preliminar. Hay `361` registros, `348` activos, `503` bloques no cero, `39` con control remoto. MATPOWER actualmente usa solo `BINIT` fijo en `bus BS`.

Ruta incremental:

1. Parsing completo:
   - conservar `MODSW`, `ST`, `VSWHI`, `VSWLO`, `SWREG`, `RMPCT`, `RMIDNT`, `BINIT`, bloques `N/B`, `NREG`.
2. Estructura extendida:
   - agregar `mpc.psse.swshunt` o `mpc.raw.swshunt` para no perder informacion.
3. Modo fijo correcto:
   - respetar `ST=0` y revisar si hoy se incorpora algun `BINIT` fuera de servicio.
4. Comparacion:
   - si PSS/E exporta shunts finales, fijar `BS` a esos valores y medir mejora.
5. Control automatico:
   - implementar solo si el paso anterior muestra que hace falta y con test acotado.

Criterio de salida:

MATPOWER reproduce mejor buses sensibles de 23/66 kV y no degrada convergencia.

Estado 2026-05-15:

- Completados pasos 1, 2 y 3: parseo completo Rev34, preservacion en `mpc.psse.swshunt`, y conversion fija respetando `ST`.
- Validado `runpf` del RAW local con `success=1` en 4 iteraciones.
- Validado test `t_psse(0)` con `168/168` exitosos.
- Implementado `runpf_psse` como entrada opt-in con `mp.xt_psse` y `mp.task_pf_psse.next_dm`.
- Implementado control PSS/E de switched shunts para los comportamientos presentes en el RAW: `MODSW=0/1/2`, `ADJM=0`, `STAT=0/1`, `SWREG`, `RMPCT`, bloques `N/B`, bus reconocible tipo 1/2, `SWSHNT`, agrupamiento por bus regulado, memoria de ciclos y reporte de `BINIT` final.
- Validado test `t_mpxt_psse(0)` con `25/25` exitosos.
- Sobre el RAW local, `runpf_psse` converge con `success=1`, 10 iteraciones de data model, y reduce automaticos fuera de banda de 59 a 36 sin alcanzar `MXTPSS`.
- Se agrego `auditoria_psse_matpower/tools/compare_v26p_raw_solution.m` para comparar `VM/VA` de `runpf` y `runpf_psse` contra la solucion guardada en el RAW.
- La referencia externa de esa fase es una salida PSS/E real con `VM/VA` y
  estado final de switched shunts para validar identidad numerica y calibrar
  reparto `RMPCT`.

## Fase 4 - HVDC de dos terminales

Motivo:

Hay `8` lineas two-terminal DC; `4` activas de `825 MW`. Al apagarlas, el caso no converge. El modelo actual `dcline` no usa perdidas `RDC` ni tap logic.

Ruta incremental:

1. Preservar RAW completo:
   - guardar todas las columnas HVDC en una estructura auxiliar.
2. Corregir perdidas:
   - mapear `RDC` a `LOSS1` o formula equivalente, validando signo y convencion.
3. Revisar status:
   - `MDC=0` debe quedar bloqueada sin inyeccion.
4. Validar isla `86-87`:
   - documentar por que bus `87` aparece como slack/generador negativo.
5. Modelo LCC opt-in:
   - resolver corriente/tension DC, angulos, taps discretos y consumo
     reactivo equivalente solo dentro de `runpf_psse`.

Criterio de salida:

Flujos e inyecciones HVDC coinciden mejor con PSS/E y no aparecen saltos artificiales en la isla `86-87`.

Estado 2026-05-20:

- Completados pasos 1, 2 y 3 para el subconjunto presente en el RAW local.
- `psse_parse` preserva los tres records Rev34 de `TWO-TERMINAL DC DATA`.
- `psse_convert` guarda `mpc.psse.twodc` con columnas, texto, mapeo a `dcline`, buses conversores y perdida estimada.
- `psse_convert_hvdc` mantiene `MDC=0` bloqueado, convierte `MDC=1` con `SETVL>0` o `SETVL<0`, y convierte `MDC=2` desde corriente en amperes.
- Para cada enlace activo `85 -> 86`: `PF=825.000000`, `PT=805.205156`, `LOSS0=19.794844`, `LOSS1=0`; perdida total `79.179375 MW`.
- El RAW grande sigue convergiendo con `runpf`, `success=1`, 4 iteraciones; con todos los `dcline` deshabilitados no converge (`success=0`, 10 iteraciones).
- Agregados casos chicos en `psse_validation_cases_twodc/` para base sin DC, `MDC=0`, `MDC=1` sin perdidas y `MDC=1` con `RDC`.
- Logs PSS/E Xplore de los casos chicos validan que `MDC=0` queda bloqueado y
  que `MDC=1`, `SETVL>0` pasa a corriente cuando `Vdci < VCMOD`:
  `Idc=SETVL/VSCHD=0.1 kA`, con perdida `RDC*Idc^2=0.1 MW` en el caso con
  `RDC=10`.
- `runpf_psse` implementa ese fallback opt-in para el subconjunto validado.
  En los casos chicos
  produce `PF/PT=29.088/29.088 MW` sin perdida y `29.188/29.088 MW` con
  `0.100 MW` de perdida, y reporta/aplica `QACR/QACI` equivalente.
- En modo potencia, `runpf_psse` resuelve el equivalente LCC opt-in con las
  ecuaciones no capacitor-commutated, seleccion discreta de taps, `alpha`,
  `gamma`, `Idc`, `Vdcr/Vdci/Vcomp`, solapes y `QACR/QACI`.
- Para el caso reducido `85 -> 86`, `runpf_psse` reproduce los targets PSS/E:
  `PAC(R)=825`, `PAC(I)=-804.1`, perdida `20.91`, `Idc=1.4132`,
  `QACR=379.4` y `QACI=367.5` dentro de tolerancia de validacion.
- En el RAW grande `runpf_psse` mantiene estado LCC propio para los
  enlaces activos paralelos `85 -> 86`, actualiza cada fila `dcline` y acumula
  `QACR/QACI` sobre los buses AC terminales.
- Como PSS/E Xplore no puede correr el RAW grande por limite de 50 buses, se
  creo `psse_twodc_5bus_v26p_active.raw` con los parametros del enlace activo
  `85 -> 86`. El log PSS/E confirma modo potencia: `PAC(R)=825.0`,
  `PAC(I)=-804.1`, `DCAMPS=1413.2`, `VCOMP=583.8` y perdida `20.91 MW`.
- Validado `t_psse(0)` con `192/192` exitosos y `t_mpxt_psse(0)` con `123/123` exitosos.
- Contrato cerrado para `TWO-TERMINAL DC DATA`: `MDC=0`, `MDC=1`, `MDC=2`,
  `SETVL~=0`, `VSCHD>0`, LCC sin capacitores, perdidas `RDC`, modo corriente
  por `VCMOD`, taps discretos por `DCTAPS` y enlaces paralelos aplicados por fila.

## Fase 5 - Transformadores e impedance correction

Motivo:

Hay `2491` transformadores, `748` de tres devanados, `4037` devanados con tap off-nominal, `134` shifts no cero, `36` devanados con `TAB`, y `12` tablas de correction ignoradas.

Ruta incremental:

1. Preservar datos omitidos:
   - `COD`, `CONT`, `RMA/RMI`, `VMA/VMI`, `NTP`, `TAB`, `CR/CX`, `MAG1/MAG2`, ratings 4-12.
2. Validar conversion actual:
   - comparar taps y shifts MATPOWER contra RAW para 2W y 3W.
3. Aplicar `TAB` fijo:
   - calcular factor de impedancia para el tap/shift actual y ajustar R/X antes de `makeYbus`.
4. Magnetizacion:
   - revisar `MAG1/MAG2` no cero y decidir si debe agregarse a shunts.
5. Control automatico:
   - no implementarlo antes de tener referencia PSS/E final de taps.

Criterio de salida:

Mejora medible en flujos de transformadores y tensiones de buses conectados a trafos regulantes.

Estado 2026-05-19:

- Completado el paso 1 para campos de control: `psse_parse` preserva winding records Rev34 completos y `psse_convert` guarda metadata en `mpc.psse.xfmr`.
- Implementado control automatico opt-in en `runpf_psse` para el subconjunto presente y seguro del RAW: `COD=1`, `ACTAPS!=0`, `CONT!=0`, `NTP>=2`, `CW in {1,2}`, `CR/CX=0`, `TAB=0`.
- `COD=-1`, `COD=0`, `CONT=0`, `TAB!=0` y modos no presentes quedan preservados/reportados.
- Sobre el RAW local, `ACTAPS=0`, por lo que no se mueven taps; el reporte reconoce `cod1=863`, `cod_m1=282`, `cod0=2842`, `cont_missing=319` y `unsupported_tab=12`.
- Validado `t_mpxt_psse(0)` con `38/38` exitosos y `t_psse(0)` con `171/171` exitosos.

Estado TAB 2026-05-19:

- Completado `TAB` / impedance correction para el modo presente en el RAW: tablas vinculadas a transformadores de tres devanados con `ZCOD=0`.
- `psse_parse` preserva `IMPEDANCE CORRECTION DATA`; `psse_convert` conserva `mpc.psse.impcor`, conserva impedancias nominales y aplica el factor complejo a `BR_R/BR_X`.
- `runpf_psse` recalcula `BR_R/BR_X` si cambia un tap con `TAB`, sin tocar `makeYbus`, `makeSbus` ni `runpf`.
- Sobre el RAW local: `12` tablas, `36` devanados con `TAB` aplicado, `unsupported_tab=0`, `tab_corrected=36`; como `ACTAPS=0`, no hay movimientos iterativos.
- Validado `t_mpxt_psse(0)` con `42/42` exitosos y `t_psse(0)` con `175/175` exitosos.
- La fase continua con magnetizacion `MAG1/MAG2` y comparacion contra una
  salida PSS/E final de taps/flujos.

## Fase 6 - System switching devices

Motivo:

Hay `508` dispositivos, `222` online. MATPOWER los convierte a ramas `R=0`, `X` fija; la auditoria necesita conservar estado normal, tipo, nombre, ratings completos y trazabilidad hacia `branch`.

Ruta incremental:

1. Preservar metadata completa en `mpc.psse.swdev`.
2. Verificar que `STAT` usado por MATPOWER coincide con el estado operativo que PSS/E exporta.
3. Mantener `NSTAT`, `STYPE`, `MET`, `NAME` y `RATE4-12` como metadata auditable.
4. Conservar el equivalente electrico como rama AC fija; no agregar control iterativo para esta seccion.

Estado implementado:

- `STAT=0` se traduce a `BR_STATUS=0`; `STAT=1` y `STAT=2` se traducen a `BR_STATUS=1`.
- `RATE1-3` alimentan `RATE_A/B/C`; `RATE4-12` quedan en `mpc.psse.swdev.rates`.
- Cada fila RAW queda enlazada por `mpc.psse.swdev.branch_idx` con la fila `branch` generada.
- `NSTAT` describe estado normal, `STYPE` clasifica el dispositivo y `MET` indica extremo medido; no alteran el PF base.

Criterio de salida:

La topologia equivalente MATPOWER se puede explicar dispositivo por dispositivo en los casos sensibles.

## Fase 7 - FACTS device

Motivo:

Hay un FACTS modo 1 en bus `40403`, con `SHMX=100`, regulando `41002`. MATPOWER lo ignora. La sensibilidad +/-100 MVAr mostro impacto alto.

Ruta incremental:

1. Preservar el registro FACTS completo.
2. Confirmar en PSS/E que tipo de dispositivo representa `MODE=1`.
3. Comparar estado final PSS/E:
   - inyeccion Q,
   - bus regulado,
   - limites.
4. Implementar equivalente inicial:
   - shunt variable/fijo equivalente segun salida PSS/E.
5. Solo despues evaluar un control automatico.

Criterio de salida:

La zona alrededor de buses `40403` y `41002` explica mejor su tension/reactiva.

Estado 2026-05-20:

- Completado el paso 1: `psse_parse` parsea `FACTS DEVICE DATA` Rev34+ y
  `psse_convert` preserva `mpc.psse.facts`.
- Confirmado el modo presente: unico FACTS `MODE=1`, `J=0`, STATCON shunt en
  `I=40403`, regulando `FCREG=41002`.
- Implementado control opt-in en `runpf_psse` para ese subconjunto:
  `MODE=1`, `J=0`, bus `I` tipo PQ, regulacion local/remota por `FCREG`,
  limite `SHMX`, y reparto `RMPCT` entre FACTS del mismo bus regulado.
- La inyeccion se aplica por `bus(:, QD)` para no interferir con `BS` de
  switched shunts ni con el exportador de `gen` del MP-Core legado.
- `mp.task_pf_psse.next_dm` ejecuta FACTS despues de switched shunts para que
  el STATCON haga el ajuste continuo final.
- Sobre el RAW local, `runpf_psse` converge con `success=1`,
  `VM(41002)=1.000000005`, `Qfacts=-20.531494022`, sin llegar al limite
  `SHMX`.
- Validado `t_psse(0)` con `182/182` exitosos y `t_mpxt_psse(0)` con
  `59/59` exitosos.
- Agregados casos chicos en `psse_validation_cases_facts/` para validacion
  PSS/E externa.

## Fase 8 - Generadores y limites Q

Motivo:

Hay `103` generadores con regulacion remota y `23` generadores finales en o mas alla de limite Q. Activar `pf.enforce_q_lims` no convergio en las pruebas.

Ruta incremental:

1. Reportar generadores con:
   - `IREG != GEN_BUS`,
   - `RMPCT` relevante,
   - `QMIN=QMAX=0`,
   - violacion final en MATPOWER.
2. Comparar contra PSS/E:
   - cuales quedaron PV,
   - cuales pasaron a PQ,
   - Q final.
3. Ajustar opcion de solver antes de modificar conversion.
4. Si hace falta, preservar regulacion remota como metadata y crear diagnostico de grupos de control.

Criterio de salida:

Menor discrepancia de `QG` sin romper convergencia.

## Fase 9 - Reportes y tests

Objetivo:

Convertir el trabajo en pruebas reproducibles y documentacion util.

Tests sugeridos:

- Test de importacion Rev34 con `V26p_Trs_2532.raw` o caso reducido:
  - secciones detectadas,
  - conteos,
  - warnings esperados,
  - `runpf success`.
- Test de no regresion:
  - `branch` Rev34 con ratings 1-12, `CKT`, `NAME`, `MET`, `LEN`, owners y `branch_idx`.
  - `system switching device`.
  - `two-terminal DC` con col 31 como bus inversor.
  - switched shunt `BINIT`.
  - transformer 3W con bus estrella.

Documentacion sugerida:

- Tabla de secciones soportadas/ignoradas por `psse2mpc`.
- Advertencias especificas para Rev34.
- Limitaciones de equivalencia PSS/E vs MATPOWER para controles automaticos.

## Orden recomendado

1. Conseguir/exportar resultados PSS/E reales.
2. Congelar baseline reproducible.
3. Mantener tests de datos preservados en estructuras auxiliares sin cambiar solucion.
4. Switched shunts.
5. HVDC two-terminal.
6. Transformadores + impedance correction.
7. FACTS.
8. Generadores/Q limits.
9. Switching devices y metadata de reportes.
10. AREA/ZONE/OWNER administrativos como metadata auditable.

## Criterios de exito

Un cambio se considera util si cumple al menos una de estas condiciones:

- Reduce diferencias contra PSS/E en `VM`, `VA`, `QG` o flujos.
- Explica una diferencia que antes era opaca.
- Conserva datos RAW hoy descartados sin cambiar resultados.
- Agrega una prueba que protege la importacion Rev34.

Un cambio no deberia aceptarse si:

- Mejora un caso artificial pero degrada `V26p_Trs_2532.raw`.
- Mezcla varias fuentes de discrepancia sin poder aislar el efecto.
- Implementa una seccion vacia en este RAW antes de resolver las secciones presentes.
