# Plan de reduccion TRANSPA con equivalente externo

## Objetivo

Construir un caso reducido a partir de `PSSE/V26p_Trs_2532.raw` que represente explicitamente la red del transportista TRANSPA y reemplace el resto del SADI por equivalentes electricos vistos desde las fronteras.

La referencia grafica es `PSSE/TRANSPA PICO VERANO 2025_2026.pdf`, pero la lista final de barras y elementos debe salir del RAW y de la conectividad real. El PDF se usa como guia de consistencia, no como inventario completo.

## Fronteras principales

- `1008 CH.CHOEL`, 500 kV.
- `2206 B.BCA 1`, 132 kV.

La barra `2208 B.BCA2` debe revisarse junto con `2206`, porque en el RAW pertenece a la misma subestacion electrica y queda acoplada a Bahia Blanca. Puede mantenerse como barra explicita de playa o fusionarse/documentarse como parte del puerto B.BCA.

## Criterio de red explicita

Mantener explicitamente:

- Barras y ramas que aparecen en el unifilar TRANSPA.
- Barras Patagonia/TRANSPA del RAW asociadas a zonas como `CHUBUT`, `STA CRUZ`, `ALUAR` y corredor `RIO NEGR`.
- Generadores, cargas, shunts, transformadores, barras auxiliares y terciarios conectados a barras retenidas.
- Elementos internos que no aparezcan graficamente en el PDF pero sean necesarios para conservar la topologia electrica o el balance de potencia.

No descartar una barra solo porque no se vea en el PDF. Si participa en un transformador, compensacion, generacion, carga, switching device o ramal interno de una barra retenida, debe quedar retenida o ser reemplazada por un equivalente local documentado.

## Tratamiento del resto de la red

El resto del SADI no se elimina sin reemplazo. Se condensa como equivalente externo:

1. Version base: inyecciones `P/Q` equivalentes en los puertos para reproducir el intercambio del caso RAW.
2. Version recomendada: equivalente Thevenin/Norton multipuerto visto desde `[1008, 2206]` y, si corresponde, `[1008, 2206, 2208]`.
3. Version de mayor fidelidad: equivalente Ward/extended Ward que conserve admitancias, inyecciones y respuesta local de tension/reactivos alrededor de las fronteras.

Para flujo estacionario y CPF, la opcion recomendada es el equivalente multipuerto. Una slack ideal en `1008` puede cerrar el flujo, pero distorsiona la rigidez externa y las sensibilidades de tension.

## Pasos de construccion

1. Parsear el RAW y extraer metadatos por barra: `I`, `NAME`, `BASKV`, `IDE`, `AREA`, `ZONE`, `OWNER`, `VM`, `VA`.
2. Armar una semilla de barras desde el PDF y ampliarla automaticamente por conectividad interna.
3. Identificar todos los elementos que cruzan entre red retenida y red eliminada.
4. Confirmar que los unicos puertos externos sean `1008` y `2206/2208`; si aparece otro cruce, agregarlo como frontera o ampliar la red retenida.
5. Calcular el equivalente externo desde el caso completo usando el estado operativo embebido del RAW como punto base.
6. Generar el caso reducido con red TRANSPA explicita y equivalente externo.
7. Validar contra el RAW completo.

## Validacion minima

Comparar:

- Tensiones `VM/VA` en todas las barras retenidas.
- Intercambio `P/Q` por cada frontera.
- Balance activo/reactivo total de la red reducida.
- Estados de shunts, transformadores y barras PV/PQ internas.
- Conectividad: sin islas no previstas y sin elementos internos perdidos.

Entregables recomendados:

- Tabla de barras retenidas.
- Tabla de barras eliminadas.
- Tabla de elementos de corte.
- Parametros del equivalente externo.
- Comparacion RAW completo vs reducido.

## Decision tecnica actual

Mantener TRANSPA explicitamente y reemplazar el resto de la red por un equivalente electrico en frontera. Para estudios serios de flujo estacionario, sensibilidad o CPF, priorizar un equivalente Thevenin/Norton multipuerto o Ward extendido antes que una simple slack ideal.
