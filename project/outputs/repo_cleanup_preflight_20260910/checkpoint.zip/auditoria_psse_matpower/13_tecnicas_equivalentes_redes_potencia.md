# Tecnicas para producir redes equivalentes en sistemas de potencia

## Proposito

Este documento resume tecnicas usadas para construir equivalentes de red en sistemas electricos de potencia, con foco en su aplicacion al caso `PSSE/V26p_Trs_2532.raw` y a la reduccion de la red TRANSPA.

La decision de partida para TRANSPA se mantiene:

- Red TRANSPA explicita.
- Resto del SADI condensado como equivalente externo.
- Fronteras principales: `1008 CH.CHOEL` de 500 kV y `2206 B.BCA 1` de 132 kV.
- La barra `2208 B.BCA2` debe tratarse junto con `2206` si se conserva la playa Bahia Blanca con mayor detalle.

El objetivo no es elegir un metodo universal, sino seleccionar el equivalente segun que variable se necesita preservar: flujo base, sensibilidad de tension, intercambio activo, respuesta dinamica o comportamiento ante contingencias.

## Marco comun

Antes de construir cualquier equivalente hay que definir:

1. Area interna o red retenida.
2. Area externa o red a reducir.
3. Barras frontera.
4. Caso base operativo.
5. Variables a preservar.
6. Rango de validez esperado.

Un equivalente puede reproducir muy bien el flujo base y aun asi fallar ante cambios de despacho, variaciones de carga, contingencias o controles discretos. Por eso debe validarse contra el caso completo.

## Resumen comparativo

| Metodo | Hipotesis principal | Que preserva | Limitaciones |
|---|---|---|---|
| Kron / Schur | Red lineal nodal `I = YV`; nodos internos eliminables. | Relacion corriente-tension vista desde buses retenidos. | Densifica la red; no preserva por si solo cargas `PQ`, barras `PV`, controles, limites ni no linealidades AC. |
| Ward | Area externa reducida alrededor de un caso base. | Flujo base e inyecciones equivalentes en frontera. | Dependiente del caso base; respuesta limitada ante cambios de tension/reactivos. |
| Ward extendido | Ward con soporte explicito de tension/reactivos. | Mejor respuesta `V/Q` que Ward simple. | Introduce elementos ficticios; sigue dependiendo del punto operativo. |
| REI | Agregacion externa mediante nodos ficticios y redes radiales equivalentes. | Agregacion de generacion/carga externa y balance de intercambio. | Sensible al agrupamiento; no garantiza preservar limites ni comportamiento fuera del caso calibrado. |
| Thevenin/Norton multipuerto | Red externa linealizada vista desde varios puertos frontera. | Rigidez externa, acoplamiento entre fronteras y caracteristica terminal. | No conserva estados internos, limites ni controles no lineales de la red externa. |
| PTDF/sensibilidades | Aproximacion DC: tension fija, reactivos ignorados, angulos pequenos. | Sensibilidad de flujos activos ante transferencias. | No representa tension, reactivos ni perdidas AC. |
| Coherencia dinamica | Generadores externos con respuesta oscilatoria similar se agrupan. | Modos electromecanicos y respuesta transitoria aproximada. | Depende del punto operativo y de los eventos usados para identificar coherencia. |
| Identificacion por medidas | Modelo externo ajustado con mediciones en frontera. | Respuesta observada en eventos reales o simulados. | Valido solo dentro del rango de excitacion y datos usados. |

## Kron / complemento de Schur

La reduccion de Kron elimina nodos internos de una matriz de admitancia. Si se particiona la red en buses retenidos `a` y buses eliminados `b`:

```text
Ia = Yaa Va + Yab Vb
Ib = Yba Va + Ybb Vb
```

Si los nodos eliminados no tienen inyeccion independiente, se obtiene:

```text
Yred = Yaa - Yab * inv(Ybb) * Yba
```

Esto conserva exactamente la relacion terminal lineal entre corrientes y tensiones en los buses retenidos. En sistemas de potencia es una herramienta algebraica fundamental, pero no es equivalente a conservar todo el flujo AC no lineal.

Ventajas:

- Metodo directo y matematicamente claro.
- Natural para obtener equivalentes de admitancia.
- Sirve como base para Thevenin/Norton y Ward.

Limitaciones:

- La red reducida puede volverse densa.
- No conserva limites termicos de lineas eliminadas.
- No representa explicitamente controles, generadores `PV`, cargas `PQ` ni shunts discretos.
- Requiere cuidado si se eliminan buses con inyecciones.

Uso recomendado para TRANSPA:

- Como base algebraica para calcular el acoplamiento externo visto desde `1008`, `2206` y eventualmente `2208`.
- No como unico producto final si se necesitan inyecciones equivalentes y soporte de tension.

Fuente:

- F. Dorfler y F. Bullo, "Kron Reduction of Graphs with Applications to Electrical Networks", arXiv. https://arxiv.org/abs/1102.2950

## Ward equivalente

El equivalente Ward divide el sistema en:

- Sistema interno o de estudio.
- Sistema externo.
- Barras frontera.

La red externa se elimina parcialmente y se reemplaza por ramas, shunts e inyecciones equivalentes en las barras frontera. Su proposito principal es reproducir el efecto del externo sobre el flujo base del sistema interno.

Ventajas:

- Es una tecnica clasica para estudios de flujo de carga.
- Mantiene una representacion compacta del externo.
- Es adecuada cuando se quiere estudiar una zona conservando condiciones de intercambio con el sistema mayor.

Limitaciones:

- Depende del caso base.
- Puede degradar la respuesta de tension y reactivos.
- No preserva bien contingencias dentro de la red eliminada.
- Los limites fisicos de elementos eliminados desaparecen o deben representarse aparte.

Uso recomendado para TRANSPA:

- Como primera version formal despues de una inyeccion `P/Q` simple.
- Util si se busca que el reducido reproduzca tensiones e intercambios del RAW en el punto `V26p`.

Fuentes:

- PowerWorld, "Equivalents". https://www.powerworld.com/WebHelp/Content/MainDocumentation_HTML/Equivalents_Topic.htm
- BPA/IPF, "Network Reduction". https://bpa-ipf.readthedocs.io/en/latest/basic/network_reduction.html

## Ward extendido

El Ward extendido busca corregir una debilidad del Ward simple: la representacion de tension y potencia reactiva. Suele modelarse con:

- Una carga `PQ`.
- Una impedancia equivalente.
- Una fuente de tension o elemento tipo `PV` detras de impedancia.

Esto permite capturar mejor la rigidez externa de tension y el soporte reactivo alrededor de la frontera.

Ventajas:

- Mejor respuesta `V/Q` que Ward simple.
- Mas util para seguridad estatica y estudios de tension.
- Compatible con representaciones de flujo de potencia.

Limitaciones:

- Tiene parametros ficticios que deben documentarse.
- Sigue siendo dependiente del punto operativo.
- Puede necesitar recalibracion si cambian despacho, topologia o controles externos.

Uso recomendado para TRANSPA:

- Buena opcion si un Thevenin/Norton simple reproduce `P/Q` pero no reproduce bien las tensiones cerca de `1008` o `2206`.
- Candidato fuerte para CPF o estudios de margen de tension si no se modela toda la red externa.

Fuente:

- pandapower, "Extended Ward Equivalent". https://pandapower.readthedocs.io/en/v2.10.1/elements/xward.html

## REI equivalente

El metodo REI, "Radial Equivalent Independent", agrega partes de la red externa mediante nodos ficticios. La idea es representar grupos de generacion y carga externa con una red radial equivalente que conserve el intercambio con el sistema interno.

Ventajas:

- Permite conservar informacion agregada de generadores o cargas externas.
- Puede representar mejor la distribucion de inyecciones que un Ward simple.
- Es util cuando se quiere mantener cierta estructura fisica agregada del externo.

Limitaciones:

- La calidad depende del agrupamiento elegido.
- Introduce barras y ramas ficticias.
- No conserva automaticamente limites internos ni respuestas fuera del escenario calibrado.

Uso recomendado para TRANSPA:

- Util si se decide agrupar regiones externas relevantes, por ejemplo Bahia Blanca / Buenos Aires / Comahue externo, en lugar de usar un unico equivalente compacto.
- Mas trabajo que Ward o Thevenin, pero puede dar una representacion mas interpretable del externo.

Fuente:

- BPA/IPF, "Network Reduction" y REI. https://bpa-ipf.readthedocs.io/en/latest/basic/network_reduction.html
- Dimo et al., "The REI Equivalent, a General Model for the Analysis of Power System Behaviour", CIGRE 1974. https://www.e-cigre.org/publications/detail/32-16-1974-the-rei-equivalent-a-general-model-for-the-analysis-of-power-system-behaviour.html

## Thevenin/Norton multipuerto

Un equivalente Thevenin o Norton representa la red externa vista desde una o varias barras frontera.

Forma Thevenin:

```text
V = Eth - Zth * I
```

Forma Norton:

```text
I = In - Yeq * V
```

Cuando hay varios puertos, `Zth` o `Yeq` son matrices, no escalares. Esto es importante para TRANSPA porque `1008` y `2206/2208` no son fronteras independientes: el externo puede acoplarlas electricamente.

Ventajas:

- Representa directamente lo que la red interna "ve" desde la frontera.
- Conserva rigidez electrica y acoplamiento entre puertos.
- Es compacto y adecuado para flujos, CPF y analisis de sensibilidad local.

Limitaciones:

- No conserva estados internos de la red externa.
- No representa limites ni contingencias externas.
- Es lineal o linealizado alrededor de un punto operativo, salvo que se recalibre por escenarios.

Uso recomendado para TRANSPA:

- Es la opcion recomendada para la primera implementacion seria:
  - Puertos: `1008`, `2206` y revisar `2208`.
  - Red TRANSPA explicita.
  - Externo como matriz de admitancia/inyeccion equivalente.
- Mejor que fijar una slack ideal en `1008`, porque conserva la rigidez finita del SADI externo.

Fuentes:

- NREL, "Development of Equivalent Network Models for Large-Scale Power Systems". https://www.nrel.gov/docs/fy21osti/78372.pdf
- A. Molina-Garcia et al., "Multi-Port Equivalent for Power Systems", Energies. https://www.mdpi.com/1996-1073/12/12/2339

## Equivalentes PTDF y sensibilidad DC

Los PTDF, "Power Transfer Distribution Factors", describen como cambian los flujos activos ante cambios de inyeccion o transferencias bajo una aproximacion DC.

Hipotesis tipicas:

- Magnitudes de tension aproximadamente constantes.
- Resistencias despreciables.
- Angulos pequenos.
- Sin modelado de potencia reactiva.

Ventajas:

- Muy utiles para flujos activos, congestion, mercados, OPF DC y estudios de transferencia.
- Permiten equivalentes zonales o reducciones orientadas a restricciones activas.

Limitaciones:

- No sirven para estudiar tension o reactivos.
- No capturan bien perdidas AC.
- No preservan automaticamente limites termicos de elementos eliminados para todos los escenarios.

Uso recomendado para TRANSPA:

- No seria el metodo principal si el objetivo es flujo AC y margen de tension.
- Puede ser util como chequeo complementario de intercambios activos por frontera.

Fuente:

- PSERC/NREL, "Network Reduction Methodology". https://www.pserc.cornell.edu/empire/Network_Reduction_Methodology_V2.pdf
- Jang, Overbye y Zhu, "Line Limit Preserving Power System Equivalent". https://documents.pserc.wisc.edu/documents/publications/papers/2013_general_publications/Line-Limit-Preserving-Power-System-Equivalent_Feb-2013.pdf

## Equivalentes dinamicos por coherencia

Para estudios dinamicos, el equivalente no puede limitarse a la `Ybus`. Se deben agregar generadores, controles, cargas y posiblemente convertidores.

La tecnica clasica es identificar generadores coherentes:

- Generadores que oscilan juntos.
- Grupos con respuestas similares de angulo, velocidad, aceleracion o modos propios.
- Cada grupo se reemplaza por una maquina equivalente.

Luego se agregan:

- Inercia.
- Amortiguamiento.
- Potencia mecanica/electrica.
- Excitatrices.
- Gobernadores.
- PSS.
- Cargas dinamicas.

Ventajas:

- Adecuado para estabilidad transitoria e interarea.
- Reduce areas externas conservando modos relevantes.

Limitaciones:

- La coherencia depende del punto operativo y de la perturbacion.
- No conviene extrapolar sin validar con eventos distintos.
- Los parametros de controles no deben promediarse sin ajuste.

Uso recomendado para TRANSPA:

- No es necesario para el primer objetivo de flujo estacionario.
- Se vuelve relevante si el reducido se usa para estabilidad transitoria, oscilaciones o estudios RMS.

Fuentes:

- Van Oirsouw, "Dynamic equivalents in power system studies", IEEE Transactions on Power Systems. https://www.osti.gov/biblio/6980240
- MDPI Energies, "Dynamic Equivalents in Power System Studies: A Review". https://www.mdpi.com/1996-1073/15/4/1396

## Equivalentes basados en medidas e identificacion

Cuando no se conoce bien el sistema externo, se puede identificar un equivalente desde mediciones en frontera:

- PMU.
- DFR.
- Registros de reles.
- Mediciones WAMS.
- Simulaciones del caso completo usadas como datos de entrenamiento.

Los modelos pueden ser:

- Funciones de transferencia.
- Espacio de estados.
- Modelos gris-caja con generador equivalente + carga + impedancia.
- Modelos black-box.
- Redes neuronales o ANFIS.

Ventajas:

- Capturan comportamiento observado.
- Utiles cuando el modelo externo es incierto o cambia.

Limitaciones:

- Requieren eventos suficientemente excitantes.
- Necesitan validacion fuera de muestra.
- Pueden fallar fuera del rango de datos usado.

Uso recomendado para TRANSPA:

- No es la primera opcion porque se dispone del RAW completo.
- Podria usarse mas adelante para calibrar el equivalente contra eventos reales o contra multiples escenarios simulados.

Fuentes:

- ORNL, "Dynamic Equivalence of Large-Scale Power Systems Based on Boundary Measurements". https://www.ornl.gov/publication/dynamic-equivalence-large-scale-power-systems-based-boundary-measurements
- ORNL, "US Eastern Interconnection Model Reductions Using a Measurement-Based Approach". https://impact.ornl.gov/en/publications/us-eastern-interconnection-ei-model-reductions-using-a-measuremen/

## RMS, EMT e hibridos

Los equivalentes tambien dependen del tipo de simulacion:

- RMS positivo-secuencia: adecuado para estabilidad electromecanica, contingencias balanceadas y estudios de gran escala.
- EMT: necesario para controles rapidos, convertidores, redes debiles, desbalances, protecciones y fenomenos de alta frecuencia.
- Hibrido RMS/EMT: combina red amplia RMS con zona detallada EMT.

Para una reduccion TRANSPA orientada a flujo estacionario o CPF, basta el dominio AC fasorial. Si el estudio pasa a convertidores, protecciones o IBR en red debil, habria que revisar si el equivalente RMS sigue siendo valido.

Fuentes:

- NERC, "Electromagnetic Transient Modeling and Simulations". https://www.nerc.com/comm/RSTC_Reliability_Guidelines/Reliability_Guideline-EMT_Modeling_and_Simulations.pdf
- NERC, "Performance of Inverter-Based Resources". https://www.nerc.com/comm/RSTC_Reliability_Guidelines/PPMV_for_Inverter-Based_Resources.pdf
- CIGRE, "The need for enhanced power system modelling techniques and simulation tools". https://www.cigre.org/article/GB/the-need-for-enhanced-power-system-modelling-techniques-and-simulation-tools-2

## Validacion del equivalente

La validacion debe hacerse contra el caso completo.

### Validacion estacionaria

Comparar:

- `VM` y `VA` en todas las barras retenidas.
- Intercambio `P/Q` en cada frontera.
- Balance total de potencia activa y reactiva.
- Flujos en corredores internos relevantes.
- Estados de shunts, taps y barras `PV/PQ`.
- Nivel de cortocircuito o rigidez equivalente si se dispone de datos.

### Validacion ante cambios

Probar:

- Variaciones de carga en TRANSPA.
- Cambios de generacion interna.
- Desconexion de lineas internas.
- Cambios en shunts o transformadores internos.
- Escenarios de mayor y menor intercambio por `1008` y `2206`.

### Validacion dinamica

Si el equivalente se usa en dinamica, comparar:

- Tension y angulo en frontera.
- `P/Q` frontera.
- Frecuencia y ROCOF.
- Angulo y velocidad de generadores retenidos.
- Primer swing.
- Amortiguamiento.
- Estado final.
- Tiempo critico de despeje si corresponde.

No debe calibrarse y validarse con los mismos eventos. La validacion debe incluir casos fuera de muestra.

## Recomendacion para el caso TRANSPA

Para el objetivo actual, el orden recomendado es:

1. Construir red TRANSPA explicita a partir del RAW y del PDF.
2. Confirmar que las unicas fronteras externas sean `1008` y `2206/2208`.
3. Crear un equivalente Thevenin/Norton multipuerto de la red externa.
4. Validar flujo base contra `V26p_Trs_2532.raw`.
5. Si las tensiones o reactivos no cierran bien, pasar a Ward extendido.
6. Si se necesita representar regiones externas con mas interpretabilidad, evaluar REI.
7. Reservar equivalentes dinamicos para una etapa posterior.

Decision tecnica actual:

- No usar una slack ideal como representacion principal del SADI externo.
- No eliminar la red externa sin compensar su intercambio y rigidez.
- Priorizar Thevenin/Norton multipuerto o Ward extendido para estudios AC/CPF.
- Documentar todos los elementos cortados y todos los parametros ficticios del equivalente.

## Fuentes consultadas

- Dorfler, F. y Bullo, F., "Kron Reduction of Graphs with Applications to Electrical Networks". https://arxiv.org/abs/1102.2950
- PowerWorld, "Equivalents". https://www.powerworld.com/WebHelp/Content/MainDocumentation_HTML/Equivalents_Topic.htm
- BPA/IPF, "Network Reduction". https://bpa-ipf.readthedocs.io/en/latest/basic/network_reduction.html
- pandapower, "Extended Ward Equivalent". https://pandapower.readthedocs.io/en/v2.10.1/elements/xward.html
- Dimo et al., "The REI Equivalent, a General Model for the Analysis of Power System Behaviour", CIGRE 1974. https://www.e-cigre.org/publications/detail/32-16-1974-the-rei-equivalent-a-general-model-for-the-analysis-of-power-system-behaviour.html
- NREL, "Development of Equivalent Network Models for Large-Scale Power Systems". https://www.nrel.gov/docs/fy21osti/78372.pdf
- Molina-Garcia et al., "Multi-Port Equivalent for Power Systems", Energies. https://www.mdpi.com/1996-1073/12/12/2339
- PSERC/NREL, "Network Reduction Methodology". https://www.pserc.cornell.edu/empire/Network_Reduction_Methodology_V2.pdf
- Jang, Overbye y Zhu, "Line Limit Preserving Power System Equivalent". https://documents.pserc.wisc.edu/documents/publications/papers/2013_general_publications/Line-Limit-Preserving-Power-System-Equivalent_Feb-2013.pdf
- Van Oirsouw, "Dynamic equivalents in power system studies". https://www.osti.gov/biblio/6980240
- MDPI Energies, "Dynamic Equivalents in Power System Studies: A Review". https://www.mdpi.com/1996-1073/15/4/1396
- ORNL, "Dynamic Equivalence of Large-Scale Power Systems Based on Boundary Measurements". https://www.ornl.gov/publication/dynamic-equivalence-large-scale-power-systems-based-boundary-measurements
- ORNL, "US Eastern Interconnection Model Reductions Using a Measurement-Based Approach". https://impact.ornl.gov/en/publications/us-eastern-interconnection-ei-model-reductions-using-a-measuremen/
- NERC, "Reliability Guideline: EMT Modeling and Simulations". https://www.nerc.com/comm/RSTC_Reliability_Guidelines/Reliability_Guideline-EMT_Modeling_and_Simulations.pdf
- NERC, "Performance of Inverter-Based Resources". https://www.nerc.com/comm/RSTC_Reliability_Guidelines/PPMV_for_Inverter-Based_Resources.pdf
- CIGRE, "The need for enhanced power system modelling techniques and simulation tools". https://www.cigre.org/article/GB/the-need-for-enhanced-power-system-modelling-techniques-and-simulation-tools-2
