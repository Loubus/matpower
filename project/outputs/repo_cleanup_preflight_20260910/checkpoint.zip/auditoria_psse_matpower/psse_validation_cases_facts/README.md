# PSS/E FACTS DEVICE DATA validation cases

Estos casos son artefactos locales de auditoria para comparar el
comportamiento de `FACTS DEVICE DATA` PSS/E contra `runpf_psse` sin depender
del RAW grande.

## Casos

- `psse_facts_3bus_base.raw`: caso base de tres barras sin FACTS.
- `psse_facts_3bus_local.raw`: STATCON `MODE=1`, `J=0`, en barra 2,
  regulando su propia tension con `FCREG=0`.
- `psse_facts_3bus_remote.raw`: STATCON `MODE=1`, `J=0`, en barra 2,
  regulando la barra remota 3 con `FCREG=3`.
- `psse_facts_3bus_remote_limit.raw`: mismo control remoto, pero con
  `SHMX=5` y `VSET=1.05` para forzar el limite superior de corriente/reactivo.

## Que exportar desde PSS/E

Para cada caso, correr flujo Newton con esta configuracion:

- Solver: `FNSL`
- Solver option array code form: `BAT_FNSL`
- Opciones RAW declaradas: `SOLVER, FNSL, SWSHNT=2, FLATST=0`
- Tolerancia de tension: `NEWTON, VCTOLV=0.00001`
- Limite de ajustes: `ADJUST, MXTPSS=20`

Luego exportar:

- buses: `I`, `NAME`, `BASKV`, `TYPE`, `VM`, `VA`, `PD`, `QD`;
- FACTS: `NAME`, `I`, `J`, `MODE`, `VSET`, `SHMX`, `TRMX`, `RMPCT`,
  `FCREG`, salida reactiva final si PSS/E la muestra;
- convergencia, metodo, numero de iteraciones y opciones `SWSHNT`,
  `MXTPSS`, `VCTOLV`.

Los logs aceptados agregan dos reportes utiles:

- `BAT_LIST 0 1 20 0`: `FACTS SENDING END DATA`;
- `BAT_LIST 0 1 27 0`: `FACTS TERMINAL END DATA`.

La comparacion local equivalente vive en `matpower/lib/t/t_mpxt_psse.m`.
Para el RAW grande, la magnitud principal a verificar es que el FACTS remoto
regule `FCREG=41002` a `VSET=1.0` sin tocar `runpf` estandar.

## Nota sobre los logs PSS/E

Si el log muestra `Input error detected` en la linea de `LOAD DATA`, esa
corrida no es comparable: PSS/E ignoro la carga y el reporte queda con
`0.0/0.0` en BUS3. Los RAWs de esta carpeta ya tienen la linea de carga Rev34
completa con `DGENP=0`, `DGENQ=0`, `DGENF=0`; ademas, `SCALE` esta escrito
como entero `1`, igual que en el RAW grande.

Ver `results_psse_validation.md` para el estado de comparacion.
