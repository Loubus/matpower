# Resultados PSS/E - FACTS DEVICE DATA

## Corrida aceptada 2026-05-20

Los cuatro logs recibidos fueron revisados:

- `psse_facts_3bus_base.log`
- `psse_facts_3bus_local.log`
- `psse_facts_3bus_remote.log`
- `psse_facts_3bus_remote_limit.log`

La corrida es comparable contra MATPOWER:

- no aparece `Input error detected`;
- PSS/E procesa `1` registro de `LOAD DATA`;
- BUS3 aparece con carga `90.0 MW / 45.0 MVAr`;
- los casos con FACTS procesan `1` registro de `FACTS device data`;
- el solver es `FNSL` con `BAT_FNSL 1 1 1 1 2 0 99 0`.
- los logs incluyen reportes FACTS via `BAT_LIST 0 1 20 0` y
  `BAT_LIST 0 1 27 0`.

La salida PSS/E impresa para el STATCON muestra Mvar con signo opuesto al
`qinj` usado internamente por `runpf_psse`: por ejemplo, PSS/E imprime
`-54.2` Mvar para el STATCON local, equivalente a `qinj=+54.2` Mvar
inyectados en MATPOWER.

## Conclusion de equivalencia de control

Para el alcance implementado, los logs permiten concluir equivalencia de
comportamiento de control entre PSS/E y `runpf_psse`: PSS/E identifica el
dispositivo como `STATCON SHUNT`, lo lista como equipo controlador de tension
tipo `LOCAL SHUNT ELEM` o `REMOTE SHUNT ELEM`, regula el bus indicado por
`FCREG` a `VSET` cuando el limite lo permite, y queda limitado cuando `SHMX`
impide alcanzar la consigna.

La conclusion es de equivalencia externa de flujo de potencia y control
iterativo, no de identidad interna de implementacion numerica. PSS/E puede usar
formulaciones internas propias para el dispositivo, mientras que MATPOWER lo
representa como inyeccion reactiva equivalente aplicada en `QD`.

## FACTS DEVICE DATA reportado por PSS/E

Los reportes `FACTS SENDING END DATA` y `FACTS TERMINAL END DATA` confirman
que PSS/E esta resolviendo el mismo STATCON modelado en los RAWs chicos.

| Caso | NAME | I | J | MODE | VSET | SHMX | PCT Q / RMPCT | OWNER | Bus regulado |
|---|---|---:|---:|---:|---:|---:|---:|---:|---|
| `psse_facts_3bus_base.raw` | no aplica | no aplica | no aplica | no aplica | no aplica | no aplica | no aplica | no aplica | no aplica |
| `psse_facts_3bus_local.raw` | `FACTS 1` | 2 | 0 | 1 | 0.9800 | 300.0 | 100.0 | 1 | BUS2 |
| `psse_facts_3bus_remote.raw` | `FACTS 1` | 2 | 0 | 1 | 0.9800 | 300.0 | 100.0 | 1 | BUS3 |
| `psse_facts_3bus_remote_limit.raw` | `FACTS 1` | 2 | 0 | 1 | 1.0500 | 5.0 | 100.0 | 1 | BUS3 |

Campos terminales reportados por PSS/E para los tres casos FACTS:

| Campo | Valor |
|---|---:|
| `PDES` | 0.0 |
| `QDES` | 0.0 |
| `VTMAX` | 1.1000 |
| `VTMIN` | 0.9000 |
| `VSMAX` | 1.0000 |
| `ISMAX` | 0.0 |
| `LINE X` / `LINX` | 0.05000 |
| `VSREF` | 0 |

## Control de tension reportado por PSS/E

El reporte de control de tension de PSS/E confirma el mismo bus regulado y el
mismo equipo controlador esperado:

| Caso | Tipo PSS/E | Bus regulado | Vact | Vset | Violacion | Equipo controlador |
|---|---|---|---:|---:|---:|---|
| `psse_facts_3bus_local.raw` | `LOCAL SHUNT ELEM` | BUS2 | 0.98000 | 0.98000 | 0.00000 | FACTS DEVICE `FACTS 1` en BUS2 |
| `psse_facts_3bus_remote.raw` | `REMOTE SHUNT ELEM` | BUS3 | 0.98000 | 0.98000 | 0.00000 | FACTS DEVICE `FACTS 1` en BUS2 |
| `psse_facts_3bus_remote_limit.raw` | `REMOTE SHUNT ELEM` | BUS3 | 0.82773 | 1.05000 | -0.22227 | FACTS DEVICE `FACTS 1` en BUS2 |

El caso limitado confirma que PSS/E mantiene el equipo en su limite de shunt:
reporta `SHNTMX=5.0`, salida STATCON aproximadamente `4.6` Mvar inyectados, y
deja una desviacion de tension remota porque no puede alcanzar `VSET=1.05`.


## Comparacion PSS/E vs MATPOWER

Los valores de solucion PSS/E se toman del reporte `LAMP`, por lo que tienen
precision de 4 decimales para tension y 0.1 Mvar para el STATCON.

| Caso | PSS/E VM2 | MATPOWER VM2 | PSS/E VM3 | MATPOWER VM3 | PSS/E Qinj FACTS | MATPOWER Qinj FACTS | Limitado |
|---|---:|---:|---:|---:|---:|---:|---:|
| `psse_facts_3bus_base.raw` | 0.9166 | 0.916607 | 0.8210 | 0.820934 | no aplica | no aplica | no aplica |
| `psse_facts_3bus_local.raw` | 0.9800 | 0.980000 | 0.8931 | 0.893092 | 54.2 | 54.208710 | 0 |
| `psse_facts_3bus_remote.raw` | 1.0582 | 1.058302 | 0.9800 | 0.980000 | 133.1 | 133.266680 | 0 |
| `psse_facts_3bus_remote_limit.raw` | 0.9225 | 0.922439 | 0.8277 | 0.827658 | 4.6 | 4.612193 | 1 |

## Mismatch reportado por PSS/E

| Caso | Mayor mismatch PSS/E | Mismatch total PSS/E |
|---|---:|---:|
| `psse_facts_3bus_base.raw` | 0.02 MVA | 0.04 MVA |
| `psse_facts_3bus_local.raw` | 0.00 MVA | 0.00 MVA |
| `psse_facts_3bus_remote.raw` | 0.10 MVA | 0.19 MVA |
| `psse_facts_3bus_remote_limit.raw` | 0.02 MVA | 0.04 MVA |

## Correcciones previas de formato RAW

Los primeros logs PSS/E recibidos el 2026-05-20 no eran comparables porque
PSS/E rechazaba la fila `LOAD DATA` y dejaba BUS3 con `0.0/0.0`. Para que
PSS/E Xplore leyera correctamente el caso, se ajustaron los RAWs chicos a:

```text
OWNER=1, SCALE=1, INTRPT=0, DGENP=0.000, DGENQ=0.000, DGENF=0
```

Con esa correccion, la validacion chica queda aceptada para los modos STATCON
presentes en el RAW grande: control local, control remoto por `FCREG`, y
limite por `SHMX`.
