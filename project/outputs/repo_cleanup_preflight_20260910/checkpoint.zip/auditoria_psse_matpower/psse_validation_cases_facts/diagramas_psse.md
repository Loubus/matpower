# Diagramas PSS/E para FACTS

## Topologia comun

```text
BUS1 230 kV slack -- line 1-2 -- BUS2 115 kV -- line 2-3 -- BUS3 115 kV carga
```

## Elementos por caso

- `psse_facts_3bus_base.raw`: no dibujar FACTS.
- `psse_facts_3bus_local.raw`: FACTS tipo STATCON en BUS2, `J=0`,
  `MODE=1`, `FCREG=0`, `VSET=0.98`, `SHMX=300`.
- `psse_facts_3bus_remote.raw`: FACTS tipo STATCON en BUS2, `J=0`,
  `MODE=1`, regulando BUS3 por `FCREG=3`, `VSET=0.98`, `SHMX=300`.
- `psse_facts_3bus_remote_limit.raw`: FACTS tipo STATCON en BUS2,
  regulando BUS3, `VSET=1.05`, `SHMX=5`; debe quedar limitado arriba.
