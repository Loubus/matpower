# PSS/E Solver Options Validation RAWs

Small Rev34 RAW cases for validating how `runpf_psse` reads, reports, and later
maps PSS/E `SYSTEM-WIDE` records.

These files intentionally keep the electrical network tiny and mostly identical
so differences in PSS/E logs can be attributed to `NEWTON`, `ADJUST`, and
`SOLVER` options instead of model changes.

## Cases

- `psse_solver_options_3bus_base.raw`
  - Minimal baseline with conservative defaults.
- `psse_solver_options_3bus_large_v26p_params.raw`
  - Same 3-bus network with the key large-RAW parameters from
    `PSSE/V26p_Trs_2532.raw`.
- `psse_solver_options_3bus_flatst0.raw`
  - Non-flat embedded initial voltages with `FLATST=0`.
- `psse_solver_options_3bus_flatst1.raw`
  - Same embedded initial voltages with `FLATST=1`.
- `psse_solver_options_3bus_itmxn3.raw`
  - Low Newton iteration limit for testing `ITMXN`.
- `psse_solver_options_3bus_toln_tight.raw`
  - Tight `TOLN` candidate for tolerance experiments.
- `psse_solver_options_3bus_nondiv1.raw`
  - `NONDIV=1` report/unsupported-path fixture.
- `psse_solver_options_3bus_phshft1.raw`
  - `PHSHFT=1` report/unsupported-path fixture.
- `psse_solver_options_3bus_areain1.raw`
  - `AREAIN=1` report/unsupported-path fixture.
- `psse_solver_options_3bus_varlim0.raw`
  - `VARLIM=0` central policy fixture.
- `psse_solver_options_3bus_adjust_aggressive.raw`
  - Small `ADJTHR`, low `ACCTAP`, small `TAPLIM`, low `SWVBND`.
- `psse_solver_options_3bus_adjust_conservative.raw`
  - Larger `ADJTHR`, high `ACCTAP`, larger `TAPLIM`, high `SWVBND`.

## Intended Workflow

1. Load a RAW in PSS/E Xplore.
2. Solve with the embedded options.
3. Save the PSS/E log and solved RAW under a future `logs/` and `solved_raw/`
   subfolder.
4. Run the same RAW through `psse2mpc(raw, 0, 34)` and `runpf_psse`.
5. Compare `success`, iterations, bus `VM/VA`, generator `QG`, and
   `results.psse.solver_options`.
