# Integrated PSS/E Control Validation Case

This folder contains a small RAW case intended for reverse-engineering PSS/E
power-flow control coordination with multiple control families active in the
same solve.

## Case

- `psse_integrated_controls_14bus.raw`
- `psse_integrated_controls_30bus_moderate.raw`
- `psse_integrated_controls_40bus.raw`

The 14-bus case is the compact smoke-test fixture. The 30-bus moderate case is
the current main PSS/E Explore candidate for integrated control validation while
staying below the 50-bus limit. The 40-bus case is retained as a diagnostic or
stress fixture because it converges in PSS/E but produces an unrealistic low
voltage around bus 33 and blocks its two-terminal DC link.

Included features:

- GENQ local voltage control.
- GENQ remote grouped voltage control with `IREG` and `RMPCT`.
- Remote switched shunts with grouped regulation.
- FACTS STATCON remote voltage control.
- ULTC transformer tap control with nonzero `MAG1/MAG2`.
- Active two-terminal DC link.
- `GENERAL.PQBRAK` low-voltage load scaling metadata.
- Closed system switching device.

## Moderate 30-bus design intent

`psse_integrated_controls_30bus_moderate.raw` is a newly designed moderate
case, not a retuned copy of the 40-bus stress case. It uses a meshed
500/345/230 kV backbone, 230/115/132/13.8 kV transformer pockets, an active
two-terminal DC link, and separated control zones. The only intentional shared
regulated buses are:

- buses 2 and 3 sharing remote GENQ regulation of bus 5 through `RMPCT=60/40`;
- switched shunts 14 and 15 plus the STATCON at bus 16 coordinating around
  regulated bus 13.

The inverter-side AC load is named `INV_LOAD_345` to avoid implying that it is
a DC load.

Local MATPOWER validation for the 30-bus case is summarized in
`results_30bus_moderate_local_validation.md`. PSS/E Xplore validation is still
required before accepting the fixture as final.

Suggested PSS/E workflow:

1. Import/load the RAW file.
2. Solve with full Newton power flow and the embedded system-wide options.
3. Export the solved RAW and the mismatch/solution reports.
4. Compare final voltages, generator Q, shunt B, tap ratio, FACTS Q, and DC
   terminal quantities against `runpf_psse`.

Note: if a generated PSS/E batch command reports `PQBRAK` changing from the RAW
value to `0.700`, the batch command is overriding the RAW `GENERAL.PQBRAK`
setting. Keep that setting synchronized when comparing PSS/E and MATPOWER.

This is a diagnostic fixture, not a production network model.
