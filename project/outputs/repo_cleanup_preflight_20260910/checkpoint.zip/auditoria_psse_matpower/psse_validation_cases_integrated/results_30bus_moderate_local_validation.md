# 30-bus Moderate Integrated Controls Fixture - Local Validation

RAW:

- `psse_integrated_controls_30bus_moderate.raw`

Status:

- Local MATPOWER parse and solve: passed.
- PSS/E Xplore validation: pending user-exported logs/solved RAW.

## Design Summary

The fixture is a 30-bus PSS/E Rev34 case designed as the moderate integrated
control candidate under the 50-bus PSS/E Xplore limit.

Represented patterns from `PSSE/V26p_Trs_2532.raw`:

- system-wide RAW solver metadata, including `PQBRAK`;
- remote GENQ control with `IREG` and `RMPCT`;
- switched shunts with `MODSW=1` and `MODSW=2`;
- FACTS `MODE=1` STATCON remote voltage control;
- transformer `COD/CONT` tap control and nonzero `MAG1/MAG2`;
- active two-terminal DC/LCC data;
- system switching device data;
- area, zone, owner and fixed shunt sections.

Patterns intentionally omitted from the main moderate fixture:

- intentionally collapsed low-voltage PQBRAK stress behavior;
- blocked DC operation;
- VSC DC, multi-terminal DC, GNE, induction machine and substation data;
- long weak radial corridors and uncontrolled regulator competition.

## Local Validation Commands

Executed from:

`C:\Users\santi\Documents\UNIVERSIDAD\PROYECTO FINAL DE CARRERA - MATPOWER`

MATLAB calls:

```matlab
[mpc, warn] = psse2mpc(raw, 0, 34);
mpopt = mpoption('verbose', 0, 'out.all', 0);
r0 = runpf(mpc, mpopt);
r1 = runpf_psse(mpc, mpopt);
```

## Parse Counts

- parse OK: yes
- warnings: 2
- buses: 30
- generators: 7
- loads: 9
- raw AC branches: 27
- MATPOWER branches after conversion: 33
- two-winding transformers: 5
- three-winding transformers: 0
- raw fixed shunts: 1
- switched shunts: 3
- FACTS devices: 1
- two-terminal DC links: 1
- system switching devices: 1

Warnings:

- `Conversion explicitly using PSS/E revision 34`
- `Converted 1 system switching devices to zero-resistance MATPOWER branches; PSS/E metadata is preserved in mpc.psse.swdev.`

## Power Flow Results

`runpf(mpc, mpopt)`:

- success: 1
- iterations: 4
- VM min: 1.001824 pu at bus 20
- VM max: 1.025000 pu at bus 21
- buses outside 0.95-1.10 pu: none

`runpf_psse(mpc, mpopt)`:

- success: 1
- iterations: 4
- VM min: 1.004213 pu at bus 9
- VM max: 1.061169 pu at bus 2
- buses outside 0.95-1.10 pu: none

## PSS/E Control State From `runpf_psse`

GENQ:

- bus 2: `QG=233.4432`, limits `[-100, 300]`
- bus 3: `QG=160.6288`, limits `[-80, 240]`
- remote GENQ group regulates bus 5 without saturating the participating units.

Switched shunts:

- final `BINIT`: bus 14 = 0.0000 MVAr, bus 15 = 0.0000 MVAr, bus 28 = -7.5330 MVAr
- no switched shunt exceeded its declared physical range.

FACTS:

- `STATCON30` reactive injection: 20.7195 MVAr
- regulated bus voltage: 1.015000 pu
- not at reactive limit.

Two-terminal DC:

- active: yes
- supported by `runpf_psse`: yes
- mode: power
- `PF=60.0000 MW`, `PT=59.9907 MW`, `loss=0.0093 MW`
- `Idc=0.043191 kA`
- `QACR=78.2298 MVAr`, `QACI=18.4679 MVAr`
- DC tap flags: `HI/HI`

Transformers:

- final taps: all 1.0000
- controllable transformers inside band: 2
- no transformer at min or max tap.

## PSS/E Xplore Validation Needed

Load `psse_integrated_controls_30bus_moderate.raw` in PSS/E Xplore, run full
Newton using the embedded options, then export:

- full `.log` from load, solve and reports;
- solved RAW;
- bus voltage report;
- generator plant/unit report;
- switched shunt report;
- FACTS report;
- two-terminal DC report;
- transformer tap report;
- mismatch/solution summary.

Acceptance target for the PSS/E run:

- convergence without `Blown up` or iteration-limit termination;
- all bus voltages between 0.95 and 1.10 pu;
- no conflicting voltage setpoint messages;
- no invalid switched-shunt band messages;
- active two-terminal DC link, unless PSS/E reports a clear model-specific
  reason that must be iterated on.
