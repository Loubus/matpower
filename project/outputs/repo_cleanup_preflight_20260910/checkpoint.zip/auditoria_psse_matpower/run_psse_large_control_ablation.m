function summary = run_psse_large_control_ablation(mode)
%RUN_PSSE_LARGE_CONTROL_ABLATION Test PSS/E control variants on V26p_Trs_2532.
%   SUMMARY = RUN_PSSE_LARGE_CONTROL_ABLATION(MODE) runs a small, reproducible
%   ablation matrix against PSSE/V26p_Trs_2532.raw and compares each MATPOWER
%   solution with the voltage state embedded in the reference RAW.
%
%   MODE can be:
%       'quick'   baseline plus targeted control ablations (default)
%       'extra'   additional controller-disable probes only
%       'full'    includes additional control-disable probes

if nargin < 1 || isempty(mode)
    mode = 'quick';
end

audit_dir = fileparts(mfilename('fullpath'));
root_dir = fileparts(audit_dir);
mp_dir = fullfile(root_dir, 'matpower');
raw_path = fullfile(root_dir, 'PSSE', 'V26p_Trs_2532.raw');
results_dir = fullfile(audit_dir, 'results', 'large_raw_control_ablation');
if ~exist(results_dir, 'dir')
    mkdir(results_dir);
end
addpath(fullfile(mp_dir, 'lib'));

mpopt = mpoption('verbose', 0, 'out.all', 0);
ref = psse2mpc(raw_path);
variants = default_variants(mode);

summary = struct();
summary.generated_at = datestr(now, 'yyyy-mm-dd HH:MM:SS');
summary.mode = mode;
summary.raw_path = raw_path;
summary.root_dir = root_dir;
summary.doc_sources = { ...
    fullfile(root_dir, 'PSSE', 'DataFormats.pdf'), ...
    fullfile(root_dir, 'PSSE', 'PAGV1.pdf'), ...
    fullfile(audit_dir, 'results', 'psse_baseline_validation_latest.md'), ...
    fullfile(mp_dir, 'lib', '+mp', 'task_pf_psse.m')};
summary.variants = variants;
summary.results = repmat(empty_result(), 1, numel(variants));

fprintf('Large RAW control ablation: %s\n', raw_path);
for k = 1:numel(variants)
    fprintf('Variant %d/%d: %s\n', k, numel(variants), variants(k).name);
    summary.results(k) = run_variant(ref, variants(k), mpopt);
    fprintf('  success=%d iter=%g max|dVM|=%.9g rms|dVM|=%.9g max|dVA|=%.9g worst_bus=%g elapsed=%.1fs\n', ...
        summary.results(k).success, summary.results(k).iterations, ...
        summary.results(k).max_abs_vm, summary.results(k).rms_vm, ...
        summary.results(k).max_abs_va, summary.results(k).worst_bus, ...
        summary.results(k).elapsed_s);
end

stamp = datestr(now, 'yyyymmdd_HHMMSS');
md_path = fullfile(results_dir, ['large_raw_control_ablation_' stamp '.md']);
csv_path = fullfile(results_dir, ['large_raw_control_ablation_' stamp '.csv']);
mat_path = fullfile(results_dir, ['large_raw_control_ablation_' stamp '.mat']);
latest_md = fullfile(results_dir, 'large_raw_control_ablation_latest.md');
latest_csv = fullfile(results_dir, 'large_raw_control_ablation_latest.csv');
mode_latest_md = fullfile(results_dir, ...
    ['large_raw_control_ablation_' lower(mode) '_latest.md']);
mode_latest_csv = fullfile(results_dir, ...
    ['large_raw_control_ablation_' lower(mode) '_latest.csv']);

write_report(summary, md_path);
write_csv(summary, csv_path);
copyfile(md_path, latest_md);
copyfile(csv_path, latest_csv);
copyfile(md_path, mode_latest_md);
copyfile(csv_path, mode_latest_csv);
save(mat_path, 'summary');

summary.report_path = md_path;
summary.csv_path = csv_path;
summary.mat_path = mat_path;
summary.latest_report_path = latest_md;
summary.latest_csv_path = latest_csv;
summary.mode_latest_report_path = mode_latest_md;
summary.mode_latest_csv_path = mode_latest_csv;

fprintf('Wrote report: %s\n', md_path);
fprintf('Wrote CSV: %s\n', csv_path);
fprintf('Wrote MAT data: %s\n', mat_path);

function variants = default_variants(mode)
legacy = {'pqbrak', 'xfmr', 'genq', 'twodc', 'swshunt', 'facts'};
deferred = {'xfmr', 'genq', 'twodc', 'swshunt', 'facts', 'pqbrak'};

variants = repmat(empty_variant(), 1, 0);
variants(end+1) = make_variant('runpf_baseline', 'runpf', {}, NaN, NaN, NaN, false, false);
variants(end+1) = make_variant('runpf_psse_default', 'runpf_psse', {}, NaN, NaN, NaN, false, false);
variants(end+1) = make_variant('legacy_order', 'runpf_psse', legacy, NaN, NaN, NaN, false, false);
variants(end+1) = make_variant('deferred_order_explicit', 'runpf_psse', deferred, NaN, NaN, NaN, false, false);
variants(end+1) = make_variant('swshunt_off', 'runpf_psse', {}, 0, NaN, NaN, false, false);
variants(end+1) = make_variant('pqbrak_off', 'runpf_psse', {}, NaN, 0, NaN, false, false);
variants(end+1) = make_variant('swshunt_pqbrak_off', 'runpf_psse', {}, 0, 0, NaN, false, false);

if strcmpi(mode, 'extra')
    variants = repmat(empty_variant(), 1, 0);
end
if strcmpi(mode, 'extra') || strcmpi(mode, 'full')
    variants(end+1) = make_variant('twodc_prepare_off', 'runpf_psse', {}, NaN, NaN, 0, false, false);
    variants(end+1) = make_variant('genq_off', 'runpf_psse', {}, NaN, NaN, NaN, true, false);
    variants(end+1) = make_variant('facts_off', 'runpf_psse', {}, NaN, NaN, NaN, false, true);
end

function v = empty_variant()
v = struct( ...
    'name', '', ...
    'runner', '', ...
    'control_order', {{}}, ...
    'swshnt', NaN, ...
    'pqbrak', NaN, ...
    'twodc_prepare', NaN, ...
    'genq_off', false, ...
    'facts_off', false);

function v = make_variant(name, runner, order, swshnt, pqbrak, twodc_prepare, genq_off, facts_off)
v = empty_variant();
v.name = name;
v.runner = runner;
v.control_order = order;
v.swshnt = swshnt;
v.pqbrak = pqbrak;
v.twodc_prepare = twodc_prepare;
v.genq_off = genq_off;
v.facts_off = facts_off;

function out = empty_result()
out = struct( ...
    'name', '', ...
    'runner', '', ...
    'success', false, ...
    'iterations', NaN, ...
    'elapsed_s', NaN, ...
    'nbus', NaN, ...
    'max_abs_vm', NaN, ...
    'rms_vm', NaN, ...
    'mean_abs_vm', NaN, ...
    'median_abs_vm', NaN, ...
    'max_abs_va', NaN, ...
    'rms_va', NaN, ...
    'mean_abs_va', NaN, ...
    'median_abs_va', NaN, ...
    'min_vm', NaN, ...
    'max_vm', NaN, ...
    'outside_095_110', NaN, ...
    'worst_bus', NaN, ...
    'worst_raw_vm', NaN, ...
    'worst_mp_vm', NaN, ...
    'worst_dvm', NaN, ...
    'worst_raw_va', NaN, ...
    'worst_mp_va', NaN, ...
    'worst_dva', NaN, ...
    'twodc_iterations', NaN, ...
    'twodc_max_iter_reached', NaN, ...
    'twodc_qsum_mvar', NaN, ...
    'swshunt_iterations', NaN, ...
    'swshunt_changed_last', NaN, ...
    'pqbrak_iterations', NaN, ...
    'pqbrak_low_buses', NaN, ...
    'notes', '');

function out = run_variant(ref, variant, mpopt)
define_constants;
mpc = ref;
mpc = apply_variant(mpc, variant);
mpopt_i = mpopt;
if ~isempty(variant.control_order)
    mpopt_i = set_exp_option(mpopt_i, 'psse_control_order', variant.control_order);
end
if ~isnan(variant.twodc_prepare)
    mpopt_i = set_exp_option(mpopt_i, 'psse_twodc_prepare', variant.twodc_prepare);
end

tic;
try
    switch lower(variant.runner)
        case 'runpf'
            result = runpf(mpc, mpopt_i);
        case 'runpf_psse'
            result = runpf_psse(mpc, mpopt_i);
        otherwise
            error('Unknown runner: %s', variant.runner);
    end
    elapsed = toc;
    out = score_result(ref, result, variant, elapsed, '');
catch err
    elapsed = toc;
    out = empty_result();
    out.name = variant.name;
    out.runner = variant.runner;
    out.elapsed_s = elapsed;
    out.notes = err.message;
end

function mpc = apply_variant(mpc, variant)
if ~isnan(variant.swshnt)
    mpc = set_psse_system_value(mpc, 'solver', 'SWSHNT', variant.swshnt);
end
if ~isnan(variant.pqbrak)
    mpc = set_psse_system_value(mpc, 'general', 'PQBRAK', variant.pqbrak);
    if isfield(mpc, 'psse') && isfield(mpc.psse, 'pqbrak')
        mpc.psse = rmfield(mpc.psse, 'pqbrak');
    end
end
if variant.genq_off && isfield(mpc, 'psse') && isfield(mpc.psse, 'genq')
    mpc.psse.genq.num = zeros(0, size(mpc.psse.genq.num, 2));
end
if variant.facts_off
    mpc = set_psse_system_value(mpc, 'solver', 'FACTS', 0);
end

function mpopt = set_exp_option(mpopt, name, value)
if ~isfield(mpopt, 'exp') || isempty(mpopt.exp)
    mpopt.exp = struct();
end
mpopt.exp.(name) = value;

function mpc = set_psse_system_value(mpc, section, key, value)
if ~isfield(mpc, 'psse') || isempty(mpc.psse)
    mpc.psse = struct();
end
if ~isfield(mpc.psse, 'system') || isempty(mpc.psse.system)
    mpc.psse.system = struct();
end
if ~isfield(mpc.psse.system, section) || isempty(mpc.psse.system.(section))
    mpc.psse.system.(section) = struct();
end
mpc.psse.system.(section).(key) = value;

function out = score_result(ref, result, variant, elapsed, notes)
define_constants;
out = empty_result();
out.name = variant.name;
out.runner = variant.runner;
out.elapsed_s = elapsed;
out.notes = notes;
out.success = logical(get_field_or(result, 'success', false));
out.iterations = get_field_or(result, 'iterations', NaN);

[~, iref, ires] = intersect(ref.bus(:, BUS_I), result.bus(:, BUS_I), 'stable');
raw_vm = ref.bus(iref, VM);
raw_va = ref.bus(iref, VA);
mp_vm = result.bus(ires, VM);
mp_va = result.bus(ires, VA);
dvm = mp_vm - raw_vm;
dva = wrap_angle_deg(mp_va - raw_va);
abs_dvm = abs(dvm);
abs_dva = abs(dva);

out.nbus = numel(dvm);
out.max_abs_vm = max(abs_dvm);
out.rms_vm = sqrt(mean(dvm .^ 2));
out.mean_abs_vm = mean(abs_dvm);
out.median_abs_vm = median(abs_dvm);
out.max_abs_va = max(abs_dva);
out.rms_va = sqrt(mean(dva .^ 2));
out.mean_abs_va = mean(abs_dva);
out.median_abs_va = median(abs_dva);
out.min_vm = min(mp_vm);
out.max_vm = max(mp_vm);
out.outside_095_110 = nnz(mp_vm < 0.95 | mp_vm > 1.10);

[~, iw] = max(abs_dvm);
out.worst_bus = ref.bus(iref(iw), BUS_I);
out.worst_raw_vm = raw_vm(iw);
out.worst_mp_vm = mp_vm(iw);
out.worst_dvm = dvm(iw);
out.worst_raw_va = raw_va(iw);
out.worst_mp_va = mp_va(iw);
out.worst_dva = dva(iw);

out = add_control_diagnostics(out, result);

function out = add_control_diagnostics(out, result)
if isfield(result, 'psse')
    if isfield(result.psse, 'twodc') && isfield(result.psse.twodc, 'control')
        ctl = result.psse.twodc.control;
        out.twodc_iterations = get_field_or(ctl, 'iterations', NaN);
        out.twodc_max_iter_reached = get_field_or(ctl, 'max_iter_reached', NaN);
        if isfield(result.psse.twodc, 'qac')
            out.twodc_qsum_mvar = sum(abs(result.psse.twodc.qac(:)));
        end
    end
    if isfield(result.psse, 'swshunt') && isfield(result.psse.swshunt, 'control')
        ctl = result.psse.swshunt.control;
        out.swshunt_iterations = get_field_or(ctl, 'iterations', NaN);
        out.swshunt_changed_last = get_field_or(ctl, 'changed_last', NaN);
    end
    if isfield(result.psse, 'pqbrak') && isfield(result.psse.pqbrak, 'control')
        ctl = result.psse.pqbrak.control;
        out.pqbrak_iterations = get_field_or(ctl, 'iterations', NaN);
        out.pqbrak_low_buses = get_field_or(ctl, 'low_buses', NaN);
    end
end

function val = get_field_or(s, name, default)
if isstruct(s) && isfield(s, name) && ~isempty(s.(name))
    val = s.(name);
else
    val = default;
end

function a = wrap_angle_deg(a)
a = mod(a + 180, 360) - 180;

function write_report(summary, path)
fid = fopen(path, 'w');
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, '# Large RAW Control Ablation\n\n');
fprintf(fid, '- Generated: `%s`\n', summary.generated_at);
fprintf(fid, '- Mode: `%s`\n', summary.mode);
fprintf(fid, '- RAW: `%s`\n\n', summary.raw_path);
fprintf(fid, '## Sources\n\n');
for k = 1:numel(summary.doc_sources)
    fprintf(fid, '- `%s`\n', summary.doc_sources{k});
end
fprintf(fid, '\n');
fprintf(fid, '## Summary\n\n');
fprintf(fid, '| variant | runner | success | iter | max abs dVM | rms dVM | max abs dVA | min VM | outside | worst bus | worst raw/mp VM | elapsed s |\n');
fprintf(fid, '|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|\n');
for k = 1:numel(summary.results)
    r = summary.results(k);
    fprintf(fid, '| `%s` | `%s` | %d | %.0f | %.9g | %.9g | %.9g | %.9g | %.0f | %.0f | %.6g / %.6g | %.1f |\n', ...
        r.name, r.runner, r.success, r.iterations, r.max_abs_vm, ...
        r.rms_vm, r.max_abs_va, r.min_vm, r.outside_095_110, ...
        r.worst_bus, r.worst_raw_vm, r.worst_mp_vm, r.elapsed_s);
end
fprintf(fid, '\n## Diagnostics\n\n');
fprintf(fid, '| variant | twodc iter | twodc max iter | twodc |Q| sum | swshunt iter | swshunt changed | pqbrak iter | pqbrak low | notes |\n');
fprintf(fid, '|---|---:|---:|---:|---:|---:|---:|---:|---|\n');
for k = 1:numel(summary.results)
    r = summary.results(k);
    fprintf(fid, '| `%s` | %.0f | %.0f | %.9g | %.0f | %.0f | %.0f | %.0f | %s |\n', ...
        r.name, r.twodc_iterations, r.twodc_max_iter_reached, ...
        r.twodc_qsum_mvar, r.swshunt_iterations, ...
        r.swshunt_changed_last, r.pqbrak_iterations, ...
        r.pqbrak_low_buses, md_escape(r.notes));
end

function write_csv(summary, path)
fid = fopen(path, 'w');
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, ['variant,runner,success,iterations,elapsed_s,nbus,' ...
    'max_abs_vm,rms_vm,mean_abs_vm,median_abs_vm,' ...
    'max_abs_va,rms_va,mean_abs_va,median_abs_va,' ...
    'min_vm,max_vm,outside_095_110,worst_bus,worst_raw_vm,' ...
    'worst_mp_vm,worst_dvm,worst_raw_va,worst_mp_va,worst_dva,' ...
    'twodc_iterations,twodc_max_iter_reached,twodc_qsum_mvar,' ...
    'swshunt_iterations,swshunt_changed_last,pqbrak_iterations,' ...
    'pqbrak_low_buses,notes\n']);
for k = 1:numel(summary.results)
    r = summary.results(k);
    fprintf(fid, ['%s,%s,%d,%.15g,%.15g,%.15g,' ...
        '%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,' ...
        '%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,' ...
        '%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,%.15g,' ...
        '%.15g,%.15g,%.15g,"%s"\n'], ...
        r.name, r.runner, r.success, r.iterations, r.elapsed_s, r.nbus, ...
        r.max_abs_vm, r.rms_vm, r.mean_abs_vm, r.median_abs_vm, ...
        r.max_abs_va, r.rms_va, r.mean_abs_va, r.median_abs_va, ...
        r.min_vm, r.max_vm, r.outside_095_110, r.worst_bus, ...
        r.worst_raw_vm, r.worst_mp_vm, r.worst_dvm, ...
        r.worst_raw_va, r.worst_mp_va, r.worst_dva, ...
        r.twodc_iterations, r.twodc_max_iter_reached, ...
        r.twodc_qsum_mvar, r.swshunt_iterations, ...
        r.swshunt_changed_last, r.pqbrak_iterations, ...
        r.pqbrak_low_buses, csv_escape(r.notes));
end

function s = md_escape(s)
s = strrep(s, '|', '\|');
if isempty(s)
    s = '';
end

function s = csv_escape(s)
s = strrep(s, '"', '""');
