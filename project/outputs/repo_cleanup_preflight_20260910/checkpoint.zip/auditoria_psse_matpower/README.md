# Auditoria PSS/E RAW Rev34 vs MATPOWER

Workspace:

`C:\Users\santi\Documents\UNIVERSIDAD\PROYECTO FINAL DE CARRERA - MATPOWER`

Caso auditado:

`PSSE/V26p_Trs_2532.raw`

Objetivo:

Documentar la evidencia ya levantada sobre la conversion `psse2mpc` y organizar un plan de trabajo para explicar y reducir discrepancias entre resultados de PSS/E y MATPOWER.

## Regla de alcance

La auditoria queda anclada al RAW local. Solo se analizan en profundidad las secciones que tienen registros reales en `V26p_Trs_2532.raw`. Las secciones vacias se listan como "sin registros en este caso".

Fuentes permitidas para este trabajo:

- RAW local: `PSSE/V26p_Trs_2532.raw`
- Codigo local MATPOWER: `matpower/lib`
- Manuales locales PSS/E: `PSSE/DataFormats.pdf`, `PSSE/PAGV1.pdf`
- Manuales locales MATPOWER: `Matpower Manuals/*.pdf`
- Pruebas ejecutadas en esta sesion

## Archivos

- `01_diagnostico_actual.md`: estado del repo, importacion, convergencia, inventario, resultados numericos y ranking.
- `02_matriz_equivalencia_raw.md`: matriz tecnica seccion por seccion, solo para secciones no vacias.
- `03_plan_de_ataque.md`: plan de validacion e implementacion incremental.
- `04_switched_shunt_data.md`: primera parte de switched shunts, con parseo completo, preservacion de datos, conversion fija y validacion.
- `05_control_switched_shunt_psse.md`: auditoria del control PSS/E de switched shunts y diseno para mimetizarlo en MATPOWER.
- `06_control_transformer_tap_psse.md`: auditoria e implementacion opt-in del control PSS/E de transformadores regulantes / ULTC.
- `07_transformer_magnetizing_psse.md`: auditoria e implementacion de `MAG1/MAG2` como shunt equivalente del transformador.
- `08_facts_device_psse.md`: auditoria e implementacion opt-in del FACTS `MODE=1`, `J=0` presente en el RAW.
- `09_two_terminal_dc_psse.md`: auditoria, preservacion y mejora opt-in del equivalente LCC de `TWO-TERMINAL DC DATA`, con perdidas `RDC`, modo corriente por `VCMOD` y `QACR/QACI` equivalente.
- `10_plan_parametros_solver_psse.md`: plan maestro para incorporar parametros `SYSTEM-WIDE` de PSS/E en `runpf_psse`.
- `compare_psse_cli_cases.m`: comparador automatico entre solved RAW/logs generados por la CLI local de PSS/E y resultados `runpf_psse`.
- `tools/inspect_v26p_twodc.m`: diagnostico reproducible del RAW grande para `TWO-TERMINAL DC DATA`.
- `psse_validation_cases_ultc/`: casos locales pequenos para validar taps regulantes con `runpf_psse` y futura corrida PSS/E.
- `psse_validation_cases_mag/`: casos locales pequenos para validar magnetizacion de transformadores en PSS/E.
- `psse_validation_cases_facts/`: casos locales pequenos para validar STATCON FACTS en PSS/E.
- `psse_validation_cases_twodc/`: casos locales pequenos para validar `MDC=0`, `MDC=1`, perdidas por `RDC` y un caso reducido de 5 buses con los parametros activos `85 -> 86` del RAW grande.

## Estado base confirmado

- Repo `matpower/`: branch `master`, commit `812acbec Improve PSS/E rev 34 RAW import`.
- `psse2mpc` importa el RAW Rev34.
- `runpf` converge con `success=1` en 4 iteraciones.
- La comparacion numerica disponible es contra el estado inicial del RAW, porque no se encontro una salida PSS/E local exportada para comparar.

## Estado luego del issue SWITCHED SHUNT DATA

- `psse_parse` parsea completamente la seccion switched shunt Rev34.
- `psse_convert` preserva la tabla en `mpc.psse.swshunt`.
- `psse_convert` suma `BINIT` a `bus(:, BS)` solo cuando `ST != 0`.
- `psse_parse` preserva `SYSTEM-WIDE`, incluyendo `SOLVER/SWSHNT`, `ADJUST/MXTPSS` y `NEWTON/VCTOLV`.
- `runpf` del RAW local sigue convergiendo con `success=1` en 4 iteraciones y queda intacto.
- `runpf_psse` activa la extension MP-Core `mp.xt_psse` y ejecuta `mp.task_pf_psse`.
- El control PSS/E de switched shunts vive en helpers `mp.psse_swshunt_*`, separado de ULTC, limites Q, HVDC y FACTS.
- Sobre el RAW local, `runpf_psse` converge con `success=1`, 10 iteraciones de data model, y reduce automaticos fuera de banda de 59 a 36 sin alcanzar `MXTPSS`.
- La comparacion principal de solucion se hace contra `VM/VA` guardados en el RAW mediante `tools/compare_v26p_raw_solution.m`; `BINIT` final queda como diagnostico auxiliar.
- Tests ejecutados: `t_psse(0)` con `168/168` exitosos y `t_mpxt_psse(0)` con `25/25` exitosos.

## Estado luego del issue TRANSFORMER TAP / ULTC

- `HEAD` de partida confirmado: `ccb8106c Match PSS/E ADJM=0 discrete shunt stepping`; `master` sincronizado 0/0 con `origin/master`.
- `psse_parse` preserva winding records Rev34 completos de transformadores, incluyendo `RATE1-12`, `COD`, `CONT`, `RMA/RMI`, `VMA/VMI`, `NTP`, `TAB`, `CR/CX`, `CNXA` y `NOD`.
- `psse_convert` preserva metadata en `mpc.psse.xfmr` y mapea filas RAW a filas `branch`.
- `runpf_psse` coordina primero control ULTC y luego switched shunts en `mp.task_pf_psse.next_dm`.
- La logica ULTC vive separada en `mp.psse_xfmr_*`, sin tocar `runpf`, `makeYbus` ni `makeSbus`.
- Sobre el RAW local, `ACTAPS=0`; por lo tanto `runpf_psse` reporta transformadores regulantes pero no mueve taps.
- Reporte RAW: `cod1=863`, `cod_m1=282`, `cod0=2842`, `cont_missing=319`, `unsupported_tab=12`, `num_adjustments=0`.
- Tests ejecutados: `t_mpxt_psse(0)` con `38/38` exitosos y `t_psse(0)` con `171/171` exitosos.

## Estado luego de TAB / impedance correction

- `psse_parse` parsea `IMPEDANCE CORRECTION DATA` y conserva `ZCOD` en transformadores de tres devanados Rev34.
- `psse_convert` preserva `mpc.psse.impcor` y aplica `TAB` al construir `branch(:, BR_R/BR_X)` para el modo presente en el RAW: `ZCOD=0`.
- `runpf_psse` reaplica la correccion `TAB` cuando cambia un tap, usando la impedancia nominal preservada.
- Sobre el RAW local hay `12` tablas, `12` transformadores de tres devanados con `TAB` y `36` devanados corregidos; todas las tablas reales son identidad (`1 + j0`) en el punto guardado.
- Reporte RAW actualizado: `unsupported_tab=0`, `tab_corrected=36`, `ACTAPS=0`, `num_adjustments=0`.
- Tests ejecutados: `t_mpxt_psse(0)` con `42/42` exitosos y `t_psse(0)` con `175/175` exitosos.

## Estado luego de MAG1/MAG2 / magnetizacion

- `psse_parse` parsea `MAG1/MAG2` en transformadores de dos y tres devanados.
- `psse_convert_xfmr` convierte la magnetizacion a shunt fijo en el bus `I` del devanado 1.
- `CM=1` se mapea directo como admitancia en pu sobre base sistema.
- `CM=2` se convierte desde perdida en vacio en W e intensidad de excitacion en pu sobre `SBASE1-2` y `NOMV1`.
- Sobre el RAW local hay `56` transformadores activos con `MAG1/MAG2` no nulo; `17` tienen algun `COD=1`.
- Casos chicos PSS/E `2W/3W` y `CM=1/CM=2` coinciden contra MATPOWER dentro de la precision impresa por PSS/E.
- Tests ejecutados: `t_psse(0)` con `176/176` exitosos y `t_mpxt_psse(0)` con `48/48` exitosos.

## Estado luego de FACTS DEVICE DATA

- `psse_parse` parsea `FACTS DEVICE DATA` Rev34+ y `psse_convert` preserva `mpc.psse.facts`.
- El unico FACTS del RAW es `MODE=1`, `J=0`, en `I=40403`, regulando remoto `FCREG=41002` con `VSET=1.0` y `SHMX=100`.
- `runpf_psse` implementa opt-in ese STATCON como inyeccion reactiva controlada por `QD`, sin tocar `runpf`, `makeYbus`, `makeSbus` ni la logica de switched shunts.
- `mp.task_pf_psse.next_dm` coordina transformadores, switched shunts y luego FACTS, para que el STATCON haga el ajuste continuo final despues de los shunts discretos.
- Sobre el RAW local, `runpf_psse` converge con `success=1`, `Qfacts=-20.531494022`, `VM(41002)=1.000000005`, y no alcanza el limite `SHMX`.
- Tests ejecutados: `t_psse(0)` con `182/182` exitosos y `t_mpxt_psse(0)` con `59/59` exitosos.

## Estado luego de TWO-TERMINAL DC DATA

- `psse_parse` parsea los tres records Rev34 completos de `TWO-TERMINAL DC DATA`.
- `psse_convert` preserva metadata en `mpc.psse.twodc`, incluyendo columnas, texto, mapeo a `dcline`, buses rectificador/inversor y perdida estimada.
- `psse_convert_hvdc` mantiene `MDC=0` bloqueado sin inyeccion, convierte `MDC=1` para `SETVL>0` y `SETVL<0`, y convierte `MDC=2` desde corriente en amperes.
- Para los cuatro enlaces activos del RAW, cada `dcline` queda en `PF=825.000000`, `PT=805.205156`, `LOSS0=19.794844`, `LOSS1=0`; perdida total `79.179375 MW`.
- El RAW local sigue convergiendo con `runpf`, `success=1`, 4 iteraciones; con todos los `dcline` deshabilitados no converge (`success=0`, 10 iteraciones).
- Logs PSS/E Xplore de los casos chicos muestran que `MDC=1`, `SETVL>0` cae a corriente cuando `Vdci < VCMOD`; `runpf_psse` implementa ese fallback opt-in para el subconjunto validado y reporta corriente/tensiones DC.
- Como PSS/E Xplore no puede abrir el RAW grande por limite de 50 buses, se agrego `psse_twodc_5bus_v26p_active.raw` para validar el enlace activo `85 -> 86` aislado con `SETVL=825`, `VSCHD=600`, `VCMOD=558`, `RDC=RCOMP=10.47`.
- El log PSS/E del caso reducido grande confirma modo potencia (`PAC(R)=825.0`, `PAC(I)=-804.1`, `DCAMPS=1413.2`) y perdida `20.91 MW`; `runpf_psse` resuelve el equivalente LCC opt-in y mueve el caso reducido a `PT=804.089934`, `LOSS0=20.910066`, `Idc=1.413202 kA`, `QACR=379.425136`, `QACI=367.541929`.
- La reactiva LCC se aplica como demanda equivalente `bus(:, QD)` dentro de `runpf_psse`. En enlaces paralelos sobre el mismo par de buses, como los cuatro activos del RAW grande, se acumula sobre los buses terminales y queda reflejada en `mpc.psse.twodc.control` y en `dcline(:, QF/QT)`.
- El contrato operativo queda acotado a `MDC=0`, `MDC=1`, `MDC=2`, `SETVL~=0`, `VSCHD>0`, LCC sin capacitores (`XCAPR=0`, `XCAPI=0`), con `DCVMIN` y registros con capacitores preservados sin accionar.
- Tests ejecutados: `t_psse(0)` con `192/192` exitosos y `t_mpxt_psse(0)` con `123/123` exitosos.

## Estado luego de PSSE CLI / comparador automatico

- La carpeta `PSSE/` contiene un runner CLI local, `Solve-RawPowerFlow.ps1`, que usa `pssecmd36.exe` y exporta logs, IDV, SAV y solved RAW.
- `PSSE/README_PSSE_CLI.md` documenta el mapeo `SOLVER -> BAT_FNSL` y `GENERAL/NEWTON/ADJUST -> BAT_SOLUTION_PARAMETERS_5`.
- `compare_psse_cli_cases(group)` compara los RAW originales de `PSSE/<group>` contra los solved RAW de `PSSE/<group>/solved_raw`, ejecutando `runpf_psse` sobre el RAW original.
- El comparador tambien genera `*_comparison_parameters_latest.csv`, con una fila por parametro efectivo PSS/E y su estado en MATPOWER: valor RAW explicito, valor efectivo usado por PSS/E, estado `runpf_psse`, valor MATPOWER y tipo de comparacion.
- Resultados generados en `results/psse_cli_comparison/`:
  - `solver_comparison_latest.csv/.md`: 12/12 casos `PSSE/SOLVER` parsean, corren y convergen.
  - `shunts_comparison_latest.csv/.md`: 3/3 casos `PSSE/SHUNTS` parsean, corren y convergen.
  - `total_comparison_latest.csv/.md`: 2/2 casos `PSSE/TOTAL` parsean, corren y convergen.
  - `integrado_comparison_latest.csv/.md`: `14bus` converge; `40bus` parsea pero no converge en `runpf_psse`, con divergencia numerica grande contra PSS/E.
- En `PSSE/INTEGRADO/psse_integrated_controls_40bus.raw`, los campos `SOLVER`, `NEWTON.ITMXN`, `NEWTON.VCTOLV`, `NEWTON.VCTOLQ`, `ADJUST.MXTPSS` y `GENERAL.PQBRAK` quedan alineados con MATPOWER, pero la comparacion de parametros efectivos muestra 10 brechas: `GENERAL.THRSHZ`, `NEWTON.ACCN`, `NEWTON.TOLN`, `NEWTON.DVLIM`, `NEWTON.NDVFCT`, `ADJUST.ADJTHR`, `ADJUST.ACCTAP`, `ADJUST.TAPLIM`, `ADJUST.SWVBND` y `ADJUST.MXSWIM`.
- Baseline `PSSE/SOLVER`: diferencias tipicas `max abs dVM = 2.61e-05 pu`, `max abs dVA = 0.00105 deg`, `max abs dQG = 0.0201 MVAr`; el caso `FLATST=1` queda mas separado (`max abs dVM = 6.63e-04 pu`, `max abs dVA = 0.0391 deg`, `max abs dQG = 0.525 MVAr`).
- Baseline `PSSE/SHUNTS`: los casos aislados de shunts quedan muy cercanos a PSS/E; el discreto local muestra `max abs dVM = 1.15e-04 pu`, `max abs dVA = 0.00445 deg`, `max abs dQG = 0.0778 MVAr`, con `dBINIT = 0`.
- Baseline `PSSE/TOTAL`: `14bus` y `30bus_moderate` convergen; el caso `30bus_moderate` queda en `max abs dVM = 0.00750 pu`, `max abs dVA = 0.0152 deg`, `max abs dQG = 6.42 MVAr`, `max abs dBINIT = 1.896 MVAr`.
- Esta evidencia convierte PSS/E CLI en referencia local reproducible para las fases siguientes de `TOLN`, parametros `ADJUST` y, mas adelante, `DVLIM/NONDIV/NDVFCT`.
