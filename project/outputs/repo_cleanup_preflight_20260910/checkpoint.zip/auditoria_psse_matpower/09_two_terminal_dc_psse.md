# TWO-TERMINAL DC DATA - PSS/E vs MATPOWER

Workspace:

`C:\Users\santi\Documents\UNIVERSIDAD\PROYECTO FINAL DE CARRERA - MATPOWER`

Caso auditado:

`PSSE/V26p_Trs_2532.raw`

## Alcance

Este cierre define el contrato final para `TWO-TERMINAL DC DATA` del RAW local.
La ruta base conserva `runpf` estandar y convierte los registros PSS/E a
`mpc.dcline`. La ruta opt-in `runpf_psse` agrega el comportamiento LCC asociado
a esos mismos registros mediante `mp.psse_twodc_*`.

El contrato cubre:

- parseo Rev34 completo de los tres records `TWO-TERMINAL DC DATA`;
- preservacion de metadata en `mpc.psse.twodc`;
- conversion estatica a `mpc.dcline` para `MDC=0`, `MDC=1` y `MDC=2`;
- perdidas activas por `RDC`;
- cambio a modo corriente cuando `Vdci < VCMOD`;
- seleccion deterministica de taps DC dentro de `runpf_psse`;
- reporte de corriente, tension DC, taps, `alpha/gamma`, solapes y
  `QACR/QACI`;
- tratamiento activo de enlaces paralelos sobre el mismo par de buses.

## Evidencia RAW

Inventario confirmado para `V26p_Trs_2532.raw`:

- `TWO-TERMINAL DC DATA`: 8 enlaces.
- Enlaces 1-4:
  - `MDC=0`, bloqueados.
  - conversores `20 -> 5010` y `22 -> 5020`.
- Enlaces 5-8:
  - `MDC=1`, activos.
  - conversores `85 -> 86`.
  - `SETVL=825 MW` por enlace.
  - total activo programado: `3300 MW`.
  - `RDC=10.47 ohm`.
  - `VSCHD=600 kV`.
  - `VCMOD=558 kV`.
  - `RCOMP=10.47 ohm`.
  - `XCAPR=0`, `XCAPI=0`.

El bloque `SYSTEM-WIDE/SOLVER` trae `DCTAPS=1`. Por lo tanto `runpf_psse`
construye grillas discretas de taps para los enlaces soportados.

## Evidencia documental

Segun `PSSE/DataFormats.pdf`, `TWO-TERMINAL DC DATA` Rev34 se compone de tres
records. Para este modelo se preservan `MDC`, `RDC`, `SETVL`, `VSCHD`,
`VCMOD`, `RCOMP`, `DCVMIN`, buses conversores, reactancias de conmutacion,
rangos de taps, pasos de taps, angulos, filtros y capacitores.

Segun `PSSE/PAGV1.pdf`, seccion `6.9.7 dc Transmission`, los enlaces LCC no
capacitor-commutated resuelven corriente/tension DC, angulos `alpha/gamma`,
conmutacion, taps y modo de control:

- `MDC=0`: linea bloqueada.
- `MDC=1`: control de potencia; con `SETVL > 0`, la potencia deseada se mide
  en el rectificador y con `SETVL < 0` se mide como potencia recibida en el
  inversor.
- `MDC=2`: control de corriente; `SETVL` se interpreta en amperes.
- Si la tension inversora cae bajo `VCMOD`, PSS/E pasa a control de corriente.
- `Vdci + Idc * RCOMP = VSCHD`; con `RCOMP=RDC`, la tension compuesta queda
  ligada a la tension del rectificador.

`Matpower Manuals/MATPOWER-manual-8.1.pdf` documenta `mpc.dcline` y su modelo
de perdidas lineal:

```text
loss = LOSS0 + LOSS1 * PF
```

`toggle_dcline` representa cada enlace DC como dos generadores ficticios
acoplados. En `ext2int`, para cada linea activa:

- generador en el bus from: `PG = -PF`;
- generador en el bus to: `PG = PT`;
- `PT = PF - loss`.

Por eso, una perdida activa constante por enlace se representa sin tocar
`runpf`, `makeYbus` ni `makeSbus`, fijando `LOSS0 = Ploss`, `LOSS1 = 0` y
`PT = PF - Ploss`.

## Modelo Final Esperado

### Preservacion

`psse_parse` conserva los tres records Rev34 completos. `psse_convert` guarda:

- `mpc.psse.twodc.colnames`: nombres de columnas PSS/E preservadas.
- `mpc.psse.twodc.num`: matriz numerica importada.
- `mpc.psse.twodc.txt`: campos de texto importados.
- `mpc.psse.twodc.col`: indices por nombre normalizado.
- `mpc.psse.twodc.dcline_idx`: mapeo a filas `mpc.dcline`.
- `mpc.psse.twodc.rect_bus_idx` y `inv_bus_idx`: mapeo interno de buses.
- `mpc.psse.twodc.loss_mw`: perdida activa del equivalente.
- `mpc.psse.twodc.control`: reporte opt-in producido por `runpf_psse`.

### Conversion estatica a `mpc.dcline`

Para `MDC=0`:

```text
BR_STATUS = 0
PF = 0
PT = 0
LOSS0 = 0
LOSS1 = 0
```

Para `MDC=1`, `SETVL > 0`, `VSCHD > 0`:

```text
PF = abs(SETVL)
Idc = PF / VSCHD
Ploss = RDC * Idc^2
PT = PF - Ploss
LOSS0 = Ploss
LOSS1 = 0
```

Para `MDC=1`, `SETVL < 0`, `VSCHD > 0`:

```text
PT = abs(SETVL)
Idc = PT / VSCHD
Ploss = RDC * Idc^2
PF = PT + Ploss
LOSS0 = Ploss
LOSS1 = 0
```

Para `MDC=2`, `VSCHD > 0`:

```text
Idc = abs(SETVL) / 1000
PF = Idc * VSCHD
Ploss = RDC * Idc^2
PT = PF - Ploss
LOSS0 = Ploss
LOSS1 = 0
```

Para los cuatro enlaces activos del RAW:

```text
Idc = 825 MW / 600 kV = 1.375 kA
Ploss = 10.47 ohm * 1.375^2 = 19.79484375 MW
Perdida total = 4 * 19.79484375 = 79.179375 MW
```

### Control opt-in `runpf_psse`

`runpf_psse` ejecuta el control despues de una solucion AC y usa las tensiones
AC resultantes para calcular el punto LCC no capacitor-commutated. El modelo
activo se aplica a registros:

```text
MDC = 1 y abs(SETVL) > 0
MDC = 2 y abs(SETVL) > 0
VSCHD > 0
XCAPR = 0
XCAPI = 0
bus rectificador e inversor mapeados
```

En modo potencia:

- `gamma = ANMNI`;
- se generan grillas discretas para taps inversor y rectificador;
- para cada tap inversor se calculan las raices positivas de corriente que
  satisfacen `P = Vdcr * Idc` si `SETVL > 0` o `P = Vdci * Idc` si
  `SETVL < 0`;
- se descartan puntos con `Vdci <= 0` o `Vdcr <= 0`;
- para cada tap rectificador se calcula `alpha` y se verifica el rango
  `ANMNR..ANMXR`;
- se elige el candidato que minimiza, en orden:
  - exceso de `Vcomp` sobre `VSCHD`;
  - distancia absoluta `|Vcomp - VSCHD|`;
  - movimiento de tap rectificador respecto del tap RAW;
  - movimiento de tap inversor respecto del tap RAW.

Si el punto de modo potencia no es valido o si `Vdci < VCMOD`, `runpf_psse`
entra en modo corriente:

```text
Idc = abs(SETVL) / VSCHD
Vdci = f(Eaci, gamma, Idc)
Vdcr = Vdci + RDC * Idc
PF = Vdcr * Idc
PT = Vdci * Idc
LOSS0 = RDC * Idc^2
```

En modo corriente, el tap inversor toma `TMNI` cuando `DCTAPS` esta activo y
el registro tiene rango valido. El tap rectificador se selecciona desde su
grilla discreta buscando el valor mas cercano al tap RAW que mantiene `alpha`
dentro de rango.

El reporte `mpc.psse.twodc.control` expone por fila:

- modo `power` o `current`;
- `PF`, `PT` y `loss_mw`;
- `Idc`, `Vdcr`, `Vdci`, `Vcomp`;
- `tapr`, `tapi`, `alpha`, `gamma`;
- corrientes AC, solapes y `QACR/QACI`;
- banderas `apply_model` y `apply_q`;
- estado del solve auxiliar de tension AC (`ac_pf_success`, `ac_pf_status`).

## Enlaces Paralelos

Los cuatro enlaces activos del RAW comparten el mismo par rectificador/inversor
`85 -> 86`. Cada fila se resuelve con su propio estado LCC, actualiza su fila
`dcline`, y sus consumos `QACR/QACI` se acumulan sobre los buses AC terminales.
El contrato final para paralelos es:

- `runpf` usa el equivalente estatico con perdidas `RDC`;
- `runpf_psse` actualiza cada fila `dcline` con el punto LCC calculado;
- `results.dcline(:, QF/QT)` refleja el `QACR/QACI` reportado con signo de
  inyeccion;
- en enlaces paralelos soportados, `runpf_psse` acumula `PF/PT`, `LOSS0` y
  `QACR/QACI` por bus sin fusionar los estados de tap, angulo o corriente.

## Comparacion Antes y Despues

### Conversor estatico

Antes del issue:

- `psse_parse` detectaba la seccion, pero la plantilla Rev34 no conservaba
  todos los campos usados por el modelo.
- `RDC`, `VCMOD`, `RCOMP`, `XCAPR` y `XCAPI` no quedaban confiables por
  desplazamiento de columnas.
- `psse_convert_hvdc` generaba `mpc.dcline` con `LOSS0=0`, `LOSS1=0` y
  `PT=PF`.

Despues del issue, las filas activas del RAW grande quedan:

```text
F  T  ST  PF          PT          LOSS0       LOSS1
85 86 1   825.000000  805.205156  19.794844  0.000000
85 86 1   825.000000  805.205156  19.794844  0.000000
85 86 1   825.000000  805.205156  19.794844  0.000000
85 86 1   825.000000  805.205156  19.794844  0.000000
```

Efecto agregado:

```text
active loss sum = 79.179375 MW
runpf no-loss success=1 iterations=4
runpf with-loss success=1 iterations=4
PG(active)-PD no-loss 1232.314062
PG(active)-PD with-loss 1311.493437
delta 79.179375 MW
runpf all dcline disabled success=0 iterations=10
```

### Casos PSS/E Xplore vs MATPOWER

| Caso | PSS/E Xplore | MATPOWER antes | MATPOWER despues |
|---|---|---|---|
| `MDC=0` | `PAC=QAC=VDC=0`, `ALPHA/GAMMA=90/90` | dependia del mapeo parcial | `BR_STATUS=0`, `PF=PT=0`, `LOSS0=0`, `ALPHA/GAMMA=90/90` |
| `MDC=1`, `RDC=0`, `VCMOD` activo | `DCAMPS=100.0`, `PAC(R)=29.1`, `PAC(I)=-29.1`, `QAC(R)=8.5`, `QAC(I)=9.1` | `PF=PT=50`, sin modo corriente | `runpf_psse`: `PF=29.087790`, `PT=29.087790`, `Idc=0.100000`, `QACR=8.520008`, `QACI=9.061854` |
| `MDC=1`, `RDC=10`, `VCMOD` activo | `DCAMPS=100.0`, `PAC(R)=29.2`, `PAC(I)=-29.1`, perdida `0.10 MW` | `PF=50`, `PT=49.9`, sin modo corriente | `runpf_psse`: `PF=29.187790`, `PT=29.087790`, `LOSS0=0.100000`, `Idc=0.100000`, `QACR=8.205781`, `QACI=9.061854` |
| `85 -> 86` reducido | `PAC(R)=825.0`, `PAC(I)=-804.1`, perdida `20.91`, `DCAMPS=1413.2`, `QACR=379.4`, `QACI=367.5` | `PF=825`, `PT=805.205156`, `LOSS0=19.794844`, sin `QACR/QACI` | `runpf_psse`: `PF=825.000000`, `PT=804.089934`, `LOSS0=20.910066`, `Idc=1.413202`, `QACR=379.425136`, `QACI=367.541929` |

### RAW grande con `runpf_psse`

El RAW grande no entra en modo corriente para los cuatro enlaces activos:

```text
runpf_psse success=1 iterations=4
twodc_current=0
active loss sum=79.116356 MW
acpf_status=fallback
```

Punto LCC reportado por enlace activo paralelo:

```text
Idc=1.374453 kA
Vdcr=600.238912 kV
Vdci=585.848392 kV
Vcomp=600.238912 kV
alpha=17.388772 deg
gamma=17.000000 deg
tapr=1.037500
tapi=1.066000
QACR=381.179360 MVAr
QACI=362.386290 MVAr
PF=825.000000 MW
PT=805.220911 MW
loss=19.779089 MW
apply_model=1
apply_q=1
```

## Implementacion

Archivos de codigo modificados por el issue:

- `matpower/lib/psse_parse.m`
  - Plantilla Rev34 de `TWO-TERMINAL DC DATA` ampliada para preservar los tres
    records completos.
- `matpower/lib/psse_convert.m`
  - Preservacion `mpc.psse.twodc`.
- `matpower/lib/psse_convert_hvdc.m`
  - Correccion del bus inversor Rev34 en columna 31.
  - Calculo de perdida activa por `RDC`.
  - `MDC=0` bloqueado sin inyeccion.
  - `MDC=1` activo con `SETVL>0` como potencia rectificadora y `SETVL<0`
    como potencia recibida en el inversor.
  - `MDC=2` convertido desde corriente en amperes.
- `matpower/lib/runpf_psse.m`
  - Sincronizacion del `results.dcline` externo con
    `results.psse.twodc.control`.
- `matpower/lib/+mp/task_pf_psse.m`
  - Coordinacion del control `TWO-TERMINAL DC` en la ruta opt-in.
- `matpower/lib/+mp/psse_twodc_states.m`
  - Estado interno desde `mpc.psse.twodc`, mapeo `ext2int`, DCTAPS, paralelos.
- `matpower/lib/+mp/psse_twodc_control.m`
  - Modo potencia, modo corriente por `VCMOD`, grillas de taps, calculo LCC.
- `matpower/lib/+mp/psse_twodc_update.m`
  - Aplicacion de `PF/PT/LOSS0` y de `QACR/QACI` cuando corresponde.
- `matpower/lib/+mp/psse_twodc_report.m`
  - Reporte compacto de estado, taps, corriente, tensiones, reactiva y modo.
- `matpower/lib/t/t_psse.m`, `matpower/lib/t/t_mpxt_psse.m`,
  `matpower/lib/t/t_psse_case4.raw`
  - Cobertura de parser, conversion, modo corriente, `SETVL<0`, perdidas,
    preservacion de filas no soportadas y reporte.

Artefactos locales de auditoria:

- `auditoria_psse_matpower/tools/inspect_v26p_twodc.m`
- `auditoria_psse_matpower/psse_validation_cases_twodc/`

## Validacion

Script reproducible:

```text
auditoria_psse_matpower/tools/inspect_v26p_twodc.m
```

Pruebas MATPOWER reportadas por el issue:

- `t_psse(0)`: `192/192` exitosos.
- `t_mpxt_psse(0)`: `123/123` exitosos.

Casos chicos, conversion estatica `psse2mpc + runpf`:

| Caso | Conversion esperada | `runpf` |
|---|---|---|
| `psse_twodc_4bus_base.raw` | sin `dcline` | `success=1`, 4 iteraciones |
| `psse_twodc_4bus_mdc0.raw` | `BR_STATUS=0`, `PF=PT=0` | `success=1`, 4 iteraciones |
| `psse_twodc_4bus_mdc1_noloss.raw` | `PF=50`, `PT=50`, `LOSS0=0` | `success=1`, 3 iteraciones |
| `psse_twodc_4bus_mdc1_loss.raw` | `PF=50`, `PT=49.9`, `LOSS0=0.1` | `success=1`, 3 iteraciones |
| `psse_twodc_5bus_v26p_active.raw` | `PF=825`, `PT=805.205156`, `LOSS0=19.794844` | `success=1`, 4 iteraciones |

Casos chicos, `runpf_psse` opt-in:

| Caso | `runpf_psse` | Referencia PSS/E |
|---|---|---|
| `psse_twodc_4bus_mdc1_noloss.raw` | `PF=29.087790`, `PT=29.087790`, `LOSS0=0`, `Idc=0.100000 kA`, `QACR=8.520008`, `QACI=9.061854`, `VCOMP=290.877903` | `PAC(R)=29.1`, `PAC(I)=-29.1`, `QAC(R)=8.5`, `QAC(I)=9.1`, `DCAMPS=100.0`, `VCOMP=290.9` |
| `psse_twodc_4bus_mdc1_loss.raw` | `PF=29.187790`, `PT=29.087790`, `LOSS0=0.100000`, `Idc=0.100000 kA`, `QACR=8.205781`, `QACI=9.061854`, `VCOMP=291.877903` | `PAC(R)=29.2`, `PAC(I)=-29.1`, `QAC(R)=8.2`, `QAC(I)=9.1`, `DCAMPS=100.0`, `VCOMP=291.9`, perdida `0.10 MW` |
| `psse_twodc_5bus_v26p_active.raw` | `PF=825.000000`, `PT=804.089934`, `LOSS0=20.910066`, `Idc=1.413202`, `QACR=379.425136`, `QACI=367.541929`, `VCOMP=583.780506` | `PAC(R)=825.0`, `PAC(I)=-804.1`, perdida `20.91`, `DCAMPS=1413.2`, `QACR=379.4`, `QACI=367.5` |

## Frontera Operativa

El modelo activo queda definido para los registros presentes y validados:

- `MDC=0` bloqueado;
- `MDC=1`, `SETVL~=0`, `VSCHD>0`;
- `MDC=2`, `SETVL~=0`, `VSCHD>0`;
- LCC sin capacitores (`XCAPR=0`, `XCAPI=0`);
- perdida activa por `RDC`;
- modo corriente por `VCMOD`;
- taps discretos habilitados por `DCTAPS`;
- enlaces paralelos resueltos y aplicados por fila.

Campos preservados sin accionar en este contrato:

- `DCVMIN`;
- registros con `XCAPR` o `XCAPI` no nulo.

La salida de referencia de PSS/E Xplore disponible cubre los casos chicos y el
caso reducido del enlace activo `85 -> 86`. Para el RAW grande, el artefacto
local reproducible es `inspect_v26p_twodc.m`; una corrida PSS/E completa fuera
del limite de 50 buses de Xplore aporta evidencia adicional de calibracion.
