# Auditoria CPF y estabilidad de tension en MATPOWER

Fecha: 2026-05-28

## Alcance

Esta auditoria revisa el checkout local de MATPOWER y los documentos locales del proyecto para responder que herramientas trae MATPOWER para:

- continuation power flow (CPF);
- estudios de estabilidad de tension en regimen permanente;
- extensiones locales PSS/E relacionadas con baja tension, GENQ o control progresivo.

No se modifico codigo fuente.

## Roles usados

- Auditor codigo MATPOWER CPF: inventario de funciones nativas, clases MP-Core, eventos, opciones y pruebas.
- Auditor documentacion: manual MATPOWER, referencia Sphinx y ejemplo CPF.
- Auditor PSS/E local: `runpf_psse`, controles PSS/E y diagnosticos locales de continuation/state.
- Integracion: sintesis, verificacion MATLAB y este informe.

## Hallazgos principales

1. MATPOWER trae una herramienta CPF nativa y madura.
   - Interfaz legacy: `matpower/lib/runcpf.m`.
   - Interfaz flexible MP-Core: `matpower/lib/run_cpf.m`, que llama a `run_mp(@mp.task_cpf, ...)`.
   - Clase de tarea: `matpower/lib/+mp/task_cpf.m`.
   - Modelos matematicos CPF: `matpower/lib/+mp/math_model_cpf*.m`.
   - Algoritmo base: predictor tangente + corrector Newton, con parametro de continuacion `lambda`.

2. Para estabilidad de tension, MATPOWER cubre el estudio clasico de limite de carga en estado estacionario.
   - El manual dice que CPF se usa para determinar limites de estabilidad estacionaria mediante curva nose.
   - El resultado clave es `results.cpf.max_lam`, junto con `results.cpf.V`, `results.cpf.lam`, `results.cpf.events` y `done_msg`.
   - El evento `NOSE` detecta el punto nariz usando el cambio de signo de la componente `lambda` del vector tangente.

3. Las opciones nativas cubren bastante del flujo CPF operativo.
   - Parametrizaciones: natural, arc length y pseudo arc length.
   - Criterios de parada: `NOSE`, `FULL` o valor objetivo de `lambda`.
   - Paso fijo o adaptativo.
   - Eventos/limites: `TARGET_LAM`, `NOSE`, full trace, `QLIM`, `PLIM`, `VLIM`, `FLIM`.
   - Callbacks de usuario soportados; eventos de usuario no estan soportados en la documentacion revisada.

4. La documentacion esta razonablemente alineada con el codigo.
   - El manual fuente contiene una seccion completa "Continuation Power Flow".
   - La tabla de opciones coincide con `mpoption.m`.
   - El ejemplo `examples/cpf_example.m` coincide con el ejemplo del manual.
   - La referencia Sphinx lista funciones legacy y clases MP-Core.

5. `runpf_psse` no es una herramienta CPF.
   - Es un flujo de potencia con controles PSS/E opt-in: GENQ, PQBRAK, ULTC/xfmr, TWODC, FACTS y switched shunts.
   - El loop de `mp.task_pf_psse.next_dm()` reconstruye modelos despues de ajustes, pero sigue siendo PF iterativo, no trazado CPF con parametro `lambda`.

6. Hay diagnosticos locales tipo continuation para el problema GENQ/40-bus, pero no son producto MATPOWER formal.
   - `auditoria_psse_matpower/results/psse_40bus_genq_trace_shadow/...` documenta un problema de handoff GENQ como "coupled continuation/state problem".
   - `auditoria_psse_matpower/results/psse_40bus_genq_handoff_frontier/run_psse_40bus_genq_handoff_frontier.m` emula una continuacion desde el estado no-GENQ, pero cada punto llama a `runpf_psse`.
   - `psse_low_voltage_fallback.m` intenta una solucion coordinada de rama de baja tension con `lsqnonlin`, pero no implementa CPF general ni curva P-V.
   - `results/psse_40bus_genq_architecture_design/.../genq_controller_architecture_proposal.md` propone una continuacion local para GENQ como diseno futuro, no como herramienta ya consolidada.
   - Los documentos locales recomiendan un controlador shadow de continuacion antes de tocar comportamiento productivo.

## Evidencia de codigo

- `matpower/lib/runcpf.m`: interfaz legacy CPF, resultados `cpf`, eventos y callbacks.
- `matpower/lib/run_cpf.m`: wrapper flexible MP-Core.
- `matpower/lib/+mp/task_cpf.m`: tarea CPF, base/target, warm start y seleccion de formulacion AC.
- `matpower/lib/+mp/math_model_cpf.m`: variable `lambda`, interpolacion base-target y ecuaciones CPF.
- `matpower/lib/cpf_tangent.m`: predictor tangente.
- `matpower/lib/cpf_corrector.m`: corrector Newton aumentado.
- `matpower/lib/cpf_nose_event.m` y `cpf_nose_event_cb.m`: deteccion y cierre por nose point.
- `matpower/lib/mpoption.m`: defaults y opciones CPF.
- `matpower/lib/t/t_cpf.m`: pruebas legacy CPF.
- `matpower/lib/t/t_run_mp_3p.m`: pruebas `run_cpf` en formulaciones polar/cartesiana y power/current balance para extension trifasica.
- `matpower/mp-opt-model/lib/pnes_master.m`: infraestructura PNE usada por MP-Core para `NOSE` y `TARGET_LAM`.

## Evidencia de documentacion

- `matpower/docs/src/MATPOWER-manual/MATPOWER-manual.tex`, seccion "Continuation Power Flow".
- `matpower/docs/sphinx/source/ref-manual/functions/run_cpf.rst`.
- `matpower/docs/sphinx/source/ref-manual/legacy/index.rst`, "Continuation Power Flow Functions".
- `matpower/examples/cpf_example.m`.

## Verificacion ejecutada

En MATLAB, con paths locales del checkout:

- `t_cpf(1)` -> `ok (97 of 415 skipped)`.
- `run_cpf({'case9', 'case9target'}, mpopt)` con `cpf.stop_at='NOSE'` y `cpf.adapt_step=1` -> `success=1`, `max_lam=1.09667`.

## Limitaciones y huecos

1. CPF nativo es AC; `mp.task_cpf.math_model_class_default` rechaza `model='DC'`.
2. La estabilidad de tension cubierta es estacionaria/estatica: curva P-V, nose point, limites de carga. No reemplaza estudios dinamicos o transitorios.
3. La documentacion explicita callbacks de usuario, pero dice que no hay mecanismo correspondiente para eventos definidos por usuario.
4. La trayectoria CPF esta acotada a una transferencia base-target; el codigo exige compatibilidad entre casos base y target, y MP-Core exige linealidad/compatibilidad de los parametros que varian con `lambda`.
5. `VLIM` y `FLIM` terminan la continuacion; no implementan acciones correctivas. `QLIM`/`PLIM` son eventos discretos simplificados.
6. Los controles PSS/E locales viven en `runpf_psse`, no en `runcpf`/`run_cpf`; por lo tanto, no hay actualmente una CPF PSS/E-integrada que trace una trayectoria con GENQ/TWODC/FACTS/PQBRAK coordinados.
7. Para el caso integrado 40-bus, la evidencia local apunta a un problema de trayectoria/estado acoplado, no a un simple ajuste de tolerancia, orden de controles o opcion `DVLIM/NDVFCT`.

## Conclusion operativa

Para estudios de estabilidad de tension con MATPOWER puro, la herramienta correcta es `runcpf` o `run_cpf`: definir caso base, caso target, elegir `cpf.stop_at`, parametrizacion, paso/adaptacion y limites opcionales; luego leer `results.cpf.max_lam`, curvas `V-lambda` y eventos.

Para el frente PSS/E del proyecto, la herramienta disponible hoy es `runpf_psse`, no CPF. Si se necesita estabilidad de tension con controles PSS/E fieles, el siguiente desarrollo deberia ser una CPF/control-continuation especifica que integre GENQ, TWODC, FACTS, switched shunts, PQBRAK y evidencia PSS/E, validada primero como shadow contra los casos 14/30/40 e informes existentes.
