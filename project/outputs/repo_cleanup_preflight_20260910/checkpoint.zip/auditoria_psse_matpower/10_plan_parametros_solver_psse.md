# Plan maestro de compatibilidad SYSTEM-WIDE PSS/E en runpf_psse

## Objetivo

Incorporar los parametros `SYSTEM-WIDE` de PSS/E en `runpf_psse` con una
arquitectura explicita, auditable y validada contra PSS/E. El objetivo no es
hacer que MATPOWER "converja parecido" por ajuste manual, sino reproducir o
reportar claramente la semantica PSS/E de cada parametro:

- que parametro se leyo del RAW;
- que efecto tendria en PSS/E;
- donde se aplica en MATPOWER;
- si esta aplicado, parcialmente aplicado, diferido o no soportado;
- con que evidencia local se valido.

El RAW grande debe usarse como prueba de estres al final de cada fase, no como
primer mecanismo de calibracion.

## Principios de implementacion

1. No modificar ecuaciones internas de MATPOWER hasta cerrar la capa de
   opciones, reporte y controles externos.
2. No asumir equivalencia directa entre nombres PSS/E y opciones MATPOWER sin
   evidencia reproducible.
3. Mantener `runpf` normal intacto. La compatibilidad PSS/E debe vivir bajo
   `runpf_psse`, `mp.psse_solver_options` y helpers `mp.psse_*`.
4. Implementar parametros que cambian trayectoria uno por uno, con casos RAW
   pequenos, logs PSS/E y solved RAW.
5. Cada parametro debe terminar clasificado como `applied`, `ignored`,
   `unsupported`, `fallback` o una categoria de cierre equivalente.
6. Ningun cambio debe depender del RAW grande como unico argumento.

## Fuentes primarias

- `PSSE/DataFormats.pdf`, seccion `System-Wide Data`.
- `PSSE/PAGV1.pdf`, actividades `FNSL`, `FDNS`, `NSOL` y ajustes automaticos.
- Logs PSS/E locales exportados desde casos chicos y desde el RAW grande.
- Solved RAW exportados desde PSS/E.
- Implementacion MATPOWER actual: `runpf_psse`, `task_pf_psse`,
  `mp.psse_solver_options` y helpers `mp.psse_*`.
- Experimentos locales reproducibles documentados junto a cada caso.

## Parametros del RAW grande de referencia

```text
NEWTON, ITMXN=40, ACCN=0.5, TOLN=1.0, VCTOLQ=0.1, VCTOLV=0.00001, DVLIM=0.99, NDVFCT=0.99
ADJUST, ADJTHR=0.005, ACCTAP=1.0, TAPLIM=0.05, SWVBND=100.0, MXTPSS=99, MXSWIM=10
SOLVER, FNSL, ACTAPS=0, AREAIN=0, PHSHFT=0, DCTAPS=1, SWSHNT=2, FLATST=0, VARLIM=0, NONDIV=0
```

## Estado actual al 2026-05-26

La primera capa ya existe en `mp.psse_solver_options(mpopt, mpc)` y se conecta
desde `runpf_psse` antes de preparar la tarea MP-Core. El reporte se guarda en:

```matlab
results.psse.solver_options
```

Campos actuales:

```matlab
policy.raw.solver
policy.raw.newton
policy.raw.adjust
policy.applied
policy.ignored
policy.unsupported
policy.fallback
policy.warnings
```

Mapeos ya implementados:

- `METHOD=FNSL` -> `mpopt.pf.alg = 'NR'`, balance de potencia polar.
- `ITMXN` -> `mpopt.pf.nr.max_it`.
- `FLATST=0` -> conserva `VM/VA` del RAW.
- `FLATST=1` -> pone `VA=0` y `VM=1.0` en buses PQ, conservando magnitudes de
  buses con control de tension.

Parametros ya consumidos por helpers PSS/E existentes:

- `ACTAPS` en control de taps AC.
- `DCTAPS` en control two-terminal DC.
- `SWSHNT` en switched shunts.
- `VARLIM` en politica de Q/voltaje.
- `MXTPSS` en varios ciclos externos de control.
- `VCTOLV` en controles de tension.
- `VCTOLQ` en GENQ.

Parametros preservados pero no aplicados a la trayectoria:

- `TOLN`
- `ACCN`
- `ADJTHR`
- `ACCTAP`
- `TAPLIM`
- `SWVBND`

Parametros o modos no soportados todavia:

- `DVLIM`
- `NDVFCT`
- `MXSWIM`
- `PHSHFT != 0`
- `AREAIN != 0`
- `NONDIV != 0`

## Matriz formal de parametros

### SOLVER

| Parametro | Semantica PSS/E | Estado MATPOWER/runpf_psse | Proximo paso |
|---|---|---|---|
| `METHOD=FNSL` | Selecciona full Newton power flow. | Aplicado: fuerza Newton NR polar de balance de potencia. | Mantener y validar contra casos chicos. |
| `ACTAPS` | Habilita ajuste automatico de taps AC. | Aplicado como compuerta de `psse_xfmr_states`. | Centralizar lectura en una policy comun y validar orden de control. |
| `AREAIN` | Ajuste automatico de intercambio por areas. | `0` aplicado/inactivo; `!=0` unsupported. | Crear caso chico de reporte; no implementar hasta tener semantica local. |
| `PHSHFT` | Ajuste automatico de phase shifters. | `0` aplicado/inactivo; `!=0` unsupported. Los shifts fijos `ANG1/ANG2/ANG3` ya se preservan en `branch(:, SHIFT)`. | Crear casos chicos antes de disenar control automatico. |
| `DCTAPS` | Habilita ajuste automatico de taps DC. | Aplicado como compuerta de `psse_twodc_states`. | Centralizar lectura y validar con casos two-terminal DC. |
| `SWSHNT` | Control global de switched shunts. | Aplicado como compuerta de `psse_swshunt_states`. | Centralizar lectura y cerrar semantica `0/1/2` con casos PSS/E. |
| `FLATST` | Selecciona flat start o estado inicial del RAW. | Aplicado. | Mantener tests; comparar trayectoria con solved RAW. |
| `VARLIM` | Politica de limites reactivos y control Q/voltaje. | Aplicado parcialmente en GENQ; no es traduccion directa de `pf.enforce_q_lims`. | Centralizar y definir matriz `VARLIM=0/1` contra PSS/E. |
| `NONDIV` | Activa Newton no-divergente. | `0` aplicado/inactivo; `!=0` unsupported. | Implementar solo en fase Newton PSS/E junto con `DVLIM/NDVFCT`. |
| `FACTS` | Compuerta de control FACTS/STATCON cuando aparece. | Aplicado como compuerta donde existe helper FACTS. | Mantener dentro de la policy comun. |

### NEWTON

| Parametro | Semantica PSS/E | Estado MATPOWER/runpf_psse | Proximo paso |
|---|---|---|---|
| `ITMXN` | Maximo de iteraciones Newton. | Aplicado a `mpopt.pf.nr.max_it`. | Mantener. |
| `TOLN` | Tolerancia de convergencia Newton PSS/E. | Fallback/diferido; MATPOWER sigue usando `mpopt.pf.tol`. | Validar unidades/escala antes de mapear. |
| `ACCN` | Factor de aceleracion/relajacion asociado a controles de tension/setpoints. | Ignorado/diferido; no se aplica como damping Newton global. | Validar con controles de tension, no con Newton puro. |
| `VCTOLQ` | Tolerancia reactiva para control Q/voltaje. | Aplicado en GENQ. | Centralizar. |
| `VCTOLV` | Tolerancia de tension para controles PSS/E. | Aplicado por varios helpers. | Centralizar. |
| `DVLIM` | Limite de cambio de tension por iteracion Newton. | Unsupported. | Fase Newton PSS/E; posible limitador de paso. |
| `NDVFCT` | Factor del modo Newton no-divergente. | Unsupported. | Solo junto con `NONDIV`. |

### ADJUST

| Parametro | Semantica PSS/E | Estado MATPOWER/runpf_psse | Proximo paso |
|---|---|---|---|
| `MXTPSS` | Maximo de ciclos externos de ajuste. | Aplicado localmente por varios helpers. | Centralizar en la policy comun. |
| `ADJTHR` | Umbral minimo para activar ajustes. | Ignorado/diferido. | Implementar con caso chico aislado. |
| `ACCTAP` | Factor de aceleracion/amortiguacion de movimiento de taps AC. | Ignorado/diferido. | Implementar despues de `TAPLIM` o junto a caso de taps validado. |
| `TAPLIM` | Limite de movimiento de tap por ciclo. | Ignorado/diferido. | Implementar con caso chico de tap continuo. |
| `SWVBND` | Banda/criterio para seleccion de switched shunts. | Ignorado/diferido. | Implementar con casos de shunt que aisen banda y modo. |
| `MXSWIM` | Limite asociado a switching de maquinas de induccion. | Unsupported. | Mantener como no soportado hasta tener modelo de induccion. |

## Arquitectura objetivo

La funcion `mp.psse_solver_options` debe evolucionar desde reporte hacia una
policy completa consumida por todos los helpers PSS/E:

```matlab
[mpopt, policy, mpc] = mp.psse_solver_options(mpopt, mpc);
```

Estructura objetivo:

```matlab
policy.raw
policy.solver
policy.newton
policy.controls
policy.adjust
policy.applied
policy.ignored
policy.unsupported
policy.fallback
policy.warnings
```

Los helpers no deberian reinterpretar cada uno por separado los registros
`mpc.psse.system`. Deberian consumir valores normalizados desde la policy o
desde un mecanismo equivalente centralizado.

## Fase 0: evidencia y casos de validacion

Antes de implementar parametros que cambien resultados:

1. Mantener un RAW chico por parametro o por familia de parametros.
2. Exportar log PSS/E y solved RAW.
3. Registrar valores `SYSTEM-WIDE` preservados antes/despues.
4. Comparar como minimo:
   - convergencia;
   - iteraciones;
   - mismatch final si esta disponible;
   - `VM/VA`;
   - controles finales;
   - taps;
   - shunts;
   - `QG`;
   - estados PV/PQ/REF.

## Fase 1: reporte y plumbing

Estado: implementada.

Alcance:

1. Crear `mp.psse_solver_options`.
2. Leer `mpc.psse.system.solver`, `newton` y `adjust`.
3. Clasificar todos los parametros.
4. Guardar `results.psse.solver_options`.
5. Mantener resultados numericos sin cambios.

Criterio de cierre:

- Todos los parametros leidos quedan categorizados.
- `t_mpxt_psse(0)` y `t_psse(0)` pasan.

## Fase 2: mapeos seguros del solver

Estado: implementada para `FNSL`, `ITMXN` y `FLATST`.

Alcance:

1. `FNSL -> pf.alg = 'NR'`.
2. `ITMXN -> pf.nr.max_it`.
3. `FLATST=0/1`.
4. Mantener `TOLN` como fallback hasta validar escala.

Criterio de cierre:

- Tests unitarios prueban cada mapeo.
- Casos chicos siguen convergiendo.
- El RAW grande se usa solo como estres final.

## Fase 3: centralizacion sin cambio numerico

Esta es la siguiente fase recomendada.

Objetivo:

Centralizar los parametros ya usados por helpers para que la semantica PSS/E
este definida en un solo lugar, sin cambiar todavia los resultados numericos.

Parametros:

- `MXTPSS`
- `VCTOLV`
- `VCTOLQ`
- `ACTAPS`
- `DCTAPS`
- `SWSHNT`
- `VARLIM`
- `FACTS` si aparece en el RAW

Tareas:

1. Expandir `policy.controls` y `policy.adjust`.
2. Hacer que los helpers `mp.psse_*_states` consuman la policy o un accessor
   comun.
3. Mantener fallback a `mpc.psse.system` donde haga falta para compatibilidad.
4. Agregar reporte por control: valor que habilita, deshabilita o limita.
5. Confirmar que los resultados numericos son iguales a la linea base previa.

Criterio de cierre:

- Sin cambios numericos no explicados.
- `t_mpxt_psse(0)` y `t_psse(0)` pasan.
- El reporte muestra que cada control uso valores normalizados.

## Fase 4: tolerancia Newton PSS/E

Parametro principal:

- `TOLN`

Riesgo:

Medio-alto. No debe asumirse que `TOLN` equivale directamente a
`mpopt.pf.tol`.

Tareas:

1. Crear casos chicos con varios valores de `TOLN`.
2. Ejecutar PSS/E y guardar logs/solved RAW.
3. Comparar iteraciones y mismatch final contra MATPOWER.
4. Definir una funcion documentada de conversion, por ejemplo
   `mp.psse_toln_to_mptol`, solo si la evidencia lo justifica.
5. Si la evidencia no es suficiente, dejar `TOLN` como fallback reportado.

Criterio de cierre:

- La conversion reproduce la decision de convergencia de PSS/E en casos chicos.
- La diferencia de `VM/VA` no empeora frente a la linea base.

## Fase 5: parametros ADJUST que cambian trayectoria

Implementar uno por uno:

1. `ADJTHR`
2. `TAPLIM`
3. `ACCTAP`
4. `SWVBND`

Regla:

Cada parametro debe tener caso chico PSS/E propio antes de tocar el RAW grande.

Hipotesis iniciales:

- `ADJTHR`: umbral minimo de violacion antes de mover controles.
- `TAPLIM`: limite de cambio de tap por ciclo externo.
- `ACCTAP`: amortiguacion/aceleracion del movimiento de taps AC.
- `SWVBND`: criterio de banda para decidir accion de switched shunts.

Criterio de cierre por parametro:

- Caso chico reproduce estado final PSS/E dentro de tolerancia.
- El reporte indica el valor usado y el motivo de cada movimiento o no
  movimiento.
- La regresion de casos existentes no cambia sin explicacion.

## Fase 6: Newton PSS/E aislado

Parametros:

- `DVLIM`
- `NONDIV`
- `NDVFCT`

Riesgo:

Alto. Estos parametros pueden requerir alterar la trayectoria interna del
Newton. No deben implementarse como hacks dentro de controles externos.

Diseno recomendado:

1. Crear una variante PSS/E explicita, por ejemplo `psse_newtonpf`, o una capa
   de paso Newton usada solo por `runpf_psse`.
2. Implementar primero reporte detallado de incrementos de tension por
   iteracion.
3. Implementar `DVLIM` como limitador de paso solo si los casos PSS/E lo
   confirman.
4. Implementar `NONDIV` y `NDVFCT` juntos, no por separado.
5. Mantener `runpf` normal sin cambios de comportamiento.

Criterio de cierre:

- Casos divergentes o mal condicionados muestran trayectoria comparable a
  PSS/E.
- Los casos normales no cambian salvo por decisiones documentadas.

## Fase 7: controles avanzados no soportados

### PHSHFT

Estado actual:

- `PHSHFT=0`: aplicado/inactivo.
- `PHSHFT!=0`: unsupported.
- Phase shift fijo `ANG1/ANG2/ANG3 -> branch(:, SHIFT)` ya esta implementado.

Plan:

1. Crear caso chico con phase shifter fijo.
2. Crear caso chico con control automatico activo.
3. Validar `COD`, limites y variable controlada.
4. Implementar solo despues de cerrar taps AC basicos.

### AREAIN

Estado actual:

- `AREAIN=0`: aplicado/inactivo.
- `AREAIN!=0`: unsupported.

Plan:

1. Crear caso chico de area interchange.
2. Identificar que generadores se ajustan en PSS/E.
3. Implementar solo con reporte claro de redispatch.

### MXSWIM

Estado actual:

- Unsupported.

Plan:

Mantener unsupported mientras no exista modelo de maquinas de induccion en
`runpf_psse`.

## Validacion obligatoria por cambio

Para cambios de codigo:

```matlab
t_mpxt_psse(0)
t_psse(0)
```

En shell:

```powershell
git -C matpower diff --check
git -C matpower status --short --branch
```

Para cambios documentales solamente:

```powershell
git -C matpower diff --check
git -C matpower status --short --branch
```

Para cambios que afecten trayectoria del RAW grande:

```matlab
run_psse_control_order_experiments()
run_psse_large_control_ablation('quick')
```

Comparar como minimo:

- `success`;
- iteraciones;
- max/RMS `VM` y `VA` contra PSS/E;
- `QG`;
- FACTS Q;
- switched shunts finales;
- taps finales;
- TWO-DC `P/Q/Idc/taps/alpha/gamma`;
- buses fuera de `0.95-1.10`;
- mismatch PSS/E si esta disponible.

## Criterios de aceptacion por parametro

Cada parametro debe cerrar con uno de estos estados:

| Estado | Significado |
|---|---|
| `matched` | Reproduce trayectoria o estado final PSS/E dentro de tolerancia. |
| `equivalent` | No reproduce trayectoria exacta, pero si decision y estado final relevante. |
| `reported_only` | Se lee y reporta, pero no afecta resultados por decision documentada. |
| `unsupported` | No existe modelo MATPOWER/runpf_psse equivalente todavia. |
| `blocked` | Falta evidencia PSS/E suficiente para implementarlo. |

## Orden recomendado inmediato

1. Cerrar Fase 3: centralizacion de parametros ya usados, sin cambio numerico.
2. Preparar matriz experimental de `TOLN`.
3. Implementar `TOLN` solo si la escala queda validada.
4. Implementar `ADJTHR`, `TAPLIM`, `ACCTAP`, `SWVBND` uno por uno.
5. Recien despues abrir `DVLIM`, `NONDIV` y `NDVFCT`.
6. Usar el RAW grande como estres al final de cada fase, no como calibrador
   inicial.

## Criterio de cierre del plan maestro

El plan se considera completo cuando `runpf_psse` pueda explicar, para cada
parametro `SYSTEM-WIDE` relevante:

- valor RAW leido;
- semantica PSS/E esperada;
- punto de aplicacion MATPOWER;
- estado de soporte;
- evidencia local;
- efecto numerico observado;
- motivo si se conserva como fallback o unsupported.

Hasta entonces, cualquier diferencia contra PSS/E debe tratarse como una mezcla
de dos causas: modelos electricos incompletos y configuracion de solucion no
replicada.
