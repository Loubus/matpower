function summary = run_psse_control_order_experiments()
%RUN_PSSE_CONTROL_ORDER_EXPERIMENTS Compare PSS/E control orders.
%   Runs the integrated 14-bus and 30-bus PSS/E RAW fixtures through
%   runpf() and runpf_psse() for a fixed set of PSS/E control orders.
%   Writes Markdown, CSV, and MAT results under
%   auditoria_psse_matpower/results/control_order_experiments/.

audit_dir = fileparts(mfilename('fullpath'));
root_dir = fileparts(audit_dir);
mp_dir = fullfile(root_dir, 'matpower');
results_dir = fullfile(audit_dir, 'results', 'control_order_experiments');
if ~exist(results_dir, 'dir')
    mkdir(results_dir);
end
addpath(fullfile(mp_dir, 'lib'));

cases = default_cases(root_dir);
orders = default_orders();
mpopt = mpoption('verbose', 0, 'out.all', 0);

summary = struct();
summary.generated_at = datestr(now, 'yyyy-mm-dd HH:MM:SS');
summary.root_dir = root_dir;
summary.matpower_dir = mp_dir;
summary.orders = orders;
summary.doc_sources = { ...
    fullfile(root_dir, 'PSSE', 'DataFormats.pdf'), ...
    fullfile(root_dir, 'PSSE', 'PAGV1.pdf'), ...
    fullfile(audit_dir, 'psse_validation_cases_best_raw', 'logs'), ...
    fullfile(audit_dir, 'psse_validation_cases_best_raw', 'solved_raw'), ...
    fullfile(mp_dir, 'lib', '+mp', 'task_pf_psse.m')};
summary.cases = repmat(empty_case_result(), 1, numel(cases));

for k = 1:numel(cases)
    fprintf('Control-order case %d/%d: %s\n', k, numel(cases), cases(k).name);
    summary.cases(k) = run_one_case(cases(k), orders, mpopt);
end

stamp = datestr(now, 'yyyymmdd_HHMMSS');
md_path = fullfile(results_dir, ['control_order_summary_' stamp '.md']);
csv_path = fullfile(results_dir, ['control_order_summary_' stamp '.csv']);
mat_path = fullfile(results_dir, ['control_order_summary_' stamp '.mat']);
latest_md = fullfile(results_dir, 'control_order_summary_latest.md');
latest_csv = fullfile(results_dir, 'control_order_summary_latest.csv');

write_report(summary, md_path);
write_csv_summary(summary, csv_path);
copyfile(md_path, latest_md);
copyfile(csv_path, latest_csv);
save(mat_path, 'summary');

summary.report_path = md_path;
summary.csv_path = csv_path;
summary.mat_path = mat_path;
summary.latest_report_path = latest_md;
summary.latest_csv_path = latest_csv;

fprintf('Wrote report: %s\n', md_path);
fprintf('Wrote CSV: %s\n', csv_path);
fprintf('Wrote MAT data: %s\n', mat_path);

function cases = default_cases(root_dir)
best_dir = fullfile(root_dir, 'auditoria_psse_matpower', ...
    'psse_validation_cases_best_raw');
cases = struct('name', {}, 'raw', {}, 'psse_log', {}, ...
    'psse_solved_raw', {}, 'role', {});
cases(end+1) = struct( ...
    'name', 'psse_integrated_controls_14bus', ...
    'raw', fullfile(best_dir, 'psse_integrated_controls_14bus.raw'), ...
    'psse_log', fullfile(best_dir, 'logs', ...
        'psse_integrated_controls_14bus.log'), ...
    'psse_solved_raw', fullfile(best_dir, 'solved_raw', ...
        'psse_integrated_controls_14bus_solved.raw'), ...
    'role', 'compact integrated smoke fixture');
cases(end+1) = struct( ...
    'name', 'psse_integrated_controls_30bus_moderate', ...
    'raw', fullfile(best_dir, 'psse_integrated_controls_30bus_moderate.raw'), ...
    'psse_log', fullfile(best_dir, 'logs', ...
        'psse_integrated_controls_30bus_moderate.log'), ...
    'psse_solved_raw', fullfile(best_dir, 'solved_raw', ...
        'psse_integrated_controls_30bus_moderate_solved.raw'), ...
    'role', 'main moderate integrated fixture');

function orders = default_orders()
orders = struct('name', {}, 'description', {}, 'controls', {});
orders(end+1) = order_row('default_current', ...
    'production default, no explicit mpopt override', {});
orders(end+1) = order_row('current_explicit', ...
    'pqbrak -> xfmr -> genq -> twodc -> swshunt -> facts', ...
    {'pqbrak', 'xfmr', 'genq', 'twodc', 'swshunt', 'facts'});
orders(end+1) = order_row('genq_last', ...
    'pqbrak -> xfmr -> twodc -> swshunt -> facts -> genq', ...
    {'pqbrak', 'xfmr', 'twodc', 'swshunt', 'facts', 'genq'});
orders(end+1) = order_row('swshunt_before_genq', ...
    'pqbrak -> xfmr -> swshunt -> genq -> twodc -> facts', ...
    {'pqbrak', 'xfmr', 'swshunt', 'genq', 'twodc', 'facts'});
orders(end+1) = order_row('facts_before_dc', ...
    'pqbrak -> xfmr -> facts -> twodc -> swshunt -> genq', ...
    {'pqbrak', 'xfmr', 'facts', 'twodc', 'swshunt', 'genq'});
orders(end+1) = order_row('shunt_facts_dc_genq', ...
    'pqbrak -> xfmr -> swshunt -> facts -> twodc -> genq', ...
    {'pqbrak', 'xfmr', 'swshunt', 'facts', 'twodc', 'genq'});

function row = order_row(name, description, controls)
row = struct('name', name, 'description', description, 'controls', {controls});

function out = empty_case_result()
out = struct( ...
    'name', '', 'role', '', 'raw', '', 'psse_log', '', ...
    'psse_reference_raw', '', 'reference_source', '', ...
    'parse_ok', false, 'parse_error', '', 'warnings', {{}}, ...
    'warning_count', 0, 'counts', struct(), 'reference', struct(), ...
    'runpf', struct(), 'orders', struct());

function result = run_one_case(tc, orders, mpopt)
result = empty_case_result();
result.name = tc.name;
result.role = tc.role;
result.raw = tc.raw;
result.psse_log = tc.psse_log;
result.psse_reference_raw = tc.psse_solved_raw;
result.reference_source = 'PSS/E solved RAW export plus log';
result.reference = parse_psse_reference(tc.psse_solved_raw, tc.psse_log);

try
    [~, mpc, warns] = capture_psse2mpc(tc.raw);
    result.parse_ok = true;
    result.warnings = warns(:)';
    result.warning_count = numel(warns);
    result.counts = count_case_elements(mpc);
catch err
    result.parse_ok = false;
    result.parse_error = getReport(err, 'basic', 'hyperlinks', 'off');
    return;
end

[result.runpf, r0] = run_solver('runpf', mpc, mpopt, {});
result.runpf.comparison = compare_result(result.reference, r0);
result.orders = repmat(empty_order_result(), 1, numel(orders));
for k = 1:numel(orders)
    fprintf('  order %d/%d: %s\n', k, numel(orders), orders(k).name);
    [info, r] = run_solver('runpf_psse', mpc, mpopt, orders(k).controls);
    info.name = orders(k).name;
    info.description = orders(k).description;
    info.controls = orders(k).controls;
    info.comparison = compare_result(result.reference, r);
    result.orders(k) = info;
end

function [txt, mpc, warns] = capture_psse2mpc(raw)
mpc = [];
warns = {};
txt = evalc('[mpc, warns] = psse2mpc(raw, 0, 34);');
if isempty(warns)
    warns = {};
end

function [info, r] = run_solver(kind, mpc, mpopt, controls)
info = empty_order_result();
r = [];
success = 0;
try
    switch kind
        case 'runpf'
            txt = evalc('[r, success] = runpf(mpc, mpopt);');
        case 'runpf_psse'
            mpopt2 = mpopt;
            if ~isempty(controls)
                mpopt2.exp.psse_control_order = controls;
            end
            txt = evalc('[r, success] = runpf_psse(mpc, mpopt2);');
        otherwise
            error('unknown solver kind');
    end
    info.ok = true;
    info.success = logical(success);
    info.output_tail = tail_text(txt, 8);
    info = summarize_result(info, r);
catch err
    info.ok = false;
    info.success = false;
    info.error = getReport(err, 'basic', 'hyperlinks', 'off');
end

function info = empty_order_result()
info = struct( ...
    'name', '', 'description', '', 'controls', {{}}, ...
    'ok', false, 'success', false, 'error', '', 'iterations', NaN, ...
    'data_model_iterations', NaN, 'network_model_iterations', NaN, ...
    'math_model_iterations', NaN, 'vm_min', NaN, 'vm_min_bus', NaN, ...
    'vm_max', NaN, 'vm_max_bus', NaN, 'outside_095_110_count', NaN, ...
    'outside_095_110', {{}}, 'control_iterations', struct(), ...
    'comparison', struct(), 'output_tail', {{}});

function info = summarize_result(info, r)
[~, ~, ~, ~, ~, ~, ~, ~, ~, ~, ~, VM, VA, BASE_KV] = idx_bus;
if isempty(r)
    return;
end
if isfield(r, 'iterations')
    info.iterations = r.iterations;
end
if isfield(r, 'task') && isobject(r.task)
    if isprop(r.task, 'i_dm'), info.data_model_iterations = r.task.i_dm; end
    if isprop(r.task, 'i_nm'), info.network_model_iterations = r.task.i_nm; end
    if isprop(r.task, 'i_mm'), info.math_model_iterations = r.task.i_mm; end
end
if isfield(r, 'bus') && ~isempty(r.bus)
    [mn, i_mn] = min(r.bus(:, VM));
    [mx, i_mx] = max(r.bus(:, VM));
    info.vm_min = mn;
    info.vm_min_bus = r.bus(i_mn, 1);
    info.vm_max = mx;
    info.vm_max_bus = r.bus(i_mx, 1);
    outside = find(r.bus(:, VM) < 0.95 | r.bus(:, VM) > 1.10);
    info.outside_095_110_count = numel(outside);
    rows = cell(numel(outside), 1);
    for k = 1:numel(outside)
        ii = outside(k);
        rows{k} = sprintf('bus %.0f: VM %.5f pu, VA %.3f deg, BASKV %.3f', ...
            r.bus(ii, 1), r.bus(ii, VM), r.bus(ii, VA), r.bus(ii, BASE_KV));
    end
    info.outside_095_110 = rows;
end
info.control_iterations = summarize_controls(r);

function c = summarize_controls(r)
c = struct();
c.pqbrak = control_iter(r, 'pqbrak');
c.xfmr = control_iter(r, 'xfmr');
c.genq = control_iter(r, 'genq');
c.twodc = control_iter(r, 'twodc');
c.swshunt = control_iter(r, 'swshunt');
c.facts = control_iter(r, 'facts');

function s = control_iter(r, family)
s = struct('present', false, 'iterations', NaN, 'num_adjustments', NaN, ...
    'changed_last', NaN, 'max_iter_reached', NaN);
if isempty(r) || ~isfield(r, 'psse') || ~isfield(r.psse, family)
    return;
end
fam = r.psse.(family);
if isfield(fam, 'control')
    ctrl = fam.control;
else
    ctrl = fam;
end
s.present = true;
if isfield(ctrl, 'iterations'), s.iterations = ctrl.iterations; end
if isfield(ctrl, 'num_adjustments'), s.num_adjustments = ctrl.num_adjustments; end
if isfield(ctrl, 'changed_last'), s.changed_last = ctrl.changed_last; end
if isfield(ctrl, 'max_iter_reached'), s.max_iter_reached = ctrl.max_iter_reached; end

function counts = count_case_elements(mpc)
counts = struct();
counts.buses = size_or_zero(mpc, 'bus');
counts.gens = size_or_zero(mpc, 'gen');
counts.matpower_branches = size_or_zero(mpc, 'branch');
counts.dcline = size_or_zero(mpc, 'dcline');
counts.xfmr = psse_count(mpc, 'xfmr');
counts.swshunt = psse_count(mpc, 'swshunt');
counts.facts = psse_count(mpc, 'facts');
counts.twodc = psse_count(mpc, 'twodc');
counts.swdev = psse_count(mpc, 'swdev');

function n = size_or_zero(s, field)
if isfield(s, field) && ~isempty(s.(field))
    n = size(s.(field), 1);
else
    n = 0;
end

function n = psse_count(mpc, field)
n = 0;
if ~isfield(mpc, 'psse') || ~isfield(mpc.psse, field)
    return;
end
x = mpc.psse.(field);
if isfield(x, 'num')
    n = size(x.num, 1);
elseif strcmp(field, 'xfmr')
    if isfield(x, 'two') && isfield(x.two, 'num'), n = n + size(x.two.num, 1); end
    if isfield(x, 'three') && isfield(x.three, 'num'), n = n + size(x.three.num, 1); end
end

function ref = parse_psse_reference(raw_path, log_path)
ref = struct();
ref.raw_path = raw_path;
ref.log_path = log_path;
ref.bus = [];
ref.gen = [];
ref.swshunt = [];
ref.facts = [];
ref.twodc = [];
ref.xfmr = [];
ref.log = struct();
if exist(raw_path, 'file') == 2
    lines = read_lines(raw_path);
    ref.bus = parse_bus_section(lines);
    ref.gen = parse_generator_section(lines);
    ref.swshunt = parse_swshunt_section(lines);
    ref.facts = parse_facts_section(lines);
    ref.twodc = parse_twodc_section(lines);
    ref.xfmr = parse_xfmr_section(lines);
end
ref.log = parse_psse_log(log_path);

function lines = read_lines(path)
txt = fileread(path);
txt = strrep(txt, sprintf('\r\n'), sprintf('\n'));
txt = strrep(txt, sprintf('\r'), sprintf('\n'));
lines = regexp(txt, sprintf('\n'), 'split')';

function section = section_lines(lines, name)
section = {};
target = ['BEGIN ' upper(name) ' DATA'];
start_idx = 0;
for k = 1:numel(lines)
    if contains(upper(lines{k}), target)
        start_idx = k + 1;
        break;
    end
end
if start_idx == 0
    return;
end
for k = start_idx:numel(lines)
    ln = strtrim(lines{k});
    if startsWith(ln, '0 / END')
        break;
    end
    if isempty(ln) || startsWith(ln, '@!')
        continue;
    end
    section{end+1, 1} = lines{k}; %#ok<AGROW>
end

function rows = parse_bus_section(lines)
sec = section_lines(lines, 'BUS');
rows = struct('bus', {}, 'name', {}, 'basekv', {}, 'type', {}, 'vm', {}, 'va', {});
for k = 1:numel(sec)
    t = csv_tokens(sec{k});
    if numel(t) < 9, continue; end
    rows(end+1) = struct('bus', num_token(t, 1), ... %#ok<AGROW>
        'name', clean_token(t{2}), 'basekv', num_token(t, 3), ...
        'type', num_token(t, 4), 'vm', num_token(t, 8), ...
        'va', num_token(t, 9));
end

function rows = parse_generator_section(lines)
sec = section_lines(lines, 'GENERATOR');
rows = struct('bus', {}, 'id', {}, 'pg', {}, 'qg', {}, 'qmax', {}, ...
    'qmin', {}, 'vs', {}, 'ireg', {}, 'status', {});
for k = 1:numel(sec)
    t = csv_tokens(sec{k});
    if numel(t) < 16, continue; end
    rows(end+1) = struct('bus', num_token(t, 1), ... %#ok<AGROW>
        'id', clean_token(t{2}), 'pg', num_token(t, 3), ...
        'qg', num_token(t, 4), 'qmax', num_token(t, 5), ...
        'qmin', num_token(t, 6), 'vs', num_token(t, 7), ...
        'ireg', num_token(t, 8), 'status', parse_generator_status(t));
end

function st = parse_generator_status(t)
st = NaN;
if numel(t) >= 16
    v16 = num_token(t, 16);
    v15 = num_token(t, 15);
    if ismember(v16, [0 1])
        st = v16;
    elseif ismember(v15, [0 1])
        st = v15;
    end
end

function rows = parse_swshunt_section(lines)
sec = section_lines(lines, 'SWITCHED SHUNT');
rows = struct('bus', {}, 'id', {}, 'modsw', {}, 'adjm', {}, 'stat', {}, ...
    'vswhi', {}, 'vswlo', {}, 'swreg', {}, 'rmpct', {}, 'binit', {}, ...
    'bmin', {}, 'bmax', {});
for k = 1:numel(sec)
    t = csv_tokens(sec{k});
    if numel(t) < 10, continue; end
    has_id = ~isempty(regexp(sec{k}, '^\s*[-+]?\d+\s*,\s*[''"]', 'once'));
    if has_id
        id = clean_token(t{2});
        modsw = num_token(t, 3); adjm = num_token(t, 4); stat = num_token(t, 5);
        vswhi = num_token(t, 6); vswlo = num_token(t, 7);
        swreg = num_token(t, 8); rmpct = num_token(t, 10); binit = num_token(t, 12);
        block_start = 14;
    else
        id = '';
        modsw = num_token(t, 2); adjm = num_token(t, 3); stat = num_token(t, 4);
        vswhi = num_token(t, 5); vswlo = num_token(t, 6);
        swreg = num_token(t, 7); rmpct = num_token(t, 8); binit = num_token(t, 10);
        block_start = 11;
    end
    [bmin, bmax] = swshunt_range(t, block_start);
    rows(end+1) = struct('bus', num_token(t, 1), 'id', id, ... %#ok<AGROW>
        'modsw', modsw, 'adjm', adjm, 'stat', stat, ...
        'vswhi', vswhi, 'vswlo', vswlo, 'swreg', swreg, ...
        'rmpct', rmpct, 'binit', binit, 'bmin', bmin, 'bmax', bmax);
end

function [bmin, bmax] = swshunt_range(t, block_start)
vals = [];
for kk = block_start:3:numel(t)-2
    st = num_token(t, kk);
    n = num_token(t, kk+1);
    b = num_token(t, kk+2);
    if isnan(st) || isnan(n) || isnan(b) || st == 0 || n == 0
        continue;
    end
    vals = [vals; (1:abs(n))' * b]; %#ok<AGROW>
end
if isempty(vals)
    bmin = NaN;
    bmax = NaN;
else
    vals = [0; vals];
    bmin = min(vals);
    bmax = max(vals);
end

function rows = parse_facts_section(lines)
sec = section_lines(lines, 'FACTS DEVICE');
rows = struct('name', {}, 'bus', {}, 'j', {}, 'mode', {}, 'vset', {}, ...
    'shmx', {}, 'rmpct', {}, 'fcreg', {});
for k = 1:numel(sec)
    t = csv_tokens(sec{k});
    if numel(t) < 20, continue; end
    rows(end+1) = struct('name', clean_token(t{1}), ... %#ok<AGROW>
        'bus', num_token(t, 2), 'j', num_token(t, 3), ...
        'mode', num_token(t, 4), 'vset', num_token(t, 7), ...
        'shmx', num_token(t, 8), 'rmpct', num_token(t, 15), ...
        'fcreg', num_token(t, 20));
end

function rows = parse_twodc_section(lines)
sec = section_lines(lines, 'TWO-TERMINAL DC');
rows = struct('name', {}, 'mdc', {}, 'rdc', {}, 'setvl', {}, ...
    'vschd', {}, 'vcmod', {}, 'rcomp', {}, 'meter', {}, ...
    'rect_bus', {}, 'inv_bus', {}, 'tapr', {}, 'tapi', {}, ...
    'anmnr', {}, 'anmxr', {}, 'anmni', {}, 'anmxi', {});
k = 1;
while k <= numel(sec)
    t1 = csv_tokens(sec{k});
    if numel(t1) < 9 || k + 2 > numel(sec)
        k = k + 1;
        continue;
    end
    tr = csv_tokens(sec{k+1});
    ti = csv_tokens(sec{k+2});
    if numel(tr) < 17 || numel(ti) < 17
        k = k + 3;
        continue;
    end
    rows(end+1) = struct('name', clean_token(t1{1}), ... %#ok<AGROW>
        'mdc', num_token(t1, 2), 'rdc', num_token(t1, 3), ...
        'setvl', num_token(t1, 4), 'vschd', num_token(t1, 5), ...
        'vcmod', num_token(t1, 6), 'rcomp', num_token(t1, 7), ...
        'meter', clean_token(t1{9}), 'rect_bus', num_token(tr, 1), ...
        'inv_bus', num_token(ti, 1), 'tapr', num_token(tr, 9), ...
        'tapi', num_token(ti, 9), 'anmnr', num_token(tr, 4), ...
        'anmxr', num_token(tr, 3), 'anmni', num_token(ti, 4), ...
        'anmxi', num_token(ti, 3));
    k = k + 3;
end

function rows = parse_xfmr_section(lines)
sec = section_lines(lines, 'TRANSFORMER');
rows = struct('i', {}, 'j', {}, 'k', {}, 'ckt', {}, 'name', {}, ...
    'stat', {}, 'windv1', {}, 'windv2', {}, 'windv3', {});
idx = 1;
while idx <= numel(sec)
    t0 = csv_tokens(sec{idx});
    if numel(t0) < 14
        idx = idx + 1;
        continue;
    end
    kbus = num_token(t0, 3);
    n_winding_lines = 2 + double(kbus ~= 0);
    if idx + 1 + n_winding_lines > numel(sec)
        break;
    end
    w1 = csv_tokens(sec{idx+2});
    w2 = csv_tokens(sec{idx+3});
    w3 = {};
    if kbus ~= 0
        w3 = csv_tokens(sec{idx+4});
    end
    rows(end+1) = struct('i', num_token(t0, 1), ... %#ok<AGROW>
        'j', num_token(t0, 2), 'k', kbus, ...
        'ckt', clean_token(t0{4}), 'name', clean_token(t0{12}), ...
        'stat', num_token(t0, 13), 'windv1', safe_num_token(w1, 1), ...
        'windv2', safe_num_token(w2, 1), 'windv3', safe_num_token(w3, 1));
    idx = idx + 2 + n_winding_lines;
end

function log = parse_psse_log(log_path)
log = struct('path', log_path, 'converged_iterations', NaN, ...
    'total_mismatch_mva', NaN, 'max_mismatch_mva', NaN, ...
    'max_mismatch_bus', NaN, 'high_voltage', NaN, ...
    'high_voltage_bus', NaN, 'low_voltage', NaN, ...
    'low_voltage_bus', NaN, 'facts_flow', [], 'twodc', []);
if exist(log_path, 'file') ~= 2
    return;
end
lines = read_lines(log_path);
for k = 1:numel(lines)
    ln = lines{k};
    m = regexp(ln, 'Reached tolerance in\s+(\d+)\s+iterations', 'tokens', 'once');
    if ~isempty(m), log.converged_iterations = str2double(m{1}); end
    m = regexp(ln, 'Largest mismatch:\s+([-0-9.]+)\s+MW\s+([-0-9.]+)\s+Mvar\s+([-0-9.]+)\s+MVA at bus\s+(\d+)', 'tokens', 'once');
    if ~isempty(m)
        log.max_mismatch_mva = str2double(m{3});
        log.max_mismatch_bus = str2double(m{4});
    end
    m = regexp(ln, 'TOTAL MISMATCH =\s+([-0-9.]+)\s+MVA', 'tokens', 'once');
    if ~isempty(m), log.total_mismatch_mva = str2double(m{1}); end
    m = regexp(ln, 'MAX\.\s+MISMATCH =\s+([-0-9.]+)\s+MVA\s+(\d+)', 'tokens', 'once');
    if ~isempty(m)
        log.max_mismatch_mva = str2double(m{1});
        log.max_mismatch_bus = str2double(m{2});
    end
    m = regexp(ln, 'HIGH VOLTAGE =\s+([-0-9.]+)\s+PU\s+(\d+)', 'tokens', 'once');
    if ~isempty(m)
        log.high_voltage = str2double(m{1});
        log.high_voltage_bus = str2double(m{2});
    end
    m = regexp(ln, 'LOW\s+VOLTAGE =\s+([-0-9.]+)\s+PU\s+(\d+)', 'tokens', 'once');
    if ~isempty(m)
        log.low_voltage = str2double(m{1});
        log.low_voltage_bus = str2double(m{2});
    end
    m = regexp(ln, 'TO STATCON SHUNT\s+STA\s+([-0-9.]+)\s+([-0-9.]+)\s+([-0-9.]+).*"([^"]+)"', 'tokens', 'once');
    if ~isempty(m)
        log.facts_flow = [log.facts_flow struct( ... %#ok<AGROW>
            'name', strtrim(m{4}), 'p_mw', str2double(m{1}), ...
            'q_mvar_flow_to_shunt', str2double(m{2}), ...
            'mva', str2double(m{3}))];
    end
end
log.twodc = parse_twodc_from_log(lines);

function rows = parse_twodc_from_log(lines)
rows = struct('name', {}, 'mdc', {}, 'setvl', {}, 'vschd', {}, ...
    'vcmod', {}, 'dcamps', {}, 'vcomp', {}, 'meter', {}, ...
    'rect_bus', {}, 'rect_pac', {}, 'rect_qac', {}, 'rect_vdc', {}, ...
    'rect_alpha', {}, 'rect_tap', {}, 'inv_bus', {}, 'inv_pac', {}, ...
    'inv_qac', {}, 'inv_vdc', {}, 'inv_gamma', {}, 'inv_tap', {});
for k = 1:numel(lines)
    if isempty(strfind(lines{k}, 'MDC ORG   RDC'))
        continue;
    end
    data_line = first_nonempty(lines, k+1, min(k+5, numel(lines)));
    if isempty(data_line)
        continue;
    end
    nums = numbers_in_line(data_line(min(13, length(data_line)+1):end));
    if numel(nums) < 10
        continue;
    end
    r_line = '';
    i_line = '';
    for j = k+1:min(k+12, numel(lines))
        s = strtrim(lines{j});
        if startsWith(s, 'R:') && isempty(r_line)
            r_line = s;
        elseif startsWith(s, 'I:') && isempty(i_line)
            i_line = s;
        end
    end
    rn = dc_terminal_numbers(r_line);
    in = dc_terminal_numbers(i_line);
    if numel(rn) < 8 || numel(in) < 8
        continue;
    end
    rows(end+1) = struct('name', strtrim(data_line(1:min(12, length(data_line)))), ... %#ok<AGROW>
        'mdc', nums(1), 'setvl', nums(5), 'vschd', nums(6), ...
        'vcmod', nums(8), 'dcamps', nums(9), 'vcomp', nums(10), ...
        'meter', parse_meter(data_line), 'rect_bus', rn(1), ...
        'rect_pac', rn(6), 'rect_qac', rn(7), 'rect_vdc', rn(8), ...
        'rect_alpha', rn(3), 'rect_tap', extract_tap(r_line), ...
        'inv_bus', in(1), 'inv_pac', in(6), 'inv_qac', in(7), ...
        'inv_vdc', in(8), 'inv_gamma', in(3), 'inv_tap', extract_tap(i_line));
end

function s = first_nonempty(lines, i1, i2)
s = '';
for i = i1:i2
    if ~isempty(strtrim(lines{i}))
        s = lines{i};
        return;
    end
end

function meter = parse_meter(line)
if contains(line, 'RECT')
    meter = 'RECT';
elseif contains(line, 'INV')
    meter = 'INV';
else
    meter = '';
end

function nums = dc_terminal_numbers(line)
m = regexp(line, '^\s*[RI]:\s+(\d+)\s+(.{12})\s+([-0-9.]+)\s+([-0-9.]+)\s+([-0-9.]+)\s+([-0-9.]+)\s+([-0-9.]+)\s+([-0-9.]+)\s+([-0-9.]+)', 'tokens', 'once');
if isempty(m)
    nums = numbers_in_line(line);
    return;
end
nums = [str2double(m{1}), str2double(m{3}), str2double(m{4}), ...
    str2double(m{5}), str2double(m{6}), str2double(m{7}), ...
    str2double(m{8}), str2double(m{9})];

function tap = extract_tap(line)
nums = numbers_in_line(line);
if numel(nums) >= 9
    tap = nums(9);
else
    tap = NaN;
end

function cmp = compare_result(ref, r)
cmp = struct();
cmp.solution = compare_solution(ref, r);
cmp.genq = compare_genq(ref, r);
cmp.facts = compare_facts(ref, r);
cmp.swshunt = compare_swshunt(ref, r);
cmp.xfmr = compare_xfmr(ref, r);
cmp.twodc = compare_twodc(ref, r);

function cmp = compare_solution(ref, r)
cmp = struct('available', false, 'max_abs_vm', NaN, 'rms_vm', NaN, ...
    'max_abs_vm_bus', NaN, 'max_abs_va', NaN, 'rms_va', NaN, ...
    'max_abs_va_bus', NaN, 'top_vm', {{}}, 'top_va', {{}}, ...
    'psse_outside_095_110', {{}});
if isempty(ref.bus) || isempty(r) || ~isfield(r, 'bus')
    return;
end
[~, ~, ~, ~, ~, ~, ~, ~, ~, ~, ~, VM, VA] = idx_bus;
ref_bus = [ref.bus.bus]';
ref_vm = [ref.bus.vm]';
ref_va = [ref.bus.va]';
[tf, loc] = ismember(ref_bus, r.bus(:, 1));
if ~any(tf)
    return;
end
dvm = r.bus(loc(tf), VM) - ref_vm(tf);
dva = angle_diff_deg(r.bus(loc(tf), VA), ref_va(tf));
bus_ok = ref_bus(tf);
[cmp.max_abs_vm, ii] = max(abs(dvm));
[cmp.max_abs_va, jj] = max(abs(dva));
cmp.max_abs_vm_bus = bus_ok(ii);
cmp.max_abs_va_bus = bus_ok(jj);
cmp.rms_vm = sqrt(mean(dvm .^ 2));
cmp.rms_va = sqrt(mean(dva .^ 2));
cmp.top_vm = top_diff_rows(bus_ok, dvm, 'VM');
cmp.top_va = top_diff_rows(bus_ok, dva, 'VA');
outside = find(ref_vm < 0.95 | ref_vm > 1.10);
cmp.psse_outside_095_110 = cell(numel(outside), 1);
for k = 1:numel(outside)
    i = outside(k);
    cmp.psse_outside_095_110{k} = sprintf('bus %.0f %s: VM %.5f pu', ...
        ref.bus(i).bus, ref.bus(i).name, ref.bus(i).vm);
end
cmp.available = true;

function rows = top_diff_rows(bus, diff, label)
[~, ord] = sort(abs(diff), 'descend');
nshow = min(5, numel(ord));
rows = cell(nshow, 1);
for k = 1:nshow
    i = ord(k);
    rows{k} = sprintf('bus %.0f: %s diff %.6g', bus(i), label, diff(i));
end

function rows = compare_genq(ref, r)
rows = struct('available', false, 'max_abs_q_diff', NaN, ...
    'rms_q_diff', NaN, 'max_abs_q_diff_bus', NaN, 'top', {{}});
if isempty(ref.gen) || isempty(r) || ~isfield(r, 'gen')
    return;
end
[GEN_BUS, ~, QG] = idx_gen;
ref_bus = [ref.gen.bus]';
ref_q = [ref.gen.qg]';
mp_q = NaN(size(ref_q));
for k = 1:numel(ref_bus)
    idx = find(r.gen(:, GEN_BUS) == ref_bus(k), 1);
    if ~isempty(idx)
        mp_q(k) = r.gen(idx, QG);
    end
end
ok = ~isnan(mp_q) & ~isnan(ref_q);
if ~any(ok)
    return;
end
dq = mp_q(ok) - ref_q(ok);
bus_ok = ref_bus(ok);
[rows.max_abs_q_diff, ii] = max(abs(dq));
rows.max_abs_q_diff_bus = bus_ok(ii);
rows.rms_q_diff = sqrt(mean(dq .^ 2));
rows.top = top_diff_rows(bus_ok, dq, 'QG');
rows.available = true;

function rows = compare_facts(ref, r)
rows = struct('available', false, 'max_abs_q_diff', NaN, ...
    'rms_q_diff', NaN, 'top', {{}});
if isempty(r) || ~isfield(r, 'psse') || ~isfield(r.psse, 'facts') || ...
        ~isfield(r.psse.facts, 'control') || ~isfield(r.psse.facts.control, 'qinj')
    return;
end
ctrl = r.psse.facts.control;
n = numel(ctrl.qinj);
dq = NaN(n, 1);
items = cell(n, 1);
for k = 1:n
    psse_q = NaN;
    name = sprintf('FACTS_%d', k);
    if isfield(ref.log, 'facts_flow') && numel(ref.log.facts_flow) >= k
        psse_q = -ref.log.facts_flow(k).q_mvar_flow_to_shunt;
        name = ref.log.facts_flow(k).name;
    elseif ~isempty(ref.facts) && numel(ref.facts) >= k
        name = ref.facts(k).name;
    end
    dq(k) = ctrl.qinj(k) - psse_q;
    items{k} = sprintf('%s: MATPOWER qinj %.4f MVAr, PSS/E qinj %.4f MVAr, diff %.4f', ...
        name, ctrl.qinj(k), psse_q, dq(k));
end
ok = ~isnan(dq);
if any(ok)
    rows.max_abs_q_diff = max(abs(dq(ok)));
    rows.rms_q_diff = sqrt(mean(dq(ok) .^ 2));
end
rows.top = items;
rows.available = true;

function rows = compare_swshunt(ref, r)
rows = struct('available', false, 'max_abs_binit_diff', NaN, ...
    'rms_binit_diff', NaN, 'top', {{}});
if isempty(ref.swshunt) || isempty(r) || ~isfield(r, 'psse') || ...
        ~isfield(r.psse, 'swshunt') || ~isfield(r.psse.swshunt, 'control') || ...
        ~isfield(r.psse.swshunt.control, 'final_binit')
    return;
end
ctrl = r.psse.swshunt.control;
n = min(numel(ref.swshunt), numel(ctrl.final_binit));
if n == 0
    return;
end
diff = ctrl.final_binit(1:n) - [ref.swshunt(1:n).binit]';
rows.max_abs_binit_diff = max(abs(diff));
rows.rms_binit_diff = sqrt(mean(diff .^ 2));
rows.top = top_diff_rows([ref.swshunt(1:n).bus]', diff, 'BINIT');
rows.available = true;

function rows = compare_xfmr(ref, r)
rows = struct('available', false, 'max_abs_windv1_diff', NaN, ...
    'rms_windv1_diff', NaN, 'top', {{}});
if isempty(ref.xfmr) || isempty(r) || ~isfield(r, 'psse') || ...
        ~isfield(r.psse, 'xfmr') || ~isfield(r.psse.xfmr, 'control') || ...
        ~isfield(r.psse.xfmr.control, 'final_windv')
    return;
end
ctrl = r.psse.xfmr.control;
n = min(numel(ref.xfmr), numel(ctrl.final_windv));
if n == 0
    return;
end
ref_w = [ref.xfmr(1:n).windv1]';
diff = ctrl.final_windv(1:n) - ref_w;
rows.max_abs_windv1_diff = max(abs(diff));
rows.rms_windv1_diff = sqrt(mean(diff .^ 2));
items = cell(min(5, n), 1);
[~, ord] = sort(abs(diff), 'descend');
for k = 1:numel(items)
    i = ord(k);
    items{k} = sprintf('%g-%g %s: MATPOWER WINDV %.5f, PSS/E %.5f, diff %.5f', ...
        ref.xfmr(i).i, ref.xfmr(i).j, ref.xfmr(i).ckt, ...
        ctrl.final_windv(i), ref_w(i), diff(i));
end
rows.top = items;
rows.available = true;

function rows = compare_twodc(ref, r)
rows = struct('available', false, 'max_abs_pac_diff', NaN, ...
    'max_abs_qac_diff', NaN, 'max_abs_idc_diff', NaN, ...
    'max_abs_tap_diff', NaN, 'max_abs_angle_diff', NaN, 'top', {{}});
if isempty(r) || ~isfield(r, 'psse') || ~isfield(r.psse, 'twodc') || ...
        ~isfield(r.psse.twodc, 'control')
    return;
end
ctrl = r.psse.twodc.control;
if ~isfield(ctrl, 'pf')
    return;
end
n = numel(ctrl.pf);
items = cell(n, 1);
pac_diff = NaN(n, 2);
qac_diff = NaN(n, 2);
idc_diff = NaN(n, 1);
tap_diff = NaN(n, 2);
angle_diff = NaN(n, 2);
for k = 1:n
    if isfield(ref.log, 'twodc') && numel(ref.log.twodc) >= k
        psse = ref.log.twodc(k);
        inv_pac = -ctrl.pt(k);
        pac_diff(k, :) = [ctrl.pf(k) - psse.rect_pac, inv_pac - psse.inv_pac];
        qac_diff(k, :) = [ctrl.qacr_mvar(k) - psse.rect_qac, ...
            ctrl.qaci_mvar(k) - psse.inv_qac];
        idc_diff(k) = ctrl.idc_ka(k) * 1000 - psse.dcamps;
        if ~isempty(ref.twodc) && numel(ref.twodc) >= k
            tap_diff(k, :) = [ctrl.tapr(k) - ref.twodc(k).tapr, ...
                ctrl.tapi(k) - ref.twodc(k).tapi];
        else
            tap_diff(k, :) = [ctrl.tapr(k) - psse.rect_tap, ...
                ctrl.tapi(k) - psse.inv_tap];
        end
        angle_diff(k, :) = [ctrl.alpha_deg(k) - psse.rect_alpha, ...
            ctrl.gamma_deg(k) - psse.inv_gamma];
        items{k} = sprintf(['link %d: dPAC %.4f/%.4f MW, dQAC %.4f/%.4f MVAr, ' ...
            'dIdc %.4f A, dtap %.5f/%.5f, dangle %.3f/%.3f deg'], ...
            k, pac_diff(k, 1), pac_diff(k, 2), qac_diff(k, 1), ...
            qac_diff(k, 2), idc_diff(k), tap_diff(k, 1), ...
            tap_diff(k, 2), angle_diff(k, 1), angle_diff(k, 2));
    else
        items{k} = sprintf('link %d: PSS/E log values unavailable', k);
    end
end
rows.max_abs_pac_diff = nanmax(abs(pac_diff(:)));
rows.max_abs_qac_diff = nanmax(abs(qac_diff(:)));
rows.max_abs_idc_diff = nanmax(abs(idc_diff(:)));
rows.max_abs_tap_diff = nanmax(abs(tap_diff(:)));
rows.max_abs_angle_diff = nanmax(abs(angle_diff(:)));
rows.top = items;
rows.available = true;

function write_report(summary, path)
fid = fopen(path, 'w');
if fid < 0
    error('could not open report for writing: %s', path);
end
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, '# PSS/E Control Order Experiment\n\n');
fprintf(fid, 'Generated: `%s`\n\n', summary.generated_at);
fprintf(fid, 'Workspace: `%s`\n\n', summary.root_dir);
fprintf(fid, 'This report compares `runpf_psse` control orders without changing original RAW/SAV/log fixtures. PSS/E references come from local logs and solved RAW text exports.\n\n');
fprintf(fid, '## Evidence Trace\n\n');
for k = 1:numel(summary.doc_sources)
    fprintf(fid, '- `%s`\n', summary.doc_sources{k});
end
fprintf(fid, '\n');
fprintf(fid, '## Orders Tested\n\n');
for k = 1:numel(summary.orders)
    fprintf(fid, '- `%s`: %s\n', summary.orders(k).name, summary.orders(k).description);
end
fprintf(fid, '\n');
for k = 1:numel(summary.cases)
    write_case_report(fid, summary.cases(k));
end

function write_case_report(fid, c)
fprintf(fid, '## %s\n\n', c.name);
fprintf(fid, '- Role: %s\n', c.role);
fprintf(fid, '- RAW: `%s`\n', c.raw);
fprintf(fid, '- PSS/E log: `%s`\n', c.psse_log);
fprintf(fid, '- PSS/E solved RAW text: `%s`\n', c.psse_reference_raw);
fprintf(fid, '- Parse OK: %s\n', yesno(c.parse_ok));
if ~c.parse_ok
    fprintf(fid, '- Parse error: `%s`\n\n', oneline(c.parse_error));
    return;
end
fprintf(fid, '- Counts: buses %d, gens %d, branches %d, dcline %d, xfmr %d, swshunt %d, facts %d, twodc %d, swdev %d\n', ...
    c.counts.buses, c.counts.gens, c.counts.matpower_branches, ...
    c.counts.dcline, c.counts.xfmr, c.counts.swshunt, c.counts.facts, ...
    c.counts.twodc, c.counts.swdev);
fprintf(fid, '- PSS/E convergence: iterations %.0f, total mismatch %.4f MVA, max mismatch %.4f MVA at bus %.0f\n', ...
    c.reference.log.converged_iterations, c.reference.log.total_mismatch_mva, ...
    c.reference.log.max_mismatch_mva, c.reference.log.max_mismatch_bus);
fprintf(fid, '- PSS/E VM high/low: %.5f at bus %.0f / %.5f at bus %.0f\n\n', ...
    c.reference.log.high_voltage, c.reference.log.high_voltage_bus, ...
    c.reference.log.low_voltage, c.reference.log.low_voltage_bus);

fprintf(fid, '### Order Summary\n\n');
fprintf(fid, '| order | success | iter | dm/nm/mm | max dVM | rms dVM | max dVA | rms dVA | max dQGEN | FACTS dQ | SWSH dB | XFMR dWINDV | DC dP | DC dQ | outside 0.95-1.10 |\n');
fprintf(fid, '|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|\n');
for k = 1:numel(c.orders)
    o = c.orders(k);
    s = o.comparison.solution;
    fprintf(fid, '| `%s` | %d | %.0f | %.0f/%.0f/%.0f | %.6g | %.6g | %.6g | %.6g | %.6g | %.6g | %.6g | %.6g | %.6g | %.6g | %d |\n', ...
        o.name, o.success, o.iterations, o.data_model_iterations, ...
        o.network_model_iterations, o.math_model_iterations, ...
        s.max_abs_vm, s.rms_vm, s.max_abs_va, s.rms_va, ...
        scalar_field(o.comparison.genq, 'max_abs_q_diff'), ...
        scalar_field(o.comparison.facts, 'max_abs_q_diff'), ...
        scalar_field(o.comparison.swshunt, 'max_abs_binit_diff'), ...
        scalar_field(o.comparison.xfmr, 'max_abs_windv1_diff'), ...
        scalar_field(o.comparison.twodc, 'max_abs_pac_diff'), ...
        scalar_field(o.comparison.twodc, 'max_abs_qac_diff'), ...
        o.outside_095_110_count);
end
fprintf(fid, '\n');

for k = 1:numel(c.orders)
    write_order_detail(fid, c.orders(k));
end

function write_order_detail(fid, o)
fprintf(fid, '### %s\n\n', o.name);
fprintf(fid, '- order: %s\n', order_text(o.controls));
fprintf(fid, '- success: %s; iterations: %.0f; task dm/nm/mm: %.0f/%.0f/%.0f\n', ...
    yesno(o.success), o.iterations, o.data_model_iterations, ...
    o.network_model_iterations, o.math_model_iterations);
fprintf(fid, '- control iterations: pqbrak %.0f, xfmr %.0f, genq %.0f, twodc %.0f, swshunt %.0f, facts %.0f\n', ...
    get_iter(o, 'pqbrak'), get_iter(o, 'xfmr'), get_iter(o, 'genq'), ...
    get_iter(o, 'twodc'), get_iter(o, 'swshunt'), get_iter(o, 'facts'));
write_bullets(fid, 'top VM differences', o.comparison.solution.top_vm);
write_bullets(fid, 'top VA differences', o.comparison.solution.top_va);
write_bullets(fid, 'GEN Q differences', o.comparison.genq.top);
write_bullets(fid, 'FACTS Q differences', o.comparison.facts.top);
write_bullets(fid, 'switched shunt differences', o.comparison.swshunt.top);
write_bullets(fid, 'transformer tap differences', o.comparison.xfmr.top);
write_bullets(fid, 'TWO-DC differences', o.comparison.twodc.top);
if o.outside_095_110_count > 0
    write_bullets(fid, 'MATPOWER buses outside 0.95-1.10', o.outside_095_110);
end
fprintf(fid, '\n');

function write_bullets(fid, title, rows)
if isempty(rows)
    return;
end
fprintf(fid, '- %s:\n', title);
for k = 1:numel(rows)
    fprintf(fid, '  - %s\n', rows{k});
end

function write_csv_summary(summary, path)
fid = fopen(path, 'w');
if fid < 0
    error('could not open CSV for writing: %s', path);
end
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, ['case,order,success,iterations,dm_iterations,nm_iterations,mm_iterations,' ...
    'max_abs_vm,rms_vm,max_abs_va,rms_va,max_abs_qgen,facts_dq,swshunt_db,' ...
    'xfmr_dwindv,twodc_dp,twodc_dq,outside_095_110,psse_iterations,' ...
    'psse_total_mismatch_mva,psse_max_mismatch_mva\n']);
for i = 1:numel(summary.cases)
    c = summary.cases(i);
    for k = 1:numel(c.orders)
        o = c.orders(k);
        s = o.comparison.solution;
        fprintf(fid, '%s,%s,%d,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%.12g,%d,%.12g,%.12g,%.12g\n', ...
            c.name, o.name, o.success, o.iterations, ...
            o.data_model_iterations, o.network_model_iterations, ...
            o.math_model_iterations, s.max_abs_vm, s.rms_vm, ...
            s.max_abs_va, s.rms_va, ...
            scalar_field(o.comparison.genq, 'max_abs_q_diff'), ...
            scalar_field(o.comparison.facts, 'max_abs_q_diff'), ...
            scalar_field(o.comparison.swshunt, 'max_abs_binit_diff'), ...
            scalar_field(o.comparison.xfmr, 'max_abs_windv1_diff'), ...
            scalar_field(o.comparison.twodc, 'max_abs_pac_diff'), ...
            scalar_field(o.comparison.twodc, 'max_abs_qac_diff'), ...
            o.outside_095_110_count, ...
            c.reference.log.converged_iterations, ...
            c.reference.log.total_mismatch_mva, ...
            c.reference.log.max_mismatch_mva);
    end
end

function txt = order_text(controls)
if isempty(controls)
    txt = 'production default';
else
    txt = strjoin(controls, ' -> ');
end

function v = scalar_field(s, field)
if isstruct(s) && isfield(s, field)
    v = s.(field);
else
    v = NaN;
end

function it = get_iter(o, family)
it = NaN;
if isfield(o.control_iterations, family)
    it = o.control_iterations.(family).iterations;
end

function out = yesno(tf)
if tf
    out = 'yes';
else
    out = 'no';
end

function s = oneline(s)
s = strtrim(regexprep(s, '\s+', ' '));

function t = csv_tokens(line)
t = {};
buf = '';
in_quote = false;
quote_char = '';
for k = 1:length(line)
    ch = line(k);
    if (ch == '''' || ch == '"')
        if in_quote && ch == quote_char
            in_quote = false;
            quote_char = '';
        elseif ~in_quote
            in_quote = true;
            quote_char = ch;
        else
            buf(end+1) = ch; %#ok<AGROW>
        end
    elseif ch == ',' && ~in_quote
        t{end+1} = strtrim(buf); %#ok<AGROW>
        buf = '';
    else
        buf(end+1) = ch; %#ok<AGROW>
    end
end
t{end+1} = strtrim(buf);

function v = num_token(tokens, idx)
if idx > numel(tokens)
    v = NaN;
else
    v = str2double(clean_token(tokens{idx}));
end

function v = safe_num_token(tokens, idx)
if isempty(tokens) || idx > numel(tokens)
    v = NaN;
else
    v = num_token(tokens, idx);
end

function s = clean_token(s)
s = strtrim(s);
if length(s) >= 2
    if (s(1) == '''' && s(end) == '''') || (s(1) == '"' && s(end) == '"')
        s = s(2:end-1);
    end
end
s = strtrim(s);

function nums = numbers_in_line(line)
tok = regexp(line, '[-+]?\d+(?:\.\d+)?(?:[Ee][-+]?\d+)?', 'match');
nums = str2double(tok);

function d = angle_diff_deg(a, b)
d = mod(a - b + 180, 360) - 180;

function x = nanmax(v)
v = v(~isnan(v));
if isempty(v)
    x = NaN;
else
    x = max(v);
end

function txt = tail_text(txt, n)
if isempty(txt)
    txt = {};
    return;
end
parts = regexp(strrep(txt, sprintf('\r'), ''), sprintf('\n'), 'split');
parts = parts(~cellfun(@isempty, parts));
if numel(parts) > n
    txt = parts(end-n+1:end);
else
    txt = parts;
end
