# PSS/E switched shunt validation cases

Estos casos son artefactos locales de auditoria para comparar el comportamiento
de PSS/E contra `runpf_psse` sin depender del RAW grande.

## Casos

- `psse_swshunt_2bus_discrete_local.raw`: dos barras, un switched shunt
  `MODSW=1` local, bloques discretos capacitivos.
- `psse_swshunt_2bus_continuous_local.raw`: dos barras, un switched shunt
  `MODSW=2` local, rango continuo capacitivo.
- `psse_swshunt_3bus_remote_group.raw`: tres barras, dos switched shunts
  `MODSW=1` que regulan la misma barra remota con suma literal de `RMPCT=200`.

## Que exportar desde PSS/E

Para cada caso, correr dos soluciones:

1. Con switched shunts automaticos habilitados (`SWSHNT=2`).
2. Con switched shunts automaticos deshabilitados (`SWSHNT=0`).

Exportar, como minimo:

- buses: `I`, `NAME`, `BASKV`, `TYPE`, `VM`, `VA`;
- switched shunts: `I`, `MODSW`, `ADJM`, `STAT`, `SWREG`, `VSWHI`,
  `VSWLO`, `RMPCT`, `BINIT`, `N1/B1 ... N8/B8`;
- convergencia, metodo y numero de iteraciones.

La comparacion principal es `VM/VA`. `BINIT` se usa como diagnostico auxiliar
para verificar direccion, limites y reparto de ajustes.
