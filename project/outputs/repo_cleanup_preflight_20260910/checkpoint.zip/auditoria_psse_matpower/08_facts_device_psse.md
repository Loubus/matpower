# FACTS DEVICE DATA PSS/E

## Alcance

Este issue cubre solo `FACTS DEVICE DATA` presente en
`PSSE/V26p_Trs_2532.raw`. No modifica HVDC, limites Q de generadores,
system switching devices, switched shunts nuevos ni ULTC nuevos.

`runpf` estandar queda intacto. El comportamiento PSS/E se activa solo por
`runpf_psse`, mediante la extension MP-Core existente.

## Evidencia RAW

El RAW contiene un unico FACTS:

| Campo | Valor |
|---|---:|
| `NAME` | `FACTS 1` |
| `I` | `40403` |
| `J` | `0` |
| `MODE` | `1` |
| `PDES/QDES` | `0 / 0` |
| `VSET` | `1.00000` |
| `SHMX` | `100.000` |
| `TRMX` | `9999.000` |
| `VTMN/VTMX` | `0.90000 / 1.10000` |
| `VSMX/IMX/LINX` | `1.00000 / 0.000 / 0.05000` |
| `RMPCT` | `100.0` |
| `OWNER` | `1` |
| `SET1/SET2` | `0 / 0` |
| `VSREF` | `0` |
| `FCREG` | `41002` |
| `MNAME/NREG` | vacio / `0` |

El bus `I=40403` es `SVC PLUS`, 13.9 kV, tipo PQ. El bus regulado
`FCREG=41002` es `SLO_HV`, 220 kV, tipo PQ.

## Evidencia documental PSS/E

`DataFormats.pdf` y `PAGV1.pdf` separan el FACTS con `J=0` como STATCON:

- `MODE=0`: fuera de servicio.
- `MODE=1`: elemento shunt operativo.
- `J=0`: no hay rama serie; `PDES/QDES`, `TRMX`, `VTMN/VTMX`, `VSMX/IMX`,
  `LINX`, `SET1/SET2`, `VSREF` y `MNAME` quedan preservados pero no actuan
  en este RAW.
- `VSET`: tension objetivo.
- `FCREG`: bus regulado por el elemento shunt; si es invalido, PSS/E cae al
  bus terminal.
- `SHMX`: limite de corriente/reactivo del shunt, en MVA a tension unidad.
- `RMPCT`: reparto entre dispositivos que regulan el mismo bus.

## Evidencia MATPOWER

MATPOWER puede representar inyecciones reactivas fijas por `bus(:, QD)` o
por `bus(:, BS)`. Para este control se evita `BS`, porque switched shunts ya
recomponen esa columna en cada iteracion. Tambien se evita agregar filas `gen`
para este caso: el exportador MP-Core legado conserva mejor las dimensiones
si el STATCON se modela como carga reactiva negativa/positiva en `QD`.

El control queda en helpers separados:

- `mp.psse_facts_states`
- `mp.psse_facts_control`
- `mp.psse_facts_update`
- `mp.psse_facts_report`

`mp.task_pf_psse.next_dm` orquesta ahora:

1. transformadores PSS/E;
2. switched shunts PSS/E;
3. FACTS STATCON.

Ese orden es importante en el RAW grande: sin FACTS, los switched shunts ya
llevan `VM(41002)` de `1.055499794` a `1.028701616`. El STATCON debe actuar
despues para hacer el ajuste continuo final.

## Decision de diseno

Se implementa solo el comportamiento presente:

- activo `MODE=1`;
- `J=0`, STATCON sin rama serie;
- bus de inyeccion `I` tipo PQ;
- regulacion local/remota por `FCREG`;
- limite simetrico `|Qfacts| <= SHMX * |V_I|`;
- reparto `RMPCT` entre FACTS que compartan bus regulado.

La inyeccion se aplica como:

```text
QD_I = QD_base_I - Qfacts
```

Por lo tanto:

- `Qfacts > 0`: inyecta reactivo y reduce `QD`.
- `Qfacts < 0`: absorbe reactivo y aumenta `QD`.

## Implementacion

- `psse_parse` parsea `FACTS DEVICE DATA` Rev34+ y conserva nombres de
  columna.
- `psse_convert` preserva la tabla en `mpc.psse.facts` y agrega mapas de
  bus terminal/regulado.
- `runpf_psse` documenta FACTS como comportamiento opt-in.
- `task_pf_psse` llama al controlador FACTS luego de switched shunts.
- `t_psse_case4.raw` incluye un registro FACTS Rev34 de prueba.
- `t_psse.m` valida parseo y preservacion.
- `t_mpxt_psse.m` valida STATCON remoto, STATCON limitado por `SHMX`, y que
  la inyeccion se aplique por `QD`.
- `psse_validation_cases_facts/` contiene RAWs chicos para validacion PSS/E
  externa.

## Validacion local

Pruebas ejecutadas:

- `t_psse(0)`: `182/182` exitosos.
- `t_mpxt_psse(0)`: `59/59` exitosos.

Configuracion PSS/E a usar para validar los casos chicos:

- Solver: `FNSL`
- Solver option array code form: `BAT_FNSL`
- Opciones RAW declaradas: `SOLVER, FNSL, SWSHNT=2, FLATST=0`
- `NEWTON, VCTOLV=0.00001`
- `ADJUST, MXTPSS=20`

Casos chicos locales:

| Caso | Resultado `runpf_psse` |
|---|---|
| `psse_facts_3bus_base.raw` | success `1`, sin FACTS |
| `psse_facts_3bus_local.raw` | success `1`, `Qfacts=54.208710` |
| `psse_facts_3bus_remote.raw` | success `1`, `Qfacts=133.266680` |
| `psse_facts_3bus_remote_limit.raw` | success `1`, `Qfacts=4.612193`, limitado |

Los logs PSS/E finales recibidos el 2026-05-20 se aceptan como comparacion
numerica de casos chicos. PSS/E lee BUS3 con carga `90.0/45.0`, procesa el
registro FACTS en los tres casos correspondientes, imprime `FACTS SENDING END
DATA`, `FACTS TERMINAL END DATA` y el reporte de control de tension donde el
equipo aparece como `LOCAL SHUNT ELEM` o `REMOTE SHUNT ELEM` asociado a
FACTS DEVICE `FACTS 1`. Con esa evidencia se concluye equivalencia externa de
comportamiento de control para el alcance implementado, aunque no identidad
interna de formulacion numerica. PSS/E reproduce las tensiones e inyecciones
STATCON de MATPOWER dentro de la precision impresa por `LAMP`. El estado de esa
comparacion queda documentado en
`psse_validation_cases_facts/results_psse_validation.md`.

RAW grande:

| Magnitud | `runpf` estandar | `runpf_psse` |
|---|---:|---:|
| convergencia | `success=1` | `success=1` |
| `VM(41002)` | `1.055499794` | `1.000000005` |
| `QD(40403)` | `0.000000000` | `20.531494022` |
| `Qfacts` | no aplica | `-20.531494022` |
| limite FACTS | no aplica | `[-99.004579830, 99.004579830]` |
| FACTS limitado | no aplica | `0` |
| margen final | no aplica | `0` |
| ajustes switched shunt | no aplica | `107` |
| ajustes transformador | no aplica | `0` |

## Riesgos y limitaciones

- No hay salida PSS/E local del RAW grande para comparar el `Qfacts` final.
- La representacion por `QD` reproduce la inyeccion de potencia reactiva,
  pero no replica los elementos internos Norton/dummy asociados a `LINX`.
- No se implementan modos FACTS serie, UPFC/IPFC, `J != 0`, `PDES/QDES`,
  `MNAME`, `NREG` ni control por `TRMX`, porque no aparecen activos en el RAW.
- El reparto `RMPCT` se implementa entre FACTS que comparten bus regulado; no
  se reparte aun con generadores u otros controles PSS/E del mismo bus.

## Proximo issue recomendado

Antes de abrir otro modelo, conviene exportar desde PSS/E una solucion final
del RAW grande con `VM/VA`, salida del FACTS y estado final de switched
shunts. Si se decide seguir implementando, el siguiente tema con mayor valor
es regulacion remota de generadores / limites Q, porque sigue afectando `QG`
y tensiones sin una equivalencia opt-in local.
