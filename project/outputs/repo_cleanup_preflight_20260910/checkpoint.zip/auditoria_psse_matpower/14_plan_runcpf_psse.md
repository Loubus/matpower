# Plan para crear `runcpf_psse`

## Reset operativo

Este documento parte de un reset operativo de contexto: no se asume que el CPF estandar ya resuelve el problema. Se relee el codigo local de MATPOWER y `runpf_psse`, se separa la investigacion por agentes, y no se modifica codigo de solver en esta etapa.

Preflight:

- La carpeta raiz `PROYECTO FINAL DE CARRERA - MATPOWER` no es un repositorio Git.
- `matpower` esta limpio.
- `matpower-extras` esta limpio.

Objetivo:

Crear un `runcpf_psse` que sea, conceptualmente, el mismo CPF de MATPOWER (`runcpf`) pero con la capa PSS/E que hoy incorpora `runpf_psse`: opciones SYSTEM-WIDE, metadata `mpc.psse`, taps, shunts, GENQ, PQBRAK, TWODC y FACTS. La meta no es reemplazar el CPF por un barrido de flujos de carga, sino conservar el predictor-corrector CPF y agregarle los modelados PSS/E.

Decision principal:

No conviene insertar una llamada caja-negra a `runpf_psse` dentro del Newton corrector de `runcpf`. El CPF real necesita resolver el sistema aumentado:

```text
F(x, lambda) = 0
p(x, lambda) = 0
```

donde `p` es la ecuacion de parametrizacion. `runpf_psse` resuelve un PF fijo con controles externos, pero no expone el Jacobiano aumentado ni la ecuacion de pseudo-longitud de arco.

Por lo tanto, la implementacion principal debe ser:

```text
runcpf_psse = runcpf + extension PSS/E de runpf_psse
```

Esto implica:

1. Mantener el sistema aumentado CPF, la tangente, el corrector y la parametrizacion.
2. Activar una extension PSS/E tambien para CPF, no solo para PF.
3. Crear una tarea `mp.task_cpf_psse` que herede el comportamiento de CPF y agregue la coordinacion de controles de `mp.task_pf_psse`.
4. Tratar cada cambio de tap, shunt, GENQ, TWODC, FACTS o PQBRAK como evento de active-set que reconstruye el modelo y reinicia el tramo CPF si corresponde.

Un barrido `lambda + runpf_psse` queda permitido solo como herramienta auxiliar de diagnostico, no como definicion de `runcpf_psse`.

## Agentes usados

- Agente 1, arquitectura CPF MATPOWER: inspecciono `runcpf.m`, `cpf_corrector.m`, `cpf_tangent.m`, callbacks y eventos CPF.
- Agente 2, arquitectura `runpf_psse`: inspecciono `runpf_psse.m`, `mp.xt_psse`, `mp.task_pf_psse` y helpers `psse_*`.
- Agente 3, formulacion matematica: analizo como adaptar CPF predictor-corrector a controles PSS/E discretos/continuos.

## Hallazgos de codigo

### CPF estandar

Archivos principales:

- `matpower/lib/runcpf.m`
- `matpower/lib/cpf_corrector.m`
- `matpower/lib/cpf_tangent.m`
- `matpower/lib/cpf_p.m`
- `matpower/lib/cpf_p_jac.m`
- `matpower/lib/cpf_current_mpc.m`
- `matpower/lib/+mp/task_cpf.m`
- `matpower/lib/+mp/math_model_cpf.m`

Evidencia:

- `runcpf.m:279-280` resuelve el caso base con `runpf`, no con `runpf_psse`.
- `runcpf.m:373` arma `Ybus`, `Yf`, `Yt`.
- `runcpf.m:376` usa `mp.task_cpf_legacy` si entra por MP-Core.
- `runcpf.m:411-412` arma `Sbusb` y `Sbust` con `makeSbus`.
- `runcpf.m:427` calcula la tangente inicial con `cpf_tangent`.
- `runcpf.m:490` corrige con `cpf_corrector`.
- `cpf_corrector.m:82-94` arma el mismatch aumentado.
- `cpf_corrector.m:115-138` arma el Jacobiano aumentado y resuelve el paso Newton.
- `cpf_tangent.m:47-77` arma el Jacobiano aumentado para la tangente.
- `matpower/lib/+mp/math_model_cpf.m:100` implementa `node_balance_equations_cpf`.
- `matpower/lib/+mp/math_model_cpf.m:235` registra callbacks/eventos MP-Core.

Formulacion legacy relevante:

```text
mis = V .* conj(Ybus * V) - Sb - lambda * (St - Sb)
F = [real(mis(PV,PQ)); imag(mis(PQ))]
F_aug = [F; p(x, lambda)]
J_aug = [dF/dx dF/dlambda; dp/dx dp/dlambda]
```

El corrector CPF no es un PF simple. La condicion adicional `p(x, lambda)` permite pasar por la nariz, especialmente con parametrizacion pseudo arc-length.

### `runpf_psse`

Archivos principales:

- `matpower/lib/runpf_psse.m`
- `matpower/lib/+mp/xt_psse.m`
- `matpower/lib/+mp/task_pf_psse.m`
- `matpower/lib/+mp/psse_solver_options.m`
- `matpower/lib/+mp/psse_system_value.m`
- `matpower/lib/+mp/psse_xfmr_control.m`
- `matpower/lib/+mp/psse_swshunt_control.m`
- `matpower/lib/+mp/psse_genq_control.m`
- `matpower/lib/+mp/psse_twodc_control.m`
- `matpower/lib/+mp/psse_facts_control.m`
- `matpower/lib/+mp/psse_pqbrak_control.m`

Evidencia:

- `runpf_psse.m:106` activa opciones MP-Core PSS/E.
- `runpf_psse.m:114` aplica `mp.psse_solver_options`.
- `runpf_psse.m:347-354` usa `makeYbus` y `makeSbus` para el PF base.
- `runpf_psse.m:673` define `psse_mpx_options`, hoy como helper local privado.
- `matpower/lib/+mp/xt_psse.m:20-24` reemplaza `mp.task_pf_legacy` por `mp.task_pf_psse`.
- `matpower/lib/+mp/task_pf_psse.m:55-114` coordina controles PSS/E en `next_dm`.
- `matpower/lib/+mp/task_pf_psse.m:116-145` define orden de controles.
- `matpower/lib/+mp/task_pf_psse.m:148-184` llama a cada familia de control.
- `psse_xfmr_control.m:1-12` documenta que el control usa la tension resuelta y reconstruye el data model si cambia tap.
- `psse_swshunt_control.m:1-9` documenta que el control usa la tension resuelta y reconstruye el data model si cambia `BINIT`.

Controles actuales:

```text
pqbrak -> xfmr -> genq -> twodc -> swshunt -> facts
```

Ese orden puede cambiar si TWODC requiere preparacion diferida, o por `mpopt.exp.psse_control_order`.

`runpf_psse` no expone una API reusable de mismatch/Jacobian PSS/E. Su contrato actual es:

```text
caso fijo + metadata psse + mpopt
  -> solve MP-Core
  -> aplicar controles externos por next_dm
  -> reconstruir modelo si cambia un control
  -> repetir hasta estado estable o fallo
```

## Problema tecnico central

Los controles PSS/E no son simplemente terminos suaves dentro de `F(x, lambda)`.

Algunos son discretos:

- Taps con `NTP`.
- Bancos shunt discretos `MODSW=1`.
- Conversion PV/PQ por GENQ/VARLIM.
- Active-set de TWODC/FACTS.

Otros son continuos pero hoy estan implementados como control externo:

- Shunts `MODSW=2`.
- Algunos equivalentes DC/FACTS.

Entonces la trayectoria CPF debe entenderse como una curva por tramos:

```text
F(x, lambda; c_k) = 0
p(x, lambda; c_k) = 0
```

donde `c_k` es el estado de control PSS/E vigente en ese tramo. Cuando cambia `c_k`, cambia el problema algebraico. Eso debe registrarse como evento y requiere reconstruir el modelo.

## Alternativas de diseno

### Alternativa A: herramienta auxiliar `lambda + runpf_psse`

Idea:

```text
for lambda_k:
    mpc_k = interpolate_case(base, target, lambda_k)
    mpc_k = seed_from_previous_solution(mpc_k, r_{k-1})
    r_k = runpf_psse(mpc_k, mpopt)
    registrar VM/VA/controles/eventos
```

Ventajas:

- Reutiliza `runpf_psse` sin tocar el core.
- Permite obtener rapido curvas P-V y margen por ultimo `lambda` convergente.
- Muy util para TRANSPA y para depurar controles.

Limitaciones:

- No es un CPF pseudo arc-length completo.
- No puede seguir la rama descendente despues de la nariz.
- La nariz se aproxima por perdida de convergencia/biseccion o por singularidad estimada, no por el corrector aumentado.
- Si cambia un tap/shunt entre dos pasos, el evento se detecta despues; hay que localizarlo por rollback/biseccion.

Uso recomendado:

- Herramienta diagnostica.
- Comparacion con `runpf_psse` para cada punto.
- Barrido rapido para TRANSPA cuando se quiera contrastar un punto CPF contra el PF PSS/E-style.

Decision:

No definir `runcpf_psse` a partir de esta alternativa. Puede existir como funcion auxiliar, pero el `runcpf_psse` del proyecto debe preservar el CPF real.

Nombre sugerido si se implementa como herramienta separada:

- `runpsse_lambdasweep`
- `runcpf_psse(..., 'mode', 'lambda_sweep')`, solo si queda claramente documentado como modo diagnostico y no como modo CPF principal.

### Alternativa B: modificar `runcpf` legacy

Idea:

Cambiar `runcpf.m` para que el base PF use `runpf_psse`, y luego agregar callbacks PSS/E al loop legacy.

Ventajas:

- Aprovecha funciones legacy ya conocidas: `cpf_corrector`, `cpf_tangent`, `cpf_detect_events`.

Problemas:

- `runcpf` legacy fija `Ybus`, `Sbusb`, `Sbust`, `ref/pv/pq` al inicio del tramo.
- Los controles PSS/E reconstruyen el modelo cuando cambian estados.
- Cada cambio de tap, shunt o GENQ invalidaria `Ybus`, `Sbusb`, `Sbust`, indices internos y callbacks.
- Alto riesgo de ensuciar `runcpf` estandar.

Decision:

No tomar esta alternativa como camino principal.

### Alternativa C: nuevo `runcpf_psse` sobre MP-Core

Idea:

Crear un entrypoint nuevo que replique la filosofia de `runpf_psse`, pero para CPF:

```text
[results, success] = runcpf_psse(basecase, targetcase, mpopt, fname, solvedcase)
```

Internamente:

- Carga base y target.
- Aplica opciones SYSTEM-WIDE PSS/E.
- Activa extension `mp.xt_psse`.
- Usa una nueva tarea `mp.task_cpf_psse`.
- La tarea corre CPF por tramos.
- Los controles PSS/E se aplican entre tramos o despues de puntos aceptados.
- Cada cambio de control se registra como evento y fuerza rebuild/restart local.

Ventajas:

- Mantiene `runcpf` limpio.
- Sigue el patron ya validado de `runpf_psse`.
- Permite usar infraestructura MP-Core de CPF: `task_cpf`, `math_model_cpf`, eventos, callbacks y warm starts.
- Es el camino correcto para una herramienta mantenible.

Decision:

Esta debe ser la solucion objetivo.

## Arquitectura objetivo

### Nuevo entrypoint

Archivo:

```text
matpower/lib/runcpf_psse.m
```

Firma:

```matlab
function [res, suc] = runcpf_psse(basecasedata, targetcasedata, mpopt, fname, solvedcase)
```

Comportamiento:

1. Cargar base y target.
2. Aplicar `mp.psse_solver_options` al caso base.
3. Propagar opciones efectivas al target, sin perder metadata `mpc.psse`.
4. Activar MP-Core y `mp.xt_psse`.
5. Seleccionar `mp.task_cpf_psse`.
6. Retornar `results.cpf`, `results.psse`, `results.success`, `results.task`.

### Factorizar helpers PSS/E hoy privados

Hoy `runpf_psse.m` contiene `psse_mpx_options` como helper local privado.

Para no duplicar logica, crear helper publico:

```text
matpower/lib/+mp/psse_mpx_options.m
```

Contrato:

```matlab
mpopt = mp.psse_mpx_options(mpopt);
```

Uso:

- `runpf_psse`
- `runcpf_psse`

Tambien conviene factorizar preparacion comun:

```text
matpower/lib/+mp/psse_prepare_case.m
```

Contrato tentativo:

```matlab
[mpc, prep] = mp.psse_prepare_case(mpc, mpopt, mode)
```

Donde `mode` puede ser:

- `'pf'`
- `'cpf_base'`
- `'cpf_target'`

Debe encapsular:

- `psse_record_solved_snapshot_detection`
- `psse_swdev_collapse`
- `psse_pqbrak_prepare`
- `psse_genq_prepare`
- `psse_twodc_prepare`
- preparacion diferida GENQ/TWODC si aplica

### Nueva task CPF PSS/E

Archivo:

```text
matpower/lib/+mp/task_cpf_psse.m
```

Base:

```matlab
classdef task_cpf_psse < mp.task_cpf_legacy
```

Responsabilidades:

- Heredar todo el comportamiento CPF de `mp.task_cpf_legacy`.
- Incorporar propiedades de control PSS/E equivalentes a `mp.task_pf_psse`.
- Reutilizar o copiar inicialmente:
  - `control_order`
  - `apply_control`
  - `sync_source_solution`
  - tracking de ultimo estado exitoso
  - rollback si un control rompe convergencia
- Respetar `warmstart` de `mp.task_cpf`.

Propiedades esperadas:

```matlab
psse_genq
psse_pqbrak
psse_xfmr
psse_twodc
psse_facts
psse_swshunt
psse_last_success_source
psse_pending_control
psse_failed_control
psse_cpf_events
```

### Extension `xt_psse`

Modificar:

```text
matpower/lib/+mp/xt_psse.m
```

Hoy:

```matlab
if isequal(task_class, @mp.task_pf_legacy)
    task_class = @mp.task_pf_psse;
end
```

Agregar:

```matlab
if isequal(task_class, @mp.task_cpf_legacy)
    task_class = @mp.task_cpf_psse;
end
```

### Reutilizacion de controles

Los helpers actuales tienen firma compatible con task:

```matlab
[dm_next, state] = mp.psse_xfmr_control(task, mm, nm, dm, mpopt, mpx, state)
```

Esto favorece reutilizarlos desde `task_cpf_psse`, siempre que `dm.source` y `nm` representen el punto CPF aceptado.

Punto delicado:

En PF, `next_dm` se llama despues de un solve PF completo. En CPF, el solve matematico puede contener muchos pasos internos. Por lo tanto, para control PSS/E fino no alcanza aplicar controles solo al final de toda la curva. Hay dos niveles:

1. Primera version MP-Core simple: aplicar controles despues de cada segmento CPF terminado por evento o objetivo.
2. Version robusta: registrar callbacks CPF PSS/E para inspeccionar cada punto aceptado y detener/reiniciar el segmento cuando cambie el active-set.

## Formulacion matematica objetivo

Para un active-set/control fijo `c`:

```text
g(x, lambda; c) = 0
p(x, lambda; c) = 0
```

Con formulacion MATPOWER polar-power:

```text
g(x, lambda; c) =
    V .* conj(Ybus(c) * V)
    - Sbus_base(Vm; c)
    - lambda * (Sbus_target(Vm; c) - Sbus_base(Vm; c))
```

Sistema aumentado:

```text
[ g(x, lambda; c) ] = 0
[ p(x, lambda; c) ] = 0
```

Jacobiano:

```text
J_aug =
[ dg/dx  dg/dlambda ]
[ dp/dx  dp/dlambda ]
```

Cuando un control cambia:

```text
c_k -> c_{k+1}
Ybus(c_k) -> Ybus(c_{k+1})
Sbus(...; c_k) -> Sbus(...; c_{k+1})
```

Ese cambio es un evento discreto. No debe quedar oculto dentro del corrector.

## Eventos requeridos

Eventos CPF ya existentes:

- `NOSE`
- `TARGET_LAM`
- `VLIM`
- `FLIM`
- `QLIM`
- `PLIM`

Eventos PSS/E nuevos:

- `PSSE_XFMR_TAP`: cambio de tap, tap en limite, ciclo o `MXTPSS`.
- `PSSE_SWSHUNT`: cambio de `BINIT`, limite, ciclo o rechazo de candidato.
- `PSSE_GENQ`: conversion PV/PQ, limite Q, regulacion remota, grupo limitado.
- `PSSE_TWODC`: cambio de estado DC/equivalente.
- `PSSE_FACTS`: cambio de inyeccion/control STATCON.
- `PSSE_PQBRAK`: cambio de modelo de carga por bajo voltaje.
- `PSSE_CONTROL_FAILURE`: control produce caso no convergente.

Cada evento debe registrar:

```text
lambda
step_index
control_family
status_before
status_after
bus/branch/gen/shunt indices externos
rollback/localizacion usada
mensaje legible
```

## Estrategia de localizacion de eventos

Para cambios discretos:

1. Resolver punto actual `lambda_a` con active-set `c_a`.
2. Proponer siguiente punto `lambda_b`.
3. Si el control PSS/E cambia en `lambda_b`, marcar intervalo `[lambda_a, lambda_b]`.
4. Biseccionar o usar secante sobre el criterio que disparo el cambio:
   - tension regulada cruzando banda
   - Q llegando a limite
   - tap/shunt candidato distinto
5. Aceptar el punto localizado.
6. Aplicar cambio de control.
7. Reiniciar segmento CPF con `lambda` fijo en el punto localizado y nuevo active-set.

Para controles continuos:

Primera version:

- Tratarlos como control externo PSS/E, igual que `runpf_psse`: ajustar despues del solve y reconstruir si cambia.

Version futura:

- Incluirlos como variables algebraicas continuas dentro del modelo CPF.

## Plan de implementacion

### Fase 0: pruebas y contrato

Crear especificacion de comportamiento antes del codigo:

- Casos sin `mpc.psse`: `runcpf_psse` debe comportarse como `runcpf`.
- Casos con controles PSS/E desactivados: debe coincidir con `runcpf` dentro de tolerancia.
- Caso TRANSPA explicito: debe aceptar `case_transpa_reduced_v1_explicit`.
- El resultado debe conservar `results.cpf` y agregar `results.psse.cpf`.

Entregables:

- `auditoria_psse_matpower/14_plan_runcpf_psse.md`
- matriz de pruebas `auditoria_psse_matpower/psse_validation_suite/runcpf_psse_validation_matrix.md`

### Fase 1: esqueleto `runcpf_psse` identico a `runcpf`

Objetivo:

Crear el entrypoint real `runcpf_psse` manteniendo el comportamiento base de `runcpf`. En esta fase, sin controles PSS/E activos o sin `mpc.psse`, el resultado debe ser equivalente a `runcpf`.

Cambios:

1. Crear `matpower/lib/runcpf_psse.m`.
2. Factorizar `mp.psse_mpx_options` desde el helper privado de `runpf_psse`.
3. Crear `matpower/lib/+mp/task_cpf_psse.m` como subclase de `mp.task_cpf_legacy`.
4. Extender `matpower/lib/+mp/xt_psse.m` para reemplazar tambien `mp.task_cpf_legacy` por `mp.task_cpf_psse`.
5. Mantener interfaz compatible:

```matlab
[results, success] = runcpf_psse(basecasedata, targetcasedata, mpopt, fname, solvedcase)
```

Comportamiento esperado:

```text
si no hay mpc.psse:
    runcpf_psse equivale a runcpf
si hay mpc.psse pero controles PSS/E estan desactivados:
    runcpf_psse equivale a runcpf
si hay mpc.psse y controles activos:
    usa la misma formulacion CPF, pero con task CPF PSS/E
```

Aceptacion:

- No se reemplaza el corrector CPF por `runpf_psse`.
- `results.cpf.lam`, `results.cpf.V`, `results.cpf.events` mantienen la semantica de MATPOWER.
- `runcpf_psse` sin metadata PSS/E coincide con `runcpf` dentro de tolerancia numerica.
- `xt_psse` queda capaz de afectar PF y CPF:

```matlab
if isequal(task_class, @mp.task_pf_legacy)
    task_class = @mp.task_pf_psse;
elseif isequal(task_class, @mp.task_cpf_legacy)
    task_class = @mp.task_cpf_psse;
end
```

### Fase 2: incorporar modelados PSS/E al CPF

Algoritmo:

1. Preparar base y target con metadata PSS/E y opciones SYSTEM-WIDE.
2. Aplicar al CPF los mismos gates de `runpf_psse`: `ACTAPS`, `SWSHNT`, `DCTAPS`, `VARLIM`, `FACTS`, `FLATST`, `METHOD`, `ITMXN`.
3. Reutilizar en `mp.task_cpf_psse` la coordinacion de `mp.task_pf_psse`:

```text
pqbrak -> xfmr -> genq -> twodc -> swshunt -> facts
```

4. Correr CPF por tramos de active-set fijo hasta:
   - nariz,
   - target,
   - limite operativo,
   - evento PSS/E.
5. Si hay evento PSS/E:
   - localizar `lambda`;
   - aplicar control;
   - reconstruir data/network/math model;
   - reiniciar con warmstart.
6. Concatenar trayectorias y reports.

Modelados que deben incorporarse:

- `PQBRAK`: baja tension y comportamiento de carga PSS/E.
- `XFMR`: taps de transformadores, `ACTAPS`, limites y ciclos.
- `GENQ`: limites/reactivo/regulacion remota PSS/E, no simple `cpf.enforce_q_lims`.
- `TWODC`: equivalentes y estados DC preservados.
- `SWSHNT`: bancos conmutables, `BINIT`, `MODSW`, `SWSHNT`.
- `FACTS`: inyecciones y control STATCON preservado.

Aceptacion:

- Sin `mpc.psse`, el resultado es equivalente a `runcpf`.
- Con PSS/E desactivado, coincide con `runcpf` en `lambda`, `VM`, `VA`.
- Con PSS/E activado, registra eventos de control.
- La base `lambda=0` coincide con `runpf_psse` para el mismo caso.
- No modifica `runcpf` salvo factor comun justificado.

### Fase 2b: herramienta auxiliar `lambda_sweep`

Objetivo:

Agregar solo si hace falta una herramienta diagnostica que use `runpf_psse` en puntos fijos de `lambda`. Esta fase no define el funcionamiento principal de `runcpf_psse`; sirve para comparar puntos de la curva y depurar eventos PSS/E.

Funciones posibles:

```text
matpower/lib/+mp/psse_interpolate_case.m
matpower/lib/+mp/psse_control_signature.m
```

Aceptacion:

- Corre en `case_transpa_reduced_v1_explicit`.
- Reproduce el base `runpf_psse`.
- Genera una traza comparable con `results.cpf`.
- Documenta explicitamente que no es pseudo arc-length completo.

### Fase 3: controles PSS/E finos

Agregar eventos y callbacks especificos:

- `event_psse_xfmr`
- `callback_psse_xfmr`
- `event_psse_swshunt`
- `callback_psse_swshunt`
- `event_psse_genq`
- `callback_psse_genq`

Objetivo:

No esperar hasta el final de un segmento largo para descubrir cambios de control. El propio CPF debe detener el tramo al primer cambio de active-set.

Aceptacion:

- Cada cambio de tap/shunt/GENQ tiene `lambda` localizado.
- Si un control oscila, se detecta ciclo y se elige mejor estado de forma trazable, igual que `runpf_psse`.
- Los reports de `results.psse.*.control` quedan sincronizados con `results.cpf.events`.

### Fase 4: validacion contra suites y TRANSPA

Casos:

- Casos chicos existentes de `psse_validation_suite`, hasta 50 buses.
- Casos unitarios:
  - sin PSS/E metadata;
  - GENQ simple;
  - GENQ remoto;
  - tap local;
  - tap remoto;
  - shunt discreto;
  - shunt continuo;
  - TWODC simple si aplica.
- Caso TRANSPA explicito.

Metricas:

- `success`
- `lambda_max`
- `lambda` de eventos
- max/RMS `dVM`, `dVA` contra `runcpf` cuando controles estan congelados
- comparacion `runpf_psse(mpc(lambda))` vs punto CPF-PSS/E en lambdas seleccionados
- continuidad de `VM/VA`
- cambios de `tap`, `BINIT`, `QG`, `bus type`
- performance

Aceptacion minima para TRANSPA:

- Base `lambda=0` igual a `runpf_psse` validado.
- Trayectoria reproducible.
- Eventos PSS/E registrados.
- Si `cpf.enforce_v_lims=1`, reportar primer limite.
- Si `stop_at=NOSE`, reportar si es nariz CPF real o ultimo lambda convergente segun modo.

## Riesgos

- Llamar `runpf_psse` como caja negra dentro del corrector no preserva pseudo arc-length.
- Cambios discretos pueden introducir saltos de trayectoria.
- `task_cpf` resuelve internamente muchos pasos; los controles PSS/E deben engancharse por callbacks/eventos si se busca granularidad.
- Los helpers PSS/E actuales estan pensados para PF completo; algunos pueden requerir estado persistente por lambda.
- Base y target CPF deben tener iguales coeficientes salvo inyecciones transferidas; taps/shunts cambiantes rompen esa condicion y obligan a segmentar.
- No hay una referencia CPF PSS/E directa en el workspace; la validacion debera combinar PF en puntos de lambda, regresion contra `runcpf` sin controles, y coherencia fisica.

## Decision recomendada

Implementar directamente el `runcpf_psse` real: un CPF de MATPOWER con extension PSS/E, no un barrido externo. La herramienta `lambda_sweep` queda relegada a diagnostico opcional.

La solucion objetivo queda:

```text
runcpf_psse
  -> mp.psse_mpx_options
  -> mp.psse_prepare_case
  -> mp.xt_psse
  -> mp.task_cpf_psse
  -> controles PSS/E por active-set/eventos
```

La frase precisa para el proyecto:

> `runcpf_psse` debe ser identico a `runcpf` en la formulacion CPF y en la semantica de resultados, pero con los modelados y controles PSS/E de `runpf_psse` incorporados como una extension de MP-Core. No debe ser un loop de `runpf_psse`; debe mantener el corrector aumentado CPF y segmentar la trayectoria cuando cambie el active-set PSS/E.

## Primeros pasos concretos

1. Crear matriz de validacion `runcpf_psse`.
2. Factorizar `mp.psse_mpx_options` para compartirlo entre `runpf_psse` y `runcpf_psse`.
3. Crear `runcpf_psse.m` con interfaz y salida compatibles con `runcpf`.
4. Crear `mp.task_cpf_psse` minima heredando de `mp.task_cpf_legacy`.
5. Agregar reemplazo CPF en `mp.xt_psse`.
6. Validar casos sin controles y controles apagados contra `runcpf`.
7. Factorizar preparacion comun `mp.psse_prepare_case`.
8. Integrar en `mp.task_cpf_psse` el orden de controles de `mp.task_pf_psse`.
9. Validar `lambda=0` contra `runpf_psse`.
10. Agregar eventos PSS/E por familia.
11. Correr `case_transpa_reduced_v1_explicit`.
12. Implementar `lambda_sweep` solo si se necesita como herramienta de comparacion puntual.
