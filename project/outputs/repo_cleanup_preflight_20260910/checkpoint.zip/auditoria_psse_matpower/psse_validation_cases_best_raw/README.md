# Best PSS/E RAW Validation Candidates

This folder contains the current best RAW fixtures for iterating on MATPOWER
PSS/E-style control algorithms under the PSS/E Xplore 50-bus limit.

## Files

- `psse_integrated_controls_14bus.raw`
  - Compact smoke-test case.
  - Useful for fast checks that integrated controls still parse and solve.

- `psse_integrated_controls_30bus_moderate.raw`
  - Main moderate fixture candidate.
  - Designed to keep voltages in a reasonable range while exercising GENQ,
    switched shunts, FACTS, ULTC transformers, TWO-DC, PQBRAK metadata and a
    system switching device.

## Intended Workflow

1. Load one RAW in PSS/E Xplore.
2. Solve with the embedded options.
3. Export the solved RAW and reports/logs.
4. Run the same RAW through `psse2mpc(raw, 0, 34)` and `runpf_psse`.
5. Compare PSS/E against MATPOWER on:
   - bus `VM/VA`;
   - generator `QGEN`;
   - switched-shunt `BINIT`;
   - FACTS reactive output;
   - transformer taps;
   - TWO-DC active/reactive quantities and tap/firing-angle state.

The 30-bus moderate case is the preferred fixture for engineering reverse
PSS/E control coordination before using stress cases.
