function plots = psse_diag_plot_run(data, outdir, opts)
%PSSE_DIAG_PLOT_RUN Create diagnostic plots for one PSS/E-aware run.

if nargin < 3 || isempty(opts)
    opts = struct();
end
outdir = char(outdir);
plot_dir = fullfile(outdir, 'plots');
if exist(plot_dir, 'dir') ~= 7
    mkdir(plot_dir);
end

cfg = plot_options(opts);
files = strings(0, 1);
modules = strings(0, 1);
warnings = strings(0, 1);
skipped = empty_skip();

if module_selected(cfg, "pv")
    [new_files, new_warnings, new_skipped] = plot_pv_groups(data, plot_dir, cfg);
    [files, modules] = append_files(files, modules, new_files, "pv");
    warnings = [warnings; new_warnings(:)];
    skipped = append_skips(skipped, new_skipped);
end
if module_selected(cfg, "gen_pq")
    new_files = plot_generator_pq_atlas(data, plot_dir, cfg);
    [files, modules] = append_files(files, modules, new_files, "gen_pq");
    new_files = plot_generator_pq_lambda(data, plot_dir, cfg);
    [files, modules] = append_files(files, modules, new_files, "gen_pq");
end
if module_selected(cfg, "redispatch")
    file = plot_redispatch_technology(data, plot_dir);
    if strlength(file) > 0
        [files, modules] = append_files(files, modules, file, "redispatch");
    else
        skipped = append_skips(skipped, skip_record("redispatch", ...
            "redispatch_technology_trace is empty"));
    end
end
if module_selected(cfg, "events")
    [file, msg] = plot_event_timeline(data, plot_dir, cfg);
    if strlength(file) > 0
        [files, modules] = append_files(files, modules, file, "events");
    else
        skipped = append_skips(skipped, skip_record("events", msg));
        if strlength(msg) > 0
            warnings(end+1, 1) = msg;
        end
    end
end
if module_selected(cfg, "branch")
    [new_files, new_warnings, new_skipped] = plot_branch_groups(data, plot_dir, cfg);
    [files, modules] = append_files(files, modules, new_files, "branch");
    warnings = [warnings; new_warnings(:)];
    skipped = append_skips(skipped, new_skipped);
end
if module_selected(cfg, "vsc")
    [new_files, new_warnings, new_skipped] = plot_vsc_groups(data, plot_dir);
    [files, modules] = append_files(files, modules, new_files, "vsc");
    warnings = [warnings; new_warnings(:)];
    skipped = append_skips(skipped, new_skipped);
end

files = files(strlength(files) > 0);
modules = modules(strlength(modules) > 0);
warnings = warnings(strlength(warnings) > 0);

plots = struct('plot_dir', string(plot_dir), 'files', files, ...
    'modules', modules, 'warnings', warnings, 'skipped_modules', skipped, ...
    'options', cfg);
write_plot_index(plot_dir, data, files, modules, warnings, skipped, cfg);
write_plotting_manifest(outdir, data, files, modules, warnings, skipped, cfg);
append_diagnostics_plot_readme(outdir, files, modules, warnings, skipped, cfg);
end

function cfg = plot_options(opts)
cfg = struct();
cfg.modules = ["pv"; "gen_pq"; "events"; "redispatch"];
if isfield(opts, 'plot_modules') && ~isempty(opts.plot_modules)
    cfg.modules = lower(string(opts.plot_modules(:)));
elseif isfield(opts, 'modules') && ~isempty(opts.modules)
    requested = lower(string(opts.modules(:)));
    plot_names = ["all"; "pv"; "gen_pq"; "events"; "redispatch"; ...
        "branch"; "vsc"];
    requested = requested(ismember(requested, plot_names));
    if ~isempty(requested)
        cfg.modules = requested;
    end
end
if any(cfg.modules == "all")
    cfg.modules = ["pv"; "gen_pq"; "events"; "redispatch"; "branch"; "vsc"];
end
cfg.modules = unique(cfg.modules, 'stable');

cfg.bus_groups = ["boundary_ports"; "buses_500kv"; ...
    "worst_voltage_drop"; "lowest_final_voltage"];
if isfield(opts, 'bus_groups') && ~isempty(opts.bus_groups)
    cfg.bus_groups = lower(string(opts.bus_groups(:)));
end
cfg.branch_groups = "top_loading";
if isfield(opts, 'branch_groups') && ~isempty(opts.branch_groups)
    cfg.branch_groups = lower(string(opts.branch_groups(:)));
end

cfg.page_size = 50;
cfg.gen_per_page = 6;
cfg.event_families = strings(0, 1);
cfg.use_compact_trace = true;
if isfield(opts, 'plot') && isstruct(opts.plot)
    p = opts.plot;
    if isfield(p, 'page_size') && ~isempty(p.page_size)
        cfg.page_size = max(1, double(p.page_size));
    end
    if isfield(p, 'gen_per_page') && ~isempty(p.gen_per_page)
        cfg.gen_per_page = max(1, double(p.gen_per_page));
    end
    if isfield(p, 'event_families') && ~isempty(p.event_families)
        cfg.event_families = lower(string(p.event_families(:)));
    end
    if isfield(p, 'use_compact_trace') && ~isempty(p.use_compact_trace)
        cfg.use_compact_trace = logical(p.use_compact_trace);
    end
end
end

function tf = module_selected(cfg, name)
tf = any(cfg.modules == lower(string(name)));
end

function [files, modules] = append_files(files, modules, new_files, module)
new_files = string(new_files(:));
new_files = new_files(strlength(new_files) > 0);
if isempty(new_files)
    return;
end
files = [files; new_files];
modules = [modules; repmat(string(module), numel(new_files), 1)];
end

function skips = empty_skip()
skips = struct('module', {}, 'reason', {});
end

function s = skip_record(module, reason)
s = struct('module', char(module), 'reason', char(reason));
end

function skips = append_skips(skips, new_skips)
if isempty(new_skips)
    return;
end
if isempty(skips)
    skips = new_skips(:);
else
    skips = [skips(:); new_skips(:)];
end
end

function [files, warnings, skipped] = plot_pv_groups(data, plot_dir, cfg)
files = strings(0, 1);
warnings = strings(0, 1);
skipped = empty_skip();
pv = pv_dataset(data, cfg);
if isempty(pv.Vmag)
    msg = "bus_trace is empty and no CPF voltage fallback was available";
    warnings(end+1, 1) = msg;
    skipped = append_skips(skipped, skip_record("pv", msg));
    return;
end
for k = 1:numel(cfg.bus_groups)
    group = cfg.bus_groups(k);
    idx = pv_group_indices(data, pv, group);
    idx = idx(idx > 0 & idx <= numel(pv.bus_ext));
    idx = unique(idx(:), 'stable');
    if isempty(idx)
        msg = "PV bus group has no buses: " + group;
        warnings(end+1, 1) = msg; %#ok<AGROW>
        skipped = append_skips(skipped, skip_record("pv", msg));
        continue;
    end
    if group == "all_physical" || group == "all_physical_buses"
        n_pages = ceil(numel(idx) / cfg.page_size);
        for page = 1:n_pages
            lo = (page - 1) * cfg.page_size + 1;
            hi = min(page * cfg.page_size, numel(idx));
            page_idx = idx(lo:hi);
            title_text = sprintf('%s - all physical buses page %02d', ...
                data.label, page);
            file = fullfile(plot_dir, sprintf('pv_all_physical_page_%02d.png', page));
            plot_pv_curves(file, pv, page_idx, title_text, true);
            files(end+1, 1) = string(file); %#ok<AGROW>
        end
    else
        file_group = canonical_bus_group(group);
        title_text = sprintf('%s - %s', data.label, strrep(char(file_group), '_', ' '));
        file = fullfile(plot_dir, sprintf('pv_%s.png', file_group));
        plot_pv_curves(file, pv, idx, title_text, numel(idx) <= cfg.page_size);
        files(end+1, 1) = string(file); %#ok<AGROW>
    end
end
end

function pv = pv_dataset(data, cfg)
pv = struct('lambda', [], 'Vmag', [], 'bus_row', [], 'bus_ext', [], ...
    'base_kv', [], 'bus_type', [], 'physical', []);
T = data.bus_trace;
if table_height(T) == 0
    return;
end
if cfg.use_compact_trace && table_height(data.cpf_points) > 0 && ...
        any(strcmp(data.cpf_points.Properties.VariableNames, 'compact_member'))
    keep_points = data.cpf_points.point_index(data.cpf_points.compact_member);
    T = T(ismember(T.point_index, keep_points), :);
end
if table_height(T) == 0
    return;
end
[bus_row, ~, row_ic] = unique(T.bus_row);
[points, ~, point_ic] = unique(T.point_index);
nb = numel(bus_row);
np = numel(points);
Vmag = NaN(nb, np);
ind = sub2ind([nb, np], row_ic, point_ic);
Vmag(ind) = T.VM;
lambda = NaN(1, np);
for p = 1:np
    k = find(point_ic == p, 1, 'first');
    lambda(p) = T.lambda(k);
end
bus_ext = NaN(nb, 1);
base_kv = NaN(nb, 1);
bus_type = NaN(nb, 1);
physical = true(nb, 1);
has_physical = any(strcmp(T.Properties.VariableNames, 'physical'));
for r = 1:nb
    k = find(row_ic == r, 1, 'first');
    bus_ext(r) = T.bus_ext(k);
    base_kv(r) = T.base_kv(k);
    bus_type(r) = T.bus_type(k);
    if has_physical
        physical(r) = logical(T.physical(k));
    else
        physical(r) = bus_ext(r) < 900000 && bus_type(r) ~= 4;
    end
end
pv.lambda = lambda;
pv.Vmag = Vmag;
pv.bus_row = bus_row;
pv.bus_ext = bus_ext;
pv.base_kv = base_kv;
pv.bus_type = bus_type;
pv.physical = physical;
end

function idx = pv_group_indices(data, pv, group)
idx = sidecar_curve_set_indices(data, pv, group);
if ~isempty(idx)
    return;
end
group = canonical_bus_group(group);
physical = logical(pv.physical(:));
switch group
    case "boundary_ports"
        ports = transpa_ports(data);
        idx = find(ismember(pv.bus_ext, ports));
    case "buses_500kv"
        idx = find(physical & pv.base_kv >= 400);
    case "worst_voltage_drop"
        drop = pv.Vmag(:, 1) - pv.Vmag(:, end);
        drop(~physical) = -Inf;
        [~, ord] = sort(drop, 'descend');
        idx = ord(1:min(40, nnz(isfinite(drop))));
    case "lowest_final_voltage"
        final_v = pv.Vmag(:, end);
        final_v(~physical) = Inf;
        [~, ord] = sort(final_v, 'ascend');
        idx = ord(1:min(40, nnz(isfinite(final_v))));
    case {"all_physical", "all_physical_buses"}
        idx = find(physical);
    case "all"
        idx = (1:numel(pv.bus_ext))';
    otherwise
        idx = zeros(0, 1);
end
end

function group = canonical_bus_group(group)
group = lower(string(group));
switch group
    case "all_physical_buses"
        group = "all_physical";
    case "worst_40_voltage_drop"
        group = "worst_voltage_drop";
    case "lowest_40_final_voltage"
        group = "lowest_final_voltage";
end
end

function idx = sidecar_curve_set_indices(data, pv, group)
idx = zeros(0, 1);
file = fullfile(char(data.source_dir), 'curve_sets.csv');
if exist(file, 'file') ~= 2
    return;
end
try
    sets = readtable(file);
catch
    return;
end
if ~all(ismember({'set_name', 'bus_i'}, sets.Properties.VariableNames))
    return;
end
aliases = sidecar_group_aliases(group);
mask = ismember(lower(string(sets.set_name)), aliases);
if ~any(mask)
    return;
end
[tf, loc] = ismember(sets.bus_i(mask), pv.bus_ext);
idx = loc(tf);
end

function aliases = sidecar_group_aliases(group)
group = canonical_bus_group(group);
switch group
    case "all_physical"
        aliases = ["all_physical"; "all_physical_buses"];
    case "worst_voltage_drop"
        aliases = ["worst_voltage_drop"; "worst_40_voltage_drop"];
    case "lowest_final_voltage"
        aliases = ["lowest_final_voltage"; "lowest_40_final_voltage"];
    otherwise
        aliases = group;
end
end

function ports = transpa_ports(data)
ports = [];
if isfield(data.raw, 'opts') && isfield(data.raw.opts, 'ports')
    ports = data.raw.opts.ports(:);
elseif isfield(data.raw, 'manifest') && isfield(data.raw.manifest, 'options') && ...
        isfield(data.raw.manifest.options, 'ports')
    ports = data.raw.manifest.options.ports(:);
end
end

function plot_pv_curves(file, pv, idx, title_text, with_legend)
fig = figure('Visible', 'off', 'Color', 'w', 'InvertHardcopy', 'off', ...
    'Position', [80 80 1500 900]);
ax = axes(fig);
style_axes(ax);
hold(ax, 'on');
if numel(idx) > 80
    plot(ax, pv.lambda, pv.Vmag(idx, :)', 'LineWidth', 0.45, ...
        'Color', [0.18 0.28 0.42]);
elseif numel(idx) > 45
    plot(ax, pv.lambda, pv.Vmag(idx, :)', 'LineWidth', 0.8);
else
    plot(ax, pv.lambda, pv.Vmag(idx, :)', 'LineWidth', 1.15);
end
grid(ax, 'on');
box(ax, 'on');
xlabel(ax, '\lambda');
ylabel(ax, 'Voltage magnitude [pu]');
title(ax, title_text, 'Interpreter', 'none');
xlim(ax, [min(pv.lambda), max(pv.lambda)]);
ymin = max(0.35, min(pv.Vmag(idx, :), [], 'all') - 0.035);
ymax = min(1.25, max(pv.Vmag(idx, :), [], 'all') + 0.035);
ylim(ax, [ymin ymax]);
if with_legend && numel(idx) <= 50
    labels = cell(numel(idx), 1);
    for ii = 1:numel(idx)
        labels{ii} = sprintf('%g (%.0f kV)', pv.bus_ext(idx(ii)), ...
            pv.base_kv(idx(ii)));
    end
    legend_handle = legend(ax, labels, 'Location', 'eastoutside', ...
        'Interpreter', 'none');
    set(legend_handle, 'Color', 'w', 'TextColor', 'k', ...
        'EdgeColor', [0.25 0.25 0.25]);
end
print(fig, char(file), '-dpng', '-r140');
close(fig);
end

function files = plot_generator_pq_atlas(data, plot_dir, cfg)
files = strings(0, 1);
if table_height(data.gen_trace) == 0 || ~isfield(data.results, 'gen')
    return;
end
try
    audit = check_gen_capability(data.results);
catch
    return;
end
elements = audit.elements(:);
if isempty(elements)
    return;
end
per_page = cfg.gen_per_page;
n_pages = ceil(numel(elements) / per_page);
for page = 1:n_pages
    idx = (page - 1) * per_page + (1:per_page);
    idx = idx(idx <= numel(elements));
    ncols = min(3, per_page);
    nrows = ceil(per_page / ncols);
    fig = figure('Visible', 'off', 'Color', 'w', ...
        'Position', [50 50 1650 1050]);
    tl = tiledlayout(fig, nrows, ncols, 'TileSpacing', 'compact', ...
        'Padding', 'compact');
    title(tl, sprintf('Generator P-Q traces over capability curves, page %02d', page), ...
        'Interpreter', 'none');
    for kk = 1:numel(idx)
        e = elements(idx(kk));
        ax = nexttile(tl);
        hold(ax, 'on');
        style_axes(ax);
        plot_capability_boundary(ax, e.info.curve);
        T = data.gen_trace(data.gen_trace.gen_idx == e.idx, :);
        if ~isempty(T)
            [~, ord] = sort(T.lambda);
            T = T(ord, :);
            plot(ax, T.PG, T.QG, '-', 'Color', [0.18 0.18 0.18], ...
                'LineWidth', 0.9);
            scatter(ax, T.PG, T.QG, 14, T.lambda, 'filled', ...
                'MarkerEdgeColor', 'none');
            plot(ax, T.PG(1), T.QG(1), 'o', 'MarkerSize', 6, ...
                'MarkerFaceColor', [0.1 0.45 0.95], ...
                'MarkerEdgeColor', [0.1 0.45 0.95]);
            plot(ax, T.PG(end), T.QG(end), 's', 'MarkerSize', 6, ...
                'MarkerFaceColor', [0.02 0.02 0.02], ...
                'MarkerEdgeColor', [0.02 0.02 0.02]);
            set_axis_limits(ax, e.info.curve, T.PG, T.QG);
        end
        grid(ax, 'on');
        axis(ax, 'equal');
        xlabel(ax, 'P (MW)');
        ylabel(ax, 'Q (MVAr)');
        title(ax, sprintf('gen %d bus %g %s | Smax %.1f MVA', ...
            e.idx, e.bus, string_field(e.info, 'gen_type'), e.info.Smax), ...
            'Interpreter', 'none');
        if kk == numel(idx) && ~isempty(T)
            cb = colorbar(ax);
            ylabel(cb, 'lambda');
        end
    end
    file = fullfile(plot_dir, sprintf('gen_pq_capability_page_%02d.png', page));
    print(fig, file, '-dpng', '-r150');
    close(fig);
    files(end+1, 1) = string(file); %#ok<AGROW>
end
end

function files = plot_generator_pq_lambda(data, plot_dir, cfg)
files = strings(0, 1);
if table_height(data.capability_audit) == 0 || table_height(data.gen_trace) == 0
    return;
end
final = data.capability_audit(data.capability_audit.source == "final", :);
if isempty(final)
    return;
end
per_page = cfg.gen_per_page;
n_pages = ceil(height(final) / per_page);
for page = 1:n_pages
    idx = (page - 1) * per_page + (1:per_page);
    idx = idx(idx <= height(final));
    ncols = min(3, per_page);
    nrows = ceil(per_page / ncols);
    fig = figure('Visible', 'off', 'Color', 'w', ...
        'Position', [50 50 1650 1050]);
    tl = tiledlayout(fig, nrows, ncols, 'TileSpacing', 'compact', ...
        'Padding', 'compact');
    title(tl, sprintf('Generator P/Q traces vs lambda, page %02d', page), ...
        'Interpreter', 'none');
    for kk = 1:numel(idx)
        g = final.gen_idx(idx(kk));
        T = data.gen_trace(data.gen_trace.gen_idx == g, :);
        [~, ord] = sort(T.lambda);
        T = T(ord, :);
        ax = nexttile(tl);
        yyaxis(ax, 'left');
        plot(ax, T.lambda, T.PG, '-o', 'LineWidth', 1, 'MarkerSize', 3);
        ylabel(ax, 'P (MW)');
        yyaxis(ax, 'right');
        plot(ax, T.lambda, T.QG, '-s', 'LineWidth', 1, 'MarkerSize', 3);
        ylabel(ax, 'Q (MVAr)');
        grid(ax, 'on');
        xlabel(ax, 'lambda');
        title(ax, sprintf('gen %d bus %g', g, final.bus_ext(idx(kk))), ...
            'Interpreter', 'none');
    end
    file = fullfile(plot_dir, sprintf('gen_pq_lambda_page_%02d.png', page));
    print(fig, file, '-dpng', '-r150');
    close(fig);
    files(end+1, 1) = string(file); %#ok<AGROW>
end
end

function file = plot_redispatch_technology(data, plot_dir)
file = "";
T = data.redispatch_technology_trace;
if table_height(T) == 0
    return;
end
tech = unique(T.technology, 'stable');
fig = figure('Visible', 'off', 'Color', 'w', 'Position', [50 50 1300 750]);
hold on;
for k = 1:numel(tech)
    Tk = T(T.technology == tech(k), :);
    plot(Tk.lambda, Tk.cumulative_mw, 'LineWidth', 1.5);
end
grid on;
xlabel('lambda');
ylabel('Cumulative redispatch applied (MW)');
title('Dynamic redispatch by technology', 'Interpreter', 'none');
legend(cellstr(tech), 'Interpreter', 'none', 'Location', 'best');
file = fullfile(plot_dir, 'redispatch_technology_cumulative.png');
print(fig, file, '-dpng', '-r150');
close(fig);
file = string(file);
end

function [file, msg] = plot_event_timeline(data, plot_dir, cfg)
file = "";
msg = "";
T = data.event_timeline;
if table_height(T) == 0
    msg = "event_timeline is empty";
    return;
end
if ~isempty(cfg.event_families)
    T = T(ismember(lower(string(T.family)), cfg.event_families), :);
end
if table_height(T) == 0
    msg = "event_timeline has no rows after event family filtering";
    return;
end
[families, ~, y] = unique(T.family, 'stable');
fig = figure('Visible', 'off', 'Color', 'w', 'Position', [50 50 1400 760]);
scatter(T.lambda, y, 42, y, 'filled');
grid on;
yticks(1:numel(families));
yticklabels(cellstr(families));
xlabel('lambda');
title('Event timeline', 'Interpreter', 'none');
for k = 1:height(T)
    text(T.lambda(k), y(k) + 0.08, char(T.event_name(k)), ...
        'Interpreter', 'none', 'FontSize', 7, 'Rotation', 25);
end
file = fullfile(plot_dir, 'event_timeline.png');
print(fig, file, '-dpng', '-r150');
close(fig);
file = string(file);
end

function [files, warnings, skipped] = plot_branch_groups(data, plot_dir, cfg)
files = strings(0, 1);
warnings = strings(0, 1);
skipped = empty_skip();
T = data.branch_trace;
if table_height(T) == 0 || ~any(strcmp(T.Properties.VariableNames, 'loading_pct'))
    msg = "branch module requested, but branch_trace/loading_pct is unavailable";
    warnings(end+1, 1) = msg;
    skipped = append_skips(skipped, skip_record("branch", msg));
    return;
end
for k = 1:numel(cfg.branch_groups)
    group = lower(string(cfg.branch_groups(k)));
    switch group
        case "top_loading"
            idx = top_branch_rows(T, min(40, numel(unique(T.branch_row))));
            file = fullfile(plot_dir, 'branch_top_loading.png');
            plot_branch_loading(file, T, idx, 'Top branch loading traces');
            files(end+1, 1) = string(file); %#ok<AGROW>
        case "all_monitored"
            idx_all = unique(T.branch_row(T.status ~= 0), 'stable');
            for page = 1:ceil(numel(idx_all) / cfg.page_size)
                lo = (page - 1) * cfg.page_size + 1;
                hi = min(page * cfg.page_size, numel(idx_all));
                idx = idx_all(lo:hi);
                file = fullfile(plot_dir, sprintf('branch_all_monitored_page_%02d.png', page));
                plot_branch_loading(file, T, idx, ...
                    sprintf('All monitored branches page %02d', page));
                files(end+1, 1) = string(file); %#ok<AGROW>
            end
        otherwise
            msg = "Unknown branch group: " + group;
            warnings(end+1, 1) = msg; %#ok<AGROW>
            skipped = append_skips(skipped, skip_record("branch", msg));
    end
end
end

function rows = top_branch_rows(T, n)
branches = unique(T.branch_row, 'stable');
score = NaN(numel(branches), 1);
for k = 1:numel(branches)
    Tk = T(T.branch_row == branches(k), :);
    score(k) = max(Tk.loading_pct, [], 'omitnan');
end
[~, ord] = sort(score, 'descend');
ord = ord(isfinite(score(ord)));
rows = branches(ord(1:min(n, numel(ord))));
end

function plot_branch_loading(file, T, branch_rows, title_text)
fig = figure('Visible', 'off', 'Color', 'w', 'Position', [80 80 1500 900]);
ax = axes(fig);
style_axes(ax);
hold(ax, 'on');
labels = cell(numel(branch_rows), 1);
for k = 1:numel(branch_rows)
    Tk = T(T.branch_row == branch_rows(k), :);
    [~, ord] = sort(Tk.lambda);
    Tk = Tk(ord, :);
    plot(ax, Tk.lambda, Tk.loading_pct, 'LineWidth', 1.0);
    labels{k} = sprintf('%d: %g-%g', branch_rows(k), ...
        Tk.from_bus_ext(1), Tk.to_bus_ext(1));
end
grid(ax, 'on');
box(ax, 'on');
xlabel(ax, '\lambda');
ylabel(ax, 'Loading [% RATE_A]');
title(ax, title_text, 'Interpreter', 'none');
if numel(branch_rows) <= 50
    legend(ax, labels, 'Location', 'eastoutside', 'Interpreter', 'none');
end
print(fig, char(file), '-dpng', '-r150');
close(fig);
end

function [files, warnings, skipped] = plot_vsc_groups(data, plot_dir)
files = strings(0, 1);
warnings = strings(0, 1);
skipped = empty_skip();
if table_height(data.vsc_trace) == 0 && table_height(data.busdc_trace) == 0 && ...
        table_height(data.branchdc_trace) == 0
    msg = "vsc module requested, but vsc_trace/busdc_trace/branchdc_trace are unavailable";
    warnings(end+1, 1) = msg;
    skipped = append_skips(skipped, skip_record("vsc", msg));
    return;
end
if table_height(data.vsc_trace) > 0
    file = fullfile(plot_dir, 'vsc_ac_dc_power_lambda.png');
    plot_vsc_trace(file, data.vsc_trace);
    files(end+1, 1) = string(file);
end
if table_height(data.busdc_trace) > 0
    file = fullfile(plot_dir, 'vsc_dc_bus_voltage_lambda.png');
    plot_busdc_trace(file, data.busdc_trace);
    files(end+1, 1) = string(file);
end
end

function plot_vsc_trace(file, T)
fig = figure('Visible', 'off', 'Color', 'w', 'Position', [80 80 1400 800]);
tl = tiledlayout(fig, 2, 1, 'TileSpacing', 'compact', 'Padding', 'compact');
title(tl, 'VSC traces vs lambda', 'Interpreter', 'none');
ax1 = nexttile(tl);
hold(ax1, 'on');
rows = unique(T.vsc_row, 'stable');
for k = 1:numel(rows)
    Tk = T(T.vsc_row == rows(k), :);
    plot(ax1, Tk.lambda, Tk.PAC, 'LineWidth', 1.0);
end
grid(ax1, 'on');
ylabel(ax1, 'PAC');
ax2 = nexttile(tl);
hold(ax2, 'on');
for k = 1:numel(rows)
    Tk = T(T.vsc_row == rows(k), :);
    plot(ax2, Tk.lambda, Tk.QAC, 'LineWidth', 1.0);
end
grid(ax2, 'on');
xlabel(ax2, '\lambda');
ylabel(ax2, 'QAC');
print(fig, char(file), '-dpng', '-r150');
close(fig);
end

function plot_busdc_trace(file, T)
fig = figure('Visible', 'off', 'Color', 'w', 'Position', [80 80 1400 800]);
ax = axes(fig);
style_axes(ax);
hold(ax, 'on');
rows = unique(T.busdc_row, 'stable');
for k = 1:numel(rows)
    Tk = T(T.busdc_row == rows(k), :);
    plot(ax, Tk.lambda, Tk.VDC, 'LineWidth', 1.0);
end
grid(ax, 'on');
xlabel(ax, '\lambda');
ylabel(ax, 'VDC');
title(ax, 'DC bus voltage traces vs lambda', 'Interpreter', 'none');
print(fig, char(file), '-dpng', '-r150');
close(fig);
end

function plot_capability_boundary(ax, curve)
if isempty(curve) || ~isstruct(curve)
    return;
end
if all(isfield(curve, {'PA', 'QA', 'PB', 'QB', 'PC', 'QC'})) && ...
        ~isfield(curve, 'PD')
    P = [curve.PA curve.PB curve.PC curve.PC curve.PB curve.PA];
    Q = [curve.QA curve.QB curve.QC -curve.QC -curve.QB -curve.QA];
elseif all(isfield(curve, ...
        {'PA', 'QA', 'PB', 'QB', 'PC', 'QC', 'PD', 'QD', 'QE'}))
    q0 = (curve.QA^2 - curve.PB^2 - curve.QB^2) / ...
        (2 * curve.QA - 2 * curve.QB);
    s0 = curve.QA - q0;
    p_arc = linspace(curve.PA, curve.PB, 60);
    q_arc = sqrt(max(0, s0^2 - p_arc.^2)) + q0;
    P = [curve.PA p_arc curve.PB curve.PC curve.PD curve.PA curve.PA];
    Q = [curve.QA q_arc curve.QB curve.QC curve.QD curve.QE curve.QA];
else
    return;
end
patch(ax, P, Q, [0.90 0.94 1.00], 'FaceAlpha', 0.30, ...
    'EdgeColor', 'none');
plot(ax, P, Q, 'k-', 'LineWidth', 1.2);
end

function style_axes(ax)
set(ax, 'Color', 'w', 'XColor', 'k', 'YColor', 'k', ...
    'GridColor', [0.72 0.72 0.72], ...
    'MinorGridColor', [0.86 0.86 0.86]);
end

function set_axis_limits(ax, curve, P, Q)
x = P(:);
y = Q(:);
if ~isempty(curve) && isstruct(curve)
    names = fieldnames(curve);
    for k = 1:numel(names)
        if startsWith(names{k}, 'P') && isscalar(curve.(names{k}))
            x(end + 1, 1) = curve.(names{k}); %#ok<AGROW>
        elseif startsWith(names{k}, 'Q') && isscalar(curve.(names{k}))
            y(end + 1, 1) = curve.(names{k}); %#ok<AGROW>
        end
    end
end
x = x(isfinite(x));
y = y(isfinite(y));
if isempty(x) || isempty(y)
    return;
end
px = max(max(x) - min(x), 1) * 0.08;
py = max(max(y) - min(y), 1) * 0.08;
xlim(ax, [min(x) - px, max(x) + px]);
ylim(ax, [min(y) - py, max(y) + py]);
end

function out = string_field(s, name)
out = "";
if isfield(s, name)
    out = string(s.(name));
end
end

function write_plot_index(plot_dir, data, files, modules, warnings, skipped, cfg)
fid = fopen(fullfile(plot_dir, 'README.md'), 'w');
if fid < 0
    return;
end
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, '# Diagnostic plots\n\n');
fprintf(fid, 'Run id: `%s`\n\n', data.run_id);
fprintf(fid, 'Selected modules: `%s`\n\n', strjoin(cfg.modules, ', '));
fprintf(fid, '## Plot counts\n\n');
u = unique(modules, 'stable');
for k = 1:numel(u)
    fprintf(fid, '- `%s`: `%d`\n', u(k), nnz(modules == u(k)));
end
if isempty(files)
    fprintf(fid, '- none\n');
end
fprintf(fid, '\n## Files\n\n');
for k = 1:numel(files)
    [~, name, ext] = fileparts(files(k));
    fprintf(fid, '- `%s%s` (`%s`)\n', name, ext, modules(k));
end
fprintf(fid, '\n## Skipped modules and warnings\n\n');
if isempty(skipped) && isempty(warnings)
    fprintf(fid, '- none\n');
else
    for k = 1:numel(skipped)
        fprintf(fid, '- `%s`: %s\n', skipped(k).module, skipped(k).reason);
    end
    for k = 1:numel(warnings)
        fprintf(fid, '- %s\n', warnings(k));
    end
end
end

function write_plotting_manifest(outdir, data, files, modules, warnings, skipped, cfg)
manifest = struct();
manifest.created_by = 'psse_diag_plot_run';
manifest.run_id = data.run_id;
manifest.selected_modules = cfg.modules;
manifest.bus_groups = cfg.bus_groups;
manifest.branch_groups = cfg.branch_groups;
manifest.plot_options = rmfield(cfg, {'modules', 'bus_groups', 'branch_groups'});
manifest.generator_plot_source = generator_source(data.gen_trace);
manifest.generated_files = generated_file_records(outdir, files, modules);
manifest.plot_counts = plot_counts_struct(modules);
manifest.skipped_modules = skipped;
manifest.warnings = warnings;
manifest.assumptions = [ ...
    "PV curves use normalized bus_trace; bus_trace falls back to results.cpf.V when cpf.bus snapshots are absent."; ...
    "TRANSPA curve_sets.csv and cpf_bus_meta.csv are reused when present, otherwise groups are derived generically."; ...
    "Branch loading plots require normalized branch_trace with RATE_A-based loading_pct."; ...
    "VSC plots require normalized vsc_trace, busdc_trace, or branchdc_trace."];
manifest.output_tables = dir_names(outdir, '*.csv');
write_json(fullfile(outdir, 'plotting_manifest.json'), manifest);
end

function append_diagnostics_plot_readme(outdir, files, modules, warnings, skipped, cfg)
readme = fullfile(outdir, 'README.md');
fid = fopen(readme, 'a');
if fid < 0
    return;
end
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, '\n## Plots\n\n');
fprintf(fid, '- selected modules: `%s`\n', strjoin(cfg.modules, ', '));
fprintf(fid, '- bus groups: `%s`\n', strjoin(cfg.bus_groups, ', '));
fprintf(fid, '- branch groups: `%s`\n', strjoin(cfg.branch_groups, ', '));
fprintf(fid, '- generated files: `%d`\n', numel(files));
u = unique(modules, 'stable');
for k = 1:numel(u)
    fprintf(fid, '- `%s` plots: `%d`\n', u(k), nnz(modules == u(k)));
end
fprintf(fid, '\n### Plot files\n\n');
if isempty(files)
    fprintf(fid, '- none\n');
else
    for k = 1:numel(files)
        [~, name, ext] = fileparts(files(k));
        fprintf(fid, '- `plots/%s%s` (`%s`)\n', name, ext, modules(k));
    end
end
fprintf(fid, '\n### Plot warnings and skipped modules\n\n');
if isempty(skipped) && isempty(warnings)
    fprintf(fid, '- none\n');
else
    for k = 1:numel(skipped)
        fprintf(fid, '- `%s`: %s\n', skipped(k).module, skipped(k).reason);
    end
    for k = 1:numel(warnings)
        fprintf(fid, '- %s\n', warnings(k));
    end
end
end

function records = generated_file_records(outdir, files, modules)
records = repmat(struct('module', '', 'file', ''), numel(files), 1);
for k = 1:numel(files)
    records(k).module = char(modules(k));
    records(k).file = char(relative_name(outdir, files(k)));
end
end

function counts = plot_counts_struct(modules)
u = unique(modules, 'stable');
counts = struct();
for k = 1:numel(u)
    counts.(matlab.lang.makeValidName(char(u(k)))) = nnz(modules == u(k));
end
end

function name = relative_name(outdir, file)
file = string(file);
prefix = string(outdir) + filesep;
if startsWith(file, prefix)
    name = extractAfter(file, strlength(prefix));
else
    name = file;
end
end

function src = generator_source(T)
src = "";
if istable(T) && width(T) > 0 && any(strcmp(T.Properties.VariableNames, 'source'))
    src = strjoin(unique(string(T.source)), ', ');
end
end

function names = dir_names(outdir, pat)
d = dir(fullfile(outdir, pat));
names = string({d.name});
end

function write_json(file, s)
fid = fopen(file, 'w');
if fid < 0
    error('psse_diag_plot_run:write_failed', ...
        'Could not open %s for writing.', file);
end
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, '%s\n', jsonencode(s, 'PrettyPrint', true));
end

function n = table_height(T)
if istable(T)
    n = height(T);
else
    n = 0;
end
end
