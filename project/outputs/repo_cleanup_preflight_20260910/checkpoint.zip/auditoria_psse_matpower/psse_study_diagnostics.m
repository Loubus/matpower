function diagnostics = psse_study_diagnostics(run_dirs, outdir, opts)
%PSSE_STUDY_DIAGNOSTICS Build diagnostics for PSS/E-aware PF/CPF runs.
% ::
%
%   DIAGNOSTICS = PSSE_STUDY_DIAGNOSTICS(RUN_DIRS)
%   DIAGNOSTICS = PSSE_STUDY_DIAGNOSTICS(RUN_DIRS, OUTDIR)
%   DIAGNOSTICS = PSSE_STUDY_DIAGNOSTICS(RUN_DIRS, OUTDIR, OPTS)
%
% Loads one or more result folders containing MATPOWER PF/CPF MAT files and
% optional diagnostic sidecars, normalizes their traces into tables, writes
% machine-readable exports, and creates first-milestone generator diagnostics.
%
% See also PSSE_DIAG_LOAD_RUN, PSSE_DIAG_NORMALIZE_RUN,
% PSSE_DIAG_EXPORT_RUN, PSSE_DIAG_PLOT_RUN, PSSE_DIAG_COMPARE_RUNS.

if nargin < 1 || isempty(run_dirs)
    error('psse_study_diagnostics:missing_run_dirs', ...
        'At least one result folder is required.');
end
if nargin < 2
    outdir = '';
end
if nargin < 3 || isempty(opts)
    opts = struct();
end

setup_paths();
run_dirs = normalize_run_dirs(run_dirs);
if isempty(outdir)
    outdir = fullfile(run_dirs{1}, 'diagnostics');
end
outdir = char(outdir);
ensure_dir(outdir);

n = numel(run_dirs);
runs = [];
exports = [];
plots = [];
for k = 1:n
    loaded = psse_diag_load_run(run_dirs{k}, opts);
    loaded = apply_run_label(loaded, opts, k);
    normalized = psse_diag_normalize_run(loaded, opts);
    if k == 1
        runs = normalized;
    else
        runs(k, 1) = normalized; %#ok<AGROW>
    end
    run_outdir = fullfile(outdir, runs(k).run_id);
    exported = psse_diag_export_run(runs(k), run_outdir, opts);
    if module_enabled(opts, 'plots', true)
        plotted = psse_diag_plot_run(runs(k), run_outdir, opts);
    else
        plotted = struct('plot_dir', "", 'files', strings(0, 1));
    end
    if k == 1
        exports = exported;
        plots = plotted;
    else
        exports(k, 1) = exported; %#ok<AGROW>
        plots(k, 1) = plotted; %#ok<AGROW>
    end
end

comparison = struct();
if n > 1
    comparison = psse_diag_compare_runs(runs, outdir, opts);
end

diagnostics = struct( ...
    'outdir', string(outdir), ...
    'runs', runs, ...
    'exports', exports, ...
    'plots', plots, ...
    'comparison', comparison );

write_aggregate_manifest(diagnostics, outdir);

fprintf('PSS/E study diagnostics written to:\n  %s\n', outdir);
fprintf('runs=%d\n', n);
end

function setup_paths()
here = fileparts(mfilename('fullpath'));
root = fileparts(here);
lib = fullfile(root, 'matpower', 'lib');
if exist(lib, 'dir') == 7
    addpath(lib);
end
if exist(here, 'dir') == 7
    addpath(here);
end
end

function loaded = apply_run_label(loaded, opts, k)
if ~isfield(opts, 'labels') || isempty(opts.labels)
    return;
end
labels = cellstr(string(opts.labels(:)));
if k <= numel(labels) && ~isempty(labels{k})
    loaded.label = string(labels{k});
end
end

function tf = module_enabled(opts, name, default)
tf = default;
if isfield(opts, 'make_plots') && strcmp(name, 'plots')
    tf = logical(opts.make_plots);
end
if isfield(opts, 'modules') && ~isempty(opts.modules)
    modules = lower(string(opts.modules(:)));
    if strcmp(name, 'plots')
        plot_modules = ["plots"; "plot"; "all"; "pv"; "gen_pq"; ...
            "events"; "redispatch"; "branch"; "vsc"];
        tf = any(ismember(modules, plot_modules));
    else
        tf = any(modules == lower(string(name)));
    end
end
end

function dirs = normalize_run_dirs(run_dirs)
if ischar(run_dirs) || isstring(run_dirs)
    dirs = cellstr(string(run_dirs));
elseif iscell(run_dirs)
    dirs = cellstr(string(run_dirs(:)));
else
    error('psse_study_diagnostics:bad_run_dirs', ...
        'RUN_DIRS must be a char, string, or cell array.');
end
for k = 1:numel(dirs)
    dirs{k} = char(dirs{k});
    if exist(dirs{k}, 'dir') ~= 7
        error('psse_study_diagnostics:missing_run_dir', ...
            'Result folder not found: %s', dirs{k});
    end
end
end

function ensure_dir(d)
if exist(d, 'dir') ~= 7
    mkdir(d);
end
end

function write_aggregate_manifest(diagnostics, outdir)
manifest = struct();
manifest.created_by = 'psse_study_diagnostics';
manifest.outdir = diagnostics.outdir;
manifest.run_count = numel(diagnostics.runs);
manifest.runs = repmat(struct('run_id', '', 'source_dir', '', ...
    'max_lambda', NaN, 'events', NaN, 'warnings', NaN), ...
    manifest.run_count, 1);
for k = 1:manifest.run_count
    rm = diagnostics.runs(k).run_manifest;
    manifest.runs(k).run_id = char(rm.run_id);
    manifest.runs(k).source_dir = char(rm.source_dir);
    manifest.runs(k).max_lambda = rm.max_lambda;
    manifest.runs(k).events = rm.event_count;
    manifest.runs(k).warnings = height(diagnostics.runs(k).warnings);
end
write_json(fullfile(outdir, 'manifest.json'), manifest);
end

function write_json(file, s)
fid = fopen(file, 'w');
if fid < 0
    error('psse_study_diagnostics:write_failed', ...
        'Could not open %s for writing.', file);
end
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, '%s\n', jsonencode(s, 'PrettyPrint', true));
end
