function out = compare_cw2_ultc_audit()
% compare_cw2_ultc_audit - Compare PSS/E and MATPOWER CW=2 ULTC audit cases.

root_dir = fileparts(fileparts(fileparts(mfilename('fullpath'))));
mp_dir = fullfile(root_dir, 'matpower');
case_dir = fullfile(root_dir, 'PSSE', 'CW2_AUDIT');
addpath(fullfile(mp_dir, 'lib'));

raw_files = dir(fullfile(case_dir, 'cw2_audit_*.raw'));
rows = struct('case_name', {}, 'mp_success', {}, 'mp_iterations', {}, ...
    'state_row', {}, 'winding', {}, 'cod', {}, 'cont', {}, 'cw', {}, ...
    'reg_bus', {}, 'vmi', {}, 'vma', {}, 'initial_windv', {}, ...
    'psse_windv', {}, 'mp_windv', {}, 'windv_diff', {}, ...
    'psse_tap', {}, 'mp_tap', {}, 'tap_diff', {});

for k = 1:numel(raw_files)
    name = erase(string(raw_files(k).name), ".raw");
    raw_path = fullfile(raw_files(k).folder, raw_files(k).name);
    solved_path = fullfile(case_dir, 'solved_raw', name + "_solved.raw");
    if exist(solved_path, 'file') ~= 2
        warning('compare_cw2_ultc_audit:missing_solved', ...
            'Skipping %s, missing solved RAW.', name);
        continue;
    end

    [mpc, ~] = psse2mpc(raw_path, 0, 34);
    psse_windv = parse_transformer_windv(char(solved_path));
    mpopt = mpoption('verbose', 0, 'out.all', 0);
    r = runpf_psse(mpc, mpopt);
    st0 = mp.psse_xfmr_states(mpc);
    rep = r.psse.xfmr.control;

    n = min([st0.n, numel(psse_windv), numel(rep.final_windv)]);
    controlled = find(st0.cod(1:n) == 1 & st0.cw(1:n) == 2);
    for kk = 1:numel(controlled)
        i = controlled(kk);
        psse_tap = scale_windv_to_tap(psse_windv(i), st0.windv(i), ...
            st0.current_tap(i));
        rows(end+1) = struct( ... %#ok<AGROW>
            'case_name', char(name), ...
            'mp_success', logical(r.success), ...
            'mp_iterations', r.iterations, ...
            'state_row', i, ...
            'winding', st0.winding(i), ...
            'cod', st0.cod(i), ...
            'cont', st0.cont(i), ...
            'cw', st0.cw(i), ...
            'reg_bus', abs(st0.cont(i)), ...
            'vmi', st0.vmi(i), ...
            'vma', st0.vma(i), ...
            'initial_windv', st0.windv(i), ...
            'psse_windv', psse_windv(i), ...
            'mp_windv', rep.final_windv(i), ...
            'windv_diff', abs(psse_windv(i) - rep.final_windv(i)), ...
            'psse_tap', psse_tap, ...
            'mp_tap', rep.final_tap(i), ...
            'tap_diff', abs(psse_tap - rep.final_tap(i)));
    end
end

out = struct();
out.rows = rows;
out.table = struct2table(rows);
out.csv_path = fullfile(case_dir, 'cw2_ultc_audit_comparison.csv');
out.report_path = fullfile(case_dir, 'cw2_ultc_audit_report.md');
writetable(out.table, out.csv_path);
write_report(out);
fprintf('Wrote CW=2 ULTC audit CSV: %s\n', out.csv_path);
fprintf('Wrote CW=2 ULTC audit report: %s\n', out.report_path);

function write_report(out)
fid = fopen(out.report_path, 'w');
if fid < 0
    error('compare_cw2_ultc_audit:report_open', ...
        'Could not open report for writing: %s', out.report_path);
end
cleanup = onCleanup(@() fclose(fid));
t = out.table;
fprintf(fid, '# CW=2 Three-Winding ULTC Audit\n\n');
fprintf(fid, 'Generated: `%s`\n\n', datestr(now, 'yyyy-mm-dd HH:MM:SS'));
fprintf(fid, 'Compares PSS/E solved RAW transformer `WINDV`/tap state against `runpf_psse` final transformer-control state.\n\n');
if isempty(t)
    fprintf(fid, 'No comparable rows found.\n');
    return;
end
fprintf(fid, '| case | success | row | W | CONT | V band | PSSE WINDV | MP WINDV | dWINDV | PSSE tap | MP tap | dtap |\n');
fprintf(fid, '|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|\n');
for k = 1:height(t)
    fprintf(fid, '| %s | %d | %d | %d | %g | %.3f-%.3f | %.9g | %.9g | %.3g | %.9g | %.9g | %.3g |\n', ...
        t.case_name{k}, t.mp_success(k), t.state_row(k), ...
        t.winding(k), t.cont(k), t.vmi(k), t.vma(k), ...
        t.psse_windv(k), t.mp_windv(k), t.windv_diff(k), ...
        t.psse_tap(k), t.mp_tap(k), t.tap_diff(k));
end
fprintf(fid, '\nMax WINDV diff: `%.12g`\n\n', max(t.windv_diff));
fprintf(fid, 'Max tap diff: `%.12g`\n', max(t.tap_diff));

function tap = scale_windv_to_tap(windv, initial_windv, initial_tap)
if isfinite(initial_windv) && abs(initial_windv) > 0
    tap = windv * initial_tap / initial_windv;
else
    tap = NaN;
end

function windv = parse_transformer_windv(raw_path)
two_windv = [];
three_windv = zeros(0, 3);
if exist(raw_path, 'file') ~= 2
    windv = [];
    return;
end
lines = section_lines(raw_path, 'TRANSFORMER DATA');
idx = 1;
while idx <= numel(lines)
    line = strtrim(lines{idx});
    if isempty(line) || startsWith(line, '@')
        idx = idx + 1;
        continue;
    end
    vals = numbers_in_line(line);
    if numel(vals) < 3
        idx = idx + 1;
        continue;
    end
    first_windv = NaN;
    if idx + 2 <= numel(lines)
        w1 = numbers_in_line(lines{idx + 2});
        if ~isempty(w1)
            first_windv = w1(1);
        end
    end
    if vals(3) ~= 0
        row = [first_windv NaN NaN];
        if idx + 3 <= numel(lines)
            w2 = numbers_in_line(lines{idx + 3});
            if ~isempty(w2)
                row(2) = w2(1);
            end
        end
        if idx + 4 <= numel(lines)
            w3 = numbers_in_line(lines{idx + 4});
            if ~isempty(w3)
                row(3) = w3(1);
            end
        end
        three_windv(end+1, :) = row; %#ok<AGROW>
        idx = idx + 5;
    else
        two_windv(end+1) = first_windv; %#ok<AGROW>
        idx = idx + 4;
    end
end
windv = [two_windv three_windv(:, 1).' three_windv(:, 2).' ...
    three_windv(:, 3).'];
windv = windv(~isnan(windv));

function section = section_lines(lines_or_path, name)
if iscell(lines_or_path)
    lines = lines_or_path;
else
    txt = fileread(lines_or_path);
    txt = strrep(txt, sprintf('\r\n'), sprintf('\n'));
    txt = strrep(txt, sprintf('\r'), sprintf('\n'));
    lines = regexp(txt, sprintf('\n'), 'split')';
end
section = {};
target = ['BEGIN ' upper(name)];
start_idx = 0;
for k = 1:numel(lines)
    if contains(upper(lines{k}), target)
        start_idx = k + 1;
        break;
    end
end
if start_idx == 0
    return;
end
for k = start_idx:numel(lines)
    ln = strtrim(lines{k});
    if startsWith(ln, '0 / END')
        break;
    end
    if isempty(ln) || startsWith(ln, '@!')
        continue;
    end
    section{end+1, 1} = lines{k}; %#ok<AGROW>
end

function nums = numbers_in_line(line)
line = regexprep(line, '/.*$', '');
tokens = regexp(line, ...
    '[-+]?(?:\d+\.?\d*|\.\d+)(?:[EeDd][-+]?\d+)?', 'match');
nums = zeros(1, numel(tokens));
for k = 1:numel(tokens)
    nums(k) = str2double(strrep(tokens{k}, 'D', 'E'));
end
