root = fileparts(fileparts(fileparts(mfilename('fullpath'))));
out_dir = fullfile(root, 'auditoria_psse_matpower', 'results', ...
    'sadi_pq_equivalent_actaps1_raw_snapshot_study_locked');
if ~exist(out_dir, 'dir')
    mkdir(out_dir);
end
diary(fullfile(out_dir, 'run_console.txt'));
cleanup = onCleanup(@() diary('off'));

addpath(fullfile(root, 'auditoria_psse_matpower', 'tools'));
opts = struct();
opts.reference_source = 'raw_snapshot';
opts.out_dir = out_dir;
opts.reduced_solver = 'runpf_psse';
opts.keep_reduced_psse_metadata = true;
opts.force_reduced_actaps = 1;
opts.apply_v26p_ultc_study_mask = true;

results_actaps_sadi_locked = build_sadi_pq_equivalent_case(opts); %#ok<NASGU>
