function summary = validate_ultc_10bus_sign()
% validate_ultc_10bus_sign - Compare 10-bus ULTC tap signs vs PSS/E solved RAW.

define_constants;

this_file = mfilename('fullpath');
tools_dir = fileparts(this_file);
audit_dir = fileparts(tools_dir);
project_dir = fileparts(audit_dir);
matpower_dir = fullfile(project_dir, 'matpower');
raw_file = fullfile(project_dir, 'PSSE', 'RAW', ...
    'psse_ultc_10bus_sign.raw');
solved_file = fullfile(project_dir, 'PSSE', 'SOLVED_ULTC_10BUS_SIGN', ...
    'solved_raw', 'psse_ultc_10bus_sign_solved.raw');
log_file = fullfile(project_dir, 'PSSE', 'SOLVED_ULTC_10BUS_SIGN', ...
    'logs', 'psse_ultc_10bus_sign.log');
out_dir = fullfile(audit_dir, 'results', 'ultc_10bus_sign');

if exist(matpower_dir, 'dir')
    addpath(genpath(matpower_dir));
end
if ~exist(out_dir, 'dir')
    mkdir(out_dir);
end

if ~exist(solved_file, 'file')
    error('validate_ultc_10bus_sign:missingSolvedRaw', ...
        'Missing PSS/E solved RAW: %s', solved_file);
end

mpopt = mpoption('verbose', 0, 'out.all', 0, 'exp.use_legacy_core', 0);
base = case10_psse_ultc_sign();
tic;
[mp_res, mp_success] = runpf_psse(base, mpopt);
matpower_seconds = toc;

psse_sol = psse2mpc(solved_file, 0, 34);
ctrl = mp_res.psse.xfmr.control;
[labels, kinds, raw_rows, windings, reg_buses, control_rows] = ...
    fixture_controls(base);
initial_windv_all = parse_fixture_windv_from_raw(raw_file);
psse_windv_all = parse_fixture_windv_from_raw(solved_file);
psse_first_delta_tap = parse_first_psse_tap_delta(log_file);

n = numel(labels);
psse_vm = NaN(n, 1);
mp_vm = NaN(n, 1);
psse_windv = NaN(n, 1);
mp_windv = NaN(n, 1);
initial_windv = NaN(n, 1);
matpower_side_sign = NaN(n, 1);
for k = 1:n
    psse_vm(k) = bus_vm(psse_sol, reg_buses(k));
    mp_vm(k) = bus_vm(mp_res, reg_buses(k));
    psse_windv(k) = psse_windv_all(k);
    initial_windv(k) = initial_windv_all(k);
    mp_windv(k) = ctrl.final_windv(control_rows(k));
    matpower_side_sign(k) = ctrl.final_tap(control_rows(k)) - initial_tap_for(base, ...
        kinds(k), raw_rows(k), windings(k));
end

tap_delta_psse = psse_windv - initial_windv;
tap_delta_mp = mp_windv - initial_windv;
direction_checked = signnz(matpower_side_sign) ~= 0;
tap_direction_match = signnz(matpower_side_sign) == ...
    signnz(psse_first_delta_tap);
windv_abs_diff = abs(mp_windv - psse_windv);
vm_abs_diff = abs(mp_vm - psse_vm);
final_state_match = windv_abs_diff < 1e-9 & vm_abs_diff < 5e-3;
passed = mp_success && all(final_state_match) && ...
    all(tap_direction_match(direction_checked));

rows = table(labels(:), kinds(:), raw_rows(:), windings(:), reg_buses(:), ...
    initial_windv(:), psse_windv(:), mp_windv(:), tap_delta_psse(:), ...
    tap_delta_mp(:), psse_first_delta_tap(:), direction_checked(:), ...
    tap_direction_match(:), psse_vm(:), mp_vm(:), ...
    vm_abs_diff(:), windv_abs_diff(:), matpower_side_sign(:), ...
    final_state_match(:), ...
    'VariableNames', {'label', 'kind', 'raw_row', 'winding', 'reg_bus', ...
    'initial_windv', 'psse_windv', 'matpower_windv', 'psse_delta_windv', ...
    'matpower_delta_windv', 'psse_first_delta_tap', 'direction_checked', ...
    'tap_direction_match', 'psse_vm', 'matpower_vm', 'vm_abs_diff', ...
    'windv_abs_diff', 'matpower_delta_tap', 'final_state_match'});

csv_path = fullfile(out_dir, 'ultc_10bus_sign_validation.csv');
md_path = fullfile(out_dir, 'ultc_10bus_sign_validation.md');
mat_path = fullfile(out_dir, 'ultc_10bus_sign_validation.mat');
write_table_csv(rows, csv_path);
write_markdown(md_path, rows, raw_file, solved_file, log_file, ...
    mp_success, matpower_seconds, passed);

summary = struct();
summary.passed = passed;
summary.matpower_success = logical(mp_success);
summary.matpower_seconds = matpower_seconds;
summary.csv_path = csv_path;
summary.md_path = md_path;
summary.mat_path = mat_path;
summary.rows = rows;

save(mat_path, 'summary', 'rows', 'mp_res', 'psse_sol');

fprintf('10-bus ULTC sign validation passed=%d matpower_success=%d seconds=%.3f\n', ...
    passed, mp_success, matpower_seconds);
fprintf('CSV: %s\n', csv_path);
fprintf('Report: %s\n', md_path);

function [labels, kinds, raw_rows, windings, reg_buses, control_rows] = ...
    fixture_controls(mpc)
c2 = mpc.psse.xfmr.two.col;
c3 = mpc.psse.xfmr.three.col;
labels = {'T1 CW1 local'; 'T2 CW1 remote'; 'T3 CW1 own-side'; ...
    'T4 CW2 local'; 'T5 3W W2 CW2'};
kinds = [2; 2; 2; 2; 3];
raw_rows = [1; 2; 3; 4; 1];
windings = [1; 1; 1; 1; 2];
control_rows = [1; 2; 3; 4; 6];
reg_buses = [
    abs(mpc.psse.xfmr.two.num(1, c2.cont1));
    abs(mpc.psse.xfmr.two.num(2, c2.cont1));
    abs(mpc.psse.xfmr.two.num(3, c2.cont1));
    abs(mpc.psse.xfmr.two.num(4, c2.cont1));
    abs(mpc.psse.xfmr.three.num(1, c3.cont2))
];

function vm = bus_vm(mpc, ext_bus)
[~, ~, ~, ~, BUS_I, ~, ~, ~, ~, ~, ~, VM] = idx_bus;
idx = find(mpc.bus(:, BUS_I) == ext_bus, 1);
if isempty(idx)
    vm = NaN;
else
    vm = mpc.bus(idx, VM);
end

function windv = parse_fixture_windv_from_raw(file_name)
lines = splitlines(string(fileread(file_name)));
lines = lines(~startsWith(strtrim(lines), '@'));
start_idx = find(contains(lines, 'BEGIN TRANSFORMER DATA'), 1);
if isempty(start_idx)
    error('validate_ultc_10bus_sign:noTransformerSection', ...
        'No transformer section found in %s.', file_name);
end
windv = NaN(5, 1);
idx = start_idx + 1;
record = 0;
while idx <= numel(lines)
    line = strip(lines(idx));
    if startsWith(line, '0 /')
        break;
    end
    if line == ""
        idx = idx + 1;
        continue;
    end
    header = parse_numbers(line);
    record = record + 1;
    is_three = numel(header) >= 3 && header(3) ~= 0;
    if is_three
        w1 = parse_numbers(lines(idx + 2)); %#ok<NASGU>
        w2 = parse_numbers(lines(idx + 3));
        if record == 5
            windv(5) = w2(1);
        end
        idx = idx + 6;
    else
        w1 = parse_numbers(lines(idx + 2));
        if record <= 4
            windv(record) = w1(1);
        end
        idx = idx + 4;
    end
end

function delta = parse_first_psse_tap_delta(file_name)
delta = NaN(5, 1);
lines = splitlines(string(fileread(file_name)));
start_idx = find(contains(lines, 'TAP RATIOS ADJUSTED:'), 1);
if isempty(start_idx)
    return;
end
for kk = start_idx + 1:numel(lines)
    line = lines(kk);
    if contains(lower(line), 'tap ratios adjusted')
        break;
    end
    nums = parse_numbers(line);
    if numel(nums) < 3
        continue;
    end
    change = nums(end);
    if contains(line, 'LOCAL115')
        delta(1) = change;
    elseif contains(line, 'REMOTE_TAP')
        delta(2) = change;
    elseif contains(line, 'REV_LOCAL')
        delta(3) = change;
    elseif contains(line, 'CW2_LOCAL')
        delta(4) = change;
    elseif contains(line, 'W3_115')
        delta(5) = change;
    end
end

function nums = parse_numbers(line)
matches = regexp(char(line), ...
    '[-+]?(?:\d+\.\d*|\.\d+|\d+)(?:[Ee][-+]?\d+)?', 'match');
nums = str2double(matches);

function tap = initial_tap_for(mpc, kind, raw_row, winding)
[~, ~, ~, ~, ~, ~, ~, ~, TAP] = idx_brch;
if kind == 2
    br = mpc.psse.xfmr.two.branch_idx(raw_row);
else
    br = mpc.psse.xfmr.three.branch_idx(raw_row, winding);
end
tap = mpc.branch(br, TAP);
if tap == 0
    tap = 1;
end

function s = signnz(x)
s = zeros(size(x));
s(x > 1e-9) = 1;
s(x < -1e-9) = -1;

function write_table_csv(rows, file_name)
fid = fopen(file_name, 'w');
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, ['label,kind,raw_row,winding,reg_bus,initial_windv,' ...
    'psse_windv,matpower_windv,psse_delta_windv,' ...
    'matpower_delta_windv,psse_first_delta_tap,direction_checked,' ...
    'tap_direction_match,' ...
    'psse_vm,matpower_vm,' ...
    'vm_abs_diff,windv_abs_diff,matpower_delta_tap,final_state_match\n']);
for kk = 1:height(rows)
    fprintf(fid, ['%s,%d,%d,%d,%d,%.12g,%.12g,%.12g,%.12g,%.12g,' ...
        '%.12g,%d,%d,%.12g,%.12g,%.12g,%.12g,%.12g,%d\n'], ...
        rows.label{kk}, rows.kind(kk), rows.raw_row(kk), rows.winding(kk), ...
        rows.reg_bus(kk), rows.initial_windv(kk), rows.psse_windv(kk), ...
        rows.matpower_windv(kk), rows.psse_delta_windv(kk), ...
        rows.matpower_delta_windv(kk), rows.psse_first_delta_tap(kk), ...
        rows.direction_checked(kk), ...
        rows.tap_direction_match(kk), ...
        rows.psse_vm(kk), rows.matpower_vm(kk), rows.vm_abs_diff(kk), ...
        rows.windv_abs_diff(kk), rows.matpower_delta_tap(kk), ...
        rows.final_state_match(kk));
end

function write_markdown(file_name, rows, raw_file, solved_file, ...
    log_file, mp_success, matpower_seconds, passed)
fid = fopen(file_name, 'w');
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, '# 10-Bus ULTC Tap-Sign Validation\n\n');
fprintf(fid, '- RAW fixture: `%s`\n', raw_file);
fprintf(fid, '- PSS/E solved RAW: `%s`\n', solved_file);
fprintf(fid, '- PSS/E log: `%s`\n', log_file);
fprintf(fid, '- MATPOWER runpf_psse success: `%d`\n', mp_success);
fprintf(fid, '- MATPOWER validation time: `%.3f s`\n', matpower_seconds);
fprintf(fid, '- Overall pass: `%d`\n\n', passed);
fprintf(fid, ['`Direction match` is evaluated only when MATPOWER has a ' ...
    'nonzero final tap movement. Cycling local controls can match PSS/E ' ...
    'in final state after returning to the starting tap.\n\n']);
fprintf(fid, ['| Control | Reg bus | Initial WINDV | PSS/E WINDV | ' ...
    'MATPOWER WINDV | PSS/E first dTap | MATPOWER dTap | Direction checked | Direction match | Final match | PSS/E VM | MATPOWER VM | dVM |\n']);
fprintf(fid, '|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|\n');
for kk = 1:height(rows)
    fprintf(fid, ['| %s | %d | %.6g | %.6g | %.6g | %.6g | %.6g | ' ...
        '%d | %d | %d | %.6f | %.6f | %.3g |\n'], ...
        rows.label{kk}, rows.reg_bus(kk), rows.initial_windv(kk), ...
        rows.psse_windv(kk), rows.matpower_windv(kk), ...
        rows.psse_first_delta_tap(kk), rows.matpower_delta_tap(kk), ...
        rows.direction_checked(kk), rows.tap_direction_match(kk), ...
        rows.final_state_match(kk), rows.psse_vm(kk), rows.matpower_vm(kk), ...
        rows.vm_abs_diff(kk));
end
