function out = compare_psse_validation_suite_controls()
% compare_psse_validation_suite_controls - Extra suite-level control checks.
%
% This is an auxiliary report for the generated psse_validation_suite. It does
% not modify MATPOWER algorithms or original fixtures.

tool_dir = fileparts(mfilename('fullpath'));
audit_dir = fileparts(tool_dir);
root_dir = fileparts(audit_dir);
suite_dir = fullfile(audit_dir, 'psse_validation_suite');
mp_dir = fullfile(root_dir, 'matpower');
addpath(fullfile(mp_dir, 'lib'));

matrix_path = fullfile(suite_dir, 'validation_matrix.csv');
main_csv = fullfile(audit_dir, 'results', 'psse_cli_comparison', ...
    'auditoria_all_comparison_latest.csv');
out_csv = fullfile(suite_dir, 'suite_control_comparison.csv');
out_md = fullfile(suite_dir, 'suite_control_comparison.md');
out_tap_csv = fullfile(suite_dir, 'suite_tap_comparison.csv');

matrix = readtable(matrix_path, 'TextType', 'string');
main_cmp = readtable(main_csv, 'TextType', 'string');
raw_files = dir(fullfile(suite_dir, '*.raw'));
mpopt = mpoption('verbose', 0, 'out.all', 0);

rows = repmat(row_template(), numel(raw_files), 1);
tap_rows = repmat(tap_row_template(), 0, 1);

for k = 1:numel(raw_files)
    name = erase(string(raw_files(k).name), ".raw");
    raw_path = fullfile(raw_files(k).folder, raw_files(k).name);
    solved_raw = fullfile(suite_dir, 'solved_raw', name + "_solved.raw");
    log_path = fullfile(suite_dir, 'logs', name + ".log");
    m = matrix(matrix.case_name == name, :);
    c = main_cmp(main_cmp.case_name == "psse_validation_suite/" + name, :);

    rows(k).case_name = name;
    if ~isempty(m)
        rows(k).category = m.category(1);
        rows(k).control_families = m.control_families(1);
    end
    if ~isempty(c) && ismember('max_abs_binit', c.Properties.VariableNames)
        rows(k).max_abs_binit = str2double(string(c.max_abs_binit(1)));
        rows(k).mp_success = str2double(string(c.run_success(1)));
    end

    families = rows(k).control_families;
    needs_run = contains(families, "ULTC") || contains(families, "FACTS") || ...
        contains(families, "TWODC");

    psse_taps = parse_transformer_taps(solved_raw);
    rows(k).psse_taps = join_numbers(psse_taps);
    rows(k).psse_tap_count = numel(psse_taps);
    rows(k).psse_twodc_taps = join_numbers(parse_twodc_taps(solved_raw));
    rows(k).psse_facts_q_abs = join_numbers(abs(parse_facts_q_from_log(log_path)));

    if ~needs_run
        rows(k).note = "main comparison covers VM/VA/QG/SWSHNT; no extra tap/FACTS/TWODC state";
        continue;
    end

    try
        [mpc, ~] = psse2mpc(raw_path, 0, 34);
        [r, success] = runpf_psse(mpc, mpopt);
        mp_taps = mp_xfmr_taps(r);
        rows(k).mp_success = double(success);
        rows(k).mp_taps = join_numbers(mp_taps);
        rows(k).mp_tap_count = numel(mp_taps);
        rows(k).tap_count_status = tap_count_status(psse_taps, mp_taps);
        tap_rows = [tap_rows; make_tap_rows(name, psse_taps, mp_taps)]; %#ok<AGROW>
        rows(k).mp_twodc_taps = join_numbers(mp_twodc_taps(r));
        rows(k).mp_facts_q_abs = join_numbers(abs(mp_facts_q(r)));
        rows(k).max_abs_tap_diff = max_pair_abs_diff( ...
            psse_taps, mp_taps);
        rows(k).max_abs_twodc_tap_diff = max_pair_abs_diff( ...
            parse_twodc_taps(solved_raw), mp_twodc_taps(r));
        rows(k).max_abs_facts_q_abs_diff = max_pair_abs_diff( ...
            abs(parse_facts_q_from_log(log_path)), abs(mp_facts_q(r)));
    catch err
        rows(k).note = string(getReport(err, 'basic', 'hyperlinks', 'off'));
    end
end

out = struct();
out.rows = rows;
out.tap_rows = tap_rows;
out.csv_path = out_csv;
out.report_path = out_md;
out.tap_csv_path = out_tap_csv;

T = struct2table(rows);
writetable(T, out_csv);
tapT = struct2table(tap_rows);
writetable(tapT, out_tap_csv);
write_report(rows, out_md);

fprintf('Wrote suite control CSV: %s\n', out_csv);
fprintf('Wrote suite tap CSV: %s\n', out_tap_csv);
fprintf('Wrote suite control report: %s\n', out_md);

function row = row_template()
row = struct( ...
    'case_name', "", ...
    'category', "", ...
    'control_families', "", ...
    'mp_success', NaN, ...
    'psse_taps', "", ...
    'mp_taps', "", ...
    'psse_tap_count', NaN, ...
    'mp_tap_count', NaN, ...
    'tap_count_status', "", ...
    'max_abs_tap_diff', NaN, ...
    'psse_twodc_taps', "", ...
    'mp_twodc_taps', "", ...
    'max_abs_twodc_tap_diff', NaN, ...
    'psse_facts_q_abs', "", ...
    'mp_facts_q_abs', "", ...
    'max_abs_facts_q_abs_diff', NaN, ...
    'max_abs_binit', NaN, ...
    'note', "");

function row = tap_row_template()
row = struct( ...
    'case_name', "", ...
    'tap_position', NaN, ...
    'psse_tap', NaN, ...
    'mp_tap', NaN, ...
    'abs_diff', NaN, ...
    'count_status', "");

function nums = parse_transformer_taps(raw_path)
two_taps = [];
three_taps = zeros(0, 3);
if exist(raw_path, 'file') ~= 2
    nums = [];
    return;
end
lines = section_lines(raw_path, 'TRANSFORMER DATA');
idx = 1;
while idx <= numel(lines)
    line = strtrim(lines{idx});
    if isempty(line) || startsWith(line, '@')
        idx = idx + 1;
        continue;
    end
    vals = numbers_in_line(line);
    if numel(vals) >= 3
        first_tap = NaN;
        if idx + 2 <= numel(lines)
            w1 = numbers_in_line(lines{idx + 2});
            if ~isempty(w1)
                first_tap = w1(1);
            end
        end
        if vals(3) ~= 0
            row = [first_tap NaN NaN];
            if idx + 3 <= numel(lines)
                w2 = numbers_in_line(lines{idx + 3});
                if ~isempty(w2)
                    row(2) = w2(1);
                end
            end
            if idx + 4 <= numel(lines)
                w3 = numbers_in_line(lines{idx + 4});
                if ~isempty(w3)
                    row(3) = w3(1);
                end
            end
            three_taps(end+1, :) = row; %#ok<AGROW>
            idx = idx + 5;
        else
            two_taps(end+1) = first_tap; %#ok<AGROW>
            idx = idx + 4;
        end
    else
        idx = idx + 1;
    end
end
% Match mp.psse_xfmr_states ordering: all 2W rows first, then 3W W1 rows,
% then 3W W2 rows, then 3W W3 rows.
nums = [two_taps three_taps(:, 1).' three_taps(:, 2).' ...
    three_taps(:, 3).'];
nums = nums(~isnan(nums));

function nums = parse_twodc_taps(raw_path)
nums = [];
if exist(raw_path, 'file') ~= 2
    return;
end
lines = section_lines(raw_path, 'TWO-TERMINAL DC DATA');
data = {};
for i = 1:numel(lines)
    line = strtrim(lines{i});
    if isempty(line) || startsWith(line, '@')
        continue;
    end
    data{end+1} = line; %#ok<AGROW>
end
idx = 1;
while idx + 2 <= numel(data)
    r = numbers_in_line(data{idx + 1});
    inv = numbers_in_line(data{idx + 2});
    if numel(r) >= 9
        nums(end+1) = r(9); %#ok<AGROW>
    end
    if numel(inv) >= 9
        nums(end+1) = inv(9); %#ok<AGROW>
    end
    idx = idx + 3;
end

function q = parse_facts_q_from_log(log_path)
q = [];
if exist(log_path, 'file') ~= 2
    return;
end
txt = fileread(log_path);
expr = 'TO\s+STATCON\s+SHUNT\s+STA\s+([-+]?\d+(?:\.\d+)?)\s+([-+]?\d+(?:\.\d+)?)';
tokens = regexp(txt, expr, 'tokens');
for i = 1:numel(tokens)
    q(end+1) = str2double(tokens{i}{2}); %#ok<AGROW>
end

function taps = mp_xfmr_taps(r)
taps = [];
if isfield(r, 'psse') && isfield(r.psse, 'xfmr') && ...
        isfield(r.psse.xfmr, 'control')
    c = r.psse.xfmr.control;
    if isfield(c, 'final_windv')
        taps = c.final_windv(:).';
    elseif isfield(c, 'final_tap')
        taps = c.final_tap(:).';
    end
end

function taps = mp_twodc_taps(r)
taps = [];
if isfield(r, 'psse') && isfield(r.psse, 'twodc') && ...
        isfield(r.psse.twodc, 'control')
    c = r.psse.twodc.control;
    if isfield(c, 'tapr')
        taps = [taps c.tapr(:).'];
    end
    if isfield(c, 'tapi')
        taps = [taps c.tapi(:).'];
    end
end

function q = mp_facts_q(r)
q = [];
if isfield(r, 'psse') && isfield(r.psse, 'facts') && ...
        isfield(r.psse.facts, 'control')
    c = r.psse.facts.control;
    if isfield(c, 'qinj')
        q = c.qinj(:).';
    end
end

function d = max_pair_abs_diff(a, b)
if isempty(a) || isempty(b)
    d = NaN;
    return;
end
n = min(numel(a), numel(b));
d = max(abs(a(1:n) - b(1:n)));

function status = tap_count_status(a, b)
if isempty(a) && isempty(b)
    status = "no_taps";
elseif numel(a) == numel(b)
    status = "match";
else
    status = "count_mismatch";
end

function rows = make_tap_rows(case_name, psse_taps, mp_taps)
n = max(numel(psse_taps), numel(mp_taps));
rows = repmat(tap_row_template(), n, 1);
status = tap_count_status(psse_taps, mp_taps);
for i = 1:n
    rows(i).case_name = string(case_name);
    rows(i).tap_position = i;
    rows(i).count_status = status;
    if i <= numel(psse_taps)
        rows(i).psse_tap = psse_taps(i);
    end
    if i <= numel(mp_taps)
        rows(i).mp_tap = mp_taps(i);
    end
    if i <= numel(psse_taps) && i <= numel(mp_taps)
        rows(i).abs_diff = abs(psse_taps(i) - mp_taps(i));
    end
end

function lines = section_lines(path, section)
lines = {};
txt = fileread(path);
all_lines = regexp(txt, '\r\n|\n|\r', 'split');
inside = false;
for i = 1:numel(all_lines)
    line = all_lines{i};
    if contains(line, ['BEGIN ' section])
        inside = true;
        continue;
    end
    if inside && contains(line, ['END OF ' section])
        break;
    end
    if inside
        lines{end+1} = line; %#ok<AGROW>
    end
end

function nums = numbers_in_line(line)
matches = regexp(line, '[-+]?\d+(?:\.\d+)?(?:[Ee][-+]?\d+)?', 'match');
nums = str2double(matches);

function s = join_numbers(nums)
if isempty(nums)
    s = "";
else
    s = string(strjoin(compose('%.6g', nums), ';'));
end

function write_report(rows, path)
fid = fopen(path, 'w');
if fid < 0
    error('Could not open report path: %s', path);
end
cleaner = onCleanup(@() fclose(fid));
fprintf(fid, '# Suite Control-State Comparison\n\n');
fprintf(fid, 'This auxiliary report complements `compare_psse_cli_cases(''AUDITORIA_ALL'')` for `psse_validation_suite` only. It compares switched-shunt deltas from the main CSV, transformer/two-terminal-DC taps from solved RAW exports, and FACTS reactive magnitudes parsed from PSS/E logs against `runpf_psse` state fields when available.\n\n');
fprintf(fid, '| case | category | success | tap count | tap count status | tap diff | TWODC tap diff | FACTS | BINIT diff | notes |\n');
fprintf(fid, '|---|---|---:|---:|---|---:|---:|---:|---:|---|\n');
for i = 1:numel(rows)
    fprintf(fid, '| %s | %s | %.0f | %.0f/%.0f | %s | %.6g | %.6g | %.6g | %.6g | %s |\n', ...
        rows(i).case_name, rows(i).category, rows(i).mp_success, ...
        rows(i).psse_tap_count, rows(i).mp_tap_count, ...
        rows(i).tap_count_status, rows(i).max_abs_tap_diff, ...
        rows(i).max_abs_twodc_tap_diff, ...
        rows(i).max_abs_facts_q_abs_diff, rows(i).max_abs_binit, ...
        replace(rows(i).note, "|", "/"));
end
