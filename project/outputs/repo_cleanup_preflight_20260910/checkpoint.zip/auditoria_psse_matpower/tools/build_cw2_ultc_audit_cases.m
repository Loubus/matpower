function cases = build_cw2_ultc_audit_cases()
% build_cw2_ultc_audit_cases - Generate targeted 3W CW=2 ULTC RAW cases.

root_dir = fileparts(fileparts(fileparts(mfilename('fullpath'))));
out_dir = fullfile(root_dir, 'PSSE', 'CW2_AUDIT');
if exist(out_dir, 'dir') ~= 7
    mkdir(out_dir);
end

cases = case_specs();
for k = 1:numel(cases)
    raw = render_case(cases(k));
    path = fullfile(out_dir, [cases(k).name '.raw']);
    fid = fopen(path, 'w');
    if fid < 0
        error('build_cw2_ultc_audit_cases:open', ...
            'Could not open %s for writing.', path);
    end
    cleanup = onCleanup(@() fclose(fid));
    fprintf(fid, '%s', raw);
    clear cleanup;
    cases(k).path = path;
end

fprintf('Generated %d CW=2 ULTC audit RAW cases in %s\n', ...
    numel(cases), out_dir);

function cases = case_specs()
base = struct( ...
    'name', '', ...
    'title', '', ...
    'load2', [100 50], ...
    'load3', [10 3], ...
    'load4', [0 0], ...
    'remote', false, ...
    'tab', false, ...
    'two_transformers', false, ...
    'controls', default_controls());

cases = repmat(base, 10, 1);

cases(1) = with_control(base, 'cw2_audit_01_w1_remote_low', ...
    'W1 CW=2 remote low-voltage control, CONT=-2', 1, -2, ...
    0.99, 1.01, [100 50], [10 3], [0 0], false, false);
cases(2) = with_control(base, 'cw2_audit_02_w1_remote_high', ...
    'W1 CW=2 remote high-voltage control, CONT=-2', 1, -2, ...
    0.94, 0.96, [45 15], [5 1], [0 0], false, false);
cases(3) = with_control(base, 'cw2_audit_03_w2_local_low', ...
    'W2 CW=2 local low-voltage control, CONT=2', 2, 2, ...
    0.98, 1.00, [100 50], [10 3], [0 0], false, false);
cases(4) = with_control(base, 'cw2_audit_04_w2_local_high', ...
    'W2 CW=2 local high-voltage control, CONT=2', 2, 2, ...
    0.84, 0.86, [45 15], [5 1], [0 0], false, false);
cases(5) = with_control(base, 'cw2_audit_05_w2_remote_low_neg', ...
    'W2 CW=2 remote low-voltage control, CONT=-4', 2, -4, ...
    0.98, 1.00, [30 10], [5 1], [80 35], true, false);
cases(6) = with_control(base, 'cw2_audit_06_w2_remote_low_pos', ...
    'W2 CW=2 remote low-voltage control, CONT=4', 2, 4, ...
    0.98, 1.00, [30 10], [5 1], [80 35], true, false);
cases(7) = with_control(base, 'cw2_audit_07_w3_local_low', ...
    'W3 CW=2 local low-voltage control, CONT=3', 3, 3, ...
    0.98, 1.00, [80 30], [40 18], [0 0], false, false);
cases(8) = with_control(base, 'cw2_audit_08_w3_local_high', ...
    'W3 CW=2 local high-voltage control, CONT=3', 3, 3, ...
    0.84, 0.86, [40 12], [5 1], [0 0], false, false);
cases(9) = with_control(base, 'cw2_audit_09_w1_tab_remote_low', ...
    'W1 CW=2 remote low-voltage control with TAB=1', 1, -2, ...
    0.99, 1.01, [100 50], [10 3], [0 0], false, true);
cases(10) = base;
cases(10).name = 'cw2_audit_10_shared_two_3w';
cases(10).title = 'Two 3W CW=2 W2 controls share remote regulated bus 6';
cases(10).two_transformers = true;

function controls = default_controls()
controls = repmat(struct( ...
    'cod', 0, 'cont', 0, 'rma', 0, 'rmi', 0, ...
    'vma', 1.10, 'vmi', 0.90, 'ntp', 33, 'tab', 0), 3, 1);
basekv = [230; 115; 13.8];
for w = 1:3
    controls(w).rma = 1.10 * basekv(w);
    controls(w).rmi = 0.90 * basekv(w);
end

function c = with_control(base, name, title, winding, cont, vmi, vma, ...
        load2, load3, load4, remote, tab)
c = base;
c.name = name;
c.title = title;
c.load2 = load2;
c.load3 = load3;
c.load4 = load4;
c.remote = remote;
c.tab = tab;
c.controls = default_controls();
c.controls(winding).cod = 1;
c.controls(winding).cont = cont;
c.controls(winding).vmi = vmi;
c.controls(winding).vma = vma;
c.controls(winding).ntp = 9;
if tab
    for w = 1:3
        c.controls(w).tab = 1;
    end
end

function raw = render_case(c)
if c.two_transformers
    raw = render_shared_case(c);
    return;
end

lines = common_header(c);
lines{end+1} = '0 / END OF SYSTEM-WIDE DATA, BEGIN BUS DATA';
lines{end+1} = bus_line(1, 'SOURCE', 230, 3);
lines{end+1} = bus_line(2, 'LOAD', 115, 1);
lines{end+1} = bus_line(3, 'TERTIARY', 13.8, 1);
if c.remote
    lines{end+1} = bus_line(4, 'REMOTE115', 115, 1);
end
lines{end+1} = '0 / END OF BUS DATA, BEGIN LOAD DATA';
lines = add_load(lines, 2, c.load2);
lines = add_load(lines, 3, c.load3);
if c.remote
    lines = add_load(lines, 4, c.load4);
end
lines{end+1} = '0 / END OF LOAD DATA, BEGIN FIXED SHUNT DATA';
lines{end+1} = '0 / END OF FIXED SHUNT DATA, BEGIN GENERATOR DATA';
pg = sum([c.load2(1) c.load3(1) c.load4(1)]);
lines{end+1} = sprintf("1,'1 ',%10.3f,     0.000,   400.000,  -400.000,1.00000,     1,   100.000,0,0,0,0,1.00000,1,100.0,400.000,0.000,1,1.0000", pg);
lines{end+1} = '0 / END OF GENERATOR DATA, BEGIN BRANCH DATA';
if c.remote
    lines{end+1} = "2,4,'1 ', 0.01000, 0.08000,   0.00000,'REMOTE PATH                              ', 250.00,250.00,250.00,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,1,1.0000";
end
lines{end+1} = '0 / END OF BRANCH DATA, BEGIN SYSTEM SWITCHING DEVICE DATA';
lines{end+1} = '0 / END OF SYSTEM SWITCHING DEVICE DATA, BEGIN TRANSFORMER DATA';
lines = add_transformer(lines, 1, 2, 3, '1 ', '3W CW2 AUDIT', c.controls);
lines = add_tail(lines, c.tab);
raw = join_lines(lines);

function raw = render_shared_case(c)
lines = common_header(c);
lines{end+1} = '0 / END OF SYSTEM-WIDE DATA, BEGIN BUS DATA';
lines{end+1} = bus_line(1, 'SRC230', 230, 3);
lines{end+1} = bus_line(2, 'W2A115', 115, 1);
lines{end+1} = bus_line(3, 'W3A013', 13.8, 1);
lines{end+1} = bus_line(4, 'W2B115', 115, 1);
lines{end+1} = bus_line(5, 'W3B013', 13.8, 1);
lines{end+1} = bus_line(6, 'SHARED115', 115, 1);
lines{end+1} = '0 / END OF BUS DATA, BEGIN LOAD DATA';
lines = add_load(lines, 3, [6 2]);
lines = add_load(lines, 5, [6 2]);
lines = add_load(lines, 6, [120 55]);
lines{end+1} = '0 / END OF LOAD DATA, BEGIN FIXED SHUNT DATA';
lines{end+1} = '0 / END OF FIXED SHUNT DATA, BEGIN GENERATOR DATA';
lines{end+1} = "1,'1 ',   132.000,     0.000,   400.000,  -400.000,1.00000,     1,   100.000,0,0,0,0,1.00000,1,100.0,400.000,0.000,1,1.0000";
lines{end+1} = '0 / END OF GENERATOR DATA, BEGIN BRANCH DATA';
lines{end+1} = "2,6,'1 ', 0.01000, 0.08000,   0.00000,'PATH A                                  ', 250.00,250.00,250.00,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,1,1.0000";
lines{end+1} = "4,6,'1 ', 0.01000, 0.08000,   0.00000,'PATH B                                  ', 250.00,250.00,250.00,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,1,1.0000";
lines{end+1} = '0 / END OF BRANCH DATA, BEGIN SYSTEM SWITCHING DEVICE DATA';
lines{end+1} = '0 / END OF SYSTEM SWITCHING DEVICE DATA, BEGIN TRANSFORMER DATA';
ctrl = default_controls();
ctrl(2).cod = 1; ctrl(2).cont = -6; ctrl(2).vmi = 0.96;
ctrl(2).vma = 0.99; ctrl(2).ntp = 5;
lines = add_transformer(lines, 1, 2, 3, '1 ', 'T3WA REG SHARED', ctrl);
lines = add_transformer(lines, 1, 4, 5, '1 ', 'T3WB REG SHARED', ctrl);
lines = add_tail(lines, false);
raw = join_lines(lines);

function lines = common_header(c)
lines = {
    '@!IC, SBASE,REV,XFRRAT,NXFRAT,BASFRQ';
    '0, 100.00, 34, 0, 1, 50.00 / PSS(R)E-34.9';
    c.title;
    'Generated CW=2 ULTC audit fixture';
    'GENERAL, THRSHZ=0.0001';
    'NEWTON, ITMXN=80, VCTOLV=0.00001';
    'ADJUST, MXTPSS=40';
    'SOLVER, FNSL, ACTAPS=1, SWSHNT=0, FLATST=1, VARLIM=-1'
    };

function s = bus_line(num, name, basekv, type)
s = sprintf("%d,'%-12s',%9.4f,%d,   1,   1,   1,1.00000,   0.0000,1.10000,0.90000,1.10000,0.90000", ...
    num, name, basekv, type);

function lines = add_load(lines, bus, load)
if load(1) == 0 && load(2) == 0
    return;
end
lines{end+1} = sprintf("%d,'1 ',1,1,1,%8.3f,%7.3f, 0.000, 0.000, 0.000, 0.000,1,1,0,0,0,0", ...
    bus, load(1), load(2));

function lines = add_transformer(lines, i, j, k, ckt, name, ctrl)
lines{end+1} = sprintf("%d,%d,%d,'%s',2,1,1, 0.00000, 0.00000,1,'%-40s',1,1,1.0000,0,1.0000,0,1.0000,0,1.0000,'            ',0", ...
    i, j, k, ckt, name);
lines{end+1} = '0.02500, 0.22000, 100.00, 0.03500, 0.26000, 100.00, 0.03000, 0.24000, 100.00,1.00000, 0.0000';
lines{end+1} = winding_line(230, 250, ctrl(1));
lines{end+1} = winding_line(115, 250, ctrl(2));
lines{end+1} = winding_line(13.8, 100, ctrl(3));

function s = winding_line(basekv, rate, c)
s = sprintf('%8.4f, 0.000, 0.000, %6.2f,%6.2f,%6.2f,0,0,0,0,0,0,0,0,0,%2d,%3d,%8.3f,%8.3f,%7.5f,%7.5f,%d,%d,0.00000,0.00000,0.000,0', ...
    basekv, rate, rate, rate, c.cod, c.cont, c.rma, c.rmi, ...
    c.vma, c.vmi, c.ntp, c.tab);

function lines = add_tail(lines, has_tab)
lines{end+1} = '0 / END OF TRANSFORMER DATA, BEGIN AREA DATA';
lines{end+1} = '0 / END OF AREA DATA, BEGIN TWO-TERMINAL DC DATA';
lines{end+1} = '0 / END OF TWO-TERMINAL DC DATA, BEGIN VSC DC LINE DATA';
lines{end+1} = '0 / END OF VSC DC LINE DATA, BEGIN IMPEDANCE CORRECTION DATA';
if has_tab
    lines{end+1} = '1, 0.90000, 0.90000, 0.00000, 1.10000, 1.10000, 0.00000, 0.00000, 0.00000, 0.00000';
end
lines{end+1} = '0 / END OF IMPEDANCE CORRECTION DATA, BEGIN MULTI-TERMINAL DC DATA';
lines{end+1} = '0 / END OF MULTI-TERMINAL DC DATA, BEGIN MULTI-SECTION LINE DATA';
lines{end+1} = '0 / END OF MULTI-SECTION LINE DATA, BEGIN ZONE DATA';
lines{end+1} = '0 / END OF ZONE DATA, BEGIN INTER-AREA TRANSFER DATA';
lines{end+1} = '0 / END OF INTER-AREA TRANSFER DATA, BEGIN OWNER DATA';
lines{end+1} = '0 / END OF OWNER DATA, BEGIN FACTS DEVICE DATA';
lines{end+1} = '0 / END OF FACTS DEVICE DATA, BEGIN SWITCHED SHUNT DATA';
lines{end+1} = '0 / END OF SWITCHED SHUNT DATA, BEGIN GNE DATA';
lines{end+1} = '0 / END OF GNE DATA, BEGIN INDUCTION MACHINE DATA';
lines{end+1} = '0 / END OF INDUCTION MACHINE DATA, BEGIN SUBSTATION DATA';
lines{end+1} = '0 / END OF SUBSTATION DATA';

function txt = join_lines(lines)
txt = strjoin(cellstr(lines(:)), newline);
txt = [txt newline];
