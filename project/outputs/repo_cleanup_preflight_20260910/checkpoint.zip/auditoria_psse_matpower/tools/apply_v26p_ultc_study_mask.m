function [mpc, mask] = apply_v26p_ultc_study_mask(mpc, rows)
% apply_v26p_ultc_study_mask - Locks proven-bad TRANSENER ULTC rows.
%
% This helper is intentionally study-specific. It preserves ACTAPS=1 for
% other transformer controls while locking the 3-winding star-equivalent rows
% whose singleton rebuilds were proven invalid in the full V26p case.

if nargin < 2 || isempty(rows)
    rows = v26p_toxic_ultc_rows();
end

st = mp.psse_xfmr_states(mpc);
rows = unique(rows(:));
rows = rows(rows >= 1 & rows <= st.n);

locked = false(st.n, 1);
if isfield(mpc.psse.xfmr, 'control_locked_out') && ...
        numel(mpc.psse.xfmr.control_locked_out) == st.n
    locked = logical(mpc.psse.xfmr.control_locked_out(:));
end
locked(rows) = true;

mpc.psse.xfmr.control_locked_out = locked;
mpc.psse.xfmr.control_study_locked_rows = rows;
mpc.psse.xfmr.control_study_lock_label = ...
    'TRANSENER V26p 3-winding star-equivalent ULTC study mask';

mask = struct();
mask.rows = rows;
mask.count = numel(rows);
mask.label = mpc.psse.xfmr.control_study_lock_label;
mask.kind = st.kind(rows);
mask.raw_row = st.raw_row(rows);
mask.winding = st.winding(rows);
mask.cw = st.cw(rows);
mask.cod = st.cod(rows);
mask.cont = st.cont(rows);
mask.branch_ext = st.branch_ext(rows);
mask.reg_bus_idx = st.reg_bus_idx(rows);

function rows = v26p_toxic_ultc_rows()
rows = [
    1767; 1768; 1827; 1858; 1859; 2040; 2050; 2052;
    2056; 2063; 2064; 2065; 2068; 2069; 2100; 2102;
    2103; 2113; 2115; 2126; 2133; 2134; 2142; 2148;
    2151; 2152; 2155; 2162; 2195; 2196; 2209; 2210;
    2211; 2232; 2235; 2242; 2243; 2244; 2245; 2246;
    2247; 2249; 2250; 2261; 2264; 2277; 2278; 2279;
    2280; 2282; 2283; 2284; 2293; 2294; 2337; 2338;
    2339; 2340; 2346; 2380; 2381; 2503; 2532; 3090
    ];
