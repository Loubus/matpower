function results = run_v26p_psse_pf(use_psse_controls)
% run_v26p_psse_pf - Runs MATPOWER PF for the local PSS/E RAW case.
%
%   RESULTS = RUN_V26P_PSSE_PF()
%   RESULTS = RUN_V26P_PSSE_PF(USE_PSSE_CONTROLS)
%
% Runs the local PSSE/V26p_Trs_2532.raw case through psse2mpc and either:
%   * runpf      when USE_PSSE_CONTROLS is false
%   * runpf_psse when USE_PSSE_CONTROLS is true
%
% Edit the configuration block below to change solver/output options.

%%-----  user configuration  -----
% Set USE_PSSE_CONTROLS to true for the opt-in PSS/E path implemented by
% runpf_psse(). Set it to false to compare against the standard MATPOWER
% power flow, where the imported BINIT values remain fixed bus shunts.
if nargin < 1
    use_psse_controls = true;
end

verbose = 0;            % set 1 for MATPOWER progress output
% Keep print_output at 0 for this RAW unless the full legacy printpf report
% is needed. The compact report avoids unrelated optional output sections.
print_output = 0;       % compact report only; 1 asks printpf for full output
raw_revision = 34;      % PSS/E RAW revision passed to psse2mpc()
enforce_q_lims = 0;     % MATPOWER generator Q-limit enforcement option
pf_alg = 'NR';          % MATPOWER PF algorithm, e.g. 'NR', 'FDXB', 'FDBX'

%%-----  paths  -----
this_file = mfilename('fullpath');
tools_dir = fileparts(this_file);
audit_dir = fileparts(tools_dir);
workspace_dir = fileparts(audit_dir);
matpower_dir = fullfile(workspace_dir, 'matpower');
raw_file = fullfile(workspace_dir, 'PSSE', 'V26p_Trs_2532.raw');

addpath(fullfile(matpower_dir, 'lib'));

%%-----  import and options  -----
mpc = psse2mpc(raw_file, 0, raw_revision);
mpopt = mpoption( ...
    'verbose', verbose, ...
    'out.all', print_output, ...
    'pf.alg', pf_alg, ...
    'pf.enforce_q_lims', enforce_q_lims ...
);

%%-----  run power flow  -----
if use_psse_controls
    results = runpf_psse(mpc, mpopt);
else
    results = runpf(mpc, mpopt);
end

%%-----  compact report  -----
[~, ~, ~, ~, ~, ~, ~, ~, ~, BS, ~, VM] = idx_bus;
fprintf('\nRAW file             : %s\n', raw_file);
fprintf('PSS/E controls       : %d\n', use_psse_controls);
fprintf('success              : %d\n', results.success);
fprintf('iterations           : %d\n', results.iterations);
fprintf('VM min / max         : %.6f / %.6f pu\n', ...
    min(results.bus(:, VM)), max(results.bus(:, VM)));
fprintf('sum bus BS           : %.3f MVAr\n', sum(results.bus(:, BS)));

if use_psse_controls && isfield(results, 'psse') && ...
        isfield(results.psse, 'swshunt') && ...
        isfield(results.psse.swshunt, 'control')
    report = results.psse.swshunt.control;
    fprintf('swshunt controllable : %d\n', report.controllable);
    fprintf('swshunt groups       : %d\n', report.num_groups);
    fprintf('swshunt multi groups : %d\n', report.multi_shunt_groups);
    fprintf('swshunt max RMPCT sum: %.1f\n', report.max_group_rmpct_sum);
    fprintf('swshunt outside band : %d\n', report.below_band + report.above_band);
    fprintf('swshunt adjustments  : %d\n', report.num_adjustments);
    fprintf('swshunt cycles       : %d\n', report.cycle_detected);
    fprintf('swshunt cycle resolved: %d\n', report.cycle_resolved);
    fprintf('swshunt max iter hit : %d\n', report.max_iter_reached);
end
