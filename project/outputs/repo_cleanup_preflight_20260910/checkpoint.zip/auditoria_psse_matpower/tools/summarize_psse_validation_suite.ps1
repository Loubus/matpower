Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$toolDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$auditDir = Split-Path -Parent $toolDir
$suiteDir = Join-Path $auditDir "psse_validation_suite"
$resultsDir = Join-Path $auditDir "results\psse_cli_comparison"

$matrixPath = Join-Path $suiteDir "validation_matrix.csv"
$comparisonPath = Join-Path $resultsDir "auditoria_all_comparison_latest.csv"
$controlPath = Join-Path $suiteDir "suite_control_comparison.csv"
$suiteCsvPath = Join-Path $suiteDir "suite_comparison_latest.csv"
$outlierPath = Join-Path $suiteDir "suite_outliers.csv"
$summaryPath = Join-Path $suiteDir "suite_comparison_summary.md"

$culture = [System.Globalization.CultureInfo]::InvariantCulture

function To-Double {
    param($Value)
    if ($null -eq $Value) { return [double]::NaN }
    $s = [string]$Value
    if ([string]::IsNullOrWhiteSpace($s) -or $s -eq "NaN") {
        return [double]::NaN
    }
    [double]::Parse($s, $culture)
}

function Fmt {
    param($Value)
    if ([double]::IsNaN([double]$Value)) { return "NaN" }
    ([double]$Value).ToString("G6", $culture)
}

$matrix = Import-Csv -LiteralPath $matrixPath
$comparison = Import-Csv -LiteralPath $comparisonPath |
    Where-Object { $_.case_name -like "psse_validation_suite/*" }
$control = if (Test-Path -LiteralPath $controlPath) {
    Import-Csv -LiteralPath $controlPath
}
else {
    @()
}

$joined = foreach ($row in $comparison) {
    $stem = Split-Path $row.case_name -Leaf
    $m = $matrix | Where-Object { $_.case_name -eq $stem } | Select-Object -First 1
    $ctrl = $control | Where-Object { $_.case_name -eq $stem } | Select-Object -First 1
    $runSuccess = [int](To-Double $row.run_success)
    $dvm = To-Double $row.max_abs_vm
    $dva = To-Double $row.max_abs_va
    $dqg = To-Double $row.max_abs_qg
    $db = To-Double $row.max_abs_binit
    $tap = if ($ctrl) { To-Double $ctrl.max_abs_tap_diff } else { [double]::NaN }
    $dctap = if ($ctrl) { To-Double $ctrl.max_abs_twodc_tap_diff } else { [double]::NaN }
    $facts = if ($ctrl) { To-Double $ctrl.max_abs_facts_q_abs_diff } else { [double]::NaN }

    $reasons = New-Object System.Collections.Generic.List[string]
    if ($runSuccess -ne 1) { $reasons.Add("runpf_psse_success=0") | Out-Null }
    if ($m.category -ne "stress_xplore") {
        if (-not [double]::IsNaN($dvm) -and $dvm -gt 0.005) { $reasons.Add("dVM>0.005") | Out-Null }
        if (-not [double]::IsNaN($dva) -and $dva -gt 1.0) { $reasons.Add("dVA>1deg") | Out-Null }
        if (-not [double]::IsNaN($dqg) -and $dqg -gt 5.0) { $reasons.Add("dQG>5MVAr") | Out-Null }
        if (-not [double]::IsNaN($db) -and $db -gt 2.0) { $reasons.Add("dBINIT>2MVAr") | Out-Null }
        if (-not [double]::IsNaN($tap) -and $tap -gt 0.005) { $reasons.Add("tap>0.005") | Out-Null }
        if (-not [double]::IsNaN($dctap) -and $dctap -gt 0.01) { $reasons.Add("twodc_tap>0.01") | Out-Null }
    }
    elseif ($runSuccess -ne 1 -or (-not [double]::IsNaN($dvm) -and $dvm -gt 0.05)) {
        $reasons.Add("stress_watch") | Out-Null
    }

    [pscustomobject]@{
        case_name = $stem
        bus_count = [int](To-Double $row.bus_count)
        category = $m.category
        control_families = $m.control_families
        run_success = $runSuccess
        psse_iterations = To-Double $row.psse_iterations
        mp_iterations = To-Double $row.mp_iterations
        max_abs_vm = $dvm
        max_abs_va = $dva
        max_abs_qg = $dqg
        max_abs_binit = $db
        max_abs_tap_diff = $tap
        max_abs_twodc_tap_diff = $dctap
        max_abs_facts_q_abs_diff = $facts
        status = if ($reasons.Count -eq 0) { "pass" } elseif ($m.category -eq "stress_xplore") { "stress_watch" } else { "review" }
        reason = ($reasons -join "; ")
    }
}

$joined | Sort-Object category, case_name |
    Export-Csv -LiteralPath $suiteCsvPath -NoTypeInformation -Encoding ASCII

$outliers = @($joined | Where-Object { $_.status -ne "pass" } | Sort-Object status, case_name)
$outliers | Export-Csv -LiteralPath $outlierPath -NoTypeInformation -Encoding ASCII

$rawCount = (Get-ChildItem -LiteralPath $suiteDir -Filter *.raw -File | Measure-Object).Count
$solvedRawCount = (Get-ChildItem -LiteralPath (Join-Path $suiteDir "solved_raw") -Filter *_solved.raw -File | Measure-Object).Count
$logCount = (Get-ChildItem -LiteralPath (Join-Path $suiteDir "logs") -Filter *.log -File |
    Where-Object { $_.Name -notlike "*.stderr.log" } | Measure-Object).Count
$idvCount = (Get-ChildItem -LiteralPath (Join-Path $suiteDir "idv") -Filter *.idv -File | Measure-Object).Count
$savCount = (Get-ChildItem -LiteralPath $suiteDir -Filter *.sav -File | Measure-Object).Count
$successCount = @($joined | Where-Object { $_.run_success -eq 1 }).Count
$normalRows = @($joined | Where-Object { $_.category -ne "stress_xplore" })
$normalSuccess = @($normalRows | Where-Object { $_.run_success -eq 1 }).Count

$md = New-Object System.Collections.Generic.List[string]
$md.Add("# PSS/E Validation Suite Comparison Summary") | Out-Null
$md.Add("") | Out-Null
$md.Add("Generated from validation_matrix.csv, auditoria_all_comparison_latest.csv, and suite_control_comparison.csv.") | Out-Null
$md.Add("") | Out-Null
$md.Add("## Artifact Counts") | Out-Null
$md.Add("") | Out-Null
$md.Add("| artifact | count |") | Out-Null
$md.Add("|---|---:|") | Out-Null
$md.Add("| RAW | $rawCount |") | Out-Null
$md.Add("| solved RAW | $solvedRawCount |") | Out-Null
$md.Add("| PSS/E logs | $logCount |") | Out-Null
$md.Add("| IDV | $idvCount |") | Out-Null
$md.Add("| SAV | $savCount |") | Out-Null
$md.Add("") | Out-Null
$md.Add("## Category Summary") | Out-Null
$md.Add("") | Out-Null
$md.Add("| category | cases | runpf success | max dVM | max dVA | max dQG | max dBINIT | max tap | max TWODC tap | max FACTS abs-Q |") | Out-Null
$md.Add("|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|") | Out-Null
foreach ($g in ($joined | Group-Object category | Sort-Object Name)) {
    $success = @($g.Group | Where-Object { $_.run_success -eq 1 }).Count
    $md.Add("| $($g.Name) | $($g.Count) | $success | $(Fmt (($g.Group | Measure-Object max_abs_vm -Maximum).Maximum)) | $(Fmt (($g.Group | Measure-Object max_abs_va -Maximum).Maximum)) | $(Fmt (($g.Group | Measure-Object max_abs_qg -Maximum).Maximum)) | $(Fmt (($g.Group | Measure-Object max_abs_binit -Maximum).Maximum)) | $(Fmt (($g.Group | Measure-Object max_abs_tap_diff -Maximum).Maximum)) | $(Fmt (($g.Group | Measure-Object max_abs_twodc_tap_diff -Maximum).Maximum)) | $(Fmt (($g.Group | Measure-Object max_abs_facts_q_abs_diff -Maximum).Maximum)) |") | Out-Null
}
$md.Add("") | Out-Null
$md.Add("## Run Summary") | Out-Null
$md.Add("") | Out-Null
$md.Add("- Suite cases compared: $($joined.Count)") | Out-Null
$md.Add("- runpf_psse success: $successCount/$($joined.Count)") | Out-Null
$md.Add("- Non-stress runpf_psse success: $normalSuccess/$($normalRows.Count)") | Out-Null
$md.Add("- Outlier/review rows: $($outliers.Count)") | Out-Null
$md.Add("") | Out-Null
$md.Add("## Outliers And Review Rows") | Out-Null
$md.Add("") | Out-Null
$md.Add("| status | case | category | reason | dVM | dVA | dQG | dBINIT | tap | TWODC tap | FACTS abs-Q |") | Out-Null
$md.Add("|---|---|---|---|---:|---:|---:|---:|---:|---:|---:|") | Out-Null
foreach ($r in $outliers) {
    $md.Add("| $($r.status) | $($r.case_name) | $($r.category) | $($r.reason) | $(Fmt $r.max_abs_vm) | $(Fmt $r.max_abs_va) | $(Fmt $r.max_abs_qg) | $(Fmt $r.max_abs_binit) | $(Fmt $r.max_abs_tap_diff) | $(Fmt $r.max_abs_twodc_tap_diff) | $(Fmt $r.max_abs_facts_q_abs_diff) |") | Out-Null
}
$md.Add("") | Out-Null
$md.Add("## Source Reports") | Out-Null
$md.Add("") | Out-Null
$md.Add("- Full harness CSV: $comparisonPath") | Out-Null
$md.Add("- Full harness Markdown: $(Join-Path $resultsDir 'auditoria_all_comparison_latest.md')") | Out-Null
$md.Add("- Suite filtered CSV: $suiteCsvPath") | Out-Null
$md.Add("- Suite control-state CSV: $controlPath") | Out-Null
$md.Add("- Suite outliers CSV: $outlierPath") | Out-Null

Set-Content -LiteralPath $summaryPath -Value $md -Encoding ASCII

Write-Host "Wrote suite CSV: $suiteCsvPath"
Write-Host "Wrote outliers CSV: $outlierPath"
Write-Host "Wrote suite summary: $summaryPath"
