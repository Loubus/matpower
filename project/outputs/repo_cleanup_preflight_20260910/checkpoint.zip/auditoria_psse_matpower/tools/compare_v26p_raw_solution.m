function comparison = compare_v26p_raw_solution()
% compare_v26p_raw_solution - Compares MATPOWER PF results to RAW voltages.
%
%   COMPARISON = COMPARE_V26P_RAW_SOLUTION()
%
% Imports the local PSSE/V26p_Trs_2532.raw case, treats the RAW bus voltage
% magnitudes and angles as the saved reference solution, and compares them
% against:
%   * runpf      with fixed imported BINIT bus shunts
%   * runpf_psse with opt-in PSS/E switched shunt control
%
% The primary metrics are voltage magnitude and angle differences by bus.
% Switched shunt BINIT movement is reported only as auxiliary diagnostic
% information because other not-yet-modeled RAW devices also affect the
% final switched shunt positions.

%%-----  user configuration  -----
verbose = 0;            % MATPOWER progress output, 0 for quiet comparison
print_output = 0;       % keep compact output for this diagnostic
raw_revision = 34;      % PSS/E RAW revision passed to psse2mpc()
enforce_q_lims = 0;     % MATPOWER generator Q-limit enforcement option
pf_alg = 'NR';          % MATPOWER PF algorithm, e.g. 'NR', 'FDXB', 'FDBX'
top_n = 15;             % number of largest deviations printed per run
write_csv = true;       % write detailed bus comparison CSV files

%%-----  paths  -----
this_file = mfilename('fullpath');
tools_dir = fileparts(this_file);
audit_dir = fileparts(tools_dir);
workspace_dir = fileparts(audit_dir);
matpower_dir = fullfile(workspace_dir, 'matpower');
raw_file = fullfile(workspace_dir, 'PSSE', 'V26p_Trs_2532.raw');
out_dir = fullfile(audit_dir, 'results');

addpath(fullfile(matpower_dir, 'lib'));
if write_csv && ~exist(out_dir, 'dir')
    mkdir(out_dir);
end

%%-----  import and reference solution  -----
[~, ~, ~, ~, BUS_I, ~, ~, ~, ~, BS, ~, VM, VA] = idx_bus;
mpc = psse2mpc(raw_file, 0, raw_revision);
raw_bus = mpc.bus(:, [BUS_I VM VA BS]);

mpopt = mpoption( ...
    'verbose', verbose, ...
    'out.all', print_output, ...
    'pf.alg', pf_alg, ...
    'pf.enforce_q_lims', enforce_q_lims ...
);

%%-----  run both MATPOWER variants  -----
results_base = runpf(mpc, mpopt);
results_psse = runpf_psse(mpc, mpopt);

comparison = struct();
comparison.raw_file = raw_file;
comparison.baseline = compare_one('runpf', raw_bus, results_base, top_n, out_dir, write_csv);
comparison.psse = compare_one('runpf_psse', raw_bus, results_psse, top_n, out_dir, write_csv);

fprintf('\nRAW reference solution: %s\n', raw_file);
print_summary(comparison.baseline);
print_summary(comparison.psse);

if isfield(results_psse, 'psse') && isfield(results_psse.psse, 'swshunt') && ...
        isfield(results_psse.psse.swshunt, 'control')
    r = results_psse.psse.swshunt.control;
    fprintf('\nAuxiliary switched shunt diagnostics from runpf_psse:\n');
    fprintf('  controllable   : %d\n', r.controllable);
    fprintf('  groups         : %d\n', r.num_groups);
    fprintf('  multi groups   : %d\n', r.multi_shunt_groups);
    fprintf('  max RMPCT sum  : %.1f\n', r.max_group_rmpct_sum);
    fprintf('  outside band   : %d\n', r.below_band + r.above_band);
    fprintf('  adjustments    : %d\n', r.num_adjustments);
    fprintf('  cycles         : %d\n', r.cycle_detected);
    fprintf('  cycle resolved : %d\n', r.cycle_resolved);
    fprintf('  max iter hit   : %d\n', r.max_iter_reached);
end

function out = compare_one(label, raw_bus, results, top_n, out_dir, write_csv)
[~, ~, ~, ~, BUS_I, ~, ~, ~, ~, BS, ~, VM, VA] = idx_bus;

raw_i = raw_bus(:, 1);
[tf, loc] = ismember(raw_i, results.bus(:, BUS_I));
if ~all(tf)
    error('compare_v26p_raw_solution:bus_mismatch', ...
        '%s results are missing %d RAW buses.', label, nnz(~tf));
end

res_bus = results.bus(loc, :);
dvm = res_bus(:, VM) - raw_bus(:, 2);
dva = angle_diff_deg(res_bus(:, VA), raw_bus(:, 3));
score = abs(dvm) + abs(dva) / 100;
[~, ord] = sort(score, 'descend');
ord = ord(1:min(top_n, length(ord)));

out = struct();
out.label = label;
out.success = results.success;
out.iterations = results.iterations;
out.max_abs_vm = max(abs(dvm));
out.rms_vm = sqrt(mean(dvm .^ 2));
out.max_abs_va = max(abs(dva));
out.rms_va = sqrt(mean(dva .^ 2));
out.sum_bs = sum(res_bus(:, BS));
out.top = [raw_i(ord) raw_bus(ord, 2) res_bus(ord, VM) dvm(ord) ...
    raw_bus(ord, 3) res_bus(ord, VA) dva(ord)];

if write_csv
    detail = table(raw_i, raw_bus(:, 2), res_bus(:, VM), dvm, ...
        raw_bus(:, 3), res_bus(:, VA), dva, raw_bus(:, 4), res_bus(:, BS), ...
        'VariableNames', {'bus', 'raw_vm', 'mp_vm', 'dvm', ...
        'raw_va', 'mp_va', 'dva_deg', 'raw_bs', 'mp_bs'});
    writetable(detail, fullfile(out_dir, sprintf('v26p_%s_vs_raw_solution.csv', label)));
end

function print_summary(out)
fprintf('\n%s vs RAW saved bus solution\n', out.label);
fprintf('  success       : %d\n', out.success);
fprintf('  iterations    : %d\n', out.iterations);
fprintf('  max |dVM|     : %.6f pu\n', out.max_abs_vm);
fprintf('  RMS dVM       : %.6f pu\n', out.rms_vm);
fprintf('  max |dVA|     : %.6f deg\n', out.max_abs_va);
fprintf('  RMS dVA       : %.6f deg\n', out.rms_va);
fprintf('  sum bus BS    : %.3f MVAr\n', out.sum_bs);
fprintf('  worst buses   :\n');
fprintf('      bus     raw VM      MP VM       dVM     raw VA      MP VA      dVA\n');
for kk = 1:size(out.top, 1)
    fprintf('  %7.0f   %8.5f   %8.5f  %+8.5f  %9.4f  %9.4f  %+8.4f\n', ...
        out.top(kk, 1), out.top(kk, 2), out.top(kk, 3), out.top(kk, 4), ...
        out.top(kk, 5), out.top(kk, 6), out.top(kk, 7));
end

function d = angle_diff_deg(a, b)
d = mod(a - b + 180, 360) - 180;
