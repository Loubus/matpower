function summary = validate_multi_xfmr_settling()
% validate_multi_xfmr_settling - Compare multi-transformer settling vs PSS/E.

define_constants;

this_file = mfilename('fullpath');
tools_dir = fileparts(this_file);
audit_dir = fileparts(tools_dir);
project_dir = fileparts(audit_dir);
matpower_dir = fullfile(project_dir, 'matpower');
out_dir = fullfile(audit_dir, 'results', 'multi_xfmr_settling');

if exist(matpower_dir, 'dir')
    addpath(genpath(matpower_dir));
end
if ~exist(out_dir, 'dir')
    mkdir(out_dir);
end

cases = [
    make_case('multi_2w_shared', 'psse_ultc_multi_2w_shared')
    make_case('multi_3w_cw2_shared', 'psse_ultc_multi_3w_cw2_shared')
];

mpopt = mpoption('verbose', 0, 'out.all', 0, ...
    'exp.use_legacy_core', 0);

rows = repmat(summary_row(), numel(cases), 1);
detail = repmat(detail_row(), 0, 1);
for k = 1:numel(cases)
    tc = cases(k);
    raw_file = fullfile(project_dir, 'PSSE', 'RAW', tc.raw_name + ".raw");
    solved_file = fullfile(project_dir, 'PSSE', tc.output_dir, ...
        'solved_raw', tc.raw_name + "_solved.raw");
    log_file = fullfile(project_dir, 'PSSE', tc.output_dir, ...
        'logs', tc.raw_name + ".log");

    rows(k).case_name = tc.name;
    rows(k).raw_file = raw_file;
    rows(k).solved_raw = solved_file;
    rows(k).psse_log = log_file;

    if exist(solved_file, 'file') ~= 2
        rows(k).note = "missing PSS/E solved RAW";
        continue;
    end

    initial_windv = parse_transformer_windv(raw_file);
    psse_windv = parse_transformer_windv(solved_file);
    psse_log = parse_psse_tap_log(log_file);

    try
        [mpc, ~] = psse2mpc(raw_file, 0, 34);
        [r, success] = runpf_psse(mpc, mpopt);
        psse_sol = psse2mpc(solved_file, 0, 34);
        mp_windv = matpower_windv_raw_order(r);
        [max_vm_diff, rms_vm_diff, common_buses] = bus_vm_diff(psse_sol, r);

        n = min([numel(psse_windv), numel(mp_windv), numel(initial_windv)]);
        tap_diff = abs(psse_windv(1:n) - mp_windv(1:n));
        rows(k).matpower_success = double(success);
        rows(k).matpower_xfmr_iterations = xfmr_scalar(r, 'iterations');
        rows(k).matpower_xfmr_adjustments = xfmr_scalar(r, 'num_adjustments');
        rows(k).matpower_cycle_detected = xfmr_scalar(r, 'cycle_detected');
        rows(k).matpower_cycle_resolved = xfmr_scalar(r, 'cycle_resolved');
        rows(k).psse_tap_blocks = psse_log.blocks;
        rows(k).psse_tap_moves = psse_log.moves;
        rows(k).tap_count_compared = n;
        rows(k).max_abs_windv_diff = max_or_nan(tap_diff);
        rows(k).max_abs_vm_diff = max_vm_diff;
        rows(k).rms_vm_diff = rms_vm_diff;
        rows(k).common_bus_count = common_buses;
        rows(k).passed = double(success) && ...
            rows(k).max_abs_windv_diff < 1e-9 && ...
            rows(k).max_abs_vm_diff < 5e-3;

        for j = 1:n
            d = detail_row();
            d.case_name = tc.name;
            d.tap_index = j;
            d.initial_windv = initial_windv(j);
            d.psse_windv = psse_windv(j);
            d.matpower_windv = mp_windv(j);
            d.psse_delta = psse_windv(j) - initial_windv(j);
            d.matpower_delta = mp_windv(j) - initial_windv(j);
            d.abs_windv_diff = tap_diff(j);
            detail(end+1, 1) = d; %#ok<AGROW>
        end
    catch err
        rows(k).note = string(getReport(err, 'basic', 'hyperlinks', 'off'));
    end
end

summary = struct();
summary.rows = rows;
summary.detail = detail;
summary.csv_path = fullfile(out_dir, 'multi_xfmr_settling_summary.csv');
summary.detail_csv_path = fullfile(out_dir, 'multi_xfmr_settling_taps.csv');
summary.md_path = fullfile(out_dir, 'multi_xfmr_settling_summary.md');
summary.mat_path = fullfile(out_dir, 'multi_xfmr_settling_summary.mat');

writetable(struct2table(rows), summary.csv_path);
if isempty(detail)
    write_empty_detail_csv(summary.detail_csv_path);
else
    writetable(struct2table(detail), summary.detail_csv_path);
end
write_report(summary.md_path, rows, detail);
save(summary.mat_path, 'summary', 'rows', 'detail');

fprintf('Multi-transformer settling cases: %d\n', numel(rows));
fprintf('Summary CSV: %s\n', summary.csv_path);
fprintf('Tap CSV: %s\n', summary.detail_csv_path);
fprintf('Report: %s\n', summary.md_path);

function tc = make_case(name, raw_name)
tc = struct( ...
    'name', string(name), ...
    'raw_name', string(raw_name), ...
    'output_dir', "SOLVED_MULTI_XFMR_SETTLING");

function row = summary_row()
row = struct( ...
    'case_name', "", ...
    'raw_file', "", ...
    'solved_raw', "", ...
    'psse_log', "", ...
    'matpower_success', NaN, ...
    'matpower_xfmr_iterations', NaN, ...
    'matpower_xfmr_adjustments', NaN, ...
    'matpower_cycle_detected', NaN, ...
    'matpower_cycle_resolved', NaN, ...
    'psse_tap_blocks', NaN, ...
    'psse_tap_moves', NaN, ...
    'tap_count_compared', NaN, ...
    'max_abs_windv_diff', NaN, ...
    'max_abs_vm_diff', NaN, ...
    'rms_vm_diff', NaN, ...
    'common_bus_count', NaN, ...
    'passed', 0, ...
    'note', "");

function row = detail_row()
row = struct( ...
    'case_name', "", ...
    'tap_index', NaN, ...
    'initial_windv', NaN, ...
    'psse_windv', NaN, ...
    'matpower_windv', NaN, ...
    'psse_delta', NaN, ...
    'matpower_delta', NaN, ...
    'abs_windv_diff', NaN);

function windv = parse_transformer_windv(raw_path)
windv = [];
lines = section_lines(raw_path, 'TRANSFORMER DATA');
idx = 1;
while idx <= numel(lines)
    line = strtrim(lines{idx});
    if isempty(line) || startsWith(line, '@')
        idx = idx + 1;
        continue;
    end
    vals = numbers_in_line(line);
    if numel(vals) >= 3
        is_three = vals(3) ~= 0;
        if idx + 2 <= numel(lines)
            w1 = numbers_in_line(lines{idx + 2});
            if ~isempty(w1)
                windv(end+1, 1) = w1(1); %#ok<AGROW>
            end
        end
        if is_three
            if idx + 3 <= numel(lines)
                w2 = numbers_in_line(lines{idx + 3});
                if ~isempty(w2)
                    windv(end+1, 1) = w2(1); %#ok<AGROW>
                end
            end
            if idx + 4 <= numel(lines)
                w3 = numbers_in_line(lines{idx + 4});
                if ~isempty(w3)
                    windv(end+1, 1) = w3(1); %#ok<AGROW>
                end
            end
            idx = idx + 5;
        else
            idx = idx + 4;
        end
    else
        idx = idx + 1;
    end
end

function info = parse_psse_tap_log(log_path)
info = struct('blocks', NaN, 'moves', NaN);
if exist(log_path, 'file') ~= 2
    return;
end
lines = regexp(fileread(log_path), '\r\n|\n|\r', 'split');
info.blocks = nnz(contains(string(lines), 'TAP RATIOS ADJUSTED:'));
info.moves = 0;
for k = 1:numel(lines)
    tok = regexp(lines{k}, '^\s*(\d+)\s+tap ratios adjusted', ...
        'tokens', 'once');
    if ~isempty(tok)
        info.moves = info.moves + str2double(tok{1});
    end
end

function windv = matpower_windv_raw_order(r)
windv = [];
if ~isfield(r, 'psse') || ~isfield(r.psse, 'xfmr')
    return;
end
xf = r.psse.xfmr;
if isfield(xf, 'two') && isfield(xf.two, 'num') && ...
        isfield(xf.two, 'col') && ~isempty(xf.two.num)
    c = xf.two.col;
    for k = 1:size(xf.two.num, 1)
        windv(end+1, 1) = xf.two.num(k, c.windv1); %#ok<AGROW>
    end
end
if isfield(xf, 'three') && isfield(xf.three, 'num') && ...
        isfield(xf.three, 'col') && ~isempty(xf.three.num)
    c = xf.three.col;
    for k = 1:size(xf.three.num, 1)
        windv(end+1, 1) = xf.three.num(k, c.windv1); %#ok<AGROW>
        windv(end+1, 1) = xf.three.num(k, c.windv2); %#ok<AGROW>
        windv(end+1, 1) = xf.three.num(k, c.windv3); %#ok<AGROW>
    end
end

function val = xfmr_scalar(r, field)
val = NaN;
if isfield(r, 'psse') && isfield(r.psse, 'xfmr') && ...
        isfield(r.psse.xfmr, 'control') && ...
        isfield(r.psse.xfmr.control, field)
    val = double(r.psse.xfmr.control.(field));
end

function [max_diff, rms_diff, n] = bus_vm_diff(psse_sol, mp_sol)
[~, ~, ~, ~, BUS_I, ~, ~, ~, ~, ~, ~, VM] = idx_bus;
psse_bus = psse_sol.bus(:, BUS_I);
mp_bus = mp_sol.bus(:, BUS_I);
[common, ia, ib] = intersect(psse_bus, mp_bus);
n = numel(common);
if n == 0
    max_diff = NaN;
    rms_diff = NaN;
    return;
end
d = psse_sol.bus(ia, VM) - mp_sol.bus(ib, VM);
max_diff = max(abs(d));
rms_diff = sqrt(mean(d .^ 2));

function lines = section_lines(path, section)
lines = {};
txt = fileread(path);
all_lines = regexp(txt, '\r\n|\n|\r', 'split');
inside = false;
for k = 1:numel(all_lines)
    line = all_lines{k};
    if contains(line, ['BEGIN ' section])
        inside = true;
        continue;
    end
    if inside && contains(line, ['END OF ' section])
        break;
    end
    if inside
        lines{end+1} = line; %#ok<AGROW>
    end
end

function nums = numbers_in_line(line)
matches = regexp(line, ...
    '[-+]?(?:\d+\.\d*|\.\d+|\d+)(?:[Ee][-+]?\d+)?', 'match');
nums = str2double(matches);

function val = max_or_nan(x)
if isempty(x)
    val = NaN;
else
    val = max(x);
end

function write_empty_detail_csv(file_name)
fid = fopen(file_name, 'w');
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, ['case_name,tap_index,initial_windv,psse_windv,' ...
    'matpower_windv,psse_delta,matpower_delta,abs_windv_diff\n']);

function write_report(file_name, rows, detail)
fid = fopen(file_name, 'w');
cleanup = onCleanup(@() fclose(fid));
fprintf(fid, '# Multi-Transformer Settling Validation\n\n');
fprintf(fid, ['These fixtures isolate transformer tap settling with GENQ, ' ...
    'switched shunts, DC taps, and FACTS disabled.\n\n']);
fprintf(fid, ['| Case | Pass | MP success | PSS/E tap blocks | PSS/E tap moves | ' ...
    'MP xfmr iterations | MP adjustments | Cycle | n taps | max dWINDV | ' ...
    'max dVM | RMS dVM | Note |\n']);
fprintf(fid, '|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|\n');
for k = 1:numel(rows)
    fprintf(fid, ['| %s | %.0f | %.0f | %.0f | %.0f | %.0f | %.0f | ' ...
        '%.0f/%.0f | %.0f | %.6g | %.6g | %.6g | %s |\n'], ...
        rows(k).case_name, rows(k).passed, rows(k).matpower_success, ...
        rows(k).psse_tap_blocks, rows(k).psse_tap_moves, ...
        rows(k).matpower_xfmr_iterations, ...
        rows(k).matpower_xfmr_adjustments, ...
        rows(k).matpower_cycle_detected, rows(k).matpower_cycle_resolved, ...
        rows(k).tap_count_compared, rows(k).max_abs_windv_diff, ...
        rows(k).max_abs_vm_diff, rows(k).rms_vm_diff, rows(k).note);
end
fprintf(fid, '\n## Tap Detail\n\n');
fprintf(fid, '| Case | Tap | Initial | PSS/E | MATPOWER | PSS/E delta | MATPOWER delta | abs diff |\n');
fprintf(fid, '|---|---:|---:|---:|---:|---:|---:|---:|\n');
for k = 1:numel(detail)
    fprintf(fid, '| %s | %.0f | %.6g | %.6g | %.6g | %.6g | %.6g | %.6g |\n', ...
        detail(k).case_name, detail(k).tap_index, ...
        detail(k).initial_windv, detail(k).psse_windv, ...
        detail(k).matpower_windv, detail(k).psse_delta, ...
        detail(k).matpower_delta, detail(k).abs_windv_diff);
end
