Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$toolDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$auditDir = Split-Path -Parent $toolDir
$suiteDir = Join-Path $auditDir "psse_validation_suite"

New-Item -ItemType Directory -Force -Path $suiteDir | Out-Null

function Join-AuditPath {
    param([string]$RelativePath)
    Join-Path $auditDir $RelativePath
}

function Read-RawText {
    param([string]$RelativePath)
    $path = Join-AuditPath $RelativePath
    if (-not (Test-Path -LiteralPath $path)) {
        throw "Missing source RAW: $path"
    }
    Get-Content -LiteralPath $path -Raw
}

function Set-RawTitle {
    param(
        [string]$Text,
        [string]$Title,
        [string]$Description
    )

    $lines = $Text -split "`r?`n"
    $caseLine = -1
    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match '^\s*0\s*,') {
            $caseLine = $i
            break
        }
    }
    if ($caseLine -lt 0) {
        throw "Could not find PSS/E case-identification line."
    }
    if ($caseLine + 1 -lt $lines.Count) {
        $lines[$caseLine + 1] = $Title.ToUpperInvariant()
    }
    if ($caseLine + 2 -lt $lines.Count) {
        $lines[$caseLine + 2] = $Description.ToUpperInvariant()
    }
    ($lines -join "`r`n")
}

function Apply-Transforms {
    param(
        [string]$Text,
        [object[]]$Transforms
    )

    $out = $Text
    foreach ($t in $Transforms) {
        if ($t.Kind -eq "ReplaceRegex") {
            $out = [regex]::Replace($out, $t.Pattern, $t.Replacement)
        }
        elseif ($t.Kind -eq "ReplaceLiteral") {
            $out = $out.Replace($t.OldValue, $t.NewValue)
        }
        else {
            throw "Unknown transform kind: $($t.Kind)"
        }
    }
    $out
}

function Count-RawBuses {
    param([string]$Text)

    $inside = $false
    $count = 0
    foreach ($line in ($Text -split "`r?`n")) {
        if ($line -match 'BEGIN BUS DATA') {
            $inside = $true
            continue
        }
        if ($inside -and $line -match 'END OF BUS DATA') {
            break
        }
        if ($inside) {
            $trimmed = $line.Trim()
            if ($trimmed -and $trimmed -notmatch '^@' -and $trimmed -match '^\d+\s*,') {
                $count++
            }
        }
    }
    $count
}

function New-ReplaceRegex {
    param([string]$Pattern, [string]$Replacement)
    [pscustomobject]@{
        Kind = "ReplaceRegex"
        Pattern = $Pattern
        Replacement = $Replacement
    }
}

function New-ReplaceLiteral {
    param([string]$OldValue, [string]$NewValue)
    [pscustomobject]@{
        Kind = "ReplaceLiteral"
        OldValue = $OldValue
        NewValue = $NewValue
    }
}

function New-Case {
    param(
        [string]$Name,
        [string]$Source,
        [string]$Category,
        [string]$ControlFamilies,
        [string]$RawOptions,
        [string]$VoltageBand,
        [string]$Thresholds,
        [string]$Purpose,
        [object[]]$Transforms = @(),
        [string]$CustomText = ""
    )

    [pscustomobject]@{
        case_name = $Name
        source = $Source
        category = $Category
        control_families = $ControlFamilies
        raw_options = $RawOptions
        voltage_band = $VoltageBand
        reference_kind = "psse_cli_solved_raw"
        thresholds = $Thresholds
        purpose = $Purpose
        transforms = $Transforms
        custom_text = $CustomText
        bus_count = 0
        raw_path = ""
    }
}

$normalThresholds = "VM<=0.005 pu; VA<=1 deg; QG<=5 MVAr; BINIT<=2 MVAr; tap<=0.005 pu; DC tap<=0.01 pu"
$stressThresholds = "Stress evidence only; compare VM/VA/QG/taps/shunts/FACTS/TWODC and convergence, do not tune from this case alone"

$factsGroupRaw = @'
@!IC, SBASE,REV,XFRRAT,NXFRAT,BASFRQ
0, 100.00, 34, 0, 1, 50.00 / PSS(R)E-34.9
SUITE I FACTS 4BUS REMOTE GROUP
TWO STATCON DEVICES SHARE A REMOTE REGULATED BUS BY RMPCT
GENERAL, THRSHZ=0.0001
SOLVER, FNSL, ACTAPS=0, AREAIN=0, PHSHFT=0, DCTAPS=0, SWSHNT=0, FACTS=1, FLATST=0, VARLIM=0, NONDIV=0
NEWTON, VCTOLV=0.00001
ADJUST, MXTPSS=20
0 / END OF SYSTEM-WIDE DATA, BEGIN BUS DATA
@!   I,'NAME        ', BASKV, IDE,AREA,ZONE,OWNER, VM,        VA,    NVHI,   NVLO,   EVHI,   EVLO
1,'SLACK       ', 230.0000,3,   1,   1,   1,1.00000,   0.0000,1.10000,0.90000,1.10000,0.90000
2,'FACTS_A     ', 230.0000,1,   1,   1,   1,1.00000,  -1.0000,1.10000,0.90000,1.10000,0.90000
3,'REMOTE_REG  ', 230.0000,1,   1,   1,   1,0.98000,  -3.0000,1.10000,0.90000,1.10000,0.90000
4,'FACTS_B     ', 230.0000,1,   1,   1,   1,1.00000,  -1.1000,1.10000,0.90000,1.10000,0.90000
0 / END OF BUS DATA, BEGIN LOAD DATA
@!   I,'ID',STAT,AREA,ZONE,      PL,        QL,        IP,        IQ,        YP,        YQ, OWNER,SCALE,INTRPT,  DGENP,     DGENQ, DGENF
3,'1 ',   1,   1,   1,   115.000,    60.000,     0.000,     0.000,     0.000,     0.000,   1,1,0,     0.000,     0.000, 0
0 / END OF LOAD DATA, BEGIN FIXED SHUNT DATA
0 / END OF FIXED SHUNT DATA, BEGIN GENERATOR DATA
@!   I,'ID',      PG,        QG,        QT,        QB,     VS,    IREG,     MBASE,     ZR,         ZX,         RT,         XT,     GTAP,STAT, RMPCT,      PT,        PB,    O1,    F1
1,'1 ',   115.000,     0.000,   400.000,  -400.000,1.00000,     1,   100.000, 0.00000E+0, 1.00000E+0, 0.00000E+0, 0.00000E+0,1.00000,1,  100.0,   300.000,  -100.000,   1,1.0000
0 / END OF GENERATOR DATA, BEGIN BRANCH DATA
@!   I,     J,'CKT',     R,          X,         B,                    'N A M E'                 ,   RATE1,   RATE2,   RATE3,   RATE4,   RATE5,   RATE6,   RATE7,   RATE8,   RATE9,  RATE10,  RATE11,  RATE12,    GI,       BI,       GJ,       BJ,STAT,MET,  LEN,  O1,  F1
1,2,'1 ', 1.00000E-02, 8.00000E-02,   0.00000,'LINE12                                  ',  250.00,  250.00,  250.00,    0.00,    0.00,    0.00,    0.00,    0.00,    0.00,    0.00,    0.00,    0.00,  0.00000,  0.00000,  0.00000,  0.00000,1,1,  10.00,   1,1.0000
2,3,'1 ', 1.50000E-02, 1.00000E-01,   0.00000,'LINE23                                  ',  250.00,  250.00,  250.00,    0.00,    0.00,    0.00,    0.00,    0.00,    0.00,    0.00,    0.00,    0.00,  0.00000,  0.00000,  0.00000,  0.00000,1,1,  10.00,   1,1.0000
1,4,'1 ', 1.00000E-02, 8.00000E-02,   0.00000,'LINE14                                  ',  250.00,  250.00,  250.00,    0.00,    0.00,    0.00,    0.00,    0.00,    0.00,    0.00,    0.00,    0.00,  0.00000,  0.00000,  0.00000,  0.00000,1,1,  10.00,   1,1.0000
4,3,'1 ', 1.50000E-02, 1.00000E-01,   0.00000,'LINE43                                  ',  250.00,  250.00,  250.00,    0.00,    0.00,    0.00,    0.00,    0.00,    0.00,    0.00,    0.00,    0.00,  0.00000,  0.00000,  0.00000,  0.00000,1,1,  10.00,   1,1.0000
0 / END OF BRANCH DATA, BEGIN SYSTEM SWITCHING DEVICE DATA
0 / END OF SYSTEM SWITCHING DEVICE DATA, BEGIN TRANSFORMER DATA
0 / END OF TRANSFORMER DATA, BEGIN AREA DATA
1,     1,      0.000,     10.000, 'AREA1'
0 / END OF AREA DATA, BEGIN TWO-TERMINAL DC DATA
0 / END OF TWO-TERMINAL DC DATA, BEGIN VSC DC LINE DATA
0 / END OF VSC DC LINE DATA, BEGIN IMPEDANCE CORRECTION DATA
0 / END OF IMPEDANCE CORRECTION DATA, BEGIN MULTI-TERMINAL DC DATA
0 / END OF MULTI-TERMINAL DC DATA, BEGIN MULTI-SECTION LINE DATA
0 / END OF MULTI-SECTION LINE DATA, BEGIN ZONE DATA
1, 'ZONE1'
0 / END OF ZONE DATA, BEGIN INTER-AREA TRANSFER DATA
0 / END OF INTER-AREA TRANSFER DATA, BEGIN OWNER DATA
1, 'OWNER1'
0 / END OF OWNER DATA, BEGIN FACTS DEVICE DATA
@!  'NAME',         I,     J,MODE,   PDES,      QDES,  VSET,      SHMX,      TRMX,   VTMN,   VTMX,   VSMX,      IMX,     LINX,   RMPCT,OWNER,    SET1,      SET2,VSREF, FCREG,   'MNAME'    ,NREG
"STATCON A   ",     2,     0,   1,   0.000,     0.000,1.02000,    80.000,     0.000,0.90000,1.10000,1.00000,     0.000, 0.05000,   60.0,   1,   0.00000,   0.00000,   0,     3,"            ",   0
"STATCON B   ",     4,     0,   1,   0.000,     0.000,1.02000,    60.000,     0.000,0.90000,1.10000,1.00000,     0.000, 0.05000,   40.0,   1,   0.00000,   0.00000,   0,     3,"            ",   0
0 / END OF FACTS DEVICE DATA, BEGIN SWITCHED SHUNT DATA
0 / END OF SWITCHED SHUNT DATA, BEGIN GNE DATA
0 / END OF GNE DATA, BEGIN INDUCTION MACHINE DATA
0 / END OF INDUCTION MACHINE DATA, BEGIN SUBSTATION DATA
0 / END OF SUBSTATION DATA
'@

$cases = @(
    New-Case "suite_u_genq_3bus_local_inband" "psse_validation_cases_genq/psse_genq_3bus_local_inband.raw" "unitario" "GENQ" "VARLIM=1; FLATST=0" "normal 0.95-1.10" $normalThresholds "GENQ local in band baseline"
    New-Case "suite_u_genq_3bus_qmax" "psse_validation_cases_genq/psse_genq_3bus_qmax.raw" "unitario" "GENQ" "VARLIM=1; QMAX binding" "normal 0.95-1.10" $normalThresholds "GENQ high-side reactive limit"
    New-Case "suite_u_genq_3bus_qmin" "psse_validation_cases_genq/psse_genq_3bus_qmin.raw" "unitario" "GENQ" "VARLIM=1; QMIN binding" "normal 0.95-1.10" $normalThresholds "GENQ low-side reactive limit"
    New-Case "suite_u_genq_3bus_qzero" "psse_validation_cases_genq/psse_genq_3bus_qmin_qmax_zero.raw" "unitario" "GENQ" "VARLIM=1; QMAX=QMIN=0" "normal 0.95-1.10" $normalThresholds "GENQ fixed-Q zero-width limits"
    New-Case "suite_u_genq_3bus_slack_limit" "psse_validation_cases_genq/psse_genq_3bus_slack_q_limit.raw" "unitario" "GENQ" "VARLIM=1; slack Q limit" "normal 0.95-1.10" $normalThresholds "Slack generator limit behavior"
    New-Case "suite_u_genq_4bus_remote_single" "psse_validation_cases_genq/psse_genq_4bus_remote_single.raw" "unitario" "GENQ" "VARLIM=1; IREG remote" "normal 0.95-1.10" $normalThresholds "Single remote regulated bus"
    New-Case "suite_u_genq_5bus_remote_group" "psse_validation_cases_genq/psse_genq_5bus_remote_group.raw" "unitario" "GENQ" "VARLIM=1; RMPCT=60/40" "normal 0.95-1.10" $normalThresholds "Remote grouped GENQ RMPCT sharing"
    New-Case "suite_u_genq_5bus_group_one_limited" "psse_validation_cases_genq/psse_genq_5bus_remote_group_one_limited.raw" "unitario" "GENQ" "VARLIM=1; one grouped generator limited" "normal 0.95-1.10" $normalThresholds "Partial grouped GENQ limit"
    New-Case "suite_u_genq_5bus_group_all_limited" "psse_validation_cases_genq/psse_genq_5bus_remote_group_all_limited.raw" "unitario" "GENQ" "VARLIM=1; all grouped generators limited" "normal 0.95-1.10" $normalThresholds "All grouped GENQ controllers binding"
    New-Case "suite_u_swshnt_2bus_continuous_local" "psse_validation_cases/psse_swshunt_2bus_continuous_local.raw" "unitario" "SWSHNT" "SWSHNT=2; MODSW=2" "normal 0.95-1.10" $normalThresholds "Continuous switched-shunt local regulation"
    New-Case "suite_u_swshnt_2bus_discrete_local" "psse_validation_cases/psse_swshunt_2bus_discrete_local.raw" "unitario" "SWSHNT" "SWSHNT=2; MODSW=1" "normal 0.95-1.10" $normalThresholds "Discrete switched-shunt local regulation"
    New-Case "suite_u_swshnt_3bus_remote_group" "psse_validation_cases/psse_swshunt_3bus_remote_group.raw" "unitario" "SWSHNT" "SWSHNT=2; SWREG remote; RMPCT group" "normal 0.95-1.10" $normalThresholds "Grouped remote switched-shunt regulation"
    New-Case "suite_u_swshnt_2bus_discrete_swsht1" "psse_validation_cases/psse_swshunt_2bus_discrete_local.raw" "unitario" "SWSHNT" "SWSHNT=1; MODSW=1" "normal 0.95-1.10" $normalThresholds "Discrete switched-shunt with PSS/E stepping flag" @((New-ReplaceRegex '(?m)^SOLVER\s*,.*$' 'SOLVER, FNSL, SWSHNT=1, FLATST=0'))
    New-Case "suite_u_ultc_2bus_local" "psse_validation_cases_ultc/psse_ultc_2bus_local.raw" "unitario" "ULTC" "ACTAPS=1; local CONT" "normal 0.95-1.10" $normalThresholds "Two-winding local tap control"
    New-Case "suite_u_ultc_2bus_actaps_off" "psse_validation_cases_ultc/psse_ultc_2bus_actaps_off.raw" "unitario" "ULTC" "ACTAPS=0" "normal 0.95-1.10" $normalThresholds "Tap controller present but adjustment disabled"
    New-Case "suite_u_ultc_2bus_cont_pos" "../PSSE/RAW/psse_ultc_2bus_cont_pos.raw" "unitario" "ULTC" "ACTAPS=1; positive CONT" "normal 0.95-1.10" $normalThresholds "Positive CONT local/terminal tap direction"
    New-Case "suite_u_ultc_2bus_cont0" "../PSSE/RAW/psse_ultc_2bus_cont0.raw" "unitario" "ULTC" "ACTAPS=1; CONT=0" "normal 0.95-1.10" $normalThresholds "Transformer tap record with no regulated bus is reported but not controlled"
    New-Case "suite_u_ultc_2bus_cod0" "../PSSE/RAW/psse_ultc_2bus_cod0.raw" "unitario" "ULTC" "ACTAPS=1; COD=0" "normal 0.95-1.10" $normalThresholds "Transformer tap record with fixed COD=0 is reported but not automatically controlled"
    New-Case "suite_u_ultc_2bus_cod_m1" "../PSSE/RAW/psse_ultc_2bus_cod_m1.raw" "unitario" "ULTC" "ACTAPS=1; COD=-1" "normal 0.95-1.10" $normalThresholds "Transformer tap record with suppressed COD=-1 is reported but not automatically controlled"
    New-Case "suite_u_ultc_2bus_cw2" "../PSSE/RAW/psse_ultc_2bus_cw2.raw" "unitario" "ULTC" "ACTAPS=1; CW=2" "normal 0.95-1.10" $normalThresholds "Two-winding tap control with winding-voltage unit conversion"
    New-Case "suite_u_ultc_2bus_ntp10_inband" "../PSSE/RAW/psse_ultc_2bus_ntp10_inband.raw" "unitario" "ULTC" "ACTAPS=1; NTP=10; in band" "normal 0.95-1.10" $normalThresholds "NTP=10 tap grid should not move when voltage is already in band"
    New-Case "suite_u_ultc_2bus_ntp10_lowv" "../PSSE/RAW/psse_ultc_2bus_ntp10_lowv.raw" "unitario" "ULTC" "ACTAPS=1; NTP=10; low voltage" "normal 0.95-1.10" $normalThresholds "NTP=10 tap grid moves when regulated voltage is low"
    New-Case "suite_u_ultc_2bus_tab" "../PSSE/RAW/psse_ultc_2bus_tab.raw" "unitario" "ULTC" "ACTAPS=1; TAB impedance correction" "normal 0.95-1.10" $normalThresholds "Two-winding tap control with impedance-correction table metadata"
    New-Case "suite_u_ultc_3bus_remote" "psse_validation_cases_ultc/psse_ultc_3bus_remote.raw" "unitario" "ULTC" "ACTAPS=1; remote CONT" "normal 0.95-1.10" $normalThresholds "Remote regulated tap control"
    New-Case "suite_u_ultc_3bus_remote_cont_pos" "../PSSE/RAW/psse_ultc_3bus_remote_cont_pos.raw" "unitario" "ULTC" "ACTAPS=1; positive remote CONT" "normal 0.95-1.10" $normalThresholds "Remote regulated tap control with positive CONT sign convention"
    New-Case "suite_u_ultc_3bus_remote_limit" "psse_validation_cases_ultc/psse_ultc_3bus_remote_limit.raw" "unitario" "ULTC" "ACTAPS=1; tap limit" "normal 0.95-1.10" $normalThresholds "Remote tap control at limit"
    New-Case "suite_u_ultc_3w_w2" "../PSSE/RAW/psse_ultc_3w_w2.raw" "unitario" "ULTC" "ACTAPS=1; three-winding W2" "normal 0.95-1.10" $normalThresholds "Three-winding W2 tap without CW=2 conversion"
    New-Case "suite_u_ultc_3w_w2_cw2" "psse_validation_cases_ultc/psse_ultc_3w_w2_cw2.raw" "unitario" "ULTC" "ACTAPS=1; three-winding; CW=2" "normal 0.95-1.10" $normalThresholds "Three-winding W2 tap with CW=2"
    New-Case "suite_u_ultc_3w_w3" "../PSSE/RAW/psse_ultc_3w_w3.raw" "unitario" "ULTC" "ACTAPS=1; three-winding W3" "normal 0.95-1.10" $normalThresholds "Three-winding W3 controlled winding tap"
    New-Case "suite_u_ultc_3w_tab" "../PSSE/RAW/psse_ultc_3w_tab.raw" "unitario" "ULTC" "ACTAPS=1; three-winding TAB" "normal 0.95-1.10" $normalThresholds "Three-winding tap with impedance-correction table metadata"
    New-Case "suite_u_ultc_3w_tab_cw2" "../PSSE/RAW/psse_ultc_3w_tab_cw2.raw" "unitario" "ULTC" "ACTAPS=1; three-winding TAB; CW=2" "normal 0.95-1.10" $normalThresholds "Three-winding CW=2 tap with impedance-correction table metadata"
    New-Case "suite_u_facts_3bus_local" "psse_validation_cases_facts/psse_facts_3bus_local.raw" "unitario" "FACTS" "FACTS=1; local FCREG" "normal 0.95-1.10" $normalThresholds "STATCON local voltage control"
    New-Case "suite_u_facts_3bus_remote" "psse_validation_cases_facts/psse_facts_3bus_remote.raw" "unitario" "FACTS" "FACTS=1; remote FCREG" "normal 0.95-1.10" $normalThresholds "STATCON remote voltage control"
    New-Case "suite_u_facts_3bus_remote_limit" "psse_validation_cases_facts/psse_facts_3bus_remote_limit.raw" "unitario" "FACTS" "FACTS=1; SHMX limit" "normal 0.95-1.10" $normalThresholds "STATCON remote control at SHMX limit"
    New-Case "suite_u_twodc_4bus_base" "psse_validation_cases_twodc/psse_twodc_4bus_base.raw" "unitario" "TWODC" "DCTAPS=1; MDC base" "normal 0.95-1.10" $normalThresholds "Two-terminal DC static baseline"
    New-Case "suite_u_twodc_5bus_active" "psse_validation_cases_twodc/psse_twodc_5bus_v26p_active.raw" "unitario" "TWODC" "DCTAPS=1; active V26p reduced link" "normal 0.95-1.10" $normalThresholds "Reduced active LCC link based on V26p parameters"
    New-Case "suite_u_swdev_3bus_closed" "psse_validation_cases_swdev/psse_swdev_3bus_closed.raw" "unitario" "SWDEV" "THRSHZ=0.0001; STAT=1" "normal 0.95-1.10" $normalThresholds "Closed system switching device collapse"
    New-Case "suite_u_pqbrak_3bus_basic" "psse_validation_cases_solver_options/psse_solver_options_3bus_base.raw" "unitario" "PQBRAK" "GENERAL.PQBRAK=0.9700" "normal 0.95-1.10" $normalThresholds "Isolated PQBRAK load-scaling gate" @((New-ReplaceRegex '(?m)^GENERAL\s*,.*$' 'GENERAL, THRSHZ=0.0001, PQBRAK=0.9700'))

    New-Case "suite_i_genq_varlim0_remote_group" "psse_validation_cases_genq/psse_genq_5bus_remote_group.raw" "interaccion_simple" "GENQ; SOLVER_OPTIONS" "VARLIM=0; remote RMPCT group" "normal 0.95-1.10" $normalThresholds "GENQ grouped control with immediate VAR-limit option" @((New-ReplaceRegex '(?m)^SOLVER\s*,.*$' 'SOLVER, FNSL, ACTAPS=0, AREAIN=0, PHSHFT=0, DCTAPS=0, SWSHNT=0, FLATST=0, VARLIM=0, NONDIV=0'))
    New-Case "suite_i_genq_flatst1_qmax" "psse_validation_cases_genq/psse_genq_3bus_qmax.raw" "interaccion_simple" "GENQ; FLATST" "FLATST=1; VARLIM=1" "normal 0.95-1.10" $normalThresholds "GENQ limit behavior after PSS/E flat start" @((New-ReplaceRegex '(?m)^SOLVER\s*,.*$' 'SOLVER, FNSL, ACTAPS=0, AREAIN=0, PHSHFT=0, DCTAPS=0, SWSHNT=0, FLATST=1, VARLIM=1, NONDIV=0'))
    New-Case "suite_i_genq_nondiv1_qmin" "psse_validation_cases_genq/psse_genq_3bus_qmin.raw" "interaccion_simple" "GENQ; NONDIV" "NONDIV=1; VARLIM=1" "normal 0.95-1.10" $normalThresholds "GENQ low-side limit with non-divergent flag reported" @((New-ReplaceRegex '(?m)^SOLVER\s*,.*$' 'SOLVER, FNSL, ACTAPS=0, AREAIN=0, PHSHFT=0, DCTAPS=0, SWSHNT=0, FLATST=0, VARLIM=1, NONDIV=1'))
    New-Case "suite_i_swshnt_flatst1_continuous" "psse_validation_cases/psse_swshunt_2bus_continuous_local.raw" "interaccion_simple" "SWSHNT; FLATST" "SWSHNT=2; FLATST=1" "normal 0.95-1.10" $normalThresholds "Continuous shunt control under flat-start initialization" @((New-ReplaceRegex '(?m)^SOLVER\s*,.*$' 'SOLVER, FNSL, SWSHNT=2, FLATST=1'))
    New-Case "suite_i_swshnt_pqbrak_remote_group" "psse_validation_cases/psse_swshunt_3bus_remote_group.raw" "interaccion_simple" "SWSHNT; PQBRAK" "SWSHNT=2; PQBRAK=0.9700" "normal 0.95-1.10" $normalThresholds "Remote grouped shunts while PQBRAK is active" @((New-ReplaceRegex '(?m)^GENERAL\s*,.*$' 'GENERAL, THRSHZ=0.0001, PQBRAK=0.9700'))
    New-Case "suite_i_ultc_varlim1_remote_limit" "psse_validation_cases_ultc/psse_ultc_3bus_remote_limit.raw" "interaccion_simple" "ULTC; GENQ" "ACTAPS=1; VARLIM=1" "normal 0.95-1.10" $normalThresholds "Remote tap limit with generator limit option enabled" @((New-ReplaceRegex '(?m)^SOLVER\s*,.*$' 'SOLVER, FNSL, ACTAPS=1, SWSHNT=0, FLATST=1, VARLIM=1'))
    New-Case "suite_i_ultc_nondiv1_local" "psse_validation_cases_ultc/psse_ultc_2bus_local.raw" "interaccion_simple" "ULTC; NONDIV" "ACTAPS=1; NONDIV=1" "normal 0.95-1.10" $normalThresholds "Local tap control with non-divergent flag reported" @((New-ReplaceRegex '(?m)^SOLVER\s*,.*$' 'SOLVER, FNSL, ACTAPS=1, SWSHNT=0, FLATST=0, NONDIV=1'))
    New-Case "suite_i_ultc_multi_2w_shared" "../PSSE/RAW/psse_ultc_multi_2w_shared.raw" "interaccion_simple" "ULTC; shared CONT" "ACTAPS=1; two 2W transformers share regulated bus" "normal 0.95-1.10" $normalThresholds "Two two-winding tap controllers regulate the same remote bus"
    New-Case "suite_i_ultc_multi_3w_cw2_shared" "../PSSE/RAW/psse_ultc_multi_3w_cw2_shared.raw" "interaccion_simple" "ULTC; shared CONT; 3W; CW=2" "ACTAPS=1; two 3W CW=2 transformers share regulated bus" "normal 0.95-1.10" $normalThresholds "Two three-winding CW=2 tap controllers regulate the same remote bus"
    New-Case "suite_i_ultc_10bus_sign_matrix" "../PSSE/RAW/psse_ultc_10bus_sign.raw" "interaccion_simple" "ULTC; sign matrix; 2W; 3W; CW=2" "ACTAPS=1; mixed CONT signs and windings" "normal 0.95-1.10" $normalThresholds "Mixed two-winding and three-winding tap-direction sign matrix"
    New-Case "suite_i_facts_4bus_remote_group" "" "interaccion_simple" "FACTS; RMPCT" "FACTS=1; remote FCREG; RMPCT=60/40" "normal 0.95-1.10" $normalThresholds "Two STATCON devices share one remote regulated bus" @() $factsGroupRaw
    New-Case "suite_i_facts_pqbrak_remote_limit" "psse_validation_cases_facts/psse_facts_3bus_remote_limit.raw" "interaccion_simple" "FACTS; PQBRAK" "FACTS=1; PQBRAK=0.9700" "normal 0.95-1.10" $normalThresholds "FACTS remote limit while PQBRAK scaling is active" @((New-ReplaceRegex '(?m)^GENERAL\s*,.*$' 'GENERAL, THRSHZ=0.0001, PQBRAK=0.9700'))
    New-Case "suite_i_twodc_dctaps0_active" "psse_validation_cases_twodc/psse_twodc_5bus_v26p_active.raw" "interaccion_simple" "TWODC; DCTAPS" "DCTAPS=0; active LCC data" "normal 0.95-1.10" $normalThresholds "Active TWODC data with DC tap adjustment disabled" @((New-ReplaceRegex '(?m)^SOLVER\s*,.*$' 'SOLVER, FNSL, ACTAPS=0, AREAIN=0, PHSHFT=0, DCTAPS=0, SWSHNT=0, FLATST=0, VARLIM=0, NONDIV=0'))
    New-Case "suite_i_twodc_varlim1_loss" "psse_validation_cases_twodc/psse_twodc_4bus_mdc1_loss.raw" "interaccion_simple" "TWODC; GENQ" "DCTAPS=1; VARLIM=1; RDC losses" "normal 0.95-1.10" $normalThresholds "TWODC loss model with VAR-limit flag enabled" @((New-ReplaceRegex '(?m)^SOLVER\s*,.*$' 'SOLVER, FNSL, ACTAPS=0, AREAIN=0, PHSHFT=0, DCTAPS=1, SWSHNT=0, FLATST=0, VARLIM=1, NONDIV=0'))
    New-Case "suite_i_swdev_open_parallel_pqbrak" "psse_validation_cases_swdev/psse_swdev_3bus_open_parallel.raw" "interaccion_simple" "SWDEV; PQBRAK" "THRSHZ=0.0001; PQBRAK=0.9700; STAT=0" "normal 0.95-1.10" $normalThresholds "Open SWDEV with parallel line while PQBRAK is active" @((New-ReplaceRegex '(?m)^GENERAL\s*,.*$' 'GENERAL, THRSHZ=0.0001, PQBRAK=0.9700'))
    New-Case "suite_i_swdev_tight_thrshz_closed" "psse_validation_cases_swdev/psse_swdev_3bus_closed.raw" "interaccion_simple" "SWDEV; SYSTEM-WIDE" "THRSHZ=0.00001; STAT=1" "normal 0.95-1.10" $normalThresholds "SWDEV collapse sensitivity to tighter THRSHZ" @((New-ReplaceRegex '(?m)^GENERAL\s*,.*$' 'GENERAL, THRSHZ=0.00001'))
    New-Case "suite_i_pqbrak_genq_remote_single" "psse_validation_cases_genq/psse_genq_4bus_remote_single.raw" "interaccion_simple" "PQBRAK; GENQ" "PQBRAK=0.9700; VARLIM=1" "normal 0.95-1.10" $normalThresholds "Remote GENQ regulation with PQBRAK active" @((New-ReplaceRegex '(?m)^GENERAL\s*,.*$' 'GENERAL, THRSHZ=0.0001, PQBRAK=0.9700'))
    New-Case "suite_i_solver_all_options_3bus" "psse_validation_cases_solver_options/psse_solver_options_3bus_large_v26p_params.raw" "interaccion_simple" "SYSTEM-WIDE; GENQ" "ACTAPS=0; DCTAPS=1; SWSHNT=2; VARLIM=0; FLATST=0; NONDIV=0; PQBRAK defaults" "normal 0.95-1.10" $normalThresholds "Compact case carrying broad V26p-style solver option records"

    New-Case "suite_m_integrated_14bus_nominal" "psse_validation_cases_integrated/psse_integrated_controls_14bus.raw" "integrado_moderado" "GENQ;SWSHNT;ULTC;FACTS;TWODC;SWDEV;PQBRAK" "ACTAPS=1;DCTAPS=1;SWSHNT=2;FACTS=1;VARLIM=1" "normal 0.95-1.10 target" $normalThresholds "Baseline 14-bus integrated controls"
    New-Case "suite_m_integrated_14bus_flatst1" "psse_validation_cases_integrated/psse_integrated_controls_14bus.raw" "integrado_moderado" "GENQ;SWSHNT;ULTC;FACTS;TWODC;SWDEV;PQBRAK;FLATST" "ACTAPS=1;DCTAPS=1;SWSHNT=2;FACTS=1;FLATST=1;VARLIM=1" "normal 0.95-1.10 target" $normalThresholds "Integrated controls with flat start" @((New-ReplaceRegex '(?m)^SOLVER\s*,.*$' 'SOLVER, FNSL, ACTAPS=1, AREAIN=0, PHSHFT=0, DCTAPS=1, SWSHNT=2, FACTS=1, FLATST=1, VARLIM=1, NONDIV=0'))
    New-Case "suite_m_integrated_14bus_varlim0" "psse_validation_cases_integrated/psse_integrated_controls_14bus.raw" "integrado_moderado" "GENQ;SWSHNT;ULTC;FACTS;TWODC;SWDEV;PQBRAK" "ACTAPS=1;DCTAPS=1;SWSHNT=2;FACTS=1;VARLIM=0" "normal 0.95-1.10 target" $normalThresholds "Integrated controls with immediate VAR-limit behavior" @((New-ReplaceRegex '(?m)^SOLVER\s*,.*$' 'SOLVER, FNSL, ACTAPS=1, AREAIN=0, PHSHFT=0, DCTAPS=1, SWSHNT=2, FACTS=1, FLATST=0, VARLIM=0, NONDIV=0'))
    New-Case "suite_m_integrated_14bus_dctaps0" "psse_validation_cases_integrated/psse_integrated_controls_14bus.raw" "integrado_moderado" "GENQ;SWSHNT;ULTC;FACTS;TWODC;SWDEV;PQBRAK" "ACTAPS=1;DCTAPS=0;SWSHNT=2;FACTS=1;VARLIM=1" "normal 0.95-1.10 target" $normalThresholds "Integrated controls with DC tap adjustment disabled" @((New-ReplaceRegex '(?m)^SOLVER\s*,.*$' 'SOLVER, FNSL, ACTAPS=1, AREAIN=0, PHSHFT=0, DCTAPS=0, SWSHNT=2, FACTS=1, FLATST=0, VARLIM=1, NONDIV=0'))
    New-Case "suite_m_integrated_30bus_nominal" "psse_validation_cases_integrated/psse_integrated_controls_30bus_moderate.raw" "integrado_moderado" "GENQ;SWSHNT;ULTC;FACTS;TWODC;SWDEV;PQBRAK" "ACTAPS=1;DCTAPS=1;SWSHNT=2;FACTS=1;VARLIM=1" "normal 0.95-1.10 target" $normalThresholds "30-bus moderate integrated acceptance case"
    New-Case "suite_m_integrated_30bus_flatst1" "psse_validation_cases_integrated/psse_integrated_controls_30bus_moderate.raw" "integrado_moderado" "GENQ;SWSHNT;ULTC;FACTS;TWODC;SWDEV;PQBRAK;FLATST" "ACTAPS=1;DCTAPS=1;SWSHNT=2;FACTS=1;FLATST=1;VARLIM=1" "normal 0.95-1.10 target" $normalThresholds "30-bus moderate with flat start" @((New-ReplaceRegex '(?m)^SOLVER\s*,.*$' 'SOLVER, FNSL, ACTAPS=1, AREAIN=0, PHSHFT=0, DCTAPS=1, SWSHNT=2, FACTS=1, FLATST=1, VARLIM=1, NONDIV=0'))
    New-Case "suite_m_integrated_30bus_swsht1" "psse_validation_cases_integrated/psse_integrated_controls_30bus_moderate.raw" "integrado_moderado" "GENQ;SWSHNT;ULTC;FACTS;TWODC;SWDEV;PQBRAK" "ACTAPS=1;DCTAPS=1;SWSHNT=1;FACTS=1;VARLIM=1" "normal 0.95-1.10 target" $normalThresholds "30-bus moderate with stepped switched-shunt option" @((New-ReplaceRegex '(?m)^SOLVER\s*,.*$' 'SOLVER, FNSL, ACTAPS=1, AREAIN=0, PHSHFT=0, DCTAPS=1, SWSHNT=1, FACTS=1, FLATST=0, VARLIM=1, NONDIV=0'))
    New-Case "suite_m_integrated_30bus_conservative_adjust" "psse_validation_cases_integrated/psse_integrated_controls_30bus_moderate.raw" "integrado_moderado" "GENQ;SWSHNT;ULTC;FACTS;TWODC;SWDEV;PQBRAK;ADJUST" "ACTAPS=1;DCTAPS=1;SWSHNT=2;FACTS=1;MXTPSS=40;VCTOLV=0.00001" "normal 0.95-1.10 target" $normalThresholds "30-bus moderate with conservative adjustment budget" @((New-ReplaceRegex '(?m)^ADJUST\s*,.*$' 'ADJUST, MXTPSS=40, ADJTHR=0.005, ACCTAP=1.0, TAPLIM=0.05, SWVBND=100.0'))

    New-Case "suite_s_30bus_pqbrak_high" "psse_validation_cases_integrated/psse_integrated_controls_30bus_moderate.raw" "stress_xplore" "GENQ;SWSHNT;ULTC;FACTS;TWODC;SWDEV;PQBRAK" "Pqbrak=1.0000; ACTAPS=1;DCTAPS=1;SWSHNT=2" "stress, voltage excursions allowed" $stressThresholds "Stress: disable PQ load relief by raising PQBRAK" @((New-ReplaceRegex '(?m)^GENERAL\s*,.*$' 'GENERAL, THRSHZ=0.0001, PQBRAK=1.0000'))
    New-Case "suite_s_30bus_nondiv1" "psse_validation_cases_integrated/psse_integrated_controls_30bus_moderate.raw" "stress_xplore" "GENQ;SWSHNT;ULTC;FACTS;TWODC;SWDEV;PQBRAK;NONDIV" "NONDIV=1; ACTAPS=1;DCTAPS=1;SWSHNT=2" "stress, voltage excursions allowed" $stressThresholds "Stress: integrated controls with non-divergent flag" @((New-ReplaceRegex '(?m)^SOLVER\s*,.*$' 'SOLVER, FNSL, ACTAPS=1, AREAIN=0, PHSHFT=0, DCTAPS=1, SWSHNT=2, FACTS=1, FLATST=0, VARLIM=1, NONDIV=1'))
    New-Case "suite_s_40bus_nominal" "psse_validation_cases_integrated/psse_integrated_controls_40bus.raw" "stress_xplore" "GENQ;SWSHNT;ULTC;FACTS;TWODC;SWDEV;PQBRAK" "ACTAPS=1;DCTAPS=1;SWSHNT=2;FACTS=1;VARLIM=1" "stress, known low-voltage fixture" $stressThresholds "40-bus coupled-control stress reference"
    New-Case "suite_s_40bus_varlim0" "psse_validation_cases_integrated/psse_integrated_controls_40bus.raw" "stress_xplore" "GENQ;SWSHNT;ULTC;FACTS;TWODC;SWDEV;PQBRAK" "ACTAPS=1;DCTAPS=1;SWSHNT=2;FACTS=1;VARLIM=0" "stress, known low-voltage fixture" $stressThresholds "40-bus stress with immediate VAR limits" @((New-ReplaceRegex '(?m)^SOLVER\s*,.*$' 'SOLVER, FNSL, ACTAPS=1, AREAIN=0, PHSHFT=0, DCTAPS=1, SWSHNT=2, FACTS=1, FLATST=0, VARLIM=0, NONDIV=0'))
    New-Case "suite_s_40bus_dctaps0" "psse_validation_cases_integrated/psse_integrated_controls_40bus.raw" "stress_xplore" "GENQ;SWSHNT;ULTC;FACTS;TWODC;SWDEV;PQBRAK" "ACTAPS=1;DCTAPS=0;SWSHNT=2;FACTS=1;VARLIM=1" "stress, known low-voltage fixture" $stressThresholds "40-bus stress with DC tap adjustment disabled" @((New-ReplaceRegex '(?m)^SOLVER\s*,.*$' 'SOLVER, FNSL, ACTAPS=1, AREAIN=0, PHSHFT=0, DCTAPS=0, SWSHNT=2, FACTS=1, FLATST=0, VARLIM=1, NONDIV=0'))
)

$matrixRows = New-Object System.Collections.Generic.List[object]
foreach ($case in $cases) {
    $text = if ([string]::IsNullOrWhiteSpace($case.custom_text)) {
        Read-RawText $case.source
    }
    else {
        $case.custom_text
    }

    $text = Set-RawTitle $text $case.case_name $case.purpose
    $text = Apply-Transforms $text $case.transforms
    $text = $text.TrimEnd() + "`r`n"

    $rawPath = Join-Path $suiteDir ($case.case_name + ".raw")
    Set-Content -LiteralPath $rawPath -Value $text -Encoding ASCII

    $busCount = Count-RawBuses $text
    if ($busCount -gt 50) {
        throw "$($case.case_name) has $busCount buses, above Xplore limit."
    }
    $case.bus_count = $busCount
    $case.raw_path = $rawPath

    $matrixRows.Add([pscustomobject]@{
        case_name = $case.case_name
        bus_count = $case.bus_count
        category = $case.category
        control_families = $case.control_families
        raw_options = $case.raw_options
        voltage_band = $case.voltage_band
        reference_kind = $case.reference_kind
        thresholds = $case.thresholds
        purpose = $case.purpose
        source = $case.source
        raw_path = $case.raw_path
    }) | Out-Null
}

$csvPath = Join-Path $suiteDir "validation_matrix.csv"
$matrixRows | Sort-Object category, case_name | Export-Csv -LiteralPath $csvPath -NoTypeInformation -Encoding ASCII

$mdPath = Join-Path $suiteDir "validation_matrix.md"
$md = New-Object System.Collections.Generic.List[string]
$md.Add("# PSS/E RAW Validation Suite Matrix") | Out-Null
$md.Add("") | Out-Null
$md.Add("Generated by tools/generate_psse_validation_suite.ps1. All generated RAW cases are capped at 50 buses for the local PSS/E Xplore license.") | Out-Null
$md.Add("") | Out-Null
$md.Add("## Counts") | Out-Null
$md.Add("") | Out-Null
$md.Add("| category | cases | max buses |") | Out-Null
$md.Add("|---|---:|---:|") | Out-Null
foreach ($g in ($matrixRows | Group-Object category | Sort-Object Name)) {
    $maxBus = ($g.Group | Measure-Object bus_count -Maximum).Maximum
    $md.Add("| $($g.Name) | $($g.Count) | $maxBus |") | Out-Null
}
$md.Add("") | Out-Null
$md.Add("## Matrix") | Out-Null
$md.Add("") | Out-Null
$md.Add("| case_name | bus_count | category | control_families | raw_options | voltage_band | reference_kind | thresholds | purpose |") | Out-Null
$md.Add("|---|---:|---|---|---|---|---|---|---|") | Out-Null
foreach ($row in ($matrixRows | Sort-Object category, case_name)) {
    $vals = @(
        $row.case_name,
        $row.bus_count,
        $row.category,
        $row.control_families,
        $row.raw_options,
        $row.voltage_band,
        $row.reference_kind,
        $row.thresholds,
        $row.purpose
    ) | ForEach-Object { ($_ -replace '\|', '/') }
    $md.Add("| $($vals -join ' | ') |") | Out-Null
}
Set-Content -LiteralPath $mdPath -Value $md -Encoding ASCII

$readmePath = Join-Path $suiteDir "README.md"
$readme = @(
    "# PSS/E Validation Suite",
    "",
    "This folder is a generated validation suite for local PSS/E Xplore vs runpf_psse comparisons.",
    "",
    "- All RAW files are <=50 buses.",
    "- Original fixtures under sibling psse_validation_cases_* folders are not modified.",
    "- PSS/E outputs are expected in solved_raw/, logs/, idv/, and optional .sav files beside this suite.",
    "- Use validation_matrix.csv or validation_matrix.md as the source of case purpose, category, options, thresholds, and reference kind.",
    "",
    "Suggested PSS/E run from workspace root:",
    "",
    "powershell -ExecutionPolicy Bypass -File .\PSSE\Solve-RawPowerFlow.ps1 -RawFile '..\auditoria_psse_matpower\psse_validation_suite\*.raw' -OutputDir '..\auditoria_psse_matpower\psse_validation_suite' -WriteSolvedRaw",
    ""
)
Set-Content -LiteralPath $readmePath -Value $readme -Encoding ASCII

Write-Host "Generated $($matrixRows.Count) RAW cases in $suiteDir"
Write-Host "Matrix CSV: $csvPath"
Write-Host "Matrix MD: $mdPath"
