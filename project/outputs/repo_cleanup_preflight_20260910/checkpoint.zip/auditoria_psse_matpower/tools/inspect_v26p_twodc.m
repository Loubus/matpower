function report = inspect_v26p_twodc()
% inspect_v26p_twodc - Reproduces the local two-terminal DC diagnostic.
%
%   REPORT = INSPECT_V26P_TWODC()
%
% Imports PSSE/V26p_Trs_2532.raw, prints the parsed PSS/E two-terminal DC
% data relevant to the current issue, prints the converted MATPOWER dcline
% equivalent, and compares runpf with the previous no-loss dcline equivalent
% against the current RDC-loss equivalent.

verbose = 0;
print_output = 0;
raw_revision = 34;
selected_buses = [20; 22; 85; 86; 5010; 5020];

this_file = mfilename('fullpath');
tools_dir = fileparts(this_file);
audit_dir = fileparts(tools_dir);
workspace_dir = fileparts(audit_dir);
matpower_dir = fullfile(workspace_dir, 'matpower');
raw_file = fullfile(workspace_dir, 'PSSE', 'V26p_Trs_2532.raw');

addpath(genpath(fullfile(matpower_dir, 'mptest', 'lib')));
addpath(genpath(fullfile(matpower_dir, 'mp-opt-model', 'lib')));
addpath(genpath(fullfile(matpower_dir, 'mips', 'lib')));
addpath(genpath(fullfile(matpower_dir, 'lib')));
addpath(genpath(fullfile(matpower_dir, 'data')));

[~, ~, ~, ~, BUS_I, ~, PD, ~, ~, ~, ~, VM, VA] = idx_bus;
[~, PG, ~, ~, ~, ~, ~, GEN_STATUS] = idx_gen;
c = idx_dcline;

mpopt = mpoption('verbose', verbose, 'out.all', print_output);
mpc = psse2mpc(raw_file, 0, raw_revision);

twodc = mpc.psse.twodc;
col = twodc.col;
active = find(mpc.dcline(:, c.BR_STATUS) > 0);
blocked = find(mpc.dcline(:, c.BR_STATUS) == 0);

fprintf('RAW file: %s\n', raw_file);
fprintf('two-terminal DC rows=%d active=%d blocked=%d\n', ...
    size(twodc.num, 1), length(active), length(blocked));
fprintf('\nParsed PSS/E columns [MDC RDC SETVL VSCHD VCMOD RCOMP IPR IPI XCAPR XCAPI]\n');
for k = 1:size(twodc.num, 1)
    fprintf('%2d %.0f %.6f %.6f %.6f %.6f %.6f %.0f %.0f %.6f %.6f\n', ...
        k, twodc.num(k, col.mdc), twodc.num(k, col.rdc), ...
        twodc.num(k, col.setvl), twodc.num(k, col.vschd), ...
        twodc.num(k, col.vcmod), twodc.num(k, col.rcomp), ...
        twodc.num(k, col.ipr), twodc.num(k, col.ipi), ...
        twodc.num(k, col.xcapr), twodc.num(k, col.xcapi));
end

fprintf('\nConverted dcline rows [F T ST PF PT LOSS0 LOSS1]\n');
for k = 1:size(mpc.dcline, 1)
    fprintf('%2d %.0f %.0f %.0f %.6f %.6f %.6f %.6f\n', ...
        k, mpc.dcline(k, c.F_BUS), mpc.dcline(k, c.T_BUS), ...
        mpc.dcline(k, c.BR_STATUS), mpc.dcline(k, c.PF), ...
        mpc.dcline(k, c.PT), mpc.dcline(k, c.LOSS0), ...
        mpc.dcline(k, c.LOSS1));
end
fprintf('active loss sum %.6f MW\n', ...
    sum(mpc.dcline(active, c.PF) - mpc.dcline(active, c.PT)));

mpc_noloss = mpc;
mpc_noloss.dcline(active, c.PT) = mpc_noloss.dcline(active, c.PF);
mpc_noloss.dcline(active, c.LOSS0) = 0;
mpc_noloss.dcline(active, c.LOSS1) = 0;

results_noloss = runpf(mpc_noloss, mpopt);
results_loss = runpf(mpc, mpopt);

mpc_disabled = mpc;
mpc_disabled.dcline(:, c.BR_STATUS) = 0;
results_disabled = runpf(mpc_disabled, mpopt);

results_psse = runpf_psse(mpc, mpopt);

fprintf('\nrunpf no-loss success=%d iterations=%d\n', ...
    results_noloss.success, results_noloss.iterations);
fprintf('runpf with-loss success=%d iterations=%d\n', ...
    results_loss.success, results_loss.iterations);
fprintf('runpf dcline-disabled success=%d iterations=%d\n', ...
    results_disabled.success, results_disabled.iterations);
twodc_control = results_psse.psse.twodc.control;
fprintf('runpf_psse with-loss success=%d iterations=%d twodc_current=%d acpf=%d acpf_status=%s\n', ...
    results_psse.success, results_psse.iterations, ...
    twodc_control.current_limited, twodc_control.ac_pf_success, ...
    twodc_control.ac_pf_status);
fprintf('runpf_psse TWODC control [row mode apply_model apply_q Idc Vdcr Vdci Vcomp alpha gamma tapr tapi QACR QACI loss]\n');
for k = 1:length(twodc_control.pf)
    fprintf('%2d %-7s %d %d %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f %.6f\n', ...
        k, twodc_control.mode{k}, twodc_control.apply_model(k), ...
        twodc_control.apply_q(k), twodc_control.idc_ka(k), ...
        twodc_control.vdcr_kv(k), twodc_control.vdci_kv(k), ...
        twodc_control.vcomp_kv(k), twodc_control.alpha_deg(k), ...
        twodc_control.gamma_deg(k), twodc_control.tapr(k), ...
        twodc_control.tapi(k), twodc_control.qacr_mvar(k), ...
        twodc_control.qaci_mvar(k), twodc_control.loss_mw(k));
end

fprintf('\nrunpf_psse dcline rows [F T ST PF PT QF QT LOSS0 LOSS1]\n');
for k = 1:size(results_psse.dcline, 1)
    fprintf('%2d %.0f %.0f %.0f %.6f %.6f %.6f %.6f %.6f %.6f\n', ...
        k, results_psse.dcline(k, c.F_BUS), results_psse.dcline(k, c.T_BUS), ...
        results_psse.dcline(k, c.BR_STATUS), results_psse.dcline(k, c.PF), ...
        results_psse.dcline(k, c.PT), results_psse.dcline(k, c.QF), ...
        results_psse.dcline(k, c.QT), results_psse.dcline(k, c.LOSS0), ...
        results_psse.dcline(k, c.LOSS1));
end

fprintf('\nBus comparison [BUS VM_no_loss VA_no_loss VM_with_loss VA_with_loss dVM dVA]\n');
bus_compare = zeros(length(selected_buses), 7);
for k = 1:length(selected_buses)
    b = selected_buses(k);
    i0 = find(results_noloss.bus(:, BUS_I) == b);
    i1 = find(results_loss.bus(:, BUS_I) == b);
    bus_compare(k, :) = [b ...
        results_noloss.bus(i0, VM) results_noloss.bus(i0, VA) ...
        results_loss.bus(i1, VM) results_loss.bus(i1, VA) ...
        results_loss.bus(i1, VM) - results_noloss.bus(i0, VM) ...
        results_loss.bus(i1, VA) - results_noloss.bus(i0, VA)];
    fprintf('%6.0f %.9f %.9f %.9f %.9f %.9f %.9f\n', bus_compare(k, :));
end

pbal_noloss = active_pg_minus_pd(results_noloss, PG, GEN_STATUS, PD);
pbal_loss = active_pg_minus_pd(results_loss, PG, GEN_STATUS, PD);
pbal_psse = active_pg_minus_pd(results_psse, PG, GEN_STATUS, PD);
fprintf('PG(active)-PD no-loss %.6f with-loss %.6f delta %.6f MW\n', ...
    pbal_noloss, pbal_loss, pbal_loss - pbal_noloss);
fprintf('PG(active)-PD runpf_psse %.6f MW\n', pbal_psse);

report = struct( ...
    'raw_file', raw_file, ...
    'twodc', twodc, ...
    'dcline', mpc.dcline, ...
    'active_loss_mw', sum(mpc.dcline(active, c.PF) - mpc.dcline(active, c.PT)), ...
    'results_noloss', results_noloss, ...
    'results_loss', results_loss, ...
    'results_disabled', results_disabled, ...
    'results_psse', results_psse, ...
    'bus_compare', bus_compare ...
);

function pbal = active_pg_minus_pd(results, PG, GEN_STATUS, PD)
online = results.gen(:, GEN_STATUS) > 0;
pbal = sum(results.gen(online, PG)) - sum(results.bus(:, PD));
