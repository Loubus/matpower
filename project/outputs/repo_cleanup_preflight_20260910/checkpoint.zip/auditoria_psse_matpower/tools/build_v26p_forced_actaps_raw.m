function out = build_v26p_forced_actaps_raw()
% build_v26p_forced_actaps_raw - Creates full V26p RAW with ACTAPS forced on.

root_dir = fileparts(fileparts(fileparts(mfilename('fullpath'))));
src = fullfile(root_dir, 'PSSE', 'V26p_Trs_2532.raw');
out_dir = fullfile(root_dir, 'PSSE', 'V26P_ACTAPS1');
if ~exist(out_dir, 'dir')
    mkdir(out_dir);
end
dst = fullfile(out_dir, 'V26p_Trs_2532_ACTAPS1.raw');

txt = fileread(src);
txt = regexprep(txt, ...
    'SOLVER,\s*FNSL,\s*ACTAPS\s*=\s*0', ...
    'SOLVER, FNSL, ACTAPS=1', ...
    'once', 'ignorecase');
fid = fopen(dst, 'w');
if fid < 0
    error('build_v26p_forced_actaps_raw:open', ...
        'Could not write %s', dst);
end
cleanup = onCleanup(@() fclose(fid));
fwrite(fid, txt);

out = struct('source', src, 'raw', dst, 'out_dir', out_dir);
fprintf('Wrote forced ACTAPS=1 RAW: %s\n', dst);
