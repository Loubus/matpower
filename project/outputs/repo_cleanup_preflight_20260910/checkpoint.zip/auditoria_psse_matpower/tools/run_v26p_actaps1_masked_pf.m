function summary = run_v26p_actaps1_masked_pf(max_tap_iter)
% run_v26p_actaps1_masked_pf - Full TRANSENER PF with masked ULTC rows.
%
% Runs PSSE/V26p_Trs_2532.raw with ACTAPS forced on and the explicit
% TRANSENER ULTC study mask applied. Compares the solved PF end state against
% the RAW initial bus voltage snapshot. If MAX_TAP_ITER is supplied, MXTPSS
% is capped for a bounded diagnostic run.

if nargin < 1
    max_tap_iter = [];
end

root_dir = fileparts(fileparts(fileparts(mfilename('fullpath'))));
mp_dir = fullfile(root_dir, 'matpower');
raw_file = fullfile(root_dir, 'PSSE', 'V26p_Trs_2532.raw');
out_dir = fullfile(root_dir, 'auditoria_psse_matpower', 'results', ...
    'v26p_ultc_study_mask_pf');
if ~exist(out_dir, 'dir')
    mkdir(out_dir);
end
addpath(fullfile(mp_dir, 'lib'));

mpc = psse2mpc(raw_file, 0, 34);
mpc.psse.system.solver.ACTAPS = 1;
mpc.psse.system.solver.FLATST = 0;
if ~isempty(max_tap_iter)
    mpc.psse.system.adjust.MXTPSS = max_tap_iter;
end
[mpc, mask] = apply_v26p_ultc_study_mask(mpc);

[~, ~, ~, ~, BUS_I, ~, ~, ~, ~, ~, ~, VM, VA] = idx_bus;
[~, ~, ~, ~, ~, ~, ~, ~, TAP] = idx_brch;
initial_bus = mpc.bus;
initial_branch = mpc.branch;

mpopt = mpoption('verbose', 0, 'out.all', 0, 'pf.enforce_q_lims', 0);
results = runpf_psse(mpc, mpopt);

vm_delta = results.bus(:, VM) - initial_bus(:, VM);
va_delta = angle_delta_deg(results.bus(:, VA), initial_bus(:, VA));
tap_delta = [];
if size(results.branch, 1) == size(initial_branch, 1)
    tap_delta = results.branch(:, TAP) - initial_branch(:, TAP);
end

summary = struct();
summary.raw_file = raw_file;
summary.success = logical(results.success);
summary.iterations = results.iterations;
summary.max_tap_iter = max_tap_iter;
summary.mask = mask;
summary.max_abs_vm_delta = max(abs(vm_delta));
summary.max_abs_va_delta = max(abs(va_delta));
summary.worst_vm = worst_bus_row(results.bus, initial_bus, vm_delta, BUS_I);
summary.worst_va = worst_bus_row(results.bus, initial_bus, va_delta, BUS_I);
summary.tap_changed_count = nnz(abs(tap_delta) > 1e-10);
if isempty(tap_delta)
    summary.max_abs_tap_delta = NaN;
else
    summary.max_abs_tap_delta = max(abs(tap_delta));
end
summary.xfmr = struct();
if isfield(results, 'psse') && isfield(results.psse, 'xfmr') && ...
        isfield(results.psse.xfmr, 'control')
    summary.xfmr = results.psse.xfmr.control;
end

summary.mat_path = fullfile(out_dir, 'v26p_actaps1_masked_pf.mat');
summary.report_path = fullfile(out_dir, 'v26p_actaps1_masked_pf.md');
save(summary.mat_path, 'summary', 'results', 'initial_bus', ...
    'initial_branch', '-v7.3');
write_report(summary);

fprintf('success=%d iterations=%d\n', summary.success, summary.iterations);
if ~isempty(summary.max_tap_iter)
    fprintf('bounded_mxtpss=%g\n', summary.max_tap_iter);
end
fprintf('study_locked=%d locked_out=%d xfmr_adjustments=%d\n', ...
    scalar_field(summary.xfmr, 'study_locked'), ...
    scalar_field(summary.xfmr, 'locked_out'), ...
    scalar_field(summary.xfmr, 'num_adjustments'));
fprintf('max_abs_vm_delta=%.12g bus=%g\n', ...
    summary.max_abs_vm_delta, summary.worst_vm.bus);
fprintf('max_abs_va_delta=%.12g bus=%g\n', ...
    summary.max_abs_va_delta, summary.worst_va.bus);
fprintf('tap_changed_count=%d max_abs_tap_delta=%.12g\n', ...
    summary.tap_changed_count, summary.max_abs_tap_delta);
fprintf('report=%s\n', summary.report_path);

function d = angle_delta_deg(a, b)
d = mod(a - b + 180, 360) - 180;

function row = worst_bus_row(bus, initial_bus, delta, bus_col)
[~, idx] = max(abs(delta));
row = struct( ...
    'row', idx, ...
    'bus', bus(idx, bus_col), ...
    'initial_vm', initial_bus(idx, 8), ...
    'final_vm', bus(idx, 8), ...
    'initial_va', initial_bus(idx, 9), ...
    'final_va', bus(idx, 9), ...
    'delta', delta(idx));

function val = scalar_field(s, field)
if isstruct(s) && isfield(s, field) && ~isempty(s.(field))
    val = double(s.(field));
else
    val = NaN;
end

function write_report(summary)
fid = fopen(summary.report_path, 'w');
if fid < 0
    error('run_v26p_actaps1_masked_pf:report_open', ...
        'Could not write %s', summary.report_path);
end
cleanup = onCleanup(@() fclose(fid));

fprintf(fid, '# V26p ACTAPS=1 Masked ULTC PF\n\n');
fprintf(fid, '- RAW: `%s`\n', summary.raw_file);
fprintf(fid, '- Success: `%d`\n', summary.success);
fprintf(fid, '- Iterations: `%d`\n', summary.iterations);
if ~isempty(summary.max_tap_iter)
    fprintf(fid, '- Bounded MXTPSS: `%g`\n', summary.max_tap_iter);
end
fprintf(fid, '- Study mask: `%s`\n', summary.mask.label);
fprintf(fid, '- Study locked rows: `%d`\n', summary.mask.count);
fprintf(fid, '- Total locked rows in report: `%g`\n', ...
    scalar_field(summary.xfmr, 'locked_out'));
fprintf(fid, '- Transformer adjustments: `%g`\n', ...
    scalar_field(summary.xfmr, 'num_adjustments'));
fprintf(fid, '- Rebuild rejections: `%g`\n\n', ...
    scalar_field(summary.xfmr, 'rebuild_rejected'));
fprintf(fid, '- Last active violations: `%g`\n', ...
    scalar_field(summary.xfmr, 'last_violations'));
fprintf(fid, '- Locked violations: `%g`\n', ...
    scalar_field(summary.xfmr, 'locked_violations'));
fprintf(fid, '- Rebuild rejected rows: `%s`\n', ...
    join_numbers(vector_field(summary.xfmr, 'rebuild_rejected_rows')));
fprintf(fid, '- Replay accepted rows: `%s`\n', ...
    join_numbers(vector_field(summary.xfmr, 'rebuild_replay_accepted_rows')));
fprintf(fid, '- Replay rejected rows: `%s`\n\n', ...
    join_numbers(vector_field(summary.xfmr, 'rebuild_replay_rejected_rows')));

fprintf(fid, '## End State vs RAW Initial Conditions\n\n');
fprintf(fid, '| metric | value | bus |\n');
fprintf(fid, '|---|---:|---:|\n');
fprintf(fid, '| max abs VM delta | %.12g pu | %.0f |\n', ...
    summary.max_abs_vm_delta, summary.worst_vm.bus);
fprintf(fid, '| max abs VA delta | %.12g deg | %.0f |\n', ...
    summary.max_abs_va_delta, summary.worst_va.bus);
fprintf(fid, '| changed branch taps | %d | |\n', summary.tap_changed_count);
fprintf(fid, '| max abs branch tap delta | %.12g | |\n\n', ...
    summary.max_abs_tap_delta);

fprintf(fid, 'Worst VM bus: initial `%.12g`, final `%.12g`, delta `%.12g`.\n\n', ...
    summary.worst_vm.initial_vm, summary.worst_vm.final_vm, ...
    summary.worst_vm.delta);
fprintf(fid, 'Worst VA bus: initial `%.12g`, final `%.12g`, delta `%.12g`.\n', ...
    summary.worst_va.initial_va, summary.worst_va.final_va, ...
    summary.worst_va.delta);

function v = vector_field(s, field)
if isstruct(s) && isfield(s, field) && ~isempty(s.(field))
    v = s.(field)(:);
else
    v = [];
end

function txt = join_numbers(v)
if isempty(v)
    txt = '';
else
    txt = strjoin(cellstr(num2str(v(:))), ' ');
end
