function results = build_sadi_pq_equivalent_case(varargin)
% build_sadi_pq_equivalent_case - Build a SADI-only fixed-P/Q border case.
%
%   RESULTS = BUILD_SADI_PQ_EQUIVALENT_CASE()
%   RESULTS = BUILD_SADI_PQ_EQUIVALENT_CASE(OPTS)
%
% Imports the full TRANSENER/PSS/E RAW, removes foreign-area networks, and
% replaces active Argentina-to-foreign AC ties by fixed P/Q equivalents at
% the Argentine boundary bus.

define_constants;

root = fileparts(fileparts(fileparts(mfilename('fullpath'))));
cfg = default_config(root);
if nargin >= 1 && ~isempty(varargin{1})
    cfg = merge_options(cfg, varargin{1});
end
if ~strcmp(cfg.border_mode, 'pq_equivalent')
    error('build_sadi_pq_equivalent_case:unsupported_mode', ...
        'Unsupported border_mode "%s"; only "pq_equivalent" is implemented.', ...
        cfg.border_mode);
end
if ~exist(cfg.out_dir, 'dir')
    mkdir(cfg.out_dir);
end

addpath(genpath(fullfile(root, 'matpower', 'lib')));
addpath(fileparts(mfilename('fullpath')));

mpopt_full = mpoption('verbose', cfg.verbose, 'out.all', 0, ...
    'pf.alg', cfg.pf_alg, 'pf.enforce_q_lims', cfg.enforce_q_lims);
mpopt_reduced = mpoption('verbose', cfg.verbose, 'out.all', 0, ...
    'pf.alg', cfg.pf_alg, 'pf.enforce_q_lims', cfg.enforce_q_lims);

mpc_full = psse2mpc(cfg.raw_file, 0, cfg.raw_revision);
study_mask_full = [];
if cfg.apply_v26p_ultc_study_mask
    [~, study_mask_full] = apply_v26p_ultc_study_mask(mpc_full);
end
switch cfg.reference_source
    case 'full_runpf_psse'
        pf_full = runpf_psse(mpc_full, mpopt_full);
        if ~pf_full.success
            error('build_sadi_pq_equivalent_case:full_pf_failed', ...
                ['Full RAW runpf_psse did not converge; refusing to ' ...
                'calibrate P/Q equivalents.']);
        end
        mpc_ref = operating_point_case(mpc_full, pf_full);
        flow_ref = pf_full;
    case 'raw_snapshot'
        pf_full = [];
        mpc_ref = branch_flow_snapshot_case(mpc_full);
        flow_ref = mpc_ref;
    otherwise
        error('build_sadi_pq_equivalent_case:unsupported_reference_source', ...
            'Unsupported reference_source "%s".', cfg.reference_source);
end
boundary = identify_boundary_equivalents(mpc_ref, flow_ref, cfg);
[mpc_sadi, boundary, masks] = build_reduced_case(mpc_ref, boundary, cfg);
if cfg.apply_v26p_ultc_study_mask
    [mpc_sadi, masks.reduced_ultc_study_mask] = ...
        apply_reduced_ultc_study_mask(mpc_sadi, study_mask_full);
end
if strcmp(cfg.reduced_solver, 'runpf_psse')
    pf_sadi = runpf_psse(mpc_sadi, mpopt_reduced);
else
    pf_sadi = runpf(mpc_sadi, mpopt_reduced);
end
validation = validate_reduced_case(mpc_ref, pf_sadi, masks, boundary, cfg);

results = struct();
results.config = cfg;
results.raw_file = cfg.raw_file;
results.output_dir = cfg.out_dir;
results.full_runpf_psse = pf_full;
results.reference_source = cfg.reference_source;
results.reference_case = mpc_ref;
results.boundary = boundary;
results.mpc_sadi = mpc_sadi;
results.runpf_sadi = pf_sadi;
results.validation = validation;
results.masks = masks;

save(fullfile(cfg.out_dir, 'sadi_pq_equivalent_results.mat'), 'results', '-v7.3');
case_file = fullfile(cfg.out_dir, 'case_sadi_pq_equivalent.m');
savecase(case_file, mpc_sadi);
write_outputs(cfg.out_dir, boundary, validation, results, case_file);

fprintf('SADI P/Q-equivalent case written to:\n  %s\n', cfg.out_dir);
if isempty(pf_full)
    fprintf('Reference source: RAW embedded VM/VA snapshot\n');
else
    fprintf('Full RAW runpf_psse success: %d\n', pf_full.success);
end
fprintf('Reduced %s success: %d\n', cfg.reduced_solver, pf_sadi.success);
fprintf('Retained buses: %d, removed buses: %d\n', ...
    nnz(masks.keep_bus), nnz(~masks.keep_bus));
fprintf('Boundary rows: %d active / %d total\n', ...
    nnz(boundary.status), height(boundary));
fprintf('max |dVM| = %.6g pu, RMS |dVM| = %.6g pu\n', ...
    validation.summary.max_abs_dvm_pu, validation.summary.rms_dvm_pu);
fprintf('max |dVA| = %.6g deg, RMS |dVA| = %.6g deg\n', ...
    validation.summary.max_abs_dva_deg, validation.summary.rms_dva_deg);
end

function cfg = default_config(root)
cfg = struct();
cfg.border_mode = 'pq_equivalent';
cfg.raw_file = fullfile(root, 'PSSE', 'V26p_Trs_2532.raw');
cfg.raw_revision = 34;
cfg.out_dir = fullfile(root, 'auditoria_psse_matpower', 'results', ...
    'sadi_pq_equivalent');
cfg.reference_source = 'full_runpf_psse';
cfg.foreign_areas = [18 19 20 22 99];
cfg.foreign_area_names = containers.Map( ...
    {'18', '19', '20', '22', '99'}, ...
    {'Paraguay', 'Chile/SING', 'Brazil', 'Bolivia', 'Uruguay'});
cfg.verbose = 0;
cfg.pf_alg = 'NR';
cfg.enforce_q_lims = 0;
cfg.reduced_solver = 'runpf';
cfg.keep_reduced_psse_metadata = false;
cfg.force_reduced_actaps = [];
cfg.apply_v26p_ultc_study_mask = false;
cfg.sign_convention = ['positive P_MW/Q_MVAr is fixed injection into SADI ' ...
    'at the Argentine boundary bus; positive Argentine-to-foreign solved ' ...
    'branch flow becomes negative fixed injection'];
end

function cfg = merge_options(cfg, opts)
names = fieldnames(opts);
for k = 1:numel(names)
    cfg.(names{k}) = opts.(names{k});
end
end

function mpc_ref = operating_point_case(mpc, pf)
define_constants;
[GEN_BUS] = idx_gen;

mpc_ref = mpc;

[tf_bus, loc_bus] = ismember(mpc.bus(:, BUS_I), pf.bus(:, BUS_I));
if all(tf_bus)
    ncol = min(size(mpc.bus, 2), size(pf.bus, 2));
    mpc_ref.bus(:, 2:ncol) = pf.bus(loc_bus, 2:ncol);
    mpc_ref.bus(:, BUS_I) = mpc.bus(:, BUS_I);
end

if size(mpc.branch, 1) == size(pf.branch, 1)
    ncol = min(size(mpc.branch, 2), size(pf.branch, 2));
    mpc_ref.branch(:, BR_R:ncol) = pf.branch(:, BR_R:ncol);
    mpc_ref.branch(:, F_BUS) = mpc.branch(:, F_BUS);
    mpc_ref.branch(:, T_BUS) = mpc.branch(:, T_BUS);
end

if size(mpc.gen, 1) == size(pf.gen, 1)
    ncol = min(size(mpc.gen, 2), size(pf.gen, 2));
    mpc_ref.gen(:, 2:ncol) = pf.gen(:, 2:ncol);
    mpc_ref.gen(:, GEN_BUS) = mpc.gen(:, GEN_BUS);
end

if isfield(mpc, 'dcline') && isfield(pf, 'dcline') && ...
        size(mpc.dcline, 1) == size(pf.dcline, 1)
    ncol = min(size(mpc.dcline, 2), size(pf.dcline, 2));
    mpc_ref.dcline(:, 3:ncol) = pf.dcline(:, 3:ncol);
    mpc_ref.dcline(:, 1:2) = mpc.dcline(:, 1:2);
end
end

function mpc_ref = branch_flow_snapshot_case(mpc)
define_constants;

mpc_ref = mpc;
if size(mpc_ref.branch, 2) < QT
    mpc_ref.branch(:, end+1:QT) = 0;
end

bus_numbers = mpc.bus(:, BUS_I);
[tf_f, fidx] = ismember(mpc.branch(:, F_BUS), bus_numbers);
[tf_t, tidx] = ismember(mpc.branch(:, T_BUS), bus_numbers);
if ~all(tf_f) || ~all(tf_t)
    error('build_sadi_pq_equivalent_case:branch_flow_bus_lookup', ...
        'Could not map every branch endpoint to a bus row.');
end

v = mpc.bus(:, VM) .* exp(1j * pi / 180 * mpc.bus(:, VA));
status = mpc.branch(:, BR_STATUS);
z = mpc.branch(:, BR_R) + 1j * mpc.branch(:, BR_X);
ys = zeros(size(z));
valid_z = abs(z) > 0;
ys(valid_z) = status(valid_z) ./ z(valid_z);
bc = status .* mpc.branch(:, BR_B);
tap = ones(size(z));
nonzero_tap = mpc.branch(:, TAP) ~= 0;
tap(nonzero_tap) = mpc.branch(nonzero_tap, TAP);
tap = tap .* exp(1j * pi / 180 * mpc.branch(:, SHIFT));

yff = (ys + 1j * bc / 2) ./ (tap .* conj(tap));
yft = -ys ./ conj(tap);
ytf = -ys ./ tap;
ytt = ys + 1j * bc / 2;

vf = v(fidx);
vt = v(tidx);
iflow_f = yff .* vf + yft .* vt;
iflow_t = ytf .* vf + ytt .* vt;
sf = mpc.baseMVA * vf .* conj(iflow_f);
st = mpc.baseMVA * vt .* conj(iflow_t);

mpc_ref.branch(:, PF) = real(sf);
mpc_ref.branch(:, QF) = imag(sf);
mpc_ref.branch(:, PT) = real(st);
mpc_ref.branch(:, QT) = imag(st);
end

function tbl = identify_boundary_equivalents(mpc, pf, cfg)
define_constants;

br_meta = mpc.psse.branch;
area_by_bus = containers.Map(mpc.bus(:, BUS_I), mpc.bus(:, BUS_AREA));
is_foreign_from = ismember(bus_area_vector(area_by_bus, br_meta.f_bus_ext), ...
    cfg.foreign_areas);
is_foreign_to = ismember(bus_area_vector(area_by_bus, br_meta.t_bus_ext), ...
    cfg.foreign_areas);
is_boundary = xor(is_foreign_from, is_foreign_to) & br_meta.branch_idx(:) > 0;
rows = find(is_boundary);

n = numel(rows);
interface = strings(n, 1);
country = strings(n, 1);
arg_bus = zeros(n, 1);
foreign_bus = zeros(n, 1);
arg_side = strings(n, 1);
foreign_area = zeros(n, 1);
source_element = strings(n, 1);
status = false(n, 1);
p_arg_to_foreign_mw = zeros(n, 1);
q_arg_to_foreign_mvar = zeros(n, 1);
p_mw = zeros(n, 1);
q_mvar = zeros(n, 1);
branch_idx = zeros(n, 1);
raw_branch_row = rows(:);
ckt = strings(n, 1);
sign_convention = strings(n, 1);

for k = 1:n
    r = rows(k);
    bi = br_meta.branch_idx(r);
    branch_idx(k) = bi;
    f_bus = br_meta.f_bus_ext(r);
    t_bus = br_meta.t_bus_ext(r);
    f_foreign = is_foreign_from(r);
    if f_foreign
        arg_bus(k) = t_bus;
        foreign_bus(k) = f_bus;
        arg_side(k) = "to";
        foreign_area(k) = area_by_bus(f_bus);
        p_arg_to_foreign_mw(k) = pf.branch(bi, PT);
        q_arg_to_foreign_mvar(k) = pf.branch(bi, QT);
    else
        arg_bus(k) = f_bus;
        foreign_bus(k) = t_bus;
        arg_side(k) = "from";
        foreign_area(k) = area_by_bus(t_bus);
        p_arg_to_foreign_mw(k) = pf.branch(bi, PF);
        q_arg_to_foreign_mvar(k) = pf.branch(bi, QF);
    end
    ckt(k) = string(strtrim(br_meta.ckt{r}));
    country(k) = foreign_area_name(cfg, foreign_area(k));
    interface(k) = sprintf('Argentina-%s', country(k));
    status(k) = br_meta.status(r) ~= 0 && pf.branch(bi, BR_STATUS) ~= 0;
    if status(k)
        p_mw(k) = -p_arg_to_foreign_mw(k);
        q_mvar(k) = -q_arg_to_foreign_mvar(k);
    end
    source_element(k) = sprintf('AC branch raw_row=%d branch_idx=%d %g-%g ckt=%s', ...
        r, bi, f_bus, t_bus, ckt(k));
    sign_convention(k) = string(cfg.sign_convention);
end

tbl = table(interface, country, arg_bus, foreign_bus, foreign_area, ckt, ...
    status, p_mw, q_mvar, p_arg_to_foreign_mw, q_arg_to_foreign_mvar, ...
    source_element, raw_branch_row, branch_idx, arg_side, sign_convention);
tbl = sortrows(tbl, {'country', 'arg_bus', 'foreign_bus', 'ckt'});
end

function areas = bus_area_vector(area_by_bus, buses)
areas = zeros(size(buses));
for k = 1:numel(buses)
    if isKey(area_by_bus, buses(k))
        areas(k) = area_by_bus(buses(k));
    else
        areas(k) = NaN;
    end
end
end

function name = foreign_area_name(cfg, area)
key = sprintf('%d', area);
if isKey(cfg.foreign_area_names, key)
    name = string(cfg.foreign_area_names(key));
else
    name = sprintf('area_%d', area);
end
end

function [mpc_red, boundary, masks] = build_reduced_case(mpc, boundary, cfg)
define_constants;
[GEN_BUS] = idx_gen;

keep_bus = ~ismember(mpc.bus(:, BUS_AREA), cfg.foreign_areas);
keep_branch = keep_bus(lookup_bus_rows(mpc, mpc.branch(:, F_BUS))) & ...
    keep_bus(lookup_bus_rows(mpc, mpc.branch(:, T_BUS)));
active_kept_branch = keep_branch & mpc.branch(:, BR_STATUS) ~= 0;
connected_bus = unique([mpc.branch(active_kept_branch, F_BUS); ...
    mpc.branch(active_kept_branch, T_BUS)]);
boundary_bus = unique(boundary.arg_bus);
keep_bus = keep_bus & (ismember(mpc.bus(:, BUS_I), connected_bus) | ...
    ismember(mpc.bus(:, BUS_I), boundary_bus));
keep_branch = keep_bus(lookup_bus_rows(mpc, mpc.branch(:, F_BUS))) & ...
    keep_bus(lookup_bus_rows(mpc, mpc.branch(:, T_BUS)));
keep_gen = keep_bus(lookup_bus_rows(mpc, mpc.gen(:, GEN_BUS)));
connected_keep_bus = keep_bus & ismember(mpc.bus(:, BUS_I), connected_bus);
boundary.reduced_bus_connected = ismember(boundary.arg_bus, connected_bus);

mpc_red = mpc;
mpc_red.bus = mpc.bus(keep_bus, :);
isolated_reduced = ~ismember(mpc_red.bus(:, BUS_I), connected_bus);
mpc_red.bus(isolated_reduced, BUS_TYPE) = NONE;
if isfield(mpc, 'bus_name')
    mpc_red.bus_name = mpc.bus_name(keep_bus, :);
end
mpc_red.branch = mpc.branch(keep_branch, :);
mpc_red.gen = mpc.gen(keep_gen, :);
keep_dcline = false(0, 1);
if isfield(mpc_red, 'dcline')
    keep_dcline = false(size(mpc.dcline, 1), 1);
    mpc_red = rmfield(mpc_red, 'dcline');
end
if isfield(mpc_red, 'userfcn')
    mpc_red = rmfield(mpc_red, 'userfcn');
end
if isfield(mpc_red, 'order')
    mpc_red = rmfield(mpc_red, 'order');
end
if cfg.keep_reduced_psse_metadata
    mpc_red.psse = subset_psse_metadata(mpc, keep_bus, keep_gen, ...
        find(keep_branch), keep_dcline);
    if ~isempty(cfg.force_reduced_actaps)
        mpc_red.psse.system.solver.ACTAPS = cfg.force_reduced_actaps;
    end
else
    mpc_red = rmfield(mpc_red, 'psse');
end

for k = 1:height(boundary)
    if ~boundary.status(k)
        continue;
    end
    ridx = find(mpc_red.bus(:, BUS_I) == boundary.arg_bus(k), 1);
    if isempty(ridx)
        error('build_sadi_pq_equivalent_case:missing_boundary_bus', ...
            'Boundary bus %g is not retained in reduced case.', boundary.arg_bus(k));
    end
    mpc_red.bus(ridx, PD) = mpc_red.bus(ridx, PD) - boundary.p_mw(k);
    mpc_red.bus(ridx, QD) = mpc_red.bus(ridx, QD) - boundary.q_mvar(k);
end

if ~any(mpc_red.bus(:, BUS_TYPE) == REF)
    pv = find(mpc_red.bus(:, BUS_TYPE) == PV, 1);
    if isempty(pv)
        pv = 1;
    end
    mpc_red.bus(pv, BUS_TYPE) = REF;
end

masks = struct();
masks.keep_bus = keep_bus;
masks.keep_branch = keep_branch;
masks.keep_gen = keep_gen;
masks.keep_dcline = keep_dcline;
masks.connected_bus = connected_keep_bus;
masks.removed_foreign_bus = mpc.bus(~keep_bus, BUS_I);
end

function rows = lookup_bus_rows(mpc, bus_numbers)
define_constants;
[tf, rows] = ismember(bus_numbers, mpc.bus(:, BUS_I));
if ~all(tf)
    missing = bus_numbers(~tf);
    error('build_sadi_pq_equivalent_case:missing_bus', ...
        'Cannot find bus %g in MATPOWER bus table.', missing(1));
end
end

function psse = subset_psse_metadata(mpc, keep_bus, keep_gen, internal_branch_idx, keep_dcline)
define_constants;
src = mpc.psse;
psse = struct();

if isfield(src, 'rev')
    psse.rev = src.rev;
end
if isfield(src, 'system')
    psse.system = src.system;
end

old_bus_to_new = zeros(size(mpc.bus, 1), 1);
old_bus_to_new(find(keep_bus)) = (1:nnz(keep_bus)).';
old_gen_to_new = zeros(size(mpc.gen, 1), 1);
old_gen_to_new(find(keep_gen)) = (1:nnz(keep_gen)).';
old_branch_to_new = zeros(size(mpc.branch, 1), 1);
old_branch_to_new(internal_branch_idx) = (1:numel(internal_branch_idx)).';
old_dcline_to_new = zeros(numel(keep_dcline), 1);
old_dcline_to_new(find(keep_dcline)) = (1:nnz(keep_dcline)).';
retained_bus = mpc.bus(keep_bus, BUS_I);

if isfield(src, 'swshunt') && isfield(src.swshunt, 'num') && ~isempty(src.swshunt.num)
    i_col = psse_col(src.swshunt, 'I');
    keep = i_col > 0 & ismember(src.swshunt.num(:, i_col), retained_bus);
    if any(keep)
        psse.swshunt = subset_rows(src.swshunt, find(keep));
    end
end

if isfield(src, 'branch') && isfield(src.branch, 'branch_idx')
    idx = src.branch.branch_idx(:);
    keep = idx > 0 & idx <= numel(old_branch_to_new) & old_branch_to_new(idx) > 0;
    if any(keep)
        br = subset_rows(src.branch, find(keep));
        br.branch_idx = remap_positive(br.branch_idx, old_branch_to_new);
        br.f_bus_idx = remap_positive(br.f_bus_idx, old_bus_to_new);
        br.t_bus_idx = remap_positive(br.t_bus_idx, old_bus_to_new);
        psse.branch = br;
    end
end

if isfield(src, 'genq') && isfield(src.genq, 'num') && ~isempty(src.genq.num) && ...
        isfield(src.genq, 'gen_idx')
    idx = src.genq.gen_idx(:);
    keep = idx > 0 & idx <= numel(old_gen_to_new) & old_gen_to_new(idx) > 0;
    rows = find(keep);
    if ~isempty(rows)
        [~, ord] = sort(idx(rows));
        gq = subset_rows(src.genq, rows(ord));
        gq.gen_idx = remap_positive(gq.gen_idx, old_gen_to_new);
        if isfield(gq, 'bus_idx')
            gq.bus_idx = remap_positive(gq.bus_idx, old_bus_to_new);
        end
        if isfield(gq, 'reg_bus_idx')
            gq.reg_bus_idx = remap_positive(gq.reg_bus_idx, old_bus_to_new);
        end
        psse.genq = gq;
    end
end

if isfield(src, 'swdev') && isfield(src.swdev, 'num') && ~isempty(src.swdev.num) && ...
        isfield(src.swdev, 'branch_idx')
    br = src.swdev.branch_idx(:);
    fb = src.swdev.f_bus_idx(:);
    tb = src.swdev.t_bus_idx(:);
    keep = br > 0 & br <= numel(old_branch_to_new) & old_branch_to_new(br) > 0 & ...
        fb > 0 & fb <= numel(old_bus_to_new) & old_bus_to_new(fb) > 0 & ...
        tb > 0 & tb <= numel(old_bus_to_new) & old_bus_to_new(tb) > 0;
    if any(keep)
        sw = subset_rows(src.swdev, find(keep));
        sw.branch_idx = remap_positive(sw.branch_idx, old_branch_to_new);
        sw.f_bus_idx = remap_positive(sw.f_bus_idx, old_bus_to_new);
        sw.t_bus_idx = remap_positive(sw.t_bus_idx, old_bus_to_new);
        psse.swdev = sw;
    end
end

if isfield(src, 'xfmr')
    xf = struct();
    if isfield(src.xfmr, 'two')
        xf.two = subset_xfmr_two(src.xfmr.two, old_branch_to_new);
    end
    if isfield(src.xfmr, 'three')
        xf.three = subset_xfmr_three(src.xfmr.three, old_branch_to_new);
    end
    if isfield(xf, 'two') || isfield(xf, 'three')
        if ~isfield(xf, 'two')
            xf.two = empty_xfmr_part(src.xfmr.three);
        end
        if ~isfield(xf, 'three')
            xf.three = empty_xfmr_part(src.xfmr.two);
        end
        psse.xfmr = xf;
    end
end

if isfield(src, 'impcor')
    psse.impcor = src.impcor;
end

if isfield(src, 'twodc') && isfield(src.twodc, 'num') && ~isempty(src.twodc.num) && ...
        isfield(src.twodc, 'dcline_idx') && ~isempty(keep_dcline)
    idx = src.twodc.dcline_idx(:);
    keep = idx > 0 & idx <= numel(old_dcline_to_new) & old_dcline_to_new(idx) > 0;
    if any(keep)
        tw = subset_rows(src.twodc, find(keep));
        tw.dcline_idx = remap_positive(tw.dcline_idx, old_dcline_to_new);
        if isfield(tw, 'rect_bus_idx')
            tw.rect_bus_idx = remap_positive(tw.rect_bus_idx, old_bus_to_new);
        end
        if isfield(tw, 'inv_bus_idx')
            tw.inv_bus_idx = remap_positive(tw.inv_bus_idx, old_bus_to_new);
        end
        psse.twodc = tw;
    end
end

if isfield(src, 'facts') && isfield(src.facts, 'num') && ~isempty(src.facts.num)
    if isfield(src.facts, 'bus_idx')
        idx = src.facts.bus_idx(:);
        keep = idx > 0 & idx <= numel(old_bus_to_new) & old_bus_to_new(idx) > 0;
    else
        i_col = psse_col(src.facts, 'I');
        keep = i_col > 0 & ismember(src.facts.num(:, i_col), retained_bus);
    end
    if any(keep)
        fx = subset_rows(src.facts, find(keep));
        if isfield(fx, 'bus_idx')
            fx.bus_idx = remap_positive(fx.bus_idx, old_bus_to_new);
        end
        if isfield(fx, 'reg_bus_idx')
            fx.reg_bus_idx = remap_positive(fx.reg_bus_idx, old_bus_to_new);
        end
        psse.facts = fx;
    end
end
end

function out = subset_xfmr_two(src, old_branch_to_new)
out = subset_rows(src, []);
if ~isfield(src, 'branch_idx') || isempty(src.branch_idx)
    return;
end
idx = src.branch_idx(:);
keep = idx > 0 & idx <= numel(old_branch_to_new) & old_branch_to_new(idx) > 0;
if any(keep)
    out = subset_rows(src, find(keep));
    out.branch_idx = remap_positive(out.branch_idx, old_branch_to_new);
end
end

function out = subset_xfmr_three(src, old_branch_to_new)
out = subset_rows(src, []);
if ~isfield(src, 'branch_idx') || isempty(src.branch_idx)
    return;
end
remapped = remap_positive(src.branch_idx, old_branch_to_new);
keep = any(remapped > 0, 2);
if any(keep)
    out = subset_rows(src, find(keep));
    out.branch_idx = remapped(keep, :);
end
end

function out = empty_xfmr_part(src)
out = subset_rows(src, []);
if isfield(out, 'branch_idx')
    out.branch_idx = zeros(0, size(src.branch_idx, 2));
end
end

function out = subset_rows(src, rows)
out = src;
fields = fieldnames(src);
if isfield(src, 'num')
    n = size(src.num, 1);
elseif isfield(src, 'branch_idx')
    n = size(src.branch_idx, 1);
else
    n = 0;
end
for k = 1:numel(fields)
    name = fields{k};
    val = src.(name);
    if (isnumeric(val) || islogical(val) || iscell(val) || isstring(val)) && ...
            ~isempty(val) && size(val, 1) == n
        idx = repmat({':'}, 1, ndims(val));
        idx{1} = rows;
        out.(name) = val(idx{:});
    end
end
end

function col = psse_col(s, name)
col = 0;
if isfield(s, 'col') && isfield(s.col, lower(name))
    col = s.col.(lower(name));
elseif isfield(s, 'colnames')
    found = find(strcmpi(s.colnames, name), 1);
    if ~isempty(found)
        col = found;
    end
end
end

function out = remap_positive(val, map)
out = zeros(size(val));
valid = val > 0 & val <= numel(map);
out(valid) = map(val(valid));
end

function [mpc, mask] = apply_reduced_ultc_study_mask(mpc, full_mask)
st = mp.psse_xfmr_states(mpc);
locked = false(st.n, 1);
if isfield(mpc.psse.xfmr, 'control_locked_out') && ...
        numel(mpc.psse.xfmr.control_locked_out) == st.n
    locked = logical(mpc.psse.xfmr.control_locked_out(:));
end

rows = zeros(0, 1);
for k = 1:numel(full_mask.rows)
    hit = find(st.kind == full_mask.kind(k) & ...
        st.raw_row == full_mask.raw_row(k) & ...
        st.winding == full_mask.winding(k));
    rows = [rows; hit(:)]; %#ok<AGROW>
end
rows = unique(rows);
locked(rows) = true;

mpc.psse.xfmr.control_locked_out = locked;
mpc.psse.xfmr.control_study_locked_rows = rows;
mpc.psse.xfmr.control_study_lock_label = ...
    'TRANSENER V26p 3-winding star-equivalent ULTC study mask mapped to SADI reduction';

mask = struct();
mask.rows = rows;
mask.count = numel(rows);
mask.source_count = numel(full_mask.rows);
mask.label = mpc.psse.xfmr.control_study_lock_label;
mask.kind = st.kind(rows);
mask.raw_row = st.raw_row(rows);
mask.winding = st.winding(rows);
mask.cw = st.cw(rows);
mask.cod = st.cod(rows);
mask.cont = st.cont(rows);
mask.branch_ext = st.branch_ext(rows);
mask.reg_bus_idx = st.reg_bus_idx(rows);
end

function validation = validate_reduced_case(mpc_ref, pf_red, masks, boundary, cfg)
define_constants;

compare_mask = masks.keep_bus & masks.connected_bus;
common_bus = mpc_ref.bus(compare_mask, BUS_I);
[tf, loc_red] = ismember(common_bus, pf_red.bus(:, BUS_I));
common_bus = common_bus(tf);
loc_ref = find(compare_mask);
loc_ref = loc_ref(tf);
loc_red = loc_red(tf);

dvm = pf_red.bus(loc_red, VM) - mpc_ref.bus(loc_ref, VM);
dva = angle_diff_deg(pf_red.bus(loc_red, VA), mpc_ref.bus(loc_ref, VA));
area = mpc_ref.bus(loc_ref, BUS_AREA);

validation.bus = table(common_bus, area, mpc_ref.bus(loc_ref, VM), ...
    pf_red.bus(loc_red, VM), dvm, mpc_ref.bus(loc_ref, VA), ...
    pf_red.bus(loc_red, VA), dva, ...
    'VariableNames', {'bus', 'area', 'vm_full_pu', 'vm_sadi_pu', ...
    'dvm_pu', 'va_full_deg', 'va_sadi_deg', 'dva_deg'});
validation.bus = sortrows(validation.bus, 'bus');

active = boundary.status;
if any(active)
    validation.country_totals = groupsummary(boundary(active, :), ...
        'country', 'sum', {'p_mw', 'q_mvar'});
else
    validation.country_totals = table();
end

validation.summary = table( ...
    pf_red.success, ...
    max(abs(dvm)), ...
    sqrt(mean(dvm .^ 2)), ...
    max(abs(dva)), ...
    sqrt(mean(dva .^ 2)), ...
    sum(mpc_ref.bus(compare_mask, PD)), ...
    sum(pf_red.bus(:, PD)), ...
    sum(mpc_ref.bus(compare_mask, QD)), ...
    sum(pf_red.bus(:, QD)), ...
    nnz(masks.keep_bus), ...
    nnz(compare_mask), ...
    nnz(masks.keep_bus & ~masks.connected_bus), ...
    nnz(~masks.keep_bus), ...
    any(ismember(pf_red.bus(:, BUS_AREA), cfg.foreign_areas)), ...
    'VariableNames', {'runpf_success', 'max_abs_dvm_pu', 'rms_dvm_pu', ...
    'max_abs_dva_deg', 'rms_dva_deg', 'full_retained_pd_mw', ...
    'sadi_pd_mw', 'full_retained_qd_mvar', 'sadi_qd_mvar', ...
    'retained_bus_count', 'connected_retained_bus_count', ...
    'isolated_retained_bus_count', 'removed_bus_count', ...
    'foreign_area_bus_retained'});
end

function d = angle_diff_deg(a, b)
d = mod(a - b + 180, 360) - 180;
end

function write_outputs(out_dir, boundary, validation, results, case_file)
writetable(boundary, fullfile(out_dir, 'boundary_pq_equivalents.csv'));
writetable(validation.bus, fullfile(out_dir, 'validation_bus_voltage.csv'));
writetable(validation.summary, fullfile(out_dir, 'validation_summary.csv'));
if ~isempty(validation.country_totals)
    writetable(validation.country_totals, fullfile(out_dir, 'boundary_country_totals.csv'));
end
write_report(fullfile(out_dir, 'sadi_pq_equivalent_report.md'), ...
    boundary, validation, results, case_file);
end

function write_report(report_file, boundary, validation, results, case_file)
fid = fopen(report_file, 'w');
if fid < 0
    error('build_sadi_pq_equivalent_case:report_open_failed', ...
        'Cannot open report for writing: %s', report_file);
end
cleanup = onCleanup(@() fclose(fid));

fprintf(fid, '# SADI fixed P/Q border equivalent\n\n');
fprintf(fid, '- RAW: `%s`\n', results.raw_file);
fprintf(fid, '- Mode: `%s`\n', results.config.border_mode);
fprintf(fid, '- Reference source: `%s`\n', results.config.reference_source);
fprintf(fid, '- Reduced solver: `%s`\n', results.config.reduced_solver);
if ~isempty(results.config.force_reduced_actaps)
    fprintf(fid, '- Reduced forced ACTAPS: `%g`\n', ...
        results.config.force_reduced_actaps);
end
fprintf(fid, '- Reduced case: `%s`\n', case_file);
if isempty(results.full_runpf_psse)
    fprintf(fid, '- Full baseline: RAW embedded `VM/VA` snapshot, no full PF rerun\n');
else
    fprintf(fid, '- Full baseline: `runpf_psse`, success `%d`\n', ...
        results.full_runpf_psse.success);
end
fprintf(fid, '- Reduced solve: `%s`, success `%d`\n\n', ...
    results.config.reduced_solver, results.runpf_sadi.success);

fprintf(fid, '## Sign convention\n\n');
fprintf(fid, '%s.\n\n', results.config.sign_convention);

fprintf(fid, '## Collapsed interfaces\n\n');
fprintf(fid, '| Interface | Argentine bus | Foreign bus | Circuit | Status | Connected | P injection MW | Q injection MVAr |\n');
fprintf(fid, '|---|---:|---:|---:|---:|---:|---:|---:|\n');
for k = 1:height(boundary)
    fprintf(fid, '| %s | %.0f | %.0f | %s | %d | %d | %.6f | %.6f |\n', ...
        boundary.interface(k), boundary.arg_bus(k), boundary.foreign_bus(k), ...
        boundary.ckt(k), boundary.status(k), boundary.reduced_bus_connected(k), ...
        boundary.p_mw(k), boundary.q_mvar(k));
end
fprintf(fid, '\nInactive ties are listed with zero fixed injection.\n\n');

fprintf(fid, '## Country totals\n\n');
if ~isempty(validation.country_totals)
    fprintf(fid, '| Country | Active rows | P injection MW | Q injection MVAr |\n');
    fprintf(fid, '|---|---:|---:|---:|\n');
    for k = 1:height(validation.country_totals)
        fprintf(fid, '| %s | %d | %.6f | %.6f |\n', ...
            validation.country_totals.country(k), ...
            validation.country_totals.GroupCount(k), ...
            validation.country_totals.sum_p_mw(k), ...
            validation.country_totals.sum_q_mvar(k));
    end
else
    fprintf(fid, 'No active boundary rows were found.\n');
end
fprintf(fid, '\n');

fprintf(fid, '## Validation\n\n');
s = validation.summary;
fprintf(fid, '- Retained buses: `%d`\n', s.retained_bus_count);
fprintf(fid, '- Connected retained buses compared: `%d`\n', ...
    s.connected_retained_bus_count);
fprintf(fid, '- Isolated retained boundary/audit buses: `%d`\n', ...
    s.isolated_retained_bus_count);
fprintf(fid, '- Removed buses outside the solvable SADI island: `%d`\n', ...
    s.removed_bus_count);
fprintf(fid, '- Foreign-area buses retained: `%d`\n', s.foreign_area_bus_retained);
fprintf(fid, '- Max/RMS VM delta: `%.9g / %.9g pu`\n', ...
    s.max_abs_dvm_pu, s.rms_dvm_pu);
fprintf(fid, '- Max/RMS VA delta: `%.9g / %.9g deg`\n', ...
    s.max_abs_dva_deg, s.rms_dva_deg);
fprintf(fid, '- Full retained PD/QD: `%.6f MW / %.6f MVAr`\n', ...
    s.full_retained_pd_mw, s.full_retained_qd_mvar);
fprintf(fid, '- SADI reduced PD/QD after equivalents: `%.6f MW / %.6f MVAr`\n\n', ...
    s.sadi_pd_mw, s.sadi_qd_mvar);

fprintf(fid, '## Fixed-P/Q limitation\n\n');
fprintf(fid, ['This reduction intentionally removes foreign-side generator Q response, ' ...
    'switched shunts, transformer tap regulation, HVDC converter controls, ' ...
    'and foreign network voltage stiffness. The Brazil-side HVDC equipment is ' ...
    'not retained as HVDC; its base-case effect is represented only through ' ...
    'the solved fixed P/Q exchange on the Argentine-facing AC border ties.\n\n']);

fprintf(fid, '## Artifacts\n\n');
fprintf(fid, '- `boundary_pq_equivalents.csv`\n');
fprintf(fid, '- `boundary_country_totals.csv`\n');
fprintf(fid, '- `validation_bus_voltage.csv`\n');
fprintf(fid, '- `validation_summary.csv`\n');
fprintf(fid, '- `case_sadi_pq_equivalent.m`\n');
fprintf(fid, '- `sadi_pq_equivalent_results.mat`\n');
end
