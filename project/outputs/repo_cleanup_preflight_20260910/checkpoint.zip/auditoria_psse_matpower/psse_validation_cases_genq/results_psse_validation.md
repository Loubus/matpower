# Resultados PSS/E - GENERATOR DATA, limites Q y regulacion remota

Logs corregidos recibidos el 2026-05-20 desde PSS/E Xplore 36.1.0. Todos
fueron corridos con `FNSL`, `VARLIM=1`, `ACTAPS=0`, `AREAIN=0`, `PHSHFT=0`,
`DCTAPS=0`, `SWSHNT=0`, `FLATST=0`, `NONDIV=0`.

## Estado de las corridas

| Caso | Estado PSS/E | Iter. | Max mismatch MVA | Total mismatch MVA | Uso documental |
|---|---:|---:|---:|---:|---|
| `psse_genq_3bus_local_inband` | tolerancia alcanzada | 3 | 0.00 | 0.00 | target PSS/E |
| `psse_genq_3bus_qmax` | tolerancia alcanzada | 3 | 0.04 | 0.06 | target PSS/E |
| `psse_genq_3bus_qmin` | tolerancia alcanzada | 4 | 0.06 | 0.09 | target PSS/E |
| `psse_genq_3bus_qmin_qmax_zero` | tolerancia alcanzada | 5 | 0.04 | 0.04 | target PSS/E |
| `psse_genq_3bus_slack_q_limit` | tolerancia alcanzada | 3 | 0.00 | 0.00 | target PSS/E |
| `psse_genq_4bus_remote_single` | tolerancia alcanzada | 18 | 0.07 | 0.14 | target PSS/E |
| `psse_genq_5bus_remote_group` | tolerancia alcanzada | 5 | 0.09 | 0.17 | target PSS/E |
| `psse_genq_5bus_remote_group_all_limited` | tolerancia alcanzada | 5 | 0.00 | 0.00 | target PSS/E |
| `psse_genq_5bus_remote_group_one_limited` | tolerancia alcanzada | 19 | 0.10 | 0.19 | target PSS/E |

## Validacion MATPOWER

La corrida final usa `runpf_psse` como camino opt-in y mantiene `runpf`
estandar sin cambios. Se ejecutaron `t_psse(0)` y `t_mpxt_psse(0)`, ademas de
la corrida explicita `psse2mpc + runpf + runpf_psse` para los nueve RAW de
esta carpeta.

### Modelo final implementado

El modelo `runpf_psse` cubre `GENERATOR DATA` y el complemento `PQBRAK`
necesario para el caso de baja tension `QMAX=QMIN=0`:

- usar el camino opt-in `runpf_psse`, sin cambiar el comportamiento de
  `runpf`;
- usar `QT/QB` como limites de reactiva, `VS` como consigna, `IREG` como bus
  regulado y `RMPCT` como participacion de grupos remotos;
- mantener como PV a los generadores que regulan dentro de sus limites;
- convertir cualitativamente a limitado/PQ al generador no swing que llegue a
  `QMAX`, `QMIN` o `QMAX=QMIN=0`, fijando `QG` en el limite;
- redistribuir la regulacion remota entre los generadores libres del grupo
  segun `RMPCT`;
- dejar el swing como swing aun cuando su `QG` exceda los limites declarados,
  reproduciendo el comportamiento observado en PSS/E;
- cuando todos los reguladores quedan limitados, aceptar que el bus regulado
  quede fuera de `VS` y comparar contra `VACT` PSS/E;
- aplicar la caracteristica PSS/E `PQBRAK` cuando una carga de potencia
  constante cae por debajo del umbral de tension, como ocurre en
  `3bus_qmin_qmax_zero`;
- no aplicar `PQBRAK` en casos con `TWO-TERMINAL DC DATA`, manteniendo separado
  el alcance LCC.

### Criterios de tolerancia

Los tests usan estos criterios:

- `success = 1` y solucion numericamente estable en la corrida MATPOWER;
- coincidencia cualitativa exacta del estado: libre, `QMAX`, `QMIN`,
  `QMAX=QMIN=0` o swing sin enforcement de Q;
- `|QG_MATPOWER - QG_PSSE| <= 0.5 MVAr` por generador objetivo;
- `|VM_MATPOWER - VM_PSSE| <= 5e-4 pu` en buses relevantes;
- `|VA_MATPOWER - VA_PSSE| <= 0,15 deg`;
- para grupos remotos libres, reparto de reactiva compatible con `RMPCT` dentro
  de `0.5 MVAr` por generador;
- el caso swing se aprueba por equivalencia con PSS/E, no por respetar
  `QMAX/QMIN` del swing.

### Casos cubiertos

| Caso | Aspecto GENERATOR DATA aislado | Comportamiento PSS/E a reproducir |
|---|---|---|
| `psse_genq_3bus_local_inband` | Regulacion local dentro de limites | PV libre mantiene `VS` local |
| `psse_genq_3bus_qmax` | Limite superior de Q | Generador no swing queda en `QMAX` |
| `psse_genq_3bus_qmin` | Limite inferior de Q | Generador no swing queda en `QMIN` |
| `psse_genq_3bus_qmin_qmax_zero` | Limite degenerado | Generador no swing queda con `QG=0` |
| `psse_genq_3bus_slack_q_limit` | Swing con limites Q estrechos | Swing no fuerza sus limites de Q |
| `psse_genq_4bus_remote_single` | Regulacion remota individual | Generador libre regula `IREG` |
| `psse_genq_5bus_remote_group` | Regulacion remota grupal libre | Reparto `QG` segun `RMPCT=60/40` |
| `psse_genq_5bus_remote_group_one_limited` | Grupo remoto con un limitado | Limitado queda en `QMAX`; libre completa regulacion |
| `psse_genq_5bus_remote_group_all_limited` | Grupo remoto todo limitado | Todos quedan en `QMAX`; `VACT` no llega a `VS` |

## Targets de generadores extraidos

| Caso | Bus | Nombre | Code | PGEN | QGEN | QMIN | QMAX | VSCHED | VACT | PCT Q | Bus regulado |
|---|---:|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| `3bus_local_inband` | 1 | `SLACK` | 3 | 22.7 | -31.9 | -300.0 | 300.0 | 1.0000 | 1.0000 | 100.0 | 1 |
| `3bus_local_inband` | 2 | `GEN_LOCAL` | 2 | 80.0 | 88.8 | -100.0 | 100.0 | 1.0300 | 1.0300 | 100.0 | 2 |
| `3bus_qmax` | 1 | `SLACK` | 3 | 0.5 | 32.9 | -300.0 | 300.0 | 1.0000 | 1.0000 | 100.0 | 1 |
| `3bus_qmax` | 2 | `GEN_QMAX` | -2 | 80.0 | 15.0 | -100.0 | 15.0 | 1.0500 | 0.9803 | 100.0 | 2 |
| `3bus_qmin` | 1 | `SLACK` | 3 | 3.3 | -77.7 | -300.0 | 300.0 | 1.0000 | 1.0000 | 100.0 | 1 |
| `3bus_qmin` | 2 | `GEN_QMIN` | -2 | 80.0 | -10.0 | -10.0 | 100.0 | 1.0000 | 1.0774 | 100.0 | 2 |
| `3bus_qmin_qmax_zero` | 1 | `SLACK` | 3 | 27.1 | 122.9 | -300.0 | 300.0 | 1.0000 | 1.0000 | 100.0 | 1 |
| `3bus_qmin_qmax_zero` | 2 | `GEN_ZEROQ` | -2 | 80.0 | 0.0 | 0.0 | 0.0 | 1.0400 | 0.6759 | 100.0 | 3 |
| `3bus_slack_q_limit` | 1 | `SLACK_LIMIT` | 3 | 81.3 | 77.7 | -20.0 | 20.0 | 1.0000 | 1.0000 | 100.0 | 1 |
| `4bus_remote_single` | 1 | `SLACK` | 3 | 1.7 | -139.3 | -300.0 | 300.0 | 1.0000 | 1.0000 | 100.0 | 1 |
| `4bus_remote_single` | 2 | `GEN_REMOTE` | 2 | 80.0 | 196.7 | -300.0 | 300.0 | 1.0200 | 1.0200 | 100.0 | 4 |
| `5bus_remote_group` | 1 | `SLACK` | 3 | -57.1 | -270.7 | -400.0 | 400.0 | 1.0000 | 1.0000 | 100.0 | 1 |
| `5bus_remote_group` | 2 | `GEN_A` | 2 | 80.0 | 209.9 | -300.0 | 300.0 | 1.0200 | 1.0200 | 60.0 | 5 |
| `5bus_remote_group` | 3 | `GEN_B` | 2 | 80.0 | 139.9 | -300.0 | 300.0 | 1.0200 | 1.0200 | 40.0 | 5 |
| `5bus_remote_group_all_limited` | 1 | `SLACK` | 3 | -58.1 | 65.1 | -400.0 | 400.0 | 1.0000 | 1.0000 | 100.0 | 1 |
| `5bus_remote_group_all_limited` | 2 | `GEN_A_LIM` | -2 | 80.0 | 20.0 | -200.0 | 20.0 | 1.0600 | 0.8929 | 60.0 | 5 |
| `5bus_remote_group_all_limited` | 3 | `GEN_B_LIM` | -2 | 80.0 | 25.0 | -200.0 | 25.0 | 1.0600 | 0.8929 | 40.0 | 5 |
| `5bus_remote_group_one_limited` | 1 | `SLACK` | 3 | -56.1 | -271.3 | -400.0 | 400.0 | 1.0000 | 1.0000 | 100.0 | 1 |
| `5bus_remote_group_one_limited` | 2 | `GEN_A_LIM` | -2 | 80.0 | 20.0 | -200.0 | 20.0 | 1.0200 | 1.0200 | 60.0 | 5 |
| `5bus_remote_group_one_limited` | 3 | `GEN_B_FREE` | 2 | 80.0 | 339.5 | -400.0 | 400.0 | 1.0200 | 1.0200 | 40.0 | 5 |

## Observaciones de comportamiento PSS/E

- PSS/E marca con `CODE=-2` los generadores que quedaron limitados por
  reactiva; en estos logs coinciden con `QGEN=QMAX`, `QGEN=QMIN` o
  `QMAX=QMIN=0`.
- El swing no respeta sus limites de Q en esta corrida: `SLACK_LIMIT` queda en
  `QGEN=77.7` aunque el RAW tiene `QMAX=20.0`; PSS/E lo reporta con marca
  `H` en el flujo, pero mantiene el bus como swing.
- Cuando un generador regulador queda limitado, PSS/E conserva `VSCHED` y
  reporta `VACT` como la tension real del bus regulado, aunque no llegue al
  objetivo.
- En regulacion remota grupal libre, PSS/E reparte `QGEN` segun `RMPCT=60/40`:
  `209.9/139.9`, que preserva la proporcion `60/40` sobre el total de
  `349.8 MVAr`.
- El log retuneado de `one_limited` aisla el caso buscado y converge:
  `GEN_A_LIM` queda en `QMAX=20` con `CODE=-2`, mientras `GEN_B_FREE` queda en
  `CODE=2` con `QGEN=339.5`, por debajo de su `QMAX=400`. El bus remoto queda
  en `VACT=1.0200`.

## Tabla PSS/E vs MATPOWER

| Caso | Regulador objetivo | Estado PSS/E | QGEN PSS/E MVAr | VACT/VREG PSS/E pu | MATPOWER success | Estado MATPOWER | QGEN MATPOWER MVAr | VREG MATPOWER pu | dQ max MVAr | dV max pu | Veredicto |
|---|---|---|---:|---:|---|---|---|---|---|---|---|
| `3bus_local_inband` | `GEN_LOCAL` | libre `CODE=2` | 88.8 | 1.0300 | 1 | libre `CODE=2` | 88.847 | 1.0300 | 0.047 | 0.0000 | OK |
| `3bus_qmax` | `GEN_QMAX` | limitado `CODE=-2`, `QMAX` | 15.0 | 0.9803 | 1 | limitado `CODE=-2`, `QMAX` | 15.000 | 0.9802 | 0.000 | 0.0001 | OK |
| `3bus_qmin` | `GEN_QMIN` | limitado `CODE=-2`, `QMIN` | -10.0 | 1.0774 | 1 | limitado `CODE=-2`, `QMIN` | -10.000 | 1.0773 | 0.000 | 0.0001 | OK |
| `3bus_qmin_qmax_zero` | `GEN_ZEROQ` | limitado `CODE=-2`, `QMAX=QMIN=0` | 0.0 | 0.6759 | 1 | limitado `CODE=-2`, `QMAX=QMIN=0` | 0.000 | 0.6757 | 0.000 | 0.0002 | OK |
| `3bus_slack_q_limit` | `SLACK_LIMIT` | swing `CODE=3`, Q fuera de limites | 77.7 | 1.0000 | 1 | swing `CODE=3`, Q fuera de limites | 77.697 | 1.0000 | 0.003 | 0.0000 | OK |
| `4bus_remote_single` | `GEN_REMOTE` | libre `CODE=2`, remoto | 196.7 | 1.0200 | 1 | libre `CODE=2`, remoto | 196.837 | 1.0200 | 0.137 | 0.0000 | OK |
| `5bus_remote_group` | `GEN_A` / `GEN_B` | libres `CODE=2/2`, remoto grupal | 209.9 / 139.9 | 1.0200 | 1 | libres `CODE=2/2`, remoto grupal | 210.109 / 140.039 | 1.0200 | 0.209 | 0.0000 | OK |
| `5bus_remote_group_one_limited` | `GEN_A_LIM` / `GEN_B_FREE` | `CODE=-2/2`, un limitado | 20.0 / 339.5 | 1.0200 | 1 | `CODE=-2/2`, un limitado | 20.000 / 339.094 | 1.0200 | 0.406 | 0.0000 | OK |
| `5bus_remote_group_all_limited` | `GEN_A_LIM` / `GEN_B_LIM` | `CODE=-2/-2`, todos limitados | 20.0 / 25.0 | 0.8929 | 1 | `CODE=-2/-2`, todos limitados | 20.000 / 25.000 | 0.8929 | 0.000 | 0.0000 | OK |

## RAW retuneados despues de leer estos logs

El RAW retuneado de `psse_genq_5bus_remote_group_one_limited.raw` queda
respaldado por el log PSS/E de las 19:44: PSS/E alcanza tolerancia en 19
iteraciones, con `MAX. MISMATCH = 0.10 MVA` y `TOTAL MISMATCH = 0.19 MVA`. El
retuneo uso las tensiones, angulos y `QG` del estado casi resuelto anterior
como condicion inicial (`FLATST=0`), sin cambiar la red, la carga, `VS`,
`RMPCT`, limites Q ni `MXTPSS=20`.
