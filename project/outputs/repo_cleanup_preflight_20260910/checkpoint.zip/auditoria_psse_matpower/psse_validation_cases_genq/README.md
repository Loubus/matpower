# Casos chicos PSS/E - GENERATOR DATA, limites Q y regulacion remota

Objetivo: obtener referencias PSS/E reproducibles para implementar en
`runpf_psse` el tratamiento de limites de reactiva y regulacion remota de
generadores sin depender del RAW grande.

Todos los casos tienen menos de 50 buses y usan RAW Rev34. Estan pensados para
ejecutarse con PSS/E Xplore y guardar el log completo.

## Casos

| Caso | Regla PSS/E aislada |
|---|---|
| `psse_genq_3bus_local_inband.raw` | Generador PV regula su propio bus sin tocar limites Q |
| `psse_genq_3bus_qmax.raw` | Generador local llega a `QMAX` |
| `psse_genq_3bus_qmin.raw` | Generador local llega a `QMIN` por exceso capacitivo |
| `psse_genq_4bus_remote_single.raw` | Un generador regula un bus remoto con `IREG` |
| `psse_genq_5bus_remote_group.raw` | Dos generadores regulan el mismo bus remoto con `RMPCT=60/40` |
| `psse_genq_5bus_remote_group_one_limited.raw` | Un generador del grupo llega a `QMAX` y el otro queda libre |
| `psse_genq_5bus_remote_group_all_limited.raw` | Todos los generadores del grupo llegan a `QMAX` |
| `psse_genq_3bus_qmin_qmax_zero.raw` | Generador con `QMAX=QMIN=0` regulando bus remoto |
| `psse_genq_3bus_slack_q_limit.raw` | Swing con limites Q estrechos para observar si PSS/E los respeta |

## Salida PSS/E a guardar

Para cada archivo:

- log completo `.log`;
- tabla de buses con `BUS`, `NAME`, `BASKV`, `TYPE`, `VM`, `VA`;
- tabla de maquinas con `BUS`, `ID`, `ST`, `PGEN`, `QGEN`, `QMAX`, `QMIN`,
  `VSCHED`, `VACT`, `PCT Q`, bus regulado;
- mismatch final;
- cualquier mensaje de limite de reactiva, cambio PV/PQ o regulacion remota.

## Criterio de uso en MATPOWER

Los valores PSS/E resultantes de estos logs seran los targets numericos para
implementar y probar el control opt-in de generadores en `runpf_psse`.

## Modelo MATPOWER implementado

La validacion final de MATPOWER usa el camino opt-in `runpf_psse`:

- mantener el flujo normal de MATPOWER sin cambios; este alcance aplica solo al
  camino opt-in `runpf_psse`;
- leer de `GENERATOR DATA` los limites `QT/QB`, la consigna `VS`, el bus
  regulado `IREG` y la participacion `RMPCT`;
- controlar generadores PV que regulan su bus local o un bus remoto;
- repartir la regulacion remota grupal segun `RMPCT` mientras los generadores
  del grupo sigan libres;
- fijar `QG` en `QMAX` o `QMIN` cuando un generador no swing alcanza limite y
  retirarlo de la regulacion activa;
- conservar el caso swing como swing, incluyendo la observacion PSS/E de que no
  fuerza los limites de Q del swing;
- aceptar que el bus regulado no llegue a `VS` cuando todos los reguladores del
  grupo quedan limitados;
- aplicar la caracteristica PSS/E de carga de baja tension `PQBRAK` para el caso
  `QMAX=QMIN=0`, donde el bus regulado cae por debajo de `0,7 pu` y PSS/E
  reporta carga efectiva menor que la nominal;
- mantener `PQBRAK` fuera de casos con `TWO-TERMINAL DC DATA`, para no mezclar
  el cierre GENQ con el flujo LCC.

## Criterios de tolerancia usados

- `success = 1` en MATPOWER;
- mismo estado cualitativo que PSS/E: generador libre, limitado en `QMAX`,
  limitado en `QMIN`, o swing sin enforcement de limite Q;
- `|VM_MATPOWER - VM_PSSE| <= 5e-4 pu` en buses relevantes;
- `|VA_MATPOWER - VA_PSSE| <= 0,15 deg`;
- `|QG_MATPOWER - QG_PSSE| <= 0.5 MVAr` por generador objetivo, considerando
  que los logs PSS/E estan redondeados;
- para grupos remotos libres, reparto de `QG` compatible con `RMPCT` dentro de
  la misma tolerancia de reactiva.

## Estado de validacion

Los logs corregidos estan resumidos en `results_psse_validation.md`. Todos los
casos convergieron en PSS/E y ya tienen targets numericos utilizables para la
implementacion opt-in en `runpf_psse`.

La corrida MATPOWER final fue ejecutada con `t_psse(0)` y `t_mpxt_psse(0)`.
Ambas baterias pasan completas y la tabla PSS/E vs MATPOWER queda cerrada en
`results_psse_validation.md`.
